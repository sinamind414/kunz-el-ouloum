import { useEffect, useMemo, useRef, useState } from "react";
import { AXES, GOLDEN_SET, LOTS, METRICS, PRIO_META, SYSTEM_PROMPT, TICKETS, type Axe, type Prio } from "../data/morchidSpec";
import { Card, Pill } from "./ui";

const KICKER = "font-mono text-[10.5px] uppercase tracking-[0.22em]";
const KEY = "morchid-spec-dod-v1";

const AXE_META = AXES.reduce(
  (acc, a) => ({ ...acc, [a.id]: a }),
  {} as Record<Axe, (typeof AXES)[number]>,
);

function useReveal<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  const [ok, setOk] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setOk(true);
          io.disconnect();
        }
      },
      { threshold: 0.08, rootMargin: "0px 0px -30px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return { ref, ok };
}

function Revealer({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  const { ref, ok } = useReveal<HTMLDivElement>();
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: ok ? 1 : 0,
        transform: ok ? "none" : "translateY(16px)",
        transition: `opacity .6s cubic-bezier(.22,.61,.36,1) ${delay}ms, transform .6s cubic-bezier(.22,.61,.36,1) ${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

/* ─────────── en-tête : la triade comme ouverture caractéristique ─────────── */
const TRIADE = [
  { ar: "أُلاحِظ", fr: "J'observe", sub: "saisie des données — chiffres, variations, comparaisons", ban: "interdit : « لأنّ »", c: "#38bdf8" },
  { ar: "أَسْتَنْتِج", fr: "Je sais / Je déduis", sub: "interprétation — connaissance mobilisée + lien causal", must: "obligatoire : لأنّ / بسبب / يعود ذلك إلى", c: "#f59e0b" },
  { ar: "أَخْلُصُ إِلَى", fr: "Je conclus", sub: "réponse directe à la question, en une phrase", ban: "interdit : reformuler le bloc 1", c: "#10b981" },
];

function Triade() {
  const [active, setActive] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setActive((a) => (a + 1) % 3), 2600);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="grid gap-2.5 md:grid-cols-3">
      {TRIADE.map((b, i) => (
        <button
          key={b.ar}
          onMouseEnter={() => setActive(i)}
          onClick={() => setActive(i)}
          className={`relative overflow-hidden rounded-2xl border p-4 text-left transition-all duration-500 ${
            active === i ? "border-white/25 bg-white/[0.07]" : "border-white/10 bg-white/[0.025] hover:border-white/20"
          }`}
          style={active === i ? { boxShadow: `inset 0 1px 0 ${b.c}33, 0 8px 30px -18px ${b.c}` } : undefined}
        >
          <span
            className="absolute inset-x-0 top-0 h-[2px] origin-left transition-transform duration-700"
            style={{ background: b.c, transform: `scaleX(${active === i ? 1 : 0.12})` }}
          />
          <div className="flex items-baseline justify-between gap-2">
            <span className="font-mono text-[10px] uppercase tracking-[0.2em]" style={{ color: b.c }}>
              bloc {i + 1}
            </span>
            <span className="font-mono text-[10px] text-white/30">TRIADE</span>
          </div>
          <div className="mt-2 text-right text-[26px] font-semibold leading-none text-white" dir="rtl" lang="ar">
            {b.ar}
          </div>
          <div className="mt-1.5 text-[13px] font-semibold" style={{ color: b.c }}>
            {b.fr}
          </div>
          <p className="mt-1.5 text-[11.5px] leading-snug text-white/55">{b.sub}</p>
          <div
            className={`mt-3 h-0 overflow-hidden transition-all duration-500 ${active === i ? "h-8" : ""}`}
          >
            <span className="font-mono text-[10.5px]" style={{ color: b.must ? "#34d399" : "#f87171" }}>
              {b.must ?? b.ban}
            </span>
          </div>
        </button>
      ))}
    </div>
  );
}

/* ─────────── métriques baseline → cible ─────────── */
function MetricRow({ m }: { m: (typeof METRICS)[number] }) {
  const { ref, ok } = useReveal<HTMLDivElement>();
  const bad = m.baseline.includes("0 %") || m.baseline.includes("100 %") || m.baseline.includes("80 %") || m.baseline.includes("rejetée") || m.baseline.includes("7 erreurs");
  return (
    <div ref={ref} className="grid grid-cols-1 items-center gap-2 border-b border-white/[0.06] py-2.5 last:border-0 sm:grid-cols-[1.1fr_auto_auto]">
      <div className="min-w-0">
        <div className="truncate text-[12.5px] font-medium text-white/85">{m.name}</div>
        <div className="mt-0.5 font-mono text-[10px] text-white/35">{m.ticket}</div>
      </div>
      <div className="flex items-center gap-2 font-mono text-[11px]">
        <span className={`rounded px-1.5 py-0.5 ${bad ? "bg-red-500/10 text-red-300/80" : "bg-white/5 text-white/50"}`}>{m.baseline}</span>
        <span
          className="text-white/25 transition-all duration-700"
          style={{ opacity: ok ? 1 : 0, transform: ok ? "none" : "translateX(-6px)" }}
        >
          →
        </span>
        <span
          className="rounded bg-emerald-500/12 px-1.5 py-0.5 font-bold text-emerald-300 transition-all duration-700"
          style={{ opacity: ok ? 1 : 0, transform: ok ? "none" : "translateX(-6px)" }}
        >
          {m.target}
        </span>
      </div>
    </div>
  );
}

/* ─────────── ticket ─────────── */
function Ticket({ t, dodState, onDod }: { t: (typeof TICKETS)[number]; dodState: Record<number, boolean>; onDod: (i: number) => void }) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const axe = AXE_META[t.axe];
  const prio = PRIO_META[t.prio];
  const dodDone = Object.values(dodState).filter(Boolean).length;

  const copyDirectives = async () => {
    try {
      await navigator.clipboard.writeText(t.directives);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* presse-papiers indisponible */
    }
  };

  return (
    <div
      className={`overflow-hidden rounded-2xl border transition-all duration-300 ${
        open ? "border-white/25 bg-white/[0.055]" : "border-white/10 bg-white/[0.025] hover:border-white/20 hover:bg-white/[0.045]"
      }`}
    >
      <div className="relative flex items-stretch">
        <span className="w-[3px] shrink-0 transition-all duration-300" style={{ background: prio.color, opacity: open ? 1 : 0.55 }} />
        <button onClick={() => setOpen(!open)} className="group flex min-w-0 flex-1 items-start gap-3 p-4 text-left">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-[11px] font-bold tracking-tight text-white/55">[{t.id}]</span>
              <span className="rounded px-1.5 py-0.5 text-[9.5px] font-bold uppercase tracking-wider" style={{ background: `${prio.color}1c`, color: prio.color }}>
                {t.prio}
              </span>
              <span className="rounded px-1.5 py-0.5 text-[9.5px] font-medium" style={{ background: `${axe.color}18`, color: axe.color }}>
                {axe.label}
              </span>
            </div>
            <h3 className="mt-1.5 text-[14.5px] font-semibold leading-snug text-white">{t.title}</h3>
            <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-[10px] text-white/35">
              <span className="text-white/50">{t.composant}</span>
              <span className="hidden sm:inline">·</span>
              <span className="truncate">{t.auditRef}</span>
            </div>
          </div>
          <div className="flex shrink-0 flex-col items-end gap-2">
            <span className="font-mono text-[10px] tabular-nums text-white/40">
              DoD {dodDone}/{t.dod.length}
            </span>
            <span className={`text-white/25 transition-transform duration-300 ${open ? "rotate-180" : "group-hover:text-white/60"}`}>▾</span>
          </div>
        </button>
      </div>

      {open && (
        <div className="space-y-5 border-t border-white/10 bg-black/30 p-4 sm:p-5">
          {/* problème + preuve */}
          <div className="grid gap-4 lg:grid-cols-[1.15fr_1fr]">
            <div>
              <div className={`${KICKER} mb-1.5 text-red-300/80`}>Problème d'audit constaté</div>
              <p className="text-[13px] leading-relaxed text-white/80">{t.probleme}</p>
            </div>
            <div>
              <div className={`${KICKER} mb-1.5 text-white/35`}>Preuve (extrait littéral du dépôt)</div>
              <pre className="overflow-x-auto whitespace-pre-wrap break-words rounded-xl border border-red-500/20 bg-red-500/[0.05] p-3 font-mono text-[10.5px] leading-relaxed text-red-100/75">
                {t.preuve}
              </pre>
            </div>
          </div>

          {/* règle visée */}
          <div className="rounded-xl border border-emerald-500/25 bg-emerald-500/[0.06] p-4">
            <div className={`${KICKER} mb-1.5 text-emerald-300`}>Règle de comportement visée</div>
            <p className="text-[13px] leading-relaxed text-white/85">{t.regle}</p>
          </div>

          {/* directives */}
          <div>
            <div className="mb-1.5 flex items-center gap-2">
              <div className={`${KICKER} text-sky-300/85`}>Spécification d'ingénierie de prompt — system directives</div>
              <button
                onClick={copyDirectives}
                className="ml-auto rounded-lg border border-sky-400/30 bg-sky-400/[0.08] px-2.5 py-1 font-mono text-[10px] font-semibold text-sky-200 transition hover:bg-sky-400/15"
              >
                {copied ? "✓ copié" : "copier le bloc"}
              </button>
            </div>
            <pre className="max-h-[420px] overflow-auto whitespace-pre-wrap break-words rounded-xl border border-sky-500/20 bg-[#050b14] p-4 font-mono text-[11px] leading-[1.75] text-sky-100/80">
              {t.directives}
            </pre>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {t.variables.map((v) => (
                <span key={v} className="rounded bg-white/[0.05] px-1.5 py-0.5 font-mono text-[10px] text-white/50">
                  {v}
                </span>
              ))}
            </div>
          </div>

          {/* few-shot */}
          <div>
            <div className={`${KICKER} mb-2.5 text-amber-300/85`}>Exemple concret d'interaction — few-shot</div>
            <div className="space-y-2.5">
              <div className="flex justify-end">
                <div className="max-w-[88%] rounded-2xl rounded-br-sm bg-white/10 px-3.5 py-2.5 text-right" dir="rtl" lang="ar">
                  <div className={`${KICKER} mb-1 text-left text-white/30`} dir="ltr">
                    entrée élève
                  </div>
                  <span className="text-[13px] leading-relaxed text-white/90">{t.exemple.entree}</span>
                </div>
              </div>

              <div className="flex justify-start">
                <div className="max-w-[92%] rounded-2xl rounded-bl-sm bg-red-500/10 px-3.5 py-3 ring-1 ring-red-500/25">
                  <div className={`${KICKER} mb-1.5 text-red-300/90`}>✕ ancien comportement (mauvais)</div>
                  <span className="whitespace-pre-line text-[12.5px] leading-[1.85] text-white/60 line-through decoration-red-400/40" dir="auto">
                    {t.exemple.ancien}
                  </span>
                </div>
              </div>

              <div className="flex justify-start">
                <div className="max-w-[92%] rounded-2xl rounded-bl-sm bg-emerald-500/10 px-3.5 py-3 ring-1 ring-emerald-500/30">
                  <div className={`${KICKER} mb-1.5 text-emerald-300`}>✓ nouveau comportement intelligent (attendu)</div>
                  <span className="whitespace-pre-line text-[13px] leading-[1.95] text-white/90" dir="auto">
                    {t.exemple.nouveau}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* DoD */}
          <div className="rounded-xl border border-white/10 bg-white/[0.03] p-4">
            <div className="mb-2 flex items-center gap-2">
              <div className={`${KICKER} text-white/40`}>Critère de validation — definition of done</div>
              <span className="ml-auto font-mono text-[10px] text-white/35">
                {dodDone}/{t.dod.length}
              </span>
            </div>
            <ul className="space-y-1.5">
              {t.dod.map((d, i) => {
                const on = dodState[i] === true;
                return (
                  <li key={d}>
                    <button
                      onClick={() => onDod(i)}
                      className={`flex w-full gap-2.5 rounded-lg p-2 text-left transition ${
                        on ? "bg-emerald-500/10 ring-1 ring-emerald-500/25" : "hover:bg-white/[0.04]"
                      }`}
                    >
                      <span
                        className={`mt-[3px] grid h-3.5 w-3.5 shrink-0 place-items-center rounded border text-[9px] transition ${
                          on ? "border-emerald-400 bg-emerald-400 text-slate-900" : "border-white/25 text-transparent"
                        }`}
                      >
                        ✓
                      </span>
                      <span className={`text-[12px] leading-snug ${on ? "text-white/45 line-through" : "text-white/75"}`}>{d}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}

export default function MorchidSpec() {
  const [axe, setAxe] = useState<Axe | "all">("all");
  const [prio, setPrio] = useState<Prio | "all">("all");
  const [q, setQ] = useState("");
  const [dod, setDod] = useState<Record<string, Record<number, boolean>>>({});
  const [promptCopied, setPromptCopied] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setDod(JSON.parse(raw));
    } catch {
      /* stockage indisponible */
    }
  }, []);

  const persist = (next: Record<string, Record<number, boolean>>) => {
    setDod(next);
    try {
      localStorage.setItem(KEY, JSON.stringify(next));
    } catch {
      /* ignore */
    }
  };
  const toggleDod = (id: string, i: number) => {
    const cur = dod[id] ?? {};
    persist({ ...dod, [id]: { ...cur, [i]: !cur[i] } });
  };

  const list = useMemo(
    () =>
      TICKETS.filter(
        (t) =>
          (axe === "all" || t.axe === axe) &&
          (prio === "all" || t.prio === prio) &&
          (!q.trim() || `${t.id} ${t.title} ${t.composant} ${t.probleme} ${t.regle}`.toLowerCase().includes(q.toLowerCase())),
      ).sort((a, b) => PRIO_META[a.prio].rank - PRIO_META[b.prio].rank),
    [axe, prio, q],
  );

  const dodTotal = TICKETS.reduce((a, t) => a + t.dod.length, 0);
  const dodDone = Object.values(dod).reduce((a, r) => a + Object.values(r).filter(Boolean).length, 0);
  const critiques = TICKETS.filter((t) => t.prio === "Critique").length;

  const copyPrompt = async () => {
    try {
      await navigator.clipboard.writeText(SYSTEM_PROMPT);
      setPromptCopied(true);
      setTimeout(() => setPromptCopied(false), 2200);
    } catch {
      /* ignore */
    }
  };

  const select = "rounded-lg border border-white/10 bg-white/[0.05] px-2.5 py-1.5 text-[12px] text-white/80 outline-none transition focus:border-sky-400/50";
  const label = "font-mono text-[10px] uppercase tracking-widest text-white/35";

  return (
    <div className="space-y-12">
      {/* ═════════ OUVERTURE : identité + triade ═════════ */}
      <section className="relative overflow-hidden rounded-3xl border border-white/12 bg-[linear-gradient(140deg,rgba(56,189,248,.09),rgba(16,185,129,.05)_40%,rgba(245,158,11,.05)_75%,transparent)] p-6 sm:p-9">
        <div className="pointer-events-none absolute -right-24 -top-28 h-72 w-72 rounded-full bg-sky-400/10 blur-[90px]" />
        <div className="pointer-events-none absolute -bottom-32 left-10 h-64 w-64 rounded-full bg-emerald-400/[0.07] blur-[90px]" />

        <div className="relative grid gap-8 lg:grid-cols-[1.25fr_1fr]">
          <div>
            <div className={`${KICKER} text-sky-300`}>SpecKit 002 · Ingénierie de l'intelligence — prompt & comportement</div>
            <h1 className="mt-3 font-display text-[30px] font-semibold leading-[1.08] tracking-tight text-white sm:text-[44px]">
              Transformer Morchid
              <br />
              <span className="text-sky-300">en expert de la pédagogie</span> SVT Bac.
            </h1>
            <p className="mt-5 max-w-2xl text-[14px] leading-relaxed text-white/70">
              {TICKETS.length} tickets de spécification <strong className="text-white">technique et comportementale</strong>, chacun traçable à
              un constat d'audit vérifié empiriquement. Chaque ticket impose une directive de <span className="font-mono text-sky-200">system_prompt</span>,
              un exemple few-shot avant/après en arabe, et une <em>definition of done</em> testable.
            </p>
            <div className="mt-5 flex flex-wrap items-center gap-2">
              <Pill tone="bad">{critiques} critiques</Pill>
              <Pill tone="warn">{TICKETS.filter((t) => t.prio === "Haute").length} hautes</Pill>
              <Pill tone="neutral">{TICKETS.filter((t) => t.prio === "Moyenne").length} moyennes</Pill>
              <Pill tone="good">{dodTotal} critères de validation</Pill>
              <Pill>4 lots d'implémentation</Pill>
            </div>
          </div>

          <div className="rounded-2xl border border-white/12 bg-black/35 p-5 backdrop-blur">
            <div className={`${KICKER} text-white/40`}>Avancement de la spécification</div>
            <div className="mt-3 flex items-end gap-3">
              <span className="font-mono text-5xl font-bold leading-none tabular-nums text-sky-300">
                {Math.round((dodDone / dodTotal) * 100)}%
              </span>
              <span className="pb-1.5 font-mono text-[11px] text-white/40">
                {dodDone}/{dodTotal} DoD cochés
              </span>
            </div>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-red-400 via-amber-400 to-emerald-400 transition-all duration-700"
                style={{ width: `${(dodDone / dodTotal) * 100}%` }}
              />
            </div>
            <p className="mt-4 border-t border-white/10 pt-3 text-[12px] leading-relaxed text-white/55">
              Cochez les critères à mesure que les tests passent. L'état est conservé sur cet appareil — rien n'est envoyé.
            </p>
          </div>
        </div>

        <div className="relative mt-9">
          <div className="mb-3 flex items-baseline gap-3">
            <span className={`${KICKER} text-amber-300/90`}>Cadre pédagogique imposé · pilier A</span>
            <span className="text-[11.5px] text-white/40">la démarche scientifique — aucun bloc n'est livré sans que l'élève ait produit le précédent</span>
          </div>
          <Triade />
        </div>
      </section>

      {/* ═════════ LES 4 PILIERS ═════════ */}
      <Revealer>
        <section>
          <div className="mb-5 border-l-2 border-sky-400/60 pl-4">
            <div className={`${KICKER} text-sky-300`}>Le cadre à imposer</div>
            <h2 className="mt-1.5 font-display text-[26px] font-semibold tracking-tight text-white sm:text-[32px]">
              Quatre piliers, quatorze tickets
            </h2>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {AXES.map((a) => {
              const n = TICKETS.filter((t) => t.axe === a.id).length;
              const on = axe === a.id;
              return (
                <button
                  key={a.id}
                  onClick={() => setAxe(on ? "all" : a.id)}
                  className={`rounded-2xl border p-4 text-left transition-all duration-300 ${
                    on ? "border-white/30 bg-white/[0.07]" : "border-white/10 bg-white/[0.025] hover:border-white/20 hover:bg-white/[0.05]"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: a.color }} />
                    <span className="font-mono text-[10px] uppercase tracking-[0.16em]" style={{ color: a.color }}>
                      {a.role}
                    </span>
                    <span className="ml-auto font-mono text-[12px] font-bold tabular-nums text-white/60">{n}</span>
                  </div>
                  <h3 className="mt-2 font-display text-[18px] font-semibold text-white">{a.label}</h3>
                  <p className="mt-1.5 text-[12px] leading-relaxed text-white/55">{a.desc}</p>
                </button>
              );
            })}
          </div>
        </section>
      </Revealer>

      {/* ═════════ MÉTRIQUES CIBLES ═════════ */}
      <Revealer>
        <section>
          <div className="mb-5 border-l-2 border-emerald-400/60 pl-4">
            <div className={`${KICKER} text-emerald-300`}>Ce que « gagner en intelligence » veut dire, chiffré</div>
            <h2 className="mt-1.5 font-display text-[26px] font-semibold tracking-tight text-white sm:text-[32px]">
              Baseline mesurée → cible exigée
            </h2>
          </div>
          <Card className="!p-0 overflow-hidden">
            <div className="border-b border-white/10 bg-white/[0.04] px-4 py-2.5">
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-[1.1fr_auto_auto]">
                <span className={`${KICKER} text-white/40`}>Métrique comportementale</span>
                <span className={`${KICKER} text-white/40 sm:col-span-2`}>Baseline auditée → cible</span>
              </div>
            </div>
            <div className="px-4 py-1">
              {METRICS.map((m) => (
                <MetricRow key={m.name} m={m} />
              ))}
            </div>
          </Card>
        </section>
      </Revealer>

      {/* ═════════ TICKETS ═════════ */}
      <section>
        <div className="mb-5 border-l-2 border-amber-400/60 pl-4">
          <div className={`${KICKER} text-amber-300`}>Les tickets</div>
          <h2 className="mt-1.5 font-display text-[26px] font-semibold tracking-tight text-white sm:text-[32px]">
            {list.length} spécification{list.length > 1 ? "s" : ""} technique{list.length > 1 ? "s" : ""} et comportementale{list.length > 1 ? "s" : ""}
          </h2>
          <p className="mt-2 max-w-3xl text-[13px] leading-relaxed text-white/50">
            Format imposé : composant ciblé · priorité · problème d'audit · règle visée · directives de system_prompt · exemple few-shot ·
            definition of done. Cliquez pour déplier.
          </p>
        </div>

        <div className="mb-4 flex flex-wrap items-end gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
          <div>
            <div className={label}>Recherche</div>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="négation, probe, verbe, détresse…"
              className={`${select} mt-1 w-56`}
            />
          </div>
          <div>
            <div className={label}>Pilier</div>
            <select value={axe} onChange={(e) => setAxe(e.target.value as Axe | "all")} className={`${select} mt-1`}>
              <option value="all">Tous les piliers</option>
              {AXES.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <div className={label}>Priorité</div>
            <select value={prio} onChange={(e) => setPrio(e.target.value as Prio | "all")} className={`${select} mt-1`}>
              <option value="all">Toutes</option>
              <option value="Critique">Critique ({TICKETS.filter((t) => t.prio === "Critique").length})</option>
              <option value="Haute">Haute ({TICKETS.filter((t) => t.prio === "Haute").length})</option>
              <option value="Moyenne">Moyenne ({TICKETS.filter((t) => t.prio === "Moyenne").length})</option>
            </select>
          </div>
          <button
            onClick={() => {
              setAxe("all");
              setPrio("all");
              setQ("");
            }}
            className="ml-auto rounded-lg border border-white/10 px-3 py-1.5 text-[12px] text-white/60 transition hover:border-white/30 hover:text-white"
          >
            Réinitialiser
          </button>
        </div>

        <div className="space-y-2.5">
          {list.map((t) => (
            <Ticket key={t.id} t={t} dodState={dod[t.id] ?? {}} onDod={(i) => toggleDod(t.id, i)} />
          ))}
          {list.length === 0 && (
            <Card>
              <p className="text-sm text-white/60">Aucun ticket ne correspond à ces filtres.</p>
            </Card>
          )}
        </div>
      </section>

      {/* ═════════ SYSTEM PROMPT CONSOLIDÉ ═════════ */}
      <Revealer>
        <section>
          <div className="mb-5 border-l-2 border-sky-400/60 pl-4">
            <div className={`${KICKER} text-sky-300`}>Livrable principal</div>
            <h2 className="mt-1.5 font-display text-[26px] font-semibold tracking-tight text-white sm:text-[32px]">
              system_prompt consolidé — les 14 directives assemblées
            </h2>
            <p className="mt-2 max-w-3xl text-[13px] leading-relaxed text-white/50">
              Prompt maître prêt à intégrer. Il résout explicitement le conflit avec AGENTS.md règle 5 : la darija est admise en{" "}
              <strong className="text-white/75">détection</strong>, jamais en <strong className="text-white/75">production</strong>.
            </p>
          </div>
          <div className="overflow-hidden rounded-2xl border border-sky-500/25 bg-[#050b14]">
            <div className="flex items-center gap-2 border-b border-sky-500/20 bg-sky-500/[0.06] px-4 py-2.5">
              <span className="h-2 w-2 rounded-full bg-red-400/70" />
              <span className="h-2 w-2 rounded-full bg-amber-400/70" />
              <span className="h-2 w-2 rounded-full bg-emerald-400/70" />
              <span className="ml-2 font-mono text-[11px] text-sky-200/70">system_prompt.morchid.md</span>
              <span className="ml-auto font-mono text-[10px] text-white/30">
                {SYSTEM_PROMPT.split("\n").length} lignes · {new Blob([SYSTEM_PROMPT]).size} o
              </span>
              <button
                onClick={copyPrompt}
                className="rounded-lg bg-sky-400 px-3 py-1 font-mono text-[11px] font-bold text-slate-900 transition hover:bg-sky-300"
              >
                {promptCopied ? "✓ copié" : "copier"}
              </button>
            </div>
            <pre className="max-h-[560px] overflow-auto whitespace-pre-wrap break-words p-5 font-mono text-[11px] leading-[1.8] text-sky-100/80">
              {SYSTEM_PROMPT}
            </pre>
          </div>
        </section>
      </Revealer>

      {/* ═════════ GOLDEN SET ═════════ */}
      <Revealer>
        <section>
          <div className="mb-5 border-l-2 border-violet-400/60 pl-4">
            <div className={`${KICKER} text-violet-300`}>Suite de validation comportementale</div>
            <h2 className="mt-1.5 font-display text-[26px] font-semibold tracking-tight text-white sm:text-[32px]">
              Golden set — {GOLDEN_SET.length} situations d'entrée / sortie attendue
            </h2>
            <p className="mt-2 max-w-3xl text-[13px] leading-relaxed text-white/50">
              Chaque ligne est un test de non-régression comportementale. GS-16 existe pour garantir que DIRECTIVE 09 (détresse) n'affaiblit
              pas le filtre anti-bruit : <span className="text-white/75">« كرة القدم » doit rester hors programme</span>.
            </p>
          </div>
          <Card className="!p-0 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[900px] border-collapse text-left">
                <thead>
                  <tr className="border-b border-white/10 bg-white/[0.04] text-[10.5px] uppercase tracking-wider text-white/50">
                    <th className="px-3 py-3">ID</th>
                    <th className="px-3 py-3">Entrée élève</th>
                    <th className="px-3 py-3">Comportement attendu (assertion)</th>
                    <th className="px-3 py-3">Ticket</th>
                  </tr>
                </thead>
                <tbody>
                  {GOLDEN_SET.map((g) => {
                    const a = AXE_META[g.axe];
                    return (
                      <tr key={g.id} className="border-b border-white/[0.06] align-top transition hover:bg-white/[0.025]">
                        <td className="px-3 py-2.5 font-mono text-[11px] font-bold text-violet-300/85">{g.id}</td>
                        <td className="px-3 py-2.5 text-[12px] text-white/80" dir="auto">
                          {g.entree}
                        </td>
                        <td className="px-3 py-2.5 text-[12px] leading-snug text-white/60">{g.attendu}</td>
                        <td className="px-3 py-2.5">
                          <span className="font-mono text-[10px]" style={{ color: a.color }}>
                            {g.ticket.replace("SPEC-MORCHID-", "M-")}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>
        </section>
      </Revealer>

      {/* ═════════ LOTS ═════════ */}
      <Revealer>
        <section>
          <div className="mb-5 border-l-2 border-red-400/60 pl-4">
            <div className={`${KICKER} text-red-300`}>Ordre d'implémentation</div>
            <h2 className="mt-1.5 font-display text-[26px] font-semibold tracking-tight text-white sm:text-[32px]">
              Quatre lots — le premier stoppe l'hémorragie
            </h2>
          </div>
          <div className="space-y-3">
            {LOTS.map((l, i) => (
              <div
                key={l.lot}
                className="grid gap-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4 transition hover:border-white/20 hover:bg-white/[0.05] lg:grid-cols-[auto_1fr_1fr]"
              >
                <div className="flex items-start gap-3 lg:w-[190px]">
                  <span className="font-mono text-3xl font-bold leading-none text-white/15">{String(i + 1).padStart(2, "0")}</span>
                  <div>
                    <h3 className="text-[13.5px] font-semibold leading-snug text-white">{l.lot.split(" — ")[0]}</h3>
                    <p className="mt-0.5 text-[11.5px] leading-snug text-white/45">{l.lot.split(" — ")[1]}</p>
                  </div>
                </div>
                <div className="flex flex-wrap content-start gap-1.5">
                  {l.tickets.map((tk) => {
                    const t = TICKETS.find((x) => x.id === tk)!;
                    return (
                      <span
                        key={tk}
                        className="rounded-lg px-2 py-1 font-mono text-[10.5px] font-semibold"
                        style={{ background: `${PRIO_META[t.prio].color}18`, color: PRIO_META[t.prio].color }}
                      >
                        {tk.replace("SPEC-MORCHID-", "M-")} · {t.axe.slice(0, 4)}
                      </span>
                    );
                  })}
                </div>
                <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/[0.05] p-3">
                  <div className={`${KICKER} text-emerald-300/80`}>Porte de sortie</div>
                  <p className="mt-1 font-mono text-[11px] leading-relaxed text-white/65">{l.gate}</p>
                  <p className="mt-2 text-[11.5px] leading-snug text-white/50">{l.why}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </Revealer>

      {/* ═════════ GARDE-FOUS D'INGÉNIERIE ═════════ */}
      <section className="rounded-3xl border border-white/12 bg-[linear-gradient(160deg,rgba(255,255,255,.05),transparent)] p-6 sm:p-8">
        <div className={`${KICKER} text-white/40`}>Contraintes héritées d'AGENTS.md — non négociables</div>
        <div className="mt-4 grid gap-3 lg:grid-cols-3">
          {[
            {
              t: "P2/R6 — aucun fit sur les notes prof",
              d: "Aucun modèle a·cov+b. Seuls les chiffres du barème officiel sont utilisables : exercice 1 = 5 pts, exercice 2 = 7 pts, exercice 3 = 8 pts (ONEC, série 2019→2026).",
              c: "#ef4444",
            },
            {
              t: "Les 40 eleve_*.txt ne sont pas un jeu de validation",
              d: "Ils ont servi à CALIBRER le moteur. Tout écart publié est un plancher, jamais une performance définitive. Lecture seule, jamais en test de sortie.",
              c: "#f59e0b",
            },
            {
              t: "Similarité sémantique = piste, jamais crédit",
              d: "Sans preuve validée, aucun point n'est accordé. Un item dont la reconnaissance demande une interprétation humaine reste MANUEL (formes: []).",
              c: "#38bdf8",
            },
            {
              t: "فصحى en sortie, darija en détection uniquement",
              d: "AGENTS.md règle 5 interdit le dialecte. Résolution d'ingénierie : AFFECT_LEXICON comprend la darija, toute réponse de Morchid reste en arabe فصحى.",
              c: "#a78bfa",
            },
            {
              t: "Zéro contenu inventé, injection mécanique",
              d: "Chiffres, formules et énoncés intacts, repris de data/bookContent.json (lecture seule). Transcription manuelle proscrite. Filtre ر/ز · ح/ة · ف/ب sur toute injection.",
              c: "#10b981",
            },
            {
              t: "Tags et scoreur INCHANGÉS",
              d: "Les 8 tags du correcteur et methodologyScorer ne sont pas modifiés : Morchid réadresse les erreurs déjà détectées. Fichiers générés (okacha.ts, hosila.ts) uniquement via leurs scripts.",
              c: "#94a3b8",
            },
          ].map((x) => (
            <div key={x.t} className="rounded-xl border border-white/10 bg-black/25 p-4">
              <div className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full" style={{ background: x.c }} />
                <span className="font-mono text-[10px] uppercase tracking-wider" style={{ color: x.c }}>
                  contrainte
                </span>
              </div>
              <h3 className="mt-1.5 text-[13px] font-semibold leading-snug text-white">{x.t}</h3>
              <p className="mt-1.5 text-[11.5px] leading-relaxed text-white/55">{x.d}</p>
            </div>
          ))}
        </div>
        <p className="mt-6 text-[13px] leading-relaxed text-white/60">
          <strong className="text-white/85">La ligne à retenir :</strong> Morchid n'a pas un problème de connaissances, il a un problème de{" "}
          <strong className="text-white/85">posture</strong>. Son moteur de validation est d'un niveau professionnel — anti-bourrage, polarité
          des négations, mélange déterministe, payload sans réponse. Mais il délivre tout, tout de suite, à tout le monde. Les 14 tickets ne
          ajoutent presque aucune connaissance nouvelle : ils{" "}
          <strong className="text-white/85">retiennent l'information assez longtemps pour que l'élève ait à la produire</strong>.
        </p>
      </section>
    </div>
  );
}
