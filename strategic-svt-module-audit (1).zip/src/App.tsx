import { useEffect, useState } from "react";
import Overview from "./components/Overview";
import Explorer from "./components/Explorer";
import UnitsView from "./components/UnitsView";
import Decisions from "./components/Decisions";
import Planner from "./components/Planner";
import Reports from "./components/Reports";
import Morchid from "./components/Morchid";
import SpecKit from "./components/SpecKit";
import Speckit2 from "./components/Speckit2";
import MorchidSpec from "./components/MorchidSpec";
import { STATS } from "./lib/compute";

const TABS = [
  { id: "morchid-spec", label: "SpecKit IA Morchid", icon: "◈" },
  { id: "speckit2", label: "Speckit 001 — fiabilité élève", icon: "⬢" },
  { id: "speckit", label: "SpecKit correctifs (22)", icon: "⬣" },
  { id: "morchid", label: "Audit Morchid", icon: "✦" },
  { id: "rapports", label: "Méta-audit des 6 rapports", icon: "◆" },
  { id: "synthese", label: "Synthèse modules", icon: "◎" },
  { id: "modules", label: "49 modules notés", icon: "≡" },
  { id: "unites", label: "Unités & trous", icon: "⊞" },
  { id: "decisions", label: "Décisions", icon: "⚖" },
  { id: "plan", label: "Plan d'action", icon: "▶" },
];

export default function App() {
  const [tab, setTab] = useState("morchid-spec");

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [tab]);

  return (
    <div className="min-h-screen bg-[#070a12] text-white antialiased">
      {/* décor ambiant */}
      <div className="pointer-events-none fixed inset-0 opacity-70">
        <div className="absolute -left-40 -top-40 h-[520px] w-[520px] rounded-full bg-emerald-500/10 blur-[130px]" />
        <div className="absolute right-0 top-24 h-[420px] w-[420px] rounded-full bg-amber-500/[0.09] blur-[130px]" />
        <div className="absolute bottom-0 left-1/3 h-[380px] w-[380px] rounded-full bg-violet-600/[0.09] blur-[130px]" />
      </div>

      <header className="sticky top-0 z-30 border-b border-white/10 bg-[#070a12]/88 backdrop-blur-xl">
        <div className="mx-auto max-w-7xl px-4 py-3 sm:px-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-emerald-400 to-amber-400 font-display text-[15px] font-bold text-[#070a12]">
                ك
              </div>
              <div>
                <h1 className="font-display text-[16px] font-semibold leading-tight tracking-tight sm:text-[17px]">
                  Inspection stratégique — كنز العلوم
                </h1>
                <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-white/40">
                  SVT · BAC algérien · speckits + audits + Play Store
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 font-mono text-[10.5px]">
              <span className="rounded-lg bg-emerald-500/10 px-2 py-1 text-emerald-300">{STATS.byTier[1].length} T1</span>
              <span className="rounded-lg bg-amber-500/10 px-2 py-1 text-amber-300">{STATS.byTier[2].length} T2</span>
              <span className="rounded-lg bg-orange-500/10 px-2 py-1 text-orange-300">{STATS.byTier[3].length} T3</span>
              <span className="rounded-lg bg-red-500/10 px-2 py-1 text-red-300">{STATS.byTier[4].length} T4</span>
              <span className="ml-1 hidden rounded-lg bg-white/5 px-2 py-1 text-white/50 sm:inline">49 → 12 modules</span>
            </div>
          </div>

          <nav className="mt-3 flex gap-1 overflow-x-auto pb-0.5">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex shrink-0 items-center gap-2 rounded-xl px-3.5 py-2 text-[12.5px] font-medium transition-all duration-200 ${
                  tab === t.id
                    ? "bg-white/10 text-white ring-1 ring-white/15"
                    : "text-white/50 hover:bg-white/5 hover:text-white/85"
                }`}
              >
                <span className={`text-[10px] ${tab === t.id ? "text-amber-300" : "opacity-60"}`}>{t.icon}</span>
                {t.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="relative mx-auto max-w-7xl px-4 py-8 sm:px-6 sm:py-10">
        {tab === "morchid-spec" && <MorchidSpec />}
        {tab === "speckit2" && <Speckit2 />}
        {tab === "speckit" && <SpecKit />}
        {tab === "morchid" && <Morchid />}
        {tab === "rapports" && <Reports />}
        {tab === "synthese" && <Overview go={setTab} />}
        {tab === "modules" && <Explorer />}
        {tab === "unites" && <UnitsView />}
        {tab === "decisions" && <Decisions />}
        {tab === "plan" && <Planner />}
      </main>

      <footer className="relative border-t border-white/10 px-4 py-6 sm:px-6">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 text-[11.5px] text-white/40">
          <span>
            Périmètre audité : <span className="font-mono text-white/60">src/components/*.tsx</span> ·{" "}
            <span className="font-mono text-white/60">src/data/*.ts</span> · 6 rapports stratégiques — programme officiel SVT 3
            <sup>e</sup> AS (réforme 2011+)
          </span>
          <a
            href="https://github.com/sinamind414/kunz-el-ouloum"
            target="_blank"
            rel="noreferrer"
            className="font-mono text-white/50 underline decoration-dotted underline-offset-4 transition hover:text-amber-300"
          >
            kunz-el-ouloum · كنز العلوم
          </a>
        </div>
      </footer>
    </div>
  );
}
