import { sql } from "drizzle-orm";
import { db } from "@/db";

// Filet de sécurité : si l'environnement repart d'une base vide sans
// `drizzle-kit push`, les tables sont créées au premier accès.
const statements = [
  sql`CREATE TABLE IF NOT EXISTS learners (
    id text PRIMARY KEY,
    name text NOT NULL,
    exam_date text NOT NULL,
    extra_date text,
    extra_count integer NOT NULL DEFAULT 0,
    created_at timestamptz NOT NULL DEFAULT now()
  )`,
  sql`CREATE TABLE IF NOT EXISTS progress (
    id text PRIMARY KEY,
    learner_id text NOT NULL,
    item_id text NOT NULL,
    phase text NOT NULL,
    status text NOT NULL,
    fragile boolean NOT NULL DEFAULT false,
    attempts integer NOT NULL DEFAULT 0,
    payload jsonb NOT NULL DEFAULT '{}'::jsonb,
    completed_at timestamptz,
    updated_at timestamptz NOT NULL DEFAULT now()
  )`,
  sql`CREATE TABLE IF NOT EXISTS reviews (
    id text PRIMARY KEY,
    learner_id text NOT NULL,
    brick_id text NOT NULL,
    due_on text NOT NULL,
    step integer NOT NULL DEFAULT 0,
    fragile boolean NOT NULL DEFAULT false,
    active boolean NOT NULL DEFAULT true,
    last_done_on text,
    done_count integer NOT NULL DEFAULT 0
  )`,
  sql`CREATE TABLE IF NOT EXISTS morchid_events (
    id serial PRIMARY KEY,
    learner_id text NOT NULL,
    item_id text NOT NULL,
    moment text NOT NULL,
    body text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
  )`,
  sql`CREATE TABLE IF NOT EXISTS notes (
    id serial PRIMARY KEY,
    learner_id text NOT NULL,
    kind text NOT NULL,
    unit_id integer,
    item_id text,
    body text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
  )`,
];

let ready: Promise<void> | null = null;

export function ensureSchema() {
  ready ??= (async () => {
    for (const statement of statements) await db.execute(statement);
  })().catch((error) => {
    ready = null;
    throw error;
  });
  return ready;
}
