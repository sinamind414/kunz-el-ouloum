// src/db/schema.ts — Kunz El Ouloum · état de l'élève uniquement.
//
// Le CONTENU (programme officiel, 19 briques, verrous) vit en TypeScript
// (src/lib/curriculum.ts). La base ne stocke que ce que l'élève a fait :
// phases validées, rappels espacés, paroles de Morchid, carnet.

import { boolean, integer, jsonb, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export type PhaseKind = "decouverte" | "vocabulaire" | "methodologie" | "application";
export type ProgressPhase = PhaseKind | "jalon";
export type ErrorType = "T1" | "T2" | "T3" | "T4";
export type MorchidMoment = "sonde" | "relance" | "cle" | "diagnostic" | "cloture" | "jalon";

export type PhasePayload = {
  /** Sonde de Morchid : hypothèse choisie AVANT le contenu. */
  probeChoice?: number;
  probeCorrect?: boolean;
  /** Copie de l'élève (application Bac ou synthèse de jalon). */
  answer?: string;
  /** Items du barème cochés à l'auto-évaluation. */
  ticked?: number[];
  score?: number;
  total?: number;
  /** Auto-évaluation < 60 % : le diagnostic T1–T4 est exigé. */
  needsType?: boolean;
  errorType?: ErrorType;
  /** Relances « أنا عالق » consommées sur cette phase (max 2). */
  stuck?: number;
  /** Dernière parole de Morchid sur cette phase (affichée dans la séance). */
  morchid?: string;
};

export const learners = pgTable("learners", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  examDate: text("exam_date").notNull(),
  extraDate: text("extra_date"),
  extraCount: integer("extra_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Une ligne par (élève, item, phase). item = brique « u1-b2 » ou jalon « jalon-u1 ». */
export const progress = pgTable("progress", {
  id: text("id").primaryKey(),
  learnerId: text("learner_id").notNull(),
  itemId: text("item_id").notNull(),
  phase: text("phase").$type<ProgressPhase>().notNull(),
  status: text("status").$type<"en_cours" | "valide">().notNull(),
  fragile: boolean("fragile").notNull().default(false),
  attempts: integer("attempts").notNull().default(0),
  payload: jsonb("payload").$type<PhasePayload>().notNull().default({}),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Rappel espacé d'une brique : J+1 (fragile) ou J+3, puis J+7, J+21, puis retiré. */
export const reviews = pgTable("reviews", {
  id: text("id").primaryKey(),
  learnerId: text("learner_id").notNull(),
  brickId: text("brick_id").notNull(),
  dueOn: text("due_on").notNull(),
  step: integer("step").notNull().default(0),
  fragile: boolean("fragile").notNull().default(false),
  active: boolean("active").notNull().default(true),
  lastDoneOn: text("last_done_on"),
  doneCount: integer("done_count").notNull().default(0),
});

/** Chaque parole de Morchid, rattachée à un item et à l'un de ses moments autorisés. */
export const morchidEvents = pgTable("morchid_events", {
  id: serial("id").primaryKey(),
  learnerId: text("learner_id").notNull(),
  itemId: text("item_id").notNull(),
  moment: text("moment").$type<MorchidMoment>().notNull(),
  body: text("body").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Carnet (تدوين) : notes de l'élève et questions « garées » pour le jalon d'unité. */
export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  learnerId: text("learner_id").notNull(),
  kind: text("kind").$type<"note" | "question">().notNull(),
  unitId: integer("unit_id"),
  itemId: text("item_id"),
  body: text("body").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Learner = typeof learners.$inferSelect;
export type ProgressRow = typeof progress.$inferSelect;
export type ReviewRow = typeof reviews.$inferSelect;
export type NoteRow = typeof notes.$inferSelect;
export type MorchidRow = typeof morchidEvents.$inferSelect;
