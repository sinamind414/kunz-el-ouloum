// src/lib/morchid.ts — le tuteur Morchid, réduit à ses moments utiles.
//
// Morchid n'a ni onglet ni chat. Il parle à 4 moments précis de la séance
// (sonde, clé, diagnostic, clôture) + une valve « أنا عالق » plafonnée.
// Les répliques sont dérivées du contenu de la brique : en production, ces
// points d'ancrage sont les SEULS endroits où l'API du tuteur serait appelée.

import type { ErrorType, MorchidMoment, PhaseKind } from "@/db/schema";
import { TEETH, type Brick, type Unit } from "@/lib/curriculum";
import { formatDayAr } from "@/lib/dates";

export type MomentDef = {
  id: MorchidMoment;
  ar: string;
  fr: string;
  at: string;
  phase: PhaseKind | "fin";
  quandFr: string;
  ditFr: string;
  nonFr: string;
  plafondFr: string;
};

export const MORCHID_MOMENTS: MomentDef[] = [
  {
    id: "sonde",
    ar: "السؤال القبلي",
    fr: "La sonde",
    at: "0:00",
    phase: "decouverte",
    quandFr: "À l'ouverture de la brique, avant le moindre contenu.",
    ditFr: "Une question d'hypothèse. Toute réponse est acceptée : la lecture qui suit la confirme ou la contredit.",
    nonFr: "Ne donne jamais la réponse avant le choix ; n'ouvre aucune conversation.",
    plafondFr: "1 fois par brique",
  },
  {
    id: "cle",
    ar: "مفتاح المنهجية",
    fr: "La clé",
    at: "≈ 7:00",
    phase: "methodologie",
    quandFr: "Phase 3, pendant le tri des phrases dans les 4 dents (فعل · دليل · علاقة · جواب).",
    ditFr: "Explique UNE dent par essai — la première mal placée —, puis clôt la phase avec la question de vérification à emporter dans l'application.",
    nonFr: "Ne rédige pas la réponse ; ne corrige pas les 4 dents d'un coup.",
    plafondFr: "1 explication par essai · révélation au 2ᵉ échec",
  },
  {
    id: "diagnostic",
    ar: "التشخيص",
    fr: "Le diagnostic",
    at: "≈ 17:00",
    phase: "application",
    quandFr: "Phase 4, uniquement si l'auto-évaluation est sous 6/10.",
    ditFr: "Fait d'abord typer l'erreur — T1 mot, T2 document, T3 inférence trop tôt, T4 hors consigne —, puis donne une consigne ciblée et rappelle le piège de la brique.",
    nonFr: "Se tait si la copie est solide ; ne recorrige pas toute la copie.",
    plafondFr: "0 ou 1 fois par brique",
  },
  {
    id: "cloture",
    ar: "كلمة الختام",
    fr: "La clôture",
    at: "19:00",
    phase: "fin",
    quandFr: "À la fin de la brique, et au jalon de fin d'unité.",
    ditFr: "Une phrase : ce qui vient d'être fixé et la date du rappel. Au jalon, il nomme la brique la plus fragile et ressort les questions garées.",
    nonFr: "Pas de nouvelle notion, pas de « veux-tu continuer ? ».",
    plafondFr: "1 phrase",
  },
];

export const MORCHID_VALVE = {
  ar: "أنا عالق",
  fr: "« Je bloque »",
  ditFr: "Une relance contextuelle sur la phase en cours — jamais la réponse avant un essai.",
  plafondFr: "2 par phase",
};

export const MORCHID_FORBIDDEN_FR = [
  "Pas d'onglet Morchid, pas de chat libre : un chat ouvert invite les sollicitations désordonnées.",
  "Rien sur l'accueil : ni notification, ni « message du tuteur ».",
  "Silence pendant le vocabulaire et pendant la rédaction.",
  "Hors de la brique en cours, la question de l'élève est « garée » dans le carnet et ressort au jalon de l'unité.",
];

export const ERROR_TYPES: { code: ErrorType; ar: string; fr: string }[] = [
  { code: "T1", ar: "مصطلح علمي خاطئ أو ناقص", fr: "Mot scientifique faux ou absent" },
  { code: "T2", ar: "لم أستغلّ الوثيقة (قيمة أو وحدة غائبة)", fr: "Document non exploité" },
  { code: "T3", ar: "استنتجت قبل أن ألاحظ", fr: "Inférence avant l'observation" },
  { code: "T4", ar: "أجبت عن سؤال غير المطلوب", fr: "Réponse hors consigne" },
];

/* ─────────────── Répliques ─────────────── */

export function presenceAr(phase: PhaseKind): string {
  if (phase === "decouverte") return "المرشد يبدأ بسؤال واحد قبل الدرس.";
  if (phase === "methodologie") return "المرشد يرافقك في مفتاح المنهجية، سنّاً بسنّ.";
  if (phase === "application") return "المرشد صامت ما دامت إجابتك صلبة.";
  return "المرشد صامت في هذه المرحلة: هي لك.";
}

export function probeFeedback(correct: boolean): string {
  return correct
    ? "فرضيتك تصمد. اقرأ الآن لتعرف لماذا، ثم سؤال واحد للتثبيت."
    : "التزمتَ بجواب، وهذا هو المطلوب. اقرأ الآن وابحث عمّا يؤكّد فرضيتك أو ينقضها.";
}

export function gateRelance(): string {
  return "ليس بعد. الجواب في «ما يجب أن يبقى» — أعد قراءتها ببطء، ثم اختر.";
}

export function gateReveal(option: string, why: string): string {
  return `الجواب: «${option}». ${why} ستعود هذه الفكرة في مراجعة الغد.`;
}

export function vocabRelance(wrong: number): string {
  return `أخطأتَ في ${wrong} من 4. لا تفتح أي قاموس: المصطلحات أمامك، ابدأ بالذي تعرفه يقيناً ثم أقصِ.`;
}

export function vocabReveal(pairs: { term: string; def: string }[]): string {
  return `الثنائيات الصحيحة: ${pairs.map((pair) => `«${pair.term}» ← ${pair.def}`).join(" · ")} ستعود في مراجعة الغد.`;
}

export function toothHint(tooth: number): string {
  const t = TEETH[tooth - 1];
  return `سنّ واحدة فقط: السنّ ${t.n} «${t.ar}» — ${t.questionAr} ${t.roleAr} ابحث عن الجملة التي تؤدّي هذا الدور، ثم أعد التوزيع.`;
}

export function toothReveal(sentences: string[]): string {
  return `الترتيب الصحيح: ${sentences.map((s, i) => `(${TEETH[i].ar}) ${s}`).join(" ")} احفظ الدور، لا الجملة.`;
}

export function methodClose(checkAr: string): string {
  return `مفتاحك جاهز. قبل أن تكتب، احمل معك سؤال التحقّق: «${checkAr}»`;
}

export function diagnosticAsk(score: number, total: number): string {
  return `قيّمتَ إجابتك بـ ${score}/${total}. قبل أن أعلّق: ما نوع خطئك؟ اختر نوعاً واحداً.`;
}

export function diagnosticReply(code: ErrorType, brick: Brick): string {
  const piege = brick.spec.application.piegeAr;
  if (code === "T1")
    return `خطأ مصطلح. أعد كتابة الجملة الخاطئة بالمصطلح الدقيق من بطاقات هذه اللبنة. والفخّ هنا: ${piege}`;
  if (code === "T2")
    return `الوثيقة لم تُستغلّ. القاعدة: قيمة + وحدة + اتجاه التغيّر قبل أيّ «لأنّ». والفخّ هنا: ${piege}`;
  if (code === "T3")
    return `استنتجتَ قبل أن تلاحظ. السنّ 2 (ألاحظ) قبل السنّ 3 (أستنتج)، دائماً. والفخّ هنا: ${piege}`;
  return `أجبتَ عن سؤال آخر. فعل الأداء «${brick.spec.methode.verbAr}» هو الذي يحدّد جملتك الأخيرة. والفخّ هنا: ${piege}`;
}

export function clotureLine(objectifAr: string, reviewOn: string, fragile: boolean): string {
  return fragile
    ? `اللبنة مكتملة لكنها هشّة: «${objectifAr}». تعود غداً، ${formatDayAr(reviewOn)}، في ست دقائق ودون درس جديد.`
    : `حصيلة اليوم: «${objectifAr}». تعود في المراجعة يوم ${formatDayAr(reviewOn)}، في ست دقائق.`;
}

export function jalonLine(unit: Unit, weakest: string | null, reviewOn: string | null, fragile: boolean): string {
  const head = fragile ? `الجسر مفتوح، لكن ${unit.number} ما زالت هشّة.` : `جسر ${unit.number} مفتوح: ${unit.titleAr}.`;
  const tail = weakest && reviewOn ? ` أضعف لبنة: «${weakest}» — تعود في المراجعة يوم ${formatDayAr(reviewOn)}.` : "";
  return `${head}${tail} الوحدة التالية تبدأ في جلستك القادمة.`;
}

export function stuckHint(
  phase: PhaseKind,
  ctx: { probeDone: boolean; answerDone: boolean },
  brick: Brick,
): string {
  if (phase === "decouverte") {
    return ctx.probeDone
      ? `الخطأ الشائع في هذه اللبنة: ${brick.spec.concept.errorAr}`
      : "لا خطأ مكلف هنا: اختر ما تظنّه. الفرضية الخاطئة تجعلك تقرأ بانتباه أكبر.";
  }
  if (phase === "vocabulaire") return "ابدأ بالمصطلح الذي تعرفه يقيناً، ثم أقصِ. لكل تعريف مصطلح واحد فقط.";
  if (phase === "methodologie")
    return "السنّ 1 هي الجملة التي تذكر «المطلوب»، والسنّ 4 هي التي تعيد صياغته. ابدأ بهما، يبقى الوسط.";
  return ctx.answerDone
    ? "قيّم كل بند بصرامة: إن لم تكتبه فعلاً فلا تعدّه. الهدف أن تعرف أين أنت، لا أن تنجح."
    : `ابدأ بفعل الأداء، ثم قيمة من السند (${brick.spec.application.supportsAr[0] ?? "الوثيقة"})، ثم «لأنّ»، ثم جملة تعيد صياغة المطلوب.`;
}
