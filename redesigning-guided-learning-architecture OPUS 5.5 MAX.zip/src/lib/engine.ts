// src/lib/engine.ts — moteur du parcours guidé : état, Next Best Action, rythme.
//
// Priorité de la tâche du jour (une seule affichée) :
//   1. reprendre l'item commencé ;
//   2. rappel espacé dû (6 min) — avant toute nouveauté ;
//   3. nouvelle séance (brique ou jalon) si le quota du jour n'est pas atteint ;
//   4. sinon : repos (« يكفي اليوم »), avec une séance bonus possible.

import { desc, eq } from "drizzle-orm";
import { cookies } from "next/headers";
import { db } from "@/db";
import { ensureSchema } from "@/db/ensure";
import {
  learners,
  morchidEvents,
  notes,
  progress,
  reviews,
  type Learner,
  type NoteRow,
  type PhaseKind,
  type PhasePayload,
  type ProgressRow,
  type ReviewRow,
} from "@/db/schema";
import {
  BRICKS,
  JALON_MINUTES,
  PATH,
  PHASES,
  PHASE_META,
  REVIEW_MINUTES,
  UNITS,
  bricksOfUnit,
  brickById,
  classPositionOn,
  itemTitleAr,
  jalonChecklist,
  jalonId,
  rubricOf,
  unitById,
  type PathItem,
} from "@/lib/curriculum";
import { DAYS_SHORT_AR, addDays, countAr, defaultExamDate, diffDays, keyToDate, todayKey, weekStart } from "@/lib/dates";
import { clotureLine, diagnosticReply, jalonLine } from "@/lib/morchid";

export const DEMO_ID = "demo-lina";
export const COOKIE = "keo_learner";

export async function currentLearnerId(): Promise<string> {
  const jar = await cookies();
  return jar.get(COOKIE)?.value || DEMO_ID;
}

export function progressId(learner: string, item: string, phase: string): string {
  return `${learner}:${item}:${phase}`;
}

/* ─────────────── Élève de démonstration ─────────────── */

const DEMO_ANSWERS = [
  "المطلوب: تحديد مقر تركيب البروتين. نلاحظ أنّ الإشعاع عند 3 دقائق يتركّز في الشبكة الهيولية الفعالة REG، ثم ينتقل عند 20 دقيقة إلى جهاز غولجي، وعند 120 دقيقة إلى حويصلات الإفراز. لأنّ الريبوزومات الملتصقة بـ REG تدمج الأحماض الأمينية المشعّة أولاً، إذن مقر تركيب البروتين هو الهيولى على مستوى REG، ثم ينتقل البروتين نحو غولجي فالإفراز.",
  "ARNm الموافق هو 5'-AUG CGC-3'. لأنّ ARNm يتكامل مع السلسلة المستنسخة (A↔U و C↔G)، فهو يطابق السلسلة غير المستنسخة مع استبدال T بـ U. يتدخّل إنزيم ARN بوليميراز داخل النواة وفق ثلاث مراحل: البداية ثم الاستطالة ثم النهاية. إذن ARNm الموافق هو 5'-AUG CGC-3'.",
  "الرامزات هي AUG ثم CCG ثم UAA. الرامزة AUG تشفّر الميثيونين والرامزة CCG تشفّر البرولين، ثم تتوقف الترجمة عند UAA. إذن السلسلة هي: ميثيونين - برولين.",
  "المرحلة المتأثّرة هي الترجمة. نلاحظ أنّ ARNm موجود بنسبة 100% بينما السلاسل الببتيدية منعدمة. لأنّ ARNm تشكّل فالاستنساخ سليم، وغياب السلسلة الببتيدية يعني أنّ الريبوزوم لم يترجم. إذن المادة المثبّطة توقف مرحلة الترجمة في الهيولى.",
];

const DEMO_JALON =
  "تبدأ المعلومة الوراثية في ADN داخل النواة، حيث يستنسخها إنزيم ARN بوليميراز في جزيئة ARNm مع U مكان T. يغادر ARNm النواة نحو الهيولى، فتقرأه الريبوزومات رامزةً بعد رامزة انطلاقاً من AUG، وتربط الأحماض الأمينية المنشّطة بروابط ببتيدية حتى رامزة التوقّف. البروتين المفرَز يُركّب على REG ثم يمرّ بجهاز غولجي قبل أن يغادر الخلية.";

async function seedDemo(id: string) {
  const today = todayKey();
  const inserted = await db
    .insert(learners)
    .values({ id, name: "لينا مرابط", examDate: defaultExamDate(today) })
    .onConflictDoNothing()
    .returning({ id: learners.id });
  if (!inserted.length) return;

  const u1 = bricksOfUnit(1);
  const offsets = [-6, -5, -3, -2];
  const ticks = [[0, 1, 2, 3], [0, 1, 2, 3], [0, 1], [0, 1, 2, 3]];
  const rows: (typeof progress.$inferInsert)[] = [];

  u1.forEach((brick, i) => {
    const when = keyToDate(addDays(today, offsets[i] ?? -1), 17);
    const rubric = rubricOf(brick);
    for (const phase of PHASES) {
      const payload: PhasePayload = {};
      let fragile = false;
      if (phase === "decouverte") {
        const probe = brick.spec.checks[0];
        payload.probeChoice = i === 1 ? (probe.correct + 1) % probe.optionsAr.length : probe.correct;
        payload.probeCorrect = i !== 1;
      }
      if (phase === "application") {
        const t = ticks[i] ?? [0];
        payload.answer = DEMO_ANSWERS[i];
        payload.ticked = t;
        payload.score = t.reduce((sum, k) => sum + (rubric[k]?.points ?? 0), 0);
        payload.total = rubric.reduce((sum, item) => sum + item.points, 0);
        if (i === 2) {
          fragile = true;
          payload.needsType = true;
          payload.errorType = "T2";
          payload.morchid = `${diagnosticReply("T2", brick)}\n${clotureLine(brick.spec.objectifAr, addDays(today, 1), true)}`;
        }
      }
      rows.push({
        id: progressId(id, brick.id, phase),
        learnerId: id,
        itemId: brick.id,
        phase,
        status: "valide",
        fragile,
        attempts: 1,
        payload,
        completedAt: when,
        updatedAt: when,
      });
    }
  });

  const checklist = jalonChecklist(1);
  const jalonTicks = checklist.map((_, k) => k).filter((k) => k !== 1);
  const jalonWhen = keyToDate(addDays(today, -1), 18);
  const unit1 = unitById(1);
  rows.push({
    id: progressId(id, jalonId(1), "jalon"),
    learnerId: id,
    itemId: jalonId(1),
    phase: "jalon",
    status: "valide",
    fragile: false,
    attempts: 1,
    payload: {
      answer: DEMO_JALON,
      ticked: jalonTicks,
      score: jalonTicks.length,
      total: checklist.length,
      morchid: unit1 ? jalonLine(unit1, u1[1]?.spec.titleAr ?? null, addDays(today, 5), false) : undefined,
    },
    completedAt: jalonWhen,
    updatedAt: jalonWhen,
  });

  await db.insert(progress).values(rows).onConflictDoNothing();

  const review = (brickIndex: number, dueIn: number, step: number, fragile: boolean, lastDone: number | null) => ({
    id: `${id}:${u1[brickIndex].id}`,
    learnerId: id,
    brickId: u1[brickIndex].id,
    dueOn: addDays(today, dueIn),
    step,
    fragile,
    active: true,
    lastDoneOn: lastDone === null ? null : addDays(today, lastDone),
    doneCount: lastDone === null ? 0 : 1,
  });
  await db
    .insert(reviews)
    .values([review(0, 4, 1, false, -3), review(1, 5, 1, false, -2), review(2, 1, 0, true, null), review(3, 1, 0, false, null)])
    .onConflictDoNothing();

  await db.insert(morchidEvents).values([
    { learnerId: id, itemId: u1[2].id, moment: "diagnostic", body: diagnosticReply("T2", u1[2]), createdAt: keyToDate(addDays(today, -3), 17) },
    {
      learnerId: id,
      itemId: jalonId(1),
      moment: "jalon",
      body: unit1 ? jalonLine(unit1, u1[1]?.spec.titleAr ?? null, addDays(today, 5), false) : "",
      createdAt: jalonWhen,
    },
  ]);

  await db.insert(notes).values([
    { learnerId: id, kind: "note", unitId: 1, itemId: u1[1].id, body: "ARNm = نسخة السلسلة غير المستنسخة مع U مكان T. الإنزيم الوحيد: ARN بوليميراز." },
    { learnerId: id, kind: "question", unitId: 4, itemId: null, body: "لماذا لا يهاجم الجهاز المناعي خلايا الجسم نفسه؟" },
  ]);
}

export async function ensureLearner(id: string): Promise<Learner> {
  await ensureSchema();
  const [existing] = await db.select().from(learners).where(eq(learners.id, id)).limit(1);
  if (existing) return existing;
  if (id === DEMO_ID) await seedDemo(id);
  else await db.insert(learners).values({ id, name: "تلميذ جديد", examDate: defaultExamDate() }).onConflictDoNothing();
  const [created] = await db.select().from(learners).where(eq(learners.id, id)).limit(1);
  return created;
}

/* ─────────────── Types d'état ─────────────── */

export type Status = "done" | "current" | "locked";
export type Score = { score: number; total: number } | null;

export type BrickView = {
  id: string;
  unitId: number;
  order: number;
  titleAr: string;
  titleFr: string;
  objectifAr: string;
  status: Status;
  fragile: boolean;
  phases: { kind: PhaseKind; status: Status; fragile: boolean }[];
  score: Score;
  reviewOn: string | null;
};

export type UnitView = {
  id: number;
  domainId: number;
  number: string;
  titleAr: string;
  titleFr: string;
  heures: number;
  windowAr: string;
  questionAr: string;
  bacWeightObserved: number;
  status: Status;
  classHere: boolean;
  bricks: BrickView[];
  jalon: { id: string; status: Status; fragile: boolean; score: Score };
};

export type Nba =
  | {
      type: "brick";
      mode: "start" | "continue";
      brickId: string;
      unitId: number;
      phase: PhaseKind;
      phaseIndex: number;
      titleAr: string;
      unitTitleAr: string;
      unitNumber: string;
      objectifAr: string;
      minutes: number;
    }
  | { type: "jalon"; mode: "start" | "continue"; unitId: number; titleAr: string; unitTitleAr: string; unitNumber: string; questionAr: string; minutes: number }
  | { type: "review"; brickId: string; titleAr: string; unitTitleAr: string; minutes: number; dueOn: string; review: ReviewRow }
  | { type: "rest"; nextTitleAr: string; nextUnitAr: string; extraUsed: boolean }
  | { type: "done" };

export type Pace = {
  relation: "aligned" | "ahead" | "behind" | "free" | "finished";
  titleAr: string;
  textAr: string;
  whyAr: string;
  classUnit: number;
  studentUnit: number;
};

export type AppState = {
  learner: Learner;
  isDemo: boolean;
  today: string;
  nba: Nba;
  playableItemId: string | null;
  currentItemId: string | null;
  currentPhase: PhaseKind | null;
  pace: Pace;
  week: { days: { key: string; label: string; done: boolean; today: boolean }[]; count: number; target: number };
  units: UnitView[];
  stats: { bricksDone: number; bricksFragile: number; bricksTotal: number; jalonsDone: number; reviewsDone: number; morchidCount: number };
  upcomingReview: { brickId: string; titleAr: string; dueOn: string } | null;
  finale: { open: boolean; opensOn: string; daysToBac: number; weeksToBac: number };
  rows: ProgressRow[];
  reviewRows: ReviewRow[];
  notes: NoteRow[];
};

const SESSIONS: [string, string, string, string] = ["جلسة واحدة", "جلستان", "جلسات", "جلسة"];
const UNITS_AR: [string, string, string, string] = ["وحدة واحدة", "وحدتان", "وحدات", "وحدة"];
const WEEKS: [string, string, string, string] = ["أسبوع واحد", "أسبوعين", "أسابيع", "أسبوعاً"];

function computePace(currentIndex: number, current: PathItem | null, cls: { unit: number; phase: string }): Pace {
  const base = { classUnit: cls.unit, studentUnit: current?.unitId ?? 12 };
  if (!current) {
    return {
      ...base,
      relation: "finished",
      titleAr: "المسار مكتمل",
      textAr: "لم يبقَ إلا المراجعات المتباعدة. المرحلة النهائية تُفتح قبل البكالوريا بثمانية أسابيع.",
      whyAr: "",
    };
  }
  const student = unitById(current.unitId);
  if (cls.phase === "vacances" || cls.phase === "rentree") {
    return {
      ...base,
      relation: "free",
      titleAr: "بداية هادئة",
      textAr: "الدروس لم تنطلق بعد في القسم. لبنة في اليوم تكفي لتدخل العام مستعدّاً.",
      whyAr: "لأنها أوّل ما تبقّى في مسارك.",
    };
  }
  if (cls.phase === "revision") {
    const backlog = PATH.length - currentIndex;
    return {
      ...base,
      relation: "behind",
      titleAr: "وقت المراجعة",
      textAr: `قسمك أنهى البرنامج. تبقّى لك في المسار ${countAr(backlog, SESSIONS)}: جلستان في اليوم تكفيان قبل البكالوريا.`,
      whyAr: "لأنها أقدم ما تبقّى لك: نبدأ من حيث توقّفت.",
    };
  }
  const klass = unitById(cls.unit);
  if (current.unitId === cls.unit) {
    return {
      ...base,
      relation: "aligned",
      titleAr: "متوازٍ مع قسمك",
      textAr: `قسمك في ${klass?.number} هذا الأسبوع، وأنت كذلك. لبنة في اليوم تكفي، لا داعي للإسراع.`,
      whyAr: `لأنها التالية في مسارك، وقسمك يدرس «${klass?.titleAr}» الآن.`,
    };
  }
  if (current.unitId > cls.unit) {
    const gap = current.unitId - cls.unit;
    return {
      ...base,
      relation: "ahead",
      titleAr: "متقدّم على قسمك",
      textAr: `أنت أمام قسمك (الفارق: ${countAr(gap, UNITS_AR)}). استثمر التقدّم في المراجعة، لا في الركض.`,
      whyAr: "لأنها التالية في مسارك؛ أنت متقدّم، فلا تُضف غيرها.",
    };
  }
  const firstOfClass = PATH.findIndex((item) => item.unitId === cls.unit);
  const backlog = Math.max(1, firstOfClass - currentIndex);
  const weeks = Math.max(1, Math.ceil(backlog / 2));
  return {
    ...base,
    relation: "behind",
    titleAr: "فارق يمكن تداركه",
    textAr: `قسمك في ${klass?.number}، وأنت في ${student?.number}. تفصلك عنه ${countAr(backlog, SESSIONS)}: جلستان إضافيتان في الأسبوع تكفيان خلال ${countAr(weeks, WEEKS)}.`,
    whyAr: "لأنها أقدم ما تبقّى لك: نبدأ من حيث توقّفت، لا من حيث القسم.",
  };
}

function itemNba(item: PathItem, mode: "start" | "continue", phase: PhaseKind | null): Nba {
  const unit = unitById(item.unitId);
  const unitTitleAr = unit?.titleAr ?? "";
  const unitNumber = unit?.number ?? "";
  if (item.kind === "jalon") {
    return { type: "jalon", mode, unitId: item.unitId, titleAr: `جسر ${unitNumber}`, unitTitleAr, unitNumber, questionAr: unit?.questionAr ?? "", minutes: JALON_MINUTES };
  }
  const current = phase ?? "decouverte";
  const phaseIndex = PHASES.indexOf(current);
  const minutes = PHASES.slice(phaseIndex).reduce((sum, kind) => sum + PHASE_META[kind].minutes, 0);
  return {
    type: "brick",
    mode,
    brickId: item.id,
    unitId: item.unitId,
    phase: current,
    phaseIndex,
    titleAr: item.brick.spec.titleAr,
    unitTitleAr,
    unitNumber,
    objectifAr: item.brick.spec.objectifAr,
    minutes,
  };
}

/* ─────────────── État complet ─────────────── */

export async function getState(learnerId: string): Promise<AppState> {
  const learner = await ensureLearner(learnerId);
  const [rows, reviewRows, noteRows, eventRows] = await Promise.all([
    db.select().from(progress).where(eq(progress.learnerId, learnerId)),
    db.select().from(reviews).where(eq(reviews.learnerId, learnerId)),
    db.select().from(notes).where(eq(notes.learnerId, learnerId)).orderBy(desc(notes.createdAt)),
    db.select({ id: morchidEvents.id }).from(morchidEvents).where(eq(morchidEvents.learnerId, learnerId)),
  ]);

  const today = todayKey();
  const map = new Map(rows.map((row) => [`${row.itemId}:${row.phase}`, row]));
  const rowOf = (item: string, phase: string) => map.get(`${item}:${phase}`);
  const valid = (item: string, phase: string) => rowOf(item, phase)?.status === "valide";
  const isDone = (item: PathItem) => (item.kind === "brick" ? PHASES.every((p) => valid(item.id, p)) : valid(item.id, "jalon"));
  const isStarted = (item: PathItem) =>
    item.kind === "brick" ? PHASES.some((p) => map.has(`${item.id}:${p}`)) : map.has(`${item.id}:jalon`);

  const currentIndex = PATH.findIndex((item) => !isDone(item));
  const current = currentIndex === -1 ? null : PATH[currentIndex];
  const currentPhase = current?.kind === "brick" ? (PHASES.find((p) => !valid(current.id, p)) ?? null) : null;

  const finishedToday = PATH.filter((item) => {
    const final = item.kind === "brick" ? rowOf(item.id, "application") : rowOf(item.id, "jalon");
    return final?.status === "valide" && final.completedAt !== null && todayKey(final.completedAt) === today;
  }).length;
  const extra = learner.extraDate === today ? learner.extraCount : 0;
  const allowance = 1 + extra;

  const activeReviews = reviewRows.filter((r) => r.active).sort((a, b) => a.dueOn.localeCompare(b.dueOn));
  const due = activeReviews.find((r) => r.dueOn <= today) ?? null;
  const upcoming = activeReviews.find((r) => r.dueOn > today) ?? null;

  const cls = classPositionOn(today, learner.examDate);
  const pace = computePace(currentIndex, current, cls);

  let nba: Nba;
  let playableItemId: string | null = null;
  if (current && isStarted(current)) {
    nba = itemNba(current, "continue", currentPhase);
    playableItemId = current.id;
  } else if (due) {
    const brick = brickById(due.brickId);
    nba = {
      type: "review",
      brickId: due.brickId,
      titleAr: brick?.spec.titleAr ?? "",
      unitTitleAr: brick ? (unitById(brick.unitId)?.titleAr ?? "") : "",
      minutes: REVIEW_MINUTES,
      dueOn: due.dueOn,
      review: due,
    };
  } else if (current && finishedToday < allowance) {
    nba = itemNba(current, "start", currentPhase);
    playableItemId = current.id;
  } else if (current) {
    nba = { type: "rest", nextTitleAr: itemTitleAr(current), nextUnitAr: unitById(current.unitId)?.titleAr ?? "", extraUsed: extra > 0 };
  } else {
    nba = { type: "done" };
  }

  const reviewByBrick = new Map(activeReviews.map((r) => [r.brickId, r]));
  const scoreOf = (item: string, phase: string): Score => {
    const payload = rowOf(item, phase)?.payload;
    return payload && typeof payload.score === "number" && typeof payload.total === "number"
      ? { score: payload.score, total: payload.total }
      : null;
  };

  const units: UnitView[] = UNITS.map((unit) => {
    const bricks: BrickView[] = bricksOfUnit(unit.id).map((brick) => {
      const done = PHASES.every((p) => valid(brick.id, p));
      const status: Status = done ? "done" : current?.id === brick.id ? "current" : "locked";
      return {
        id: brick.id,
        unitId: unit.id,
        order: brick.order,
        titleAr: brick.spec.titleAr,
        titleFr: brick.spec.titleFr,
        objectifAr: brick.spec.objectifAr,
        status,
        fragile: PHASES.some((p) => rowOf(brick.id, p)?.fragile),
        phases: PHASES.map((kind) => ({
          kind,
          status: valid(brick.id, kind) ? "done" : status === "current" && kind === currentPhase ? "current" : "locked",
          fragile: Boolean(rowOf(brick.id, kind)?.fragile),
        })),
        score: scoreOf(brick.id, "application"),
        reviewOn: reviewByBrick.get(brick.id)?.dueOn ?? null,
      };
    });
    const jalonDone = valid(jalonId(unit.id), "jalon");
    const jalonStatus: Status = jalonDone ? "done" : current?.id === jalonId(unit.id) ? "current" : "locked";
    const unitDone = jalonDone && bricks.every((b) => b.status === "done");
    return {
      id: unit.id,
      domainId: unit.domainId,
      number: unit.number,
      titleAr: unit.titleAr,
      titleFr: unit.titleFr,
      heures: unit.heures,
      windowAr: unit.windowAr,
      questionAr: unit.questionAr,
      bacWeightObserved: unit.bacWeightObserved,
      status: unitDone ? "done" : current?.unitId === unit.id ? "current" : "locked",
      classHere: cls.phase === "cours" && cls.unit === unit.id,
      bricks,
      jalon: {
        id: jalonId(unit.id),
        status: jalonStatus,
        fragile: Boolean(rowOf(jalonId(unit.id), "jalon")?.fragile),
        score: scoreOf(jalonId(unit.id), "jalon"),
      },
    };
  });

  const start = weekStart(today);
  const activity = new Set<string>();
  for (const row of rows) if (row.status === "valide" && row.completedAt) activity.add(todayKey(row.completedAt));
  for (const review of reviewRows) if (review.lastDoneOn) activity.add(review.lastDoneOn);
  const days = DAYS_SHORT_AR.map((label, i) => {
    const key = addDays(start, i);
    return { key, label, done: activity.has(key), today: key === today };
  });

  const allBricks = units.flatMap((u) => u.bricks);
  const daysToBac = diffDays(today, learner.examDate);
  const upcomingBrick = upcoming ? brickById(upcoming.brickId) : undefined;

  return {
    learner,
    isDemo: learner.id === DEMO_ID,
    today,
    nba,
    playableItemId,
    currentItemId: current?.id ?? null,
    currentPhase,
    pace,
    week: { days, count: days.filter((d) => d.done).length, target: 5 },
    units,
    stats: {
      bricksDone: allBricks.filter((b) => b.status === "done").length,
      bricksFragile: allBricks.filter((b) => b.status === "done" && b.fragile).length,
      bricksTotal: BRICKS.length,
      jalonsDone: units.filter((u) => u.jalon.status === "done").length,
      reviewsDone: reviewRows.reduce((sum, r) => sum + r.doneCount, 0),
      morchidCount: eventRows.length,
    },
    upcomingReview: upcoming && upcomingBrick ? { brickId: upcoming.brickId, titleAr: upcomingBrick.spec.titleAr, dueOn: upcoming.dueOn } : null,
    finale: {
      open: daysToBac >= 0 && daysToBac <= 56,
      opensOn: addDays(learner.examDate, -56),
      daysToBac,
      weeksToBac: Math.max(0, Math.floor(daysToBac / 7)),
    },
    rows,
    reviewRows,
    notes: noteRows,
  };
}

/** Accès à un item : jouable, relecture (déjà tenu), en attente (c'est le prochain), ou fermé. */
export function itemMode(state: AppState, itemId: string): "play" | "relecture" | "attente" | "locked" {
  if (state.playableItemId === itemId) return "play";
  const index = PATH.findIndex((item) => item.id === itemId);
  const currentIndex = state.currentItemId ? PATH.findIndex((item) => item.id === state.currentItemId) : PATH.length;
  if (index < 0) return "locked";
  if (index < currentIndex) return "relecture";
  if (index === currentIndex) return "attente";
  return "locked";
}

export function payloadOf(state: AppState, itemId: string, phase: string): PhasePayload {
  return state.rows.find((row) => row.itemId === itemId && row.phase === phase)?.payload ?? {};
}

export function rowFor(state: AppState, itemId: string, phase: string): ProgressRow | undefined {
  return state.rows.find((row) => row.itemId === itemId && row.phase === phase);
}

export function previousItemTitle(itemId: string): string | null {
  const index = PATH.findIndex((item) => item.id === itemId);
  return index > 0 ? itemTitleAr(PATH[index - 1]) : null;
}
