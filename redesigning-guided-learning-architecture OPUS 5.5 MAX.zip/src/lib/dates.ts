// Dates calendaires à l'heure d'Alger, au format AAAA-MM-JJ.

const TZ = "Africa/Algiers";

export const MONTHS_AR = [
  "جانفي",
  "فيفري",
  "مارس",
  "أفريل",
  "ماي",
  "جوان",
  "جويلية",
  "أوت",
  "سبتمبر",
  "أكتوبر",
  "نوفمبر",
  "ديسمبر",
];
export const DAYS_AR = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
export const DAYS_SHORT_AR = ["أحد", "إثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"];

export function todayKey(date: Date = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

function parts(key: string) {
  const [y, m, d] = key.split("-").map(Number);
  return { y, m, d };
}

export function addDays(key: string, days: number): string {
  const { y, m, d } = parts(key);
  return new Date(Date.UTC(y, m - 1, d + days)).toISOString().slice(0, 10);
}

/** b − a, en jours. */
export function diffDays(a: string, b: string): number {
  return Math.round((Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`)) / 86_400_000);
}

/** 0 = dimanche (semaine scolaire algérienne : dimanche → jeudi). */
export function weekdayIndex(key: string): number {
  return new Date(`${key}T12:00:00Z`).getUTCDay();
}

export function weekStart(key: string): string {
  return addDays(key, -weekdayIndex(key));
}

export function keyToDate(key: string, hour = 18): Date {
  return new Date(`${key}T${String(hour).padStart(2, "0")}:00:00+01:00`);
}

export function monthOf(key: string): number {
  return parts(key).m;
}

export function formatDayAr(key: string): string {
  const { m, d } = parts(key);
  return `${DAYS_AR[weekdayIndex(key)]} ${d} ${MONTHS_AR[m - 1]}`;
}

export function formatShortAr(key: string): string {
  const { m, d } = parts(key);
  return `${d} ${MONTHS_AR[m - 1]}`;
}

export function formatFr(key: string): string {
  const { y, m, d } = parts(key);
  return new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "long", timeZone: "UTC" }).format(
    new Date(Date.UTC(y, m - 1, d)),
  );
}

/** Le Bac SVT tombe d'ordinaire à la mi-juin : 14 juin par défaut, modifiable dans « أنا ». */
export function defaultExamDate(today: string = todayKey()): string {
  const { y } = parts(today);
  const thisYear = `${y}-06-14`;
  return today < thisYear ? thisYear : `${y + 1}-06-14`;
}

export function isDateKey(value: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`));
}

/** Accords arabes simples : 1, 2, 3–10, 11+. */
export function countAr(n: number, forms: [one: string, two: string, few: string, many: string]): string {
  if (n === 1) return forms[0];
  if (n === 2) return forms[1];
  if (n >= 3 && n <= 10) return `${n} ${forms[2]}`;
  return `${n} ${forms[3]}`;
}
