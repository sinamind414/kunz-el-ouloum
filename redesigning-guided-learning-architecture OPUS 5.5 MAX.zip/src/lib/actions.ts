// src/lib/actions.ts — toutes les écritures. Chaque verrou est validé ICI,
// côté serveur : le client ne reçoit jamais les bonnes réponses.

import { and, asc, eq, lte } from "drizzle-orm";
import { cookies } from "next/headers";
import { db } from "@/db";
import {
  learners,
  morchidEvents,
  notes,
  progress,
  reviews,
  type ErrorType,
  type MorchidMoment,
  type PhaseKind,
  type PhasePayload,
  type ProgressPhase,
} from "@/db/schema";
import { brickById, jalonChecklist, jalonId, rubricOf, teethSentences, unitById, unitIdFromJalon } from "@/lib/curriculum";
import { addDays, diffDays, formatDayAr, isDateKey, todayKey } from "@/lib/dates";
import { COOKIE, DEMO_ID, currentLearnerId, ensureLearner, getState, progressId } from "@/lib/engine";
import * as M from "@/lib/morchid";

export type ActionResult = { ok: boolean; error?: string; morchid?: string; info?: string; done?: boolean };

const fail = (error: string): ActionResult => ({ ok: false, error });

async function log(learner: string, itemId: string, moment: MorchidMoment, body: string) {
  await db.insert(morchidEvents).values({ learnerId: learner, itemId, moment, body });
  return body;
}

async function loadRow(learner: string, item: string, phase: ProgressPhase) {
  const [row] = await db.select().from(progress).where(eq(progress.id, progressId(learner, item, phase))).limit(1);
  return row ?? null;
}

async function saveRow(
  learner: string,
  item: string,
  phase: ProgressPhase,
  data: { status: "en_cours" | "valide"; fragile?: boolean; attempts: number; payload: PhasePayload },
) {
  const now = new Date();
  const values = {
    status: data.status,
    fragile: data.fragile ?? false,
    attempts: data.attempts,
    payload: data.payload,
    completedAt: data.status === "valide" ? now : null,
    updatedAt: now,
  };
  await db
    .insert(progress)
    .values({ id: progressId(learner, item, phase), learnerId: learner, itemId: item, phase, ...values })
    .onConflictDoUpdate({ target: progress.id, set: values });
}

async function scheduleReview(learner: string, brickId: string, fragile: boolean, inDays: number) {
  const dueOn = addDays(todayKey(), inDays);
  await db
    .insert(reviews)
    .values({ id: `${learner}:${brickId}`, learnerId: learner, brickId, dueOn, step: 0, fragile, active: true })
    .onConflictDoUpdate({ target: reviews.id, set: { dueOn, fragile, active: true, step: 0 } });
  return dueOn;
}

function choiceIn(value: unknown, length: number): number | null {
  const n = Number(value);
  return Number.isInteger(n) && n >= 0 && n < length ? n : null;
}

function indexList(value: unknown, length: number): number[] {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.map(Number).filter((n) => Number.isInteger(n) && n >= 0 && n < length))].sort((a, b) => a - b);
}

/* ─────────────── Brique : les 4 phases ─────────────── */

async function brickAction(learner: string, type: string, body: Record<string, unknown>): Promise<ActionResult> {
  const brickId = String(body.brickId ?? "");
  const brick = brickById(brickId);
  if (!brick) return fail("لبنة غير موجودة.");
  const state = await getState(learner);
  if (state.playableItemId !== brickId) {
    if (state.currentItemId !== brickId) return fail("هذه اللبنة لم تُفتح بعد، أو أنها مثبّتة: المسار خطّي.");
    if (state.nba.type === "review") return fail("مراجعة قصيرة تنتظرك أولاً في صفحة «اليوم».");
    if (state.nba.type === "rest") return fail("يكفي اليوم. هذه اللبنة تنتظرك غداً.");
    return fail("هذه اللبنة ليست مهمّة اليوم.");
  }
  const phase = state.currentPhase as PhaseKind | null;
  if (!phase) return fail("اللبنة مكتملة.");
  const row = await loadRow(learner, brickId, phase);
  const payload: PhasePayload = { ...(row?.payload ?? {}) };
  const attempts = row?.attempts ?? 0;
  const spec = brick.spec;

  const keep = (status: "en_cours" | "valide", fragile: boolean, tries: number) =>
    saveRow(learner, brickId, phase, { status, fragile, attempts: tries, payload });

  if (type === "stuck") {
    const used = payload.stuck ?? 0;
    if (used >= 2) return fail("استعملتَ الإعانتين في هذه المرحلة. الخطوة التالية لك.");
    const hint = M.stuckHint(phase, { probeDone: payload.probeChoice !== undefined, answerDone: Boolean(payload.answer) }, brick);
    payload.stuck = used + 1;
    payload.morchid = hint;
    await keep("en_cours", row?.fragile ?? false, attempts);
    return { ok: true, morchid: await log(learner, brickId, "relance", hint) };
  }

  if (phase === "decouverte") {
    if (type === "probe") {
      if (payload.probeChoice !== undefined) return fail("فرضيتك مسجّلة.");
      const choice = choiceIn(body.choice, spec.checks[0].optionsAr.length);
      if (choice === null) return fail("اختر فرضية.");
      payload.probeChoice = choice;
      payload.probeCorrect = choice === spec.checks[0].correct;
      payload.morchid = M.probeFeedback(payload.probeCorrect);
      await keep("en_cours", false, 0);
      return { ok: true, morchid: await log(learner, brickId, "sonde", payload.morchid) };
    }
    if (type === "gate") {
      if (payload.probeChoice === undefined) return fail("السؤال القبلي أولاً.");
      const check = spec.checks[1] ?? spec.checks[0];
      const choice = choiceIn(body.choice, check.optionsAr.length);
      if (choice === null) return fail("اختر جواباً.");
      const tries = attempts + 1;
      if (choice === check.correct) {
        payload.morchid = undefined;
        await keep("valide", false, tries);
        return { ok: true, done: true, info: "المفهوم مثبّت. المرحلة التالية: المصطلحات." };
      }
      if (tries < 2) {
        payload.morchid = M.gateRelance();
        await keep("en_cours", false, tries);
        return { ok: true, morchid: await log(learner, brickId, "relance", payload.morchid) };
      }
      payload.morchid = M.gateReveal(check.optionsAr[check.correct], check.whyAr);
      await keep("valide", true, tries);
      return { ok: true, done: true, morchid: await log(learner, brickId, "relance", payload.morchid) };
    }
  }

  if (phase === "vocabulaire" && type === "vocab") {
    const answers = (body.answers ?? {}) as Record<string, unknown>;
    if (spec.vocab.some((_, i) => choiceIn(answers[String(i)], spec.vocab.length) === null)) {
      return fail("اربط التعاريف الأربعة قبل التحقّق.");
    }
    const wrong = spec.vocab.map((_, i) => i).filter((i) => Number(answers[String(i)]) !== i);
    const tries = attempts + 1;
    if (!wrong.length) {
      payload.morchid = undefined;
      await keep("valide", false, tries);
      return { ok: true, done: true, info: "المصطلحات الأربعة مثبّتة." };
    }
    if (tries < 2) {
      payload.morchid = M.vocabRelance(wrong.length);
      await keep("en_cours", false, tries);
      return { ok: true, morchid: await log(learner, brickId, "relance", payload.morchid) };
    }
    payload.morchid = M.vocabReveal(wrong.map((i) => ({ term: spec.vocab[i].termAr, def: spec.vocab[i].defAr })));
    await keep("valide", true, tries);
    return { ok: true, done: true, morchid: await log(learner, brickId, "relance", payload.morchid) };
  }

  if (phase === "methodologie" && type === "teeth") {
    const sentences = teethSentences(brick);
    const answers = (body.answers ?? {}) as Record<string, unknown>;
    if (sentences.some((_, i) => choiceIn(Number(answers[String(i)]) - 1, 4) === null)) {
      return fail("أسند كل جملة إلى سنّ قبل التحقّق.");
    }
    const wrong = sentences.map((_, i) => i).filter((i) => Number(answers[String(i)]) !== i + 1);
    const tries = attempts + 1;
    if (!wrong.length) {
      payload.morchid = M.methodClose(spec.methode.checkAr);
      await keep("valide", false, tries);
      return { ok: true, done: true, morchid: await log(learner, brickId, "cle", payload.morchid) };
    }
    if (tries < 2) {
      payload.morchid = M.toothHint(wrong[0] + 1);
      await keep("en_cours", false, tries);
      return { ok: true, morchid: await log(learner, brickId, "cle", payload.morchid) };
    }
    payload.morchid = `${M.toothReveal(sentences)}\n${M.methodClose(spec.methode.checkAr)}`;
    await keep("valide", true, tries);
    return { ok: true, done: true, morchid: await log(learner, brickId, "cle", payload.morchid) };
  }

  if (phase === "application") {
    if (type === "answer") {
      if (payload.answer) return fail("إجابتك مسجّلة. قيّمها الآن بالسلّم.");
      const text = String(body.text ?? "").trim();
      if (text.length < 40) return fail("اكتب إجابة حقيقية — بضعة أسطر كما في ورقة الامتحان.");
      payload.answer = text.slice(0, 2400);
      payload.morchid = undefined;
      await keep("en_cours", false, attempts);
      return { ok: true, info: "إجابتك مسجّلة. سلّم التنقيط ظاهر الآن." };
    }
    if (type === "selfcheck") {
      if (!payload.answer) return fail("اكتب أولاً، ثم قيّم.");
      if (payload.needsType) return fail("حدّد نوع الخطأ أولاً.");
      const rubric = rubricOf(brick);
      const ticked = indexList(body.ticked, rubric.length);
      const score = ticked.reduce((sum, i) => sum + rubric[i].points, 0);
      const total = rubric.reduce((sum, item) => sum + item.points, 0);
      payload.ticked = ticked;
      payload.score = score;
      payload.total = total;
      if (score / total >= 0.6) {
        const due = await scheduleReview(learner, brickId, false, 3);
        payload.morchid = M.clotureLine(spec.objectifAr, due, false);
        await keep("valide", false, attempts + 1);
        return { ok: true, done: true, morchid: await log(learner, brickId, "cloture", payload.morchid) };
      }
      payload.needsType = true;
      payload.morchid = M.diagnosticAsk(score, total);
      await keep("en_cours", false, attempts + 1);
      return { ok: true, morchid: await log(learner, brickId, "diagnostic", payload.morchid) };
    }
    if (type === "errortype") {
      if (!payload.needsType) return fail("لا حاجة للتشخيص: إجابتك صلبة.");
      const code = String(body.code ?? "") as ErrorType;
      if (!["T1", "T2", "T3", "T4"].includes(code)) return fail("اختر نوعاً واحداً.");
      payload.errorType = code;
      const reply = await log(learner, brickId, "diagnostic", M.diagnosticReply(code, brick));
      const due = await scheduleReview(learner, brickId, true, 1);
      const closing = await log(learner, brickId, "cloture", M.clotureLine(spec.objectifAr, due, true));
      payload.morchid = `${reply}\n${closing}`;
      await keep("valide", true, attempts + 1);
      return { ok: true, done: true, morchid: payload.morchid };
    }
  }

  return fail("هذه الخطوة لا تخصّ المرحلة الحالية.");
}

/* ─────────────── Jalon d'unité (جسر) ─────────────── */

async function jalonAction(learner: string, type: string, body: Record<string, unknown>): Promise<ActionResult> {
  const unitId = Number(body.unitId);
  const unit = unitById(unitId);
  if (!unit) return fail("وحدة غير موجودة.");
  const item = jalonId(unitId);
  const state = await getState(learner);
  if (state.playableItemId !== item) {
    return fail(state.nba.type === "review" ? "مراجعة قصيرة تنتظرك أولاً." : "هذا الجسر ليس مهمّة اليوم.");
  }
  const row = await loadRow(learner, item, "jalon");
  const payload: PhasePayload = { ...(row?.payload ?? {}) };

  if (type === "jalon-answer") {
    if (payload.answer) return fail("الحصيلة مسجّلة.");
    const text = String(body.text ?? "").trim();
    if (text.length < 60) return fail("اكتب حصيلة حقيقية: خمسة أسطر على الأقل تجيب عن سؤال الوحدة.");
    payload.answer = text.slice(0, 3000);
    await saveRow(learner, item, "jalon", { status: "en_cours", attempts: 0, payload });
    return { ok: true, info: "حصيلتك مسجّلة. قارنها الآن بقائمة التحقّق." };
  }

  if (type === "jalon-check") {
    if (!payload.answer) return fail("اكتب الحصيلة أولاً.");
    const list = jalonChecklist(unitId);
    const ticked = indexList(body.ticked, list.length);
    const fragile = ticked.length / list.length < 0.6;
    const missedIdea = list.findIndex((entry, i) => entry.kind === "idee" && !ticked.includes(i));
    const unitView = state.units.find((u) => u.id === unitId);
    const weakId = missedIdea >= 0 ? list[missedIdea].brickId : (unitView?.bricks.find((b) => b.fragile)?.id ?? null);
    let weakest: string | null = null;
    let due: string | null = null;
    if (weakId) {
      weakest = brickById(weakId)?.spec.titleAr ?? null;
      due = await scheduleReview(learner, weakId, true, 1);
    }
    payload.ticked = ticked;
    payload.score = ticked.length;
    payload.total = list.length;
    payload.morchid = M.jalonLine(unit, weakest, due, fragile);
    await saveRow(learner, item, "jalon", { status: "valide", fragile, attempts: (row?.attempts ?? 0) + 1, payload });
    return { ok: true, done: true, morchid: await log(learner, item, "jalon", payload.morchid) };
  }

  return fail("إجراء غير معروف.");
}

/* ─────────────── Rappel espacé ─────────────── */

async function reviewAction(learner: string, body: Record<string, unknown>): Promise<ActionResult> {
  const today = todayKey();
  const [due] = await db
    .select()
    .from(reviews)
    .where(and(eq(reviews.learnerId, learner), eq(reviews.active, true), lte(reviews.dueOn, today)))
    .orderBy(asc(reviews.dueOn))
    .limit(1);
  if (!due) return fail("لا مراجعة مستحقّة اليوم.");
  const brick = brickById(due.brickId);
  if (!brick) return fail("لبنة غير موجودة.");
  const check = brick.spec.checks[2] ?? brick.spec.checks[0];
  const vocabIndex = due.doneCount % brick.spec.vocab.length;
  const choice = choiceIn(body.choice, check.optionsAr.length);
  const term = choiceIn(body.term, brick.spec.vocab.length);
  const sentence = String(body.sentence ?? "").trim();
  if (choice === null || term === null) return fail("أجب عن السؤالين.");
  if (sentence.length < 15) return fail("اكتب الفكرة الأساسية في جملة كاملة.");

  if (choice === check.correct && term === vocabIndex) {
    const step = due.step + 1;
    const retire = step >= 3;
    const next = retire ? due.dueOn : addDays(today, step === 1 ? 7 : 21);
    await db
      .update(reviews)
      .set({ step, dueOn: next, active: !retire, fragile: false, lastDoneOn: today, doneCount: due.doneCount + 1 })
      .where(eq(reviews.id, due.id));
    return { ok: true, done: true, info: retire ? "ثابتة نهائياً: لن تعود هذه اللبنة." : `ثابتة. تعود يوم ${formatDayAr(next)}.` };
  }

  await db
    .update(reviews)
    .set({ dueOn: addDays(today, 1), fragile: true, lastDoneOn: today, doneCount: due.doneCount + 1 })
    .where(eq(reviews.id, due.id));
  const why = choice !== check.correct ? check.whyAr : `المصطلح المقصود: «${brick.spec.vocab[vocabIndex].termAr}».`;
  return { ok: true, done: true, info: `ما زالت هشّة. ${why} تعود غداً في ست دقائق.` };
}

/* ─────────────── Point d'entrée ─────────────── */

export async function runAction(body: Record<string, unknown>): Promise<ActionResult> {
  const type = String(body.type ?? "");
  const learnerId = await currentLearnerId();
  const learner = await ensureLearner(learnerId);
  const jar = await cookies();
  const cookieOptions = { path: "/", httpOnly: true, sameSite: "lax" as const, maxAge: 60 * 60 * 24 * 365 };

  switch (type) {
    case "probe":
    case "gate":
    case "vocab":
    case "teeth":
    case "answer":
    case "selfcheck":
    case "errortype":
    case "stuck":
      return brickAction(learnerId, type, body);
    case "jalon-answer":
    case "jalon-check":
      return jalonAction(learnerId, type, body);
    case "review":
      return reviewAction(learnerId, body);
    case "extra": {
      const state = await getState(learnerId);
      if (state.nba.type !== "rest") return fail("مهمّة اليوم لم تكتمل بعد.");
      if (state.nba.extraUsed) return fail("جلسة إضافية واحدة في اليوم: الإيقاع أهمّ من الكمّ.");
      await db.update(learners).set({ extraDate: todayKey(), extraCount: 1 }).where(eq(learners.id, learnerId));
      return { ok: true, info: "جلسة إضافية مفتوحة لليوم فقط." };
    }
    case "note": {
      const kind = body.kind === "question" ? "question" : "note";
      const text = String(body.body ?? "").trim();
      if (text.length < 3) return fail("الملاحظة قصيرة جداً.");
      const itemId = typeof body.itemId === "string" && body.itemId ? body.itemId : null;
      const unitId = itemId ? (brickById(itemId)?.unitId ?? unitIdFromJalon(itemId)) : Number(body.unitId) || null;
      await db.insert(notes).values({ learnerId, kind, unitId, itemId, body: text.slice(0, 600) });
      return {
        ok: true,
        info: kind === "question" ? "سؤالك محفوظ: يعود إليك في جسر الوحدة، لا قبل." : "محفوظة في كرّاستك.",
      };
    }
    case "profile": {
      const name = String(body.name ?? "").trim();
      const examDate = String(body.examDate ?? "");
      if (name.length < 2 || name.length > 40) return fail("الاسم بين حرفين وأربعين حرفاً.");
      if (!isDateKey(examDate)) return fail("تاريخ غير صالح.");
      const span = diffDays(todayKey(), examDate);
      if (span < -30 || span > 800) return fail("التاريخ بعيد جداً عن السنة الدراسية.");
      await db.update(learners).set({ name, examDate }).where(eq(learners.id, learnerId));
      return { ok: true, info: "تمّ الحفظ. الإيقاع أعيد حسابه." };
    }
    case "new-learner": {
      const id = `l-${crypto.randomUUID().slice(0, 8)}`;
      await ensureLearner(id);
      jar.set(COOKIE, id, cookieOptions);
      return { ok: true, info: "مسار جديد يبدأ من اللبنة الأولى." };
    }
    case "reset-demo": {
      await db.delete(progress).where(eq(progress.learnerId, DEMO_ID));
      await db.delete(reviews).where(eq(reviews.learnerId, DEMO_ID));
      await db.delete(morchidEvents).where(eq(morchidEvents.learnerId, DEMO_ID));
      await db.delete(notes).where(eq(notes.learnerId, DEMO_ID));
      await db.delete(learners).where(eq(learners.id, DEMO_ID));
      await ensureLearner(DEMO_ID);
      jar.set(COOKIE, DEMO_ID, cookieOptions);
      return { ok: true, info: "عدتَ إلى مسار لينا التجريبي." };
    }
    default:
      void learner;
      return fail("إجراء غير معروف.");
  }
}
