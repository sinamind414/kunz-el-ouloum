// src/lib/blueprint.ts — le document produit (livrables 1 à 4), en français.
// Chaque règle décrite ici est celle qu'applique le code (engine.ts, actions.ts).

export type Level = "premier-plan" | "dans-la-brique" | "sous-menu" | "masque";

export const LEVELS: Record<Level, { label: string; hint: string; tone: string }> = {
  "premier-plan": { label: "Premier plan", hint: "Visible dès l'ouverture ou onglet principal.", tone: "bg-[#d7e6dc] text-[#143d2e]" },
  "dans-la-brique": { label: "Dans la brique", hint: "N'est plus une destination : devient une phase ou le support d'une phase.", tone: "bg-[#1f5c45] text-[#fbf8f1]" },
  "sous-menu": { label: "Sous-menu", hint: "À un geste depuis l'un des 4 onglets, quand c'est utile.", tone: "bg-[#f3e6c4] text-[#8a5a3c]" },
  masque: { label: "Masqué au quotidien", hint: "Réglage, jalon, J-56, ou supprimé.", tone: "bg-[#ece6da] text-[#6b6458]" },
};

export const PILLARS = [
  {
    id: "aujourdhui",
    ar: "اليوم",
    fr: "Aujourd'hui",
    route: "/",
    question: "Que dois-je faire maintenant ?",
    role: "La seule tâche du jour (Next Best Action), le rythme de la semaine, la position face à la classe. Rien d'autre.",
    contains: ["Carte Next Best Action", "Rappel espacé quand il est dû", "Rythme hebdomadaire 5/7", "Rail « toi / ta classe »"],
  },
  {
    id: "parcours",
    ar: "مساري",
    fr: "Parcours",
    route: "/parcours",
    question: "Où vais-je ?",
    role: "Le chemin linéaire : 3 domaines, 11 unités, 19 briques, 11 jalons. Tout est visible, seule l'étape courante s'ouvre ; ce qui est tenu reste relisible.",
    contains: ["Briques (séances de 19 min)", "Jalons d'unité (جسر)", "Relecture des briques tenues"],
  },
  {
    id: "bac",
    ar: "البكالوريا",
    fr: "Bac",
    route: "/bac",
    question: "Suis-je prêt pour l'épreuve ?",
    role: "Ce qui ressemble à l'examen, débloqué par le parcours : copies corrigées, jalons, poids réel des unités. Phase finale à J-56.",
    contains: ["Mes copies (applications Bac)", "Jalons d'unité", "« Ce qui tombe vraiment »", "Plan final + épreuve blanche (J-56)"],
  },
  {
    id: "moi",
    ar: "أنا",
    fr: "Moi",
    route: "/moi",
    question: "Où en suis-je, calmement ?",
    role: "Suivi sans pression et réglages : olivier des jalons, carnet (tadwin + questions garées), date du Bac, suivi parent/enseignant, compte.",
    contains: ["Olivier des jalons", "Carnet", "Date du Bac", "Suivi adulte", "Compte"],
  },
] as const;

export type LegacyRow = { legacy: string; ar: string; origin: string; destination: string; level: Level; why: string };

/** Les 35 surfaces relevées dans le dépôt (App.tsx, trainingHub.ts, src/components, src/data). */
export const LEGACY_MAP: LegacyRow[] = [
  { legacy: "home", ar: "الرئيسية", origin: "Onglet principal", destination: "Aujourd'hui → carte Next Best Action unique", level: "premier-plan", why: "L'accueil n'est plus un mur de cartes : une tâche, une durée, un bouton." },
  { legacy: "lesson", ar: "الدروس", origin: "Onglet principal", destination: "Phase 1 « Découverte » de chaque brique · relecture dans Parcours", level: "dans-la-brique", why: "On n'entre plus par une liste de leçons : la leçon arrive le jour où elle sert." },
  { legacy: "review", ar: "المراجعة", origin: "Onglet principal", destination: "Rappel espacé sur Aujourd'hui, seulement quand il est dû", level: "premier-plan", why: "Le rappel passe avant le neuf, mais n'est plus une rubrique à visiter." },
  { legacy: "chat", ar: "المرشد", origin: "Onglet principal", destination: "Supprimé comme onglet · Morchid à 4 moments de la brique", level: "dans-la-brique", why: "Un chat ouvert invite exactement les sollicitations désordonnées à supprimer." },
  { legacy: "stats", ar: "تقدمي", origin: "Onglet principal", destination: "Moi → olivier des jalons, chiffres rédigés en phrases", level: "sous-menu", why: "Le suivi se consulte ; il ne se pratique pas chaque jour." },
  { legacy: "focus", ar: "المؤقّت (تركيز)", origin: "Menu « المزيد »", destination: "Minuteur de 19 min intégré à la séance (règle d'or 20–25 min)", level: "dans-la-brique", why: "Un minuteur séparé est un détour ; dans la séance, il cadre sans être visité." },
  { legacy: "training", ar: "التمارين والتدريب", origin: "Menu « المزيد » (hub à 8 portes)", destination: "Supprimé — ses 8 portes sont redistribuées ci-dessous", level: "masque", why: "Un hub de 8 portes, c'est une bibliothèque dans la bibliothèque." },
  { legacy: "mindmap", ar: "الخرائط الذهنية", origin: "Menu « المزيد »", destination: "Synthèse de l'unité au jalon, puis relisible dans Parcours", level: "sous-menu", why: "La carte de synthèse a du sens après l'unité, pas avant." },
  { legacy: "methodology", ar: "مفتاح المنهجية", origin: "Menu « المزيد »", destination: "Phase 3 « Méthode » : clé à 4 dents فعل · دليل · علاقة · جواب", level: "dans-la-brique", why: "La méthode se pratique chaque jour sur un document, pas dans un cours à part." },
  { legacy: "badges", ar: "الأوسمة والإنجازات", origin: "Menu « المزيد »", destination: "Moi → olivier : une feuille par brique, une olive par jalon", level: "masque", why: "Une récompense se regarde de temps en temps ; elle ne concurrence pas la tâche." },
  { legacy: "teacher", ar: "لوحة المتابعة", origin: "Menu « المزيد »", destination: "Moi → suivi parent/enseignant (la même vue que l'élève)", level: "masque", why: "Utile aux adultes, inutile à la séance du jour." },
  { legacy: "plan", ar: "خطة المراجعة النهائية", origin: "Hub Entraînement", destination: "Bac → phase finale, ouverte à J-56", level: "masque", why: "Avant J-56, le moteur Next Best Action EST le plan ; un second plan crée un conflit." },
  { legacy: "bacideas", ar: "أفكار التمارين حسب الدورة", origin: "Hub Entraînement", destination: "Bac → « Ce qui tombe vraiment » (poids constaté par unité)", level: "sous-menu", why: "Utile pour prioriser en fin d'année, pas pour choisir quoi faire ce soir." },
  { legacy: "situations", ar: "تمارين بالوضعيات", origin: "Hub Entraînement", destination: "Phase 4 « Application Bac » + jalon d'unité", level: "dans-la-brique", why: "La situation arrive quand la notion est prête à être appliquée." },
  { legacy: "schemas", ar: "ارسم من الذاكرة", origin: "Hub Entraînement", destination: "Extension de la phase 2 pour les briques à schéma obligatoire", level: "dans-la-brique", why: "Le schéma est du vocabulaire visuel : il se rappelle, il ne se feuillette pas." },
  { legacy: "bootcamp", ar: "تحدي البكالوريا", origin: "Hub Entraînement", destination: "Bac → épreuve blanche chronométrée (J-56)", level: "masque", why: "La pression d'examen trop tôt ajoute du stress sans ajouter d'apprentissage." },
  { legacy: "workshop", ar: "الورشة التفاعلية", origin: "Hub Entraînement", destination: "Phase 4 : production écrite AVANT le barème", level: "dans-la-brique", why: "Produire est le geste central ; il n'a pas besoin d'une salle à part." },
  { legacy: "animations", ar: "الأنميشن العلمي", origin: "Hub Entraînement", destination: "Support visuel de la phase 1 quand la brique en a un", level: "dans-la-brique", why: "Une animation sert une notion précise, jamais une flânerie." },
  { legacy: "tadwin", ar: "التدوين الشامل", origin: "Hub Entraînement", destination: "Tiroir « دوّن » dans chaque séance + carnet dans Moi", level: "sous-menu", why: "On note là où l'idée naît ; on relit dans un seul carnet." },
  { legacy: "SplashView", ar: "شاشة الانطلاق", origin: "Écran", destination: "Première ouverture seulement", level: "masque", why: "Chaque seconde avant la tâche est une décision de plus." },
  { legacy: "MotivationDeclic", ar: "الدافع اليومي", origin: "Overlay quotidien", destination: "Remplacé par la ligne « pourquoi celle-ci ? » de la carte du jour", level: "masque", why: "Une raison concrète motive mieux qu'une citation." },
  { legacy: "DailyGoalWidget · TodayCard · SmartReminderCard · BoussoleCard", ar: "بطاقات الرئيسية", origin: "Cartes de l'accueil", destination: "Fusionnées dans la carte Next Best Action", level: "premier-plan", why: "Quatre cartes qui disent « fais quelque chose » = aucune qui dit quoi." },
  { legacy: "StudyReminderModal", ar: "التذكير", origin: "Modale", destination: "Un seul rappel quotidien, qui ouvre directement la tâche du jour", level: "masque", why: "Le rappel pointe une action, jamais un menu." },
  { legacy: "StreakCelebrationModal", ar: "سلسلة الأيام", origin: "Modale", destination: "Rythme hebdomadaire 5/7, sans série à casser", level: "masque", why: "La peur de casser la série est un stress, pas une motivation." },
  { legacy: "WeeklyReportShareModal", ar: "التقرير الأسبوعي", origin: "Modale", destination: "Moi → suivi adulte", level: "masque", why: "Le rapport s'adresse aux adultes." },
  { legacy: "SearchView", ar: "البحث", origin: "Écran", destination: "Limité à la relecture des briques déjà tenues", level: "masque", why: "Chercher dans tout le programme, c'est rouvrir la bibliothèque." },
  { legacy: "QcmLivreView · QcmBilanView", ar: "أسئلة الكتاب", origin: "Écrans", destination: "Verrous de phase et rappels espacés", level: "dans-la-brique", why: "Un QCM n'a de valeur qu'au moment où il verrouille ou ravive." },
  { legacy: "MicroCapsulePanel · microRemediations", ar: "الكبسولات", origin: "Panneau", destination: "Contenu des relances « أنا عالق » de Morchid", level: "dans-la-brique", why: "La remédiation arrive quand l'élève bloque, pas en libre-service." },
  { legacy: "CorrecteurPanel · WritingReviewPanel", ar: "المصحّح", origin: "Panneaux", destination: "Phase 4 : barème + diagnostic T1–T4", level: "dans-la-brique", why: "Corriger, c'est d'abord nommer son type d'erreur." },
  { legacy: "Bac2025ExamView · MockExamPanel · CombatTrainerView", ar: "مواضيع وامتحانات", origin: "Écrans", destination: "Bac → épreuve blanche (J-56)", level: "masque", why: "Un seul format d'examen blanc, au bon moment." },
  { legacy: "ElectrophoresisSimulator · ScienceAnimations", ar: "المحاكيات", origin: "Écrans", destination: "Support de phase 1 (unité 2)", level: "dans-la-brique", why: "Le simulateur sert la brique « charge et migration », pas une vitrine." },
  { legacy: "UnitIntroPortal · unitOpenings", ar: "افتتاح الوحدة", origin: "Portail", destination: "Sonde de la 1re brique de l'unité", level: "dans-la-brique", why: "L'ouverture d'unité devient une question, pas une page d'accueil de plus." },
  { legacy: "TahlilWall", ar: "جدار التحليل", origin: "Écran", destination: "Phase 3 « Méthode »", level: "dans-la-brique", why: "L'analyse de document est le cœur de la phase 3." },
  { legacy: "BackupPanel · StudentAuthView", ar: "الحساب والنسخ الاحتياطي", origin: "Panneaux", destination: "Moi → compte", level: "masque", why: "Réglage ponctuel." },
  { legacy: "okacha · hosila · HtmlLessonViewer", ar: "المتون والحصائل", origin: "Corpus", destination: "Sources des phases 1 et 2 (contenu, pas navigation)", level: "dans-la-brique", why: "Le corpus alimente les briques ; il n'est plus un rayonnage." },
];

export const UNLOCK_RULES = [
  {
    title: "Verrou de phase",
    rule: "Découverte → Vocabulaire → Méthode → Application : la phase suivante n'apparaît qu'une fois la précédente validée. Il n'existe aucun bouton « passer ».",
  },
  {
    title: "La copie avant le barème",
    rule: "En phase 4, le barème et le piège ne s'affichent qu'après une réponse écrite. On produit d'abord, on compare ensuite.",
  },
  {
    title: "Verrou de brique",
    rule: "La brique N+1 s'ouvre quand la brique N est entièrement validée. Les briques à venir sont visibles (pour savoir où l'on va), jamais jouables.",
  },
  {
    title: "Jalon d'unité (جسر)",
    rule: "Après la dernière brique d'une unité : synthèse de mémoire sur la question de l'unité, puis check-list (idées-clés + pièges officiels). Il ouvre l'unité suivante et ressort les questions garées.",
  },
  {
    title: "Quota quotidien",
    rule: "Une seule nouvelle séance par jour (brique ou jalon), plus une séance bonus au maximum, à la demande. Finir tôt n'ouvre pas le catalogue : l'écran passe en « يكفي اليوم ».",
  },
  {
    title: "Rappel prioritaire",
    rule: "Un rappel dû passe avant toute nouveauté : 6 minutes (1 question, 1 mot, 1 phrase). J+1 si la brique était fragile, sinon J+3, puis J+7 et J+21. Échec : retour le lendemain.",
  },
  {
    title: "Valve anti-mur",
    rule: "Deux échecs sur un même verrou : Morchid révèle, la phase est validée « fragile » et revient en rappel le lendemain. L'élève n'est jamais coincé.",
  },
  {
    title: "Calage sur la classe",
    rule: "Le rythme se mesure à la progression officielle (التدرج السنوي), pas au programme entier. En retard : une proposition chiffrée, par exemple 2 séances de plus par semaine pendant 2 semaines.",
  },
];

export const CALM = {
  yes: [
    "Olivier : une feuille par brique (verte = solide, dorée = fragile), une olive par jalon.",
    "Rythme hebdomadaire 5/7 : un jour manqué ne casse rien.",
    "Jalons = ponts (جسور) entre unités, salués par une phrase de Morchid.",
    "Copies Bac qui s'accumulent : la preuve tangible du travail fait.",
  ],
  no: [
    "XP et niveaux",
    "Classements entre élèves",
    "Série quotidienne à ne pas casser",
    "Compte à rebours J-xxx sur l'accueil",
    "Pourcentage global du programme",
    "Confettis et notifications de relance",
  ],
};

export const DASHBOARD_ZONES = [
  {
    zone: "Zone 0",
    name: "En-tête",
    content: "Date en clair, salutation, une phrase : « une seule tâche aujourd'hui, le reste attend ». Image calme (olivier).",
    rule: "Aucun compteur, aucun badge.",
  },
  {
    zone: "Zone 1",
    name: "Carte Next Best Action — ≈ 70 % de l'attention",
    content:
      "Type et durée (brique 19 min · rappel 6 min · jalon 20 min · repos) ; unité ; titre ; objectif en 5 mots ; bande des 4 phases ; ligne Morchid seulement si la prochaine phase l'implique ; UN bouton ; « pourquoi celle-ci ? ».",
    rule: "Un seul bouton primaire sur tout l'écran.",
  },
  {
    zone: "Zone 2",
    name: "Rythme de la semaine",
    content: "7 jours (dimanche → samedi), objectif 5 séances, jour courant cerclé.",
    rule: "Aucune série à perdre.",
  },
  {
    zone: "Zone 3",
    name: "Position face à la classe",
    content:
      "Rail des 11 unités groupées par domaine, deux repères : « القسم » (la classe selon التدرج السنوي) et « أنت ». Une phrase : aligné, en avance, ou en retard avec un plan de rattrapage chiffré en séances.",
    rule: "Jamais de pourcentage du programme, jamais de rouge.",
  },
  {
    zone: "Zone 4",
    name: "Rien d'autre",
    content: "Le Bac, les badges, les statistiques et la date de l'examen vivent ailleurs.",
    rule: "Si un élément n'aide pas à démarrer la séance, il quitte l'accueil.",
  },
];

export const DASHBOARD_STATES = [
  { state: "Brique du jour", text: "« لبنة اليوم · 19 دقيقة » → lance la séance." },
  { state: "Reprise", text: "« أكمل لبنتك · المرحلة 3 من 4 » → reprend exactement là où l'on s'est arrêté." },
  { state: "Rappel dû", text: "Le formulaire de 6 minutes s'affiche dans la carte, avant toute nouveauté." },
  { state: "Jalon", text: "« أغلق الوحدة قبل أن تفتح التالية » → synthèse de l'unité." },
  { state: "Repos", text: "« يكفي اليوم » + aperçu de demain + une séance bonus possible." },
];

export const NO_PANIC = [
  "Comparer à la classe, pas au programme : « aligné avec ta classe » rassure, « 12 % du programme » paralyse.",
  "Traduire un retard en séances : « 4 séances te séparent de ta classe : 2 de plus par semaine suffisent pendant 2 semaines ».",
  "Montrer des unités (11 points), jamais des pourcentages.",
  "La date du Bac et les semaines restantes vivent dans « Moi », jamais sur l'accueil.",
  "Palette sans rouge : le doré signale « fragile, à revoir », pas « échec ».",
];
