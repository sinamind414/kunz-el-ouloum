// src/lib/curriculum.ts — programme officiel 3AS + découpe en séances quotidiennes.
//
// Hiérarchie : domaine → unité (programme national) → BRIQUE (1 séance de
// 19 min, 4 phases) → jalon d'unité (جسر). L'ordre de PATH est l'unique
// chemin de l'élève : il n'existe aucune autre porte d'entrée vers le contenu.

import type { PhaseKind } from "@/db/schema";
import { BRIQUE_SPECS, type BriqueSpec } from "@/lib/seedData";
import { diffDays, monthOf } from "@/lib/dates";

/* ─────────────── La boucle d'une brique ─────────────── */

export const PHASES: PhaseKind[] = ["decouverte", "vocabulaire", "methodologie", "application"];

export type PhaseMeta = {
  ar: string;
  fr: string;
  minutes: number;
  gesteAr: string;
  gesteFr: string;
  verrouAr: string;
  verrouFr: string;
  morchidAr: string | null;
  morchidFr: string | null;
  interditAr: string;
  interditFr: string;
};

export const PHASE_META: Record<PhaseKind, PhaseMeta> = {
  decouverte: {
    ar: "اكتشاف",
    fr: "Découverte conceptuelle",
    minutes: 4,
    gesteAr: "فرضية أولاً، ثم مفهوم واحد",
    gesteFr: "Poser une hypothèse, puis lire UNE notion",
    verrouAr: "سؤال تثبيت واحد بعد القراءة",
    verrouFr: "1 question de vérification après la lecture",
    morchidAr: "يبدأ بسؤال قبلي واحد قبل أي درس",
    morchidFr: "Sonde : 1 question avant tout contenu",
    interditAr: "لا تمرين ولا سلّم تنقيط هنا",
    interditFr: "Aucun exercice, aucun barème",
  },
  vocabulaire: {
    ar: "مصطلحات",
    fr: "Vocabulaire scientifique",
    minutes: 3,
    gesteAr: "أربعة مصطلحات، كلٌّ بتعريفه الدقيق",
    gesteFr: "Associer 4 termes à leur définition exacte",
    verrouAr: "ربط المصطلحات الأربعة دون خطأ",
    verrouFr: "4 associations justes sur 4",
    morchidAr: null,
    morchidFr: null,
    interditAr: "لا قاموس ولا قائمة خارج اللبنة",
    interditFr: "Pas de lexique global à feuilleter",
  },
  methodologie: {
    ar: "منهجية",
    fr: "Méthodologie d'analyse de document",
    minutes: 6,
    gesteAr: "مفتاح المنهجية: فعل · دليل · علاقة · جواب",
    gesteFr: "Ranger une réponse modèle dans les 4 dents de la clé",
    verrouAr: "إسناد كل جملة إلى سنّها",
    verrouFr: "Chaque phrase dans la bonne dent",
    morchidAr: "يشرح سنّاً واحدة في كل محاولة",
    morchidFr: "Clé : explique UNE dent par essai",
    interditAr: "لا تكتب جواباً كاملاً هنا",
    interditFr: "Pas de rédaction complète",
  },
  application: {
    ar: "تطبيق بكالوريا",
    fr: "Application type Bac",
    minutes: 6,
    gesteAr: "أكتب أولاً، ثم أقيّم بسلّم التنقيط",
    gesteFr: "Rédiger, puis s'auto-évaluer avec le barème",
    verrouAr: "إجابة مكتوبة ثم تقييم ذاتي، أو تشخيص الخطأ",
    verrouFr: "Copie écrite + auto-évaluation ≥ 6/10, sinon diagnostic",
    morchidAr: "يتدخّل فقط إن كانت الإجابة هشّة",
    morchidFr: "Diagnostic T1–T4 si la copie est sous 6/10",
    interditAr: "لا سلّم قبل أن تكتب",
    interditFr: "Pas de barème avant la copie",
  },
};

export const BRICK_MINUTES = PHASES.reduce((sum, phase) => sum + PHASE_META[phase].minutes, 0);
export const JALON_MINUTES = 20;
export const REVIEW_MINUTES = 6;

/** Les 4 dents de مفتاح المنهجية (Boussole / Miftah de l'application héritée). */
export const TEETH = [
  {
    n: 1,
    ar: "فعل",
    nameAr: "أحدّد فعل الأداء",
    questionAr: "ما المطلوب بالضبط؟",
    triadAr: "",
    roleAr: "أطوّق فعل الأداء والكلمات المفتاحية، ولا أكتب جواباً هنا.",
  },
  {
    n: 2,
    ar: "دليل",
    nameAr: "أستخرج المعطيات",
    questionAr: "ما الذي أملك؟",
    triadAr: "ألاحظ",
    roleAr: "قيمة + وحدة + اتجاه التغيّر من الوثيقة، دون تفسير.",
  },
  {
    n: 3,
    ar: "علاقة",
    nameAr: "أربط السبب بالنتيجة",
    questionAr: "هل يسمح الفعل بـ«لأنّ»؟",
    triadAr: "أستنتج",
    roleAr: "الربط السببي: لأنّ… إذن…",
  },
  {
    n: 4,
    ar: "جواب",
    nameAr: "أعيد صياغة المطلوب",
    questionAr: "ما الخلاصة؟",
    triadAr: "أخلص",
    roleAr: "جملة ختامية تعيد صياغة المطلوب كحقيقة علمية.",
  },
] as const;

/* ─────────────── Programme national 3AS (التدرج السنوي 2017) ─────────────── */

export type Domain = { id: 1 | 2 | 3; titleAr: string; shortAr: string; titleFr: string; image: string };

export const DOMAINS: Domain[] = [
  { id: 1, titleAr: "التخصص الوظيفي للبروتينات", shortAr: "البروتينات", titleFr: "Spécialisation des protéines", image: "/images/proteins.jpg" },
  { id: 2, titleAr: "التحوّلات الطاقوية على مستوى ما فوق البنية الخلوية", shortAr: "الطاقة", titleFr: "Conversions énergétiques", image: "/images/leaf.jpg" },
  { id: 3, titleAr: "التكتونية العامة", shortAr: "التكتونية", titleFr: "Tectonique globale", image: "/images/earth.jpg" },
];

export type Unit = {
  id: number;
  domainId: 1 | 2 | 3;
  number: string;
  titleAr: string;
  titleFr: string;
  competenceAr: string;
  questionAr: string;
  heures: number;
  trimestre: 1 | 2 | 3;
  /** Fenêtre officielle (MM-JJ) : sert à situer la classe, jamais à bloquer. */
  window: { from: string; to: string };
  windowAr: string;
  /** Part des points constatée dans les sessions indexées par l'application. */
  bacWeightObserved: number;
  trapsAr: string[];
};

export const UNITS: Unit[] = [
  {
    id: 1,
    domainId: 1,
    number: "الوحدة 1",
    titleAr: "تركيب البروتين",
    titleFr: "Synthèse des protéines",
    competenceAr: "يحدّد آليات تركيب البروتين",
    questionAr: "كيف تتحوّل معلومة مكتوبة في ADN إلى بروتين يعمل داخل الخلية؟",
    heures: 8,
    trimestre: 1,
    window: { from: "09-08", to: "09-30" },
    windowAr: "سبتمبر",
    bacWeightObserved: 18.6,
    trapsAr: [
      "الخلط بين الاستنساخ والترجمة عند تحديد مستوى تدخّل دواء أو سمّ.",
      "كتابة الثيمين T في ARNm بدل اليوراسيل U.",
    ],
  },
  {
    id: 2,
    domainId: 1,
    number: "الوحدة 2",
    titleAr: "العلاقة بين بنية ووظيفة البروتين",
    titleFr: "Structure et fonction des protéines",
    competenceAr: "يجد العلاقة بين البنية والتخصص الوظيفي للبروتين",
    questionAr: "كيف تحدّد البنية الفراغية للبروتين وظيفته؟",
    heures: 5,
    trimestre: 1,
    window: { from: "10-01", to: "10-07" },
    windowAr: "الأسبوع الأول من أكتوبر",
    bacWeightObserved: 5.1,
    trapsAr: [
      "الخلط بين المهبط والمصعد عند قراءة اتجاه الهجرة الكهربائية.",
      "نسيان أنّ شحنة الحمض الأميني تتعلّق بـ pH الوسط مقارنةً بـ pHi.",
    ],
  },
  {
    id: 3,
    domainId: 1,
    number: "الوحدة 3",
    titleAr: "النشاط الإنزيمي للبروتينات",
    titleFr: "Activité enzymatique",
    competenceAr: "يُظهر التخصص الوظيفي للبروتينات في التحفيز الإنزيمي",
    questionAr: "كيف يحفّز الإنزيم تفاعلاً حيوياً بهذه الدقّة؟",
    heures: 5,
    trimestre: 1,
    window: { from: "10-08", to: "10-14" },
    windowAr: "الأسبوع الثاني من أكتوبر",
    bacWeightObserved: 14.7,
    trapsAr: ["الخلط بين Km و Vmax عند تفسير منحنى مثبّط.", "اعتبار الإنزيم يُستهلك في التفاعل."],
  },
  {
    id: 4,
    domainId: 1,
    number: "الوحدة 4",
    titleAr: "دور البروتينات في الدفاع عن الذات",
    titleFr: "Immunité",
    competenceAr: "يُظهر التخصص الوظيفي للبروتينات في الدفاع عن الذات",
    questionAr: "كيف تميّز العضوية الذات عن اللاذات وتتخلّص من الغازي؟",
    heures: 18,
    trimestre: 1,
    window: { from: "10-15", to: "11-30" },
    windowAr: "منتصف أكتوبر ← نهاية نوفمبر",
    bacWeightObserved: 20,
    trapsAr: [
      "القول إنّ الجسم المضاد يقتل المستضد بنفسه.",
      "الخلط بين دور الخلية البلازمية (الإفراز) ودور LTc (تخريب الخلية المصابة).",
    ],
  },
  {
    id: 5,
    domainId: 1,
    number: "الوحدة 5",
    titleAr: "دور البروتينات في الاتصال العصبي",
    titleFr: "Communication nerveuse",
    competenceAr: "يُظهر التخصص الوظيفي للبروتينات في الاتصال العصبي",
    questionAr: "كيف تُترجم الرسالة العصبية على مستوى المشبك؟",
    heures: 15,
    trimestre: 1,
    window: { from: "12-01", to: "01-21" },
    windowAr: "ديسمبر ← منتصف جانفي",
    bacWeightObserved: 18.6,
    trapsAr: [
      "الخلط بين تأثير قبل مشبكي (تحرير المبلّغ) وتأثير بعد مشبكي (المستقبِل).",
      "نسيان دور شوارد الكالسيوم في تحرير المبلّغ العصبي.",
    ],
  },
  {
    id: 6,
    domainId: 2,
    number: "الوحدة 6",
    titleAr: "آليات تحويل الطاقة الضوئية إلى طاقة كيميائية كامنة",
    titleFr: "Photosynthèse",
    competenceAr: "يعرف آليات تحويل الطاقة الضوئية إلى طاقة كيميائية كامنة في الجزيئات العضوية",
    questionAr: "كيف يحوّل النبات طاقة الضوء إلى مادة عضوية؟",
    heures: 15,
    trimestre: 2,
    window: { from: "01-22", to: "02-14" },
    windowAr: "نهاية جانفي ← منتصف فيفري",
    bacWeightObserved: 11.7,
    trapsAr: ["وضع حلقة كالفن داخل التيلاكويد بدل الحشوة.", "اعتبار الأكسجين المنطلق آتياً من CO₂ بدل الماء."],
  },
  {
    id: 7,
    domainId: 2,
    number: "الوحدة 7",
    titleAr: "آليات تحويل الطاقة الكيميائية الكامنة إلى ATP",
    titleFr: "Respiration et fermentation",
    competenceAr: "يحدّد آليات تحويل الطاقة الكامنة في الجزيئات العضوية إلى ATP",
    questionAr: "كيف تستخرج الخلية الطاقة المخزّنة في الغلوكوز، وبأيّ مردود؟",
    heures: 15,
    trimestre: 2,
    window: { from: "02-15", to: "03-14" },
    windowAr: "منتصف فيفري ← منتصف مارس",
    bacWeightObserved: 6.7,
    trapsAr: [
      "نسبة معظم ATP إلى حلقة كريبس بدل الفسفرة التأكسدية.",
      "وضع التحلّل السكري داخل الميتوكوندري بدل الهيولى.",
    ],
  },
  {
    id: 8,
    domainId: 2,
    number: "الوحدة 8",
    titleAr: "تحويل الطاقة على مستوى ما فوق البنية الخلوية",
    titleFr: "Bilan énergétique cellulaire",
    competenceAr: "ينشئ مخططاً تحصيلياً للتحوّلات الطاقوية على المستوى الخلوي",
    questionAr: "كيف تتكامل العضيّتان داخل خلية واحدة لتأمين حصيلة طاقوية متوازنة؟",
    heures: 2,
    trimestre: 2,
    window: { from: "03-15", to: "04-04" },
    windowAr: "بعد اختبارات الفصل الثاني",
    bacWeightObserved: 1.1,
    trapsAr: ["اعتبار انعدام المبادلات الغازية عند نقطة التعويض توقّفاً للوظيفتين."],
  },
  {
    id: 9,
    domainId: 3,
    number: "الوحدة 9",
    titleAr: "النشاط التكتوني للصفائح",
    titleFr: "Activité tectonique des plaques",
    competenceAr: "يقترح تفسيراً للنشاط التكتوني للصفائح",
    questionAr: "ما الذي يحرّك الصفائح، وماذا يحدث عند حدودها؟",
    heures: 10,
    trimestre: 3,
    window: { from: "04-05", to: "04-18" },
    windowAr: "النصف الأول من أفريل",
    bacWeightObserved: 1.1,
    trapsAr: [
      "تفسير الانصهار بارتفاع الحرارة وحده دون دور الماء.",
      "جعل الصفيحة القارية تغوص تحت الصفيحة المحيطية.",
    ],
  },
  {
    id: 10,
    domainId: 3,
    number: "الوحدة 10",
    titleAr: "بنية الكرة الأرضية",
    titleFr: "Structure du globe",
    competenceAr: "يصف نموذج بنية الكرة الأرضية اعتماداً على معطيات سيسمولوجية",
    questionAr: "كيف نعرف ما بداخل الأرض ولم ندخلها قطّ؟",
    heures: 2,
    trimestre: 3,
    window: { from: "04-19", to: "04-30" },
    windowAr: "النصف الثاني من أفريل",
    bacWeightObserved: 1.1,
    trapsAr: [
      "الاستدلال بتباطؤ الأمواج P وحده على سيولة النواة الخارجية.",
      "الخلط بين انقطاع موهو وانقطاع غوتنبرغ.",
    ],
  },
  {
    id: 11,
    domainId: 3,
    number: "الوحدة 11",
    titleAr: "النشاط التكتوني والبنيات الجيولوجية المرتبطة به",
    titleFr: "Structures géologiques",
    competenceAr: "يتعرّف على البنيات الجيولوجية والظواهر المرتبطة بالنشاط التكتوني",
    questionAr: "كيف نقرأ في الصخور تاريخ بناء القشرة وهدمها؟",
    heures: 13,
    trimestre: 3,
    window: { from: "05-01", to: "05-25" },
    windowAr: "ماي",
    bacWeightObserved: 1.1,
    trapsAr: ["تصنيف منطقة جيولوجية بمجرّد وجود البراكين.", "وضع الغرانيت في القشرة المحيطية."],
  },
];

/* ─────────────── Briques et chemin unique ─────────────── */

export type Brick = { id: string; unitId: number; order: number; spec: BriqueSpec };

export const BRICKS: Brick[] = (() => {
  const counters = new Map<number, number>();
  return [...BRIQUE_SPECS]
    .sort((a, b) => a.unitId - b.unitId)
    .map((spec) => {
      const order = (counters.get(spec.unitId) ?? 0) + 1;
      counters.set(spec.unitId, order);
      return { id: `u${spec.unitId}-b${order}`, unitId: spec.unitId, order, spec };
    });
})();

export function jalonId(unitId: number): string {
  return `jalon-u${unitId}`;
}

export function unitIdFromJalon(id: string): number | null {
  const match = id.match(/^jalon-u(\d+)$/);
  return match ? Number(match[1]) : null;
}

export function brickById(id: string): Brick | undefined {
  return BRICKS.find((brick) => brick.id === id);
}

export function unitById(id: number): Unit | undefined {
  return UNITS.find((unit) => unit.id === id);
}

export function bricksOfUnit(unitId: number): Brick[] {
  return BRICKS.filter((brick) => brick.unitId === unitId);
}

export type PathItem =
  | { kind: "brick"; id: string; unitId: number; brick: Brick }
  | { kind: "jalon"; id: string; unitId: number };

/** L'unique chemin : briques de l'unité, puis son jalon, unité après unité. */
export const PATH: PathItem[] = UNITS.flatMap((unit) => [
  ...bricksOfUnit(unit.id).map((brick) => ({ kind: "brick" as const, id: brick.id, unitId: unit.id, brick })),
  { kind: "jalon" as const, id: jalonId(unit.id), unitId: unit.id },
]);

export function itemTitleAr(item: PathItem): string {
  if (item.kind === "brick") return item.brick.spec.titleAr;
  const unit = unitById(item.unitId);
  return `جسر ${unit?.number ?? ""}: ${unit?.titleAr ?? ""}`;
}

/* ─────────────── Matière dérivée pour les verrous ─────────────── */

/** Les 4 phrases de la démonstration, préfixe « السنّ n : » retiré, dans l'ordre des dents. */
export function teethSentences(brick: Brick): string[] {
  return brick.spec.methode.demoAr
    .split("\n")
    .map((line) => line.replace(/^\s*السنّ\s*\d\s*:\s*/, "").trim())
    .filter(Boolean)
    .slice(0, 4);
}

/** Barème de la phase 4 : « 2 ن : … » → { points: 2, textAr: "…" }. */
export function rubricOf(brick: Brick): { textAr: string; points: number }[] {
  return brick.spec.application.attendusAr.map((line) => {
    const match = line.match(/^\s*([\d.,]+)\s*ن\s*:?\s*/);
    return {
      textAr: match ? line.slice(match[0].length).trim() : line,
      points: match ? Number(match[1].replace(",", ".")) : 1,
    };
  });
}

export type JalonItem = { kind: "idee" | "piege"; brickId: string | null; textAr: string };

/** Check-list du jalon : idées-clés des briques de l'unité + pièges officiels de l'unité. */
export function jalonChecklist(unitId: number): JalonItem[] {
  const unit = unitById(unitId);
  const bricks = bricksOfUnit(unitId);
  const perBrick = bricks.length === 1 ? 3 : 1;
  const ideas: JalonItem[] = bricks.flatMap((brick) =>
    brick.spec.concept.keyPointsAr.slice(0, perBrick).map((textAr) => ({ kind: "idee" as const, brickId: brick.id, textAr })),
  );
  const traps: JalonItem[] = (unit?.trapsAr ?? []).map((textAr) => ({ kind: "piege" as const, brickId: null, textAr }));
  return [...ideas, ...traps];
}

/** Permutation déterministe (jamais l'identité) : même ordre au serveur et au client. */
export function seededOrder(n: number, seed: string): number[] {
  let hash = 2166136261;
  for (let i = 0; i < seed.length; i += 1) hash = Math.imul(hash ^ seed.charCodeAt(i), 16777619);
  const order = Array.from({ length: n }, (_, i) => i);
  for (let i = n - 1; i > 0; i -= 1) {
    hash = Math.imul(hash ^ (hash >>> 15), 2246822507);
    hash = Math.imul(hash ^ (hash >>> 13), 3266489909);
    const j = (hash >>> 0) % (i + 1);
    [order[i], order[j]] = [order[j], order[i]];
  }
  if (n > 1 && order.every((value, index) => value === index)) order.push(order.shift() as number);
  return order;
}

/* ─────────────── Où en est la classe ? (التدرج السنوي) ─────────────── */

export type ClassPosition = { unit: number; phase: "vacances" | "rentree" | "cours" | "revision" };

function schoolYearStart(key: string): number {
  const [year, month] = key.split("-").map(Number);
  return month >= 9 ? year : year - 1;
}

function offsetOf(monthDay: string, startYear: number): number {
  const [month, day] = monthDay.split("-").map(Number);
  const year = month >= 9 ? startYear : startYear + 1;
  return diffDays(`${startYear}-09-01`, `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`);
}

/** Position de la classe selon la progression officielle — un repère, jamais un verrou. */
export function classPositionOn(today: string, examDate: string): ClassPosition {
  const month = monthOf(today);
  if (month === 7 || month === 8 || today >= examDate) return { unit: 0, phase: "vacances" };
  const start = schoolYearStart(today);
  const offset = diffDays(`${start}-09-01`, today);
  if (offset < offsetOf(UNITS[0].window.from, start)) return { unit: 0, phase: "rentree" };
  for (const unit of UNITS) {
    if (offset <= offsetOf(unit.window.to, start)) return { unit: unit.id, phase: "cours" };
  }
  return { unit: 12, phase: "revision" };
}
