import Link from "next/link";
import { Lock } from "lucide-react";
import { ExtraButton } from "@/components/widgets";
import type { AppState } from "@/lib/engine";

export function Gate({ title, text }: { title: string; text: string }) {
  return (
    <section className="card mx-auto mt-6 max-w-lg p-6 text-center">
      <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-cream text-mute">
        <Lock className="h-5 w-5" />
      </span>
      <h1 className="mt-4 font-naskh text-2xl">{title}</h1>
      <p className="mt-2 text-sm leading-7 text-mute">{text}</p>
      <Link href="/parcours" className="btn-ghost mt-5">
        العودة إلى المسار
      </Link>
    </section>
  );
}

/** L'item est le prochain du chemin, mais autre chose passe avant aujourd'hui. */
export function Waiting({ state }: { state: AppState }) {
  if (state.nba.type === "review") {
    return (
      <section className="card mx-auto mt-6 max-w-lg p-6 text-center">
        <p className="eyebrow">قبل الجديد</p>
        <h1 className="mt-2 font-naskh text-2xl">مراجعة قصيرة تنتظرك أولاً</h1>
        <p className="mt-2 text-sm leading-7 text-mute">
          ست دقائق على «{state.nba.titleAr}»، ثم تُفتح هذه المهمّة. نثبّت ما سبق قبل أن نبني فوقه.
        </p>
        <Link href="/" className="btn-primary mt-5">
          إلى المراجعة
        </Link>
      </section>
    );
  }
  if (state.nba.type === "rest") {
    return (
      <section className="card mx-auto mt-6 max-w-lg p-6 text-center">
        <p className="eyebrow">يكفي اليوم</p>
        <h1 className="mt-2 font-naskh text-2xl">هذه المهمّة تنتظرك غداً</h1>
        <p className="mt-2 text-sm leading-7 text-mute">
          جلسة واحدة جديدة في اليوم: هكذا يبقى الإيقاع ثابتاً حتى جوان. إن كان لديك وقت حقيقي، جلسة إضافية واحدة ممكنة.
        </p>
        {!state.nba.extraUsed && (
          <div className="mt-5 flex justify-center">
            <ExtraButton />
          </div>
        )}
      </section>
    );
  }
  return <Gate title="ليست مهمّة اليوم" text="عُد إلى صفحة «اليوم»: المهمّة الوحيدة ذات الأولوية هناك." />;
}

export function MorchidQuote({ text, light = false }: { text: string; light?: boolean }) {
  return (
    <div className={`flex gap-3 rounded-2xl p-4 ${light ? "bg-paper/10" : "bg-forest-deep text-paper"}`}>
      <img src="/images/morchid.jpg" alt="المرشد" className="h-11 w-11 shrink-0 rounded-2xl object-cover" />
      <div>
        <p className="text-[11px] font-bold text-gold-soft">المرشد · كلمة الختام</p>
        <p className="mt-1 whitespace-pre-line text-sm leading-7">{text}</p>
      </div>
    </div>
  );
}
