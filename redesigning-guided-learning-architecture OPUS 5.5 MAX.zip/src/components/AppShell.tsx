"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import { GraduationCap, Route, Sprout, Sun } from "lucide-react";

/** Les 4 piliers — et rien d'autre en navigation. Morchid n'a pas d'onglet. */
const TABS = [
  { href: "/", ar: "اليوم", fr: "Aujourd'hui", Icon: Sun, active: (p: string) => p === "/" },
  { href: "/parcours", ar: "مساري", fr: "Parcours", Icon: Route, active: (p: string) => p.startsWith("/parcours") },
  { href: "/bac", ar: "البكالوريا", fr: "Bac", Icon: GraduationCap, active: (p: string) => p.startsWith("/bac") },
  { href: "/moi", ar: "أنا", fr: "Moi", Icon: Sprout, active: (p: string) => p.startsWith("/moi") },
] as const;

export default function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname() || "/";

  if (pathname.startsWith("/architecture")) {
    return (
      <div dir="ltr" lang="fr" className="min-h-dvh bg-[#f6f2ea] font-fr text-ink">
        {children}
      </div>
    );
  }

  // Mode séance : une brique ou un jalon en cours → plus aucune navigation concurrente.
  const focus = /^\/parcours\/.+/.test(pathname);

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-3xl flex-col">
      <header className="sticky top-0 z-30 border-b border-line/70 bg-cream/90 backdrop-blur-md">
        <div className="flex items-center justify-between gap-3 px-4 py-3 md:px-6">
          <Link href="/" className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-2xl bg-forest-deep font-naskh text-lg font-bold text-gold-soft">
              ك
            </span>
            <span className="leading-tight">
              <span className="block font-naskh text-lg font-bold text-forest-deep">كنز العلوم</span>
              <span className="block text-[10px] font-medium text-mute">علوم الطبيعة والحياة · بكالوريا</span>
            </span>
          </Link>
          {!focus && (
            <nav className="hidden items-center gap-1 md:flex" aria-label="الأقسام الرئيسية">
              {TABS.map(({ href, ar, Icon, active }) => {
                const on = active(pathname);
                return (
                  <Link
                    key={href}
                    href={href}
                    className={`flex items-center gap-1.5 rounded-full px-3.5 py-2 text-sm font-semibold transition ${
                      on ? "bg-forest-deep text-paper" : "text-ink-soft hover:bg-paper"
                    }`}
                  >
                    <Icon className="h-4 w-4" strokeWidth={on ? 2.4 : 1.8} />
                    {ar}
                  </Link>
                );
              })}
            </nav>
          )}
          {focus ? (
            <Link href="/" className="btn-ghost">
              أكمل لاحقاً
            </Link>
          ) : (
            <Link href="/architecture" dir="ltr" className="rounded-full border border-line bg-paper px-3 py-1 font-fr text-[10px] font-semibold text-mute">
              Architecture
            </Link>
          )}
        </div>
      </header>

      <main className={`flex-1 px-4 pt-5 md:px-6 ${focus ? "pb-12" : "pb-32 md:pb-14"}`}>{children}</main>

      {!focus && (
        <nav
          className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-paper/95 px-2 pb-[max(10px,env(safe-area-inset-bottom))] pt-2 backdrop-blur-md md:hidden"
          aria-label="الأقسام الرئيسية"
        >
          <ul className="mx-auto grid max-w-md grid-cols-4 gap-1">
            {TABS.map(({ href, ar, fr, Icon, active }) => {
              const on = active(pathname);
              return (
                <li key={href}>
                  <Link
                    href={href}
                    className={`flex flex-col items-center rounded-2xl px-1 py-1.5 transition ${
                      on ? "bg-sage text-forest-deep" : "text-mute"
                    }`}
                  >
                    <Icon className="h-5 w-5" strokeWidth={on ? 2.4 : 1.8} />
                    <span className="mt-0.5 text-[11px] font-bold">{ar}</span>
                    <span dir="ltr" className="font-fr text-[9px] opacity-70">
                      {fr}
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      )}
    </div>
  );
}
