"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Clock, NotebookPen } from "lucide-react";

export type ActionResponse = { ok: boolean; error?: string; info?: string; morchid?: string; done?: boolean };

export async function postAction(payload: Record<string, unknown>): Promise<ActionResponse> {
  try {
    const res = await fetch("/api/action", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    return (await res.json()) as ActionResponse;
  } catch {
    return { ok: false, error: "تعذّر الاتصال. أعد المحاولة." };
  }
}

export function Options({
  options,
  value,
  onChange,
  name,
}: {
  options: { key: number; label: string }[];
  value: number | null;
  onChange: (key: number) => void;
  name: string;
}) {
  return (
    <div className="mt-4 grid gap-2" role="radiogroup" aria-label={name}>
      {options.map((option) => (
        <button
          key={option.key}
          type="button"
          role="radio"
          aria-checked={value === option.key}
          data-on={value === option.key}
          onClick={() => onChange(option.key)}
          className="option"
        >
          <span
            className={`mt-1.5 h-3.5 w-3.5 shrink-0 rounded-full border ${
              value === option.key ? "border-forest bg-forest" : "border-line bg-paper"
            }`}
          />
          <span>{option.label}</span>
        </button>
      ))}
    </div>
  );
}

export function Notice({ tone, children }: { tone: "info" | "error"; children: React.ReactNode }) {
  return (
    <p
      className={`rounded-2xl px-4 py-2.5 text-sm leading-7 ${
        tone === "info" ? "bg-sage-soft text-forest-deep" : "border border-gold/40 bg-gold-soft/60 text-clay"
      }`}
    >
      {children}
    </p>
  );
}

/** Repère de temps doux : 19 min proposées, alerte calme à 25 min (règle d'or 20–25). */
export function SessionTimer({ minutes }: { minutes: number }) {
  const [elapsed, setElapsed] = useState(0);
  useEffect(() => {
    const timer = window.setInterval(() => setElapsed((value) => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, []);
  const left = minutes * 60 - elapsed;
  const abs = Math.abs(left);
  const label = `${left < 0 ? "+" : ""}${Math.floor(abs / 60)}:${String(abs % 60).padStart(2, "0")}`;
  const message = elapsed > 25 * 60 ? "25 دقيقة: أغلق هنا وأكمل غداً" : left < 0 ? "أنهِ الجملة ثم أغلق" : "الوقت المقترح";
  return (
    <div className="flex items-center gap-2 rounded-full border border-line bg-paper px-3 py-1.5 text-xs">
      <Clock className="h-3.5 w-3.5 text-forest" />
      <span dir="ltr" className="font-fr font-semibold tabular-nums text-forest-deep">
        {label}
      </span>
      <span className="text-mute">{message}</span>
    </div>
  );
}

/** Tiroir « دوّن » : une note, ou une question garée qui ressortira au jalon de l'unité. */
export function NoteDrawer({ itemId, unitId }: { itemId?: string; unitId?: number }) {
  const [open, setOpen] = useState(false);
  const [kind, setKind] = useState<"note" | "question">("note");
  const [text, setText] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const router = useRouter();

  async function save() {
    setPending(true);
    const result = await postAction({ type: "note", kind, body: text, itemId, unitId });
    setPending(false);
    setMessage(result.ok ? (result.info ?? "محفوظة.") : (result.error ?? "تعذّر الحفظ."));
    if (result.ok) {
      setText("");
      router.refresh();
    }
  }

  return (
    <div className="w-full">
      <button type="button" onClick={() => setOpen((v) => !v)} className="btn-ghost">
        <NotebookPen className="h-4 w-4" /> دوّن
      </button>
      {open && (
        <div className="card mt-3 space-y-3 p-4">
          <div className="flex gap-2">
            <button type="button" data-on={kind === "note"} onClick={() => setKind("note")} className="chip">
              ملاحظة
            </button>
            <button type="button" data-on={kind === "question"} onClick={() => setKind("question")} className="chip">
              سؤال مؤجّل
            </button>
          </div>
          <p className="text-xs leading-6 text-mute">
            {kind === "question"
              ? "سؤال خارج هذه اللبنة؟ لا نفتح حواراً الآن: يُحفظ ويعود إليك في جسر الوحدة."
              : "ثلاثة أسطر بأسلوبك، تجدها في كرّاستك (صفحة «أنا»)."}
          </p>
          <textarea value={text} onChange={(e) => setText(e.target.value)} rows={3} className="field" />
          <div className="flex items-center justify-between gap-3">
            <span className="text-xs text-mute">{message}</span>
            <button type="button" disabled={pending || text.trim().length < 3} onClick={save} className="btn-primary !px-5 !py-2">
              احفظ
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/** Rappel espacé : 1 question, 1 mot, 1 phrase — 6 minutes, avant toute nouveauté. */
export function ReviewForm({
  check,
  vocab,
}: {
  check: { promptAr: string; options: string[] };
  vocab: { defAr: string; terms: { i: number; termAr: string }[] };
}) {
  const router = useRouter();
  const [choice, setChoice] = useState<number | null>(null);
  const [term, setTerm] = useState<number | null>(null);
  const [sentence, setSentence] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);

  async function submit() {
    setPending(true);
    setError(null);
    const response = await postAction({ type: "review", choice, term, sentence });
    setPending(false);
    if (!response.ok) setError(response.error ?? "تعذّر الحفظ.");
    else setResult(response.info ?? "سُجّلت المراجعة.");
  }

  if (result) {
    return (
      <div className="mt-4 space-y-3">
        <Notice tone="info">{result}</Notice>
        <button type="button" onClick={() => router.refresh()} className="btn-primary w-full">
          متابعة إلى مهمّة اليوم
        </button>
      </div>
    );
  }

  return (
    <div className="mt-4 space-y-5">
      <div>
        <p className="text-sm font-semibold leading-7">1. {check.promptAr}</p>
        <Options name="سؤال المراجعة" options={check.options.map((label, key) => ({ key, label }))} value={choice} onChange={setChoice} />
      </div>
      <div>
        <p className="text-sm font-semibold leading-7">2. أيّ مصطلح يوافق هذا التعريف؟</p>
        <p className="mt-1 text-sm leading-7 text-ink-soft">«{vocab.defAr}»</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {vocab.terms.map((t) => (
            <button key={t.i} type="button" data-on={term === t.i} onClick={() => setTerm(t.i)} className="chip">
              {t.termAr}
            </button>
          ))}
        </div>
      </div>
      <div>
        <p className="text-sm font-semibold leading-7">3. الفكرة التي يجب أن تبقى، في جملة واحدة</p>
        <textarea value={sentence} onChange={(e) => setSentence(e.target.value)} rows={2} className="field mt-2" />
      </div>
      {error && <Notice tone="error">{error}</Notice>}
      <button
        type="button"
        disabled={pending || choice === null || term === null || sentence.trim().length < 15}
        onClick={submit}
        className="btn-primary w-full"
      >
        أنهِ المراجعة
      </button>
    </div>
  );
}

export function ExtraButton() {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  return (
    <div className="space-y-2">
      <button
        type="button"
        disabled={pending}
        onClick={async () => {
          setPending(true);
          const result = await postAction({ type: "extra" });
          setPending(false);
          if (!result.ok) setError(result.error ?? "تعذّر.");
          router.refresh();
        }}
        className="btn-ghost"
      >
        لديّ 19 دقيقة أخرى اليوم
      </button>
      {error && <p className="text-xs text-clay">{error}</p>}
    </div>
  );
}

export function JalonForm({
  unitId,
  questionAr,
  answer,
  checklist,
  parked,
}: {
  unitId: number;
  questionAr: string;
  answer: string | null;
  checklist: { kind: "idee" | "piege"; textAr: string }[];
  parked: string[];
}) {
  const router = useRouter();
  const [text, setText] = useState("");
  const [ticked, setTicked] = useState<number[]>([]);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function send(payload: Record<string, unknown>) {
    setPending(true);
    setError(null);
    const result = await postAction({ unitId, ...payload });
    setPending(false);
    if (!result.ok) setError(result.error ?? "تعذّر الحفظ.");
    router.refresh();
  }

  if (!answer) {
    return (
      <div className="space-y-4">
        <section className="card p-5">
          <p className="eyebrow">سؤال الوحدة</p>
          <h2 className="mt-2 font-naskh text-2xl leading-snug">{questionAr}</h2>
          <p className="mt-3 text-sm leading-7 text-mute">
            أجب من ذاكرتك في خمسة إلى ثمانية أسطر، كأنك تشرح الوحدة لزميل. لا تفتح أي درس: هذا ما يجعل الجسر جسراً.
          </p>
        </section>
        {parked.length > 0 && (
          <section className="rounded-[24px] bg-gold-soft/60 p-5">
            <p className="eyebrow">أسئلتك المؤجّلة لهذه الوحدة</p>
            <ul className="mt-2 space-y-1 text-sm leading-7">
              {parked.map((q) => (
                <li key={q}>• {q}</li>
              ))}
            </ul>
            <p className="mt-2 text-xs text-clay">حاول أن تجيب عنها داخل حصيلتك: هذا موعدها.</p>
          </section>
        )}
        <textarea value={text} onChange={(e) => setText(e.target.value)} rows={9} className="field" placeholder="ابدأ من المعلومة الأولى في الوحدة وانتهِ بالخلاصة…" />
        {error && <Notice tone="error">{error}</Notice>}
        <button type="button" disabled={pending || text.trim().length < 60} onClick={() => send({ type: "jalon-answer", text })} className="btn-primary w-full">
          سلّم الحصيلة
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <section className="card p-5">
        <p className="eyebrow">حصيلتك</p>
        <p className="mt-2 whitespace-pre-line text-sm leading-8 text-ink-soft">{answer}</p>
      </section>
      <section className="card p-5">
        <p className="eyebrow">قائمة التحقّق — ضع علامة على ما ذكرتَه فعلاً</p>
        <ul className="mt-3 space-y-2">
          {checklist.map((item, i) => (
            <li key={item.textAr}>
              <label className="option cursor-pointer" data-on={ticked.includes(i)}>
                <input
                  type="checkbox"
                  className="mt-1.5 accent-[#1f5c45]"
                  checked={ticked.includes(i)}
                  onChange={() => setTicked((v) => (v.includes(i) ? v.filter((x) => x !== i) : [...v, i]))}
                />
                <span>
                  <span className="ml-1 text-[11px] font-bold text-gold">{item.kind === "idee" ? "فكرة أساسية" : "تجنّبتُ الفخّ"}</span>
                  {item.textAr}
                </span>
              </label>
            </li>
          ))}
        </ul>
        <p className="mt-3 text-xs text-mute">
          {ticked.length} من {checklist.length} — الجسر يُفتح في كل الحالات، لكن ما لم تذكره يعود في المراجعة.
        </p>
      </section>
      {error && <Notice tone="error">{error}</Notice>}
      <button type="button" disabled={pending} onClick={() => send({ type: "jalon-check", ticked })} className="btn-primary w-full">
        أغلق الوحدة وافتح الجسر
      </button>
    </div>
  );
}

export function ProfileForm({ name, examDate }: { name: string; examDate: string }) {
  const router = useRouter();
  const [value, setValue] = useState(name);
  const [date, setDate] = useState(examDate);
  const [message, setMessage] = useState<string | null>(null);
  return (
    <form
      className="grid gap-3 md:grid-cols-[1fr_1fr_auto] md:items-end"
      onSubmit={async (event) => {
        event.preventDefault();
        const result = await postAction({ type: "profile", name: value, examDate: date });
        setMessage(result.ok ? (result.info ?? "تمّ.") : (result.error ?? "تعذّر."));
        router.refresh();
      }}
    >
      <label className="grid gap-1 text-xs font-semibold text-mute">
        الاسم
        <input value={value} onChange={(e) => setValue(e.target.value)} className="field !py-2" />
      </label>
      <label className="grid gap-1 text-xs font-semibold text-mute">
        تاريخ البكالوريا
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="field !py-2" dir="ltr" />
      </label>
      <button className="btn-primary !py-2.5">حفظ</button>
      {message && <p className="text-xs text-forest md:col-span-3">{message}</p>}
    </form>
  );
}

export function AccountButtons({ isDemo }: { isDemo: boolean }) {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  async function go(type: "new-learner" | "reset-demo") {
    setPending(true);
    await postAction({ type });
    setPending(false);
    router.push("/");
    router.refresh();
  }
  return (
    <div className="flex flex-wrap gap-2">
      <button type="button" disabled={pending} onClick={() => go("new-learner")} className="btn-ghost">
        ابدأ مساراً جديداً من الصفر
      </button>
      <button type="button" disabled={pending} onClick={() => go("reset-demo")} className="btn-ghost">
        {isDemo ? "أعد ضبط مسار لينا التجريبي" : "عُد إلى مسار لينا التجريبي"}
      </button>
    </div>
  );
}

export function MockExam({
  exercises,
}: {
  exercises: { id: string; unitNumber: string; titleAr: string; enonceAr: string; supportsAr: string[]; rubric: { textAr: string; points: number }[] }[];
}) {
  const [texts, setTexts] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [ticked, setTicked] = useState<Record<string, number[]>>({});
  const total = exercises.reduce((sum, ex) => sum + ex.rubric.reduce((s, r) => s + r.points, 0), 0);
  const score = exercises.reduce(
    (sum, ex) => sum + (ticked[ex.id] ?? []).reduce((s, i) => s + (ex.rubric[i]?.points ?? 0), 0),
    0,
  );
  return (
    <div className="space-y-5">
      <div className="flex justify-end">
        <SessionTimer minutes={60} />
      </div>
      {exercises.map((ex, n) => (
        <section key={ex.id} className="card space-y-3 p-5">
          <p className="eyebrow">
            التمرين {n + 1} · {ex.unitNumber}
          </p>
          <h2 className="font-semibold leading-7">{ex.titleAr}</h2>
          <p className="text-[15px] leading-8">{ex.enonceAr}</p>
          <ul className="text-sm text-mute">
            {ex.supportsAr.map((s) => (
              <li key={s}>• {s}</li>
            ))}
          </ul>
          <textarea
            rows={6}
            className="field"
            disabled={submitted}
            value={texts[ex.id] ?? ""}
            onChange={(e) => setTexts((v) => ({ ...v, [ex.id]: e.target.value }))}
          />
          {submitted && (
            <ul className="space-y-2">
              {ex.rubric.map((r, i) => (
                <li key={r.textAr}>
                  <label className="option cursor-pointer" data-on={(ticked[ex.id] ?? []).includes(i)}>
                    <input
                      type="checkbox"
                      className="mt-1.5 accent-[#1f5c45]"
                      checked={(ticked[ex.id] ?? []).includes(i)}
                      onChange={() =>
                        setTicked((v) => {
                          const cur = v[ex.id] ?? [];
                          return { ...v, [ex.id]: cur.includes(i) ? cur.filter((x) => x !== i) : [...cur, i] };
                        })
                      }
                    />
                    <span className="flex-1">{r.textAr}</span>
                    <span className="text-xs font-bold text-gold">{r.points} ن</span>
                  </label>
                </li>
              ))}
            </ul>
          )}
        </section>
      ))}
      {submitted ? (
        <Notice tone="info">
          مجموعك المقدَّر: {score}/{total}. هذا تمرين ضغط لا يُحفظ: ما أخطأت فيه يعود عبر مراجعات المسار، لا عبر بنك مواضيع.
        </Notice>
      ) : (
        <button type="button" onClick={() => setSubmitted(true)} className="btn-primary w-full">
          سلّم الورقة واكشف السلالم
        </button>
      )}
    </div>
  );
}
