"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Check, LifeBuoy } from "lucide-react";
import { NoteDrawer, Notice, Options, SessionTimer, postAction } from "@/components/widgets";

type PhaseKind = "decouverte" | "vocabulaire" | "methodologie" | "application";

export type SessionView = {
  brickId: string;
  unitLabel: string;
  titleAr: string;
  titleFr: string;
  objectifAr: string;
  phase: PhaseKind;
  phaseKey: string;
  minutesTotal: number;
  phases: { kind: PhaseKind; ar: string; minutes: number; status: "done" | "current" | "locked"; fragile: boolean }[];
  morchid: { lines: string[]; presence: string; speaking: boolean };
  stuckLeft: number;
  decouverte?: {
    probe: { promptAr: string; options: string[] };
    probeChoice: number | null;
    probeCorrect: boolean | null;
    content: { bodyAr: string[]; keyPointsAr: string[]; errorAr: string } | null;
    gate: { promptAr: string; options: string[] } | null;
  };
  vocabulaire?: { defs: { i: number; defAr: string }[]; terms: { i: number; termAr: string }[] };
  methodologie?: {
    verbAr: string;
    docAr: string;
    sentences: { i: number; textAr: string }[];
    teeth: { n: number; ar: string; nameAr: string; questionAr: string; triadAr: string }[];
  };
  application?: {
    enonceAr: string;
    supportsAr: string[];
    checkAr: string;
    answer: string | null;
    rubric: { textAr: string; points: number }[] | null;
    piegeAr: string | null;
    needsType: boolean;
    score: number | null;
    total: number | null;
    errorTypes: { code: string; ar: string }[];
  };
};

type Act = (payload: Record<string, unknown>) => Promise<void>;

export default function SessionPlayer({ view }: { view: SessionView }) {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  // La dernière parole de Morchid reste visible au changement de phase (révélations, question de vérification).
  const [flash, setFlash] = useState<string | null>(null);

  const act: Act = async (payload) => {
    setPending(true);
    setError(null);
    setInfo(null);
    setFlash(null);
    const result = await postAction({ brickId: view.brickId, ...payload });
    setPending(false);
    if (!result.ok) setError(result.error ?? "تعذّر الحفظ.");
    else if (result.info) setInfo(result.info);
    if (result.morchid) setFlash(result.morchid);
    router.refresh();
  };

  const morchid = flash ? { ...view.morchid, lines: [flash], speaking: true } : view.morchid;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link href="/" className="text-xs font-semibold text-mute hover:text-forest">
          → اليوم
        </Link>
        <SessionTimer minutes={view.minutesTotal} />
      </div>

      <header>
        <p className="text-xs font-semibold text-forest">{view.unitLabel}</p>
        <h1 className="mt-1 font-naskh text-[2rem] leading-snug text-ink">{view.titleAr}</h1>
        <p dir="ltr" className="mt-0.5 text-end font-fr text-[11px] text-mute">
          {view.titleFr}
        </p>
        <p className="mt-2 text-sm text-ink-soft">
          <span className="font-semibold text-forest-deep">الهدف:</span> {view.objectifAr}
        </p>
      </header>

      <ol className="grid grid-cols-4 gap-1.5" aria-label="مراحل اللبنة">
        {view.phases.map((p, i) => (
          <li
            key={p.kind}
            className={`rounded-2xl border px-2 py-2 text-center ${
              p.status === "done"
                ? p.fragile
                  ? "border-gold/40 bg-gold-soft/60 text-clay"
                  : "border-forest/30 bg-sage text-forest-deep"
                : p.status === "current"
                  ? "border-forest bg-paper text-forest-deep shadow-[0_0_0_3px_rgba(31,92,69,0.12)]"
                  : "border-line bg-cream text-mute"
            }`}
          >
            <span className="flex items-center justify-center gap-1 text-[11px] font-bold">
              {p.status === "done" && <Check className="h-3 w-3" />}
              {i + 1}. {p.ar}
            </span>
            <span className="block text-[10px] opacity-75">{p.minutes} د</span>
          </li>
        ))}
      </ol>

      <MorchidBox morchid={morchid} />

      {info && <Notice tone="info">{info}</Notice>}
      {error && <Notice tone="error">{error}</Notice>}

      <div key={view.phaseKey}>
        {view.phase === "decouverte" && view.decouverte && <Decouverte data={view.decouverte} act={act} pending={pending} />}
        {view.phase === "vocabulaire" && view.vocabulaire && <Vocab data={view.vocabulaire} act={act} pending={pending} />}
        {view.phase === "methodologie" && view.methodologie && <Method data={view.methodologie} act={act} pending={pending} />}
        {view.phase === "application" && view.application && <Apply data={view.application} act={act} pending={pending} />}
      </div>

      <footer className="flex flex-wrap items-start justify-between gap-3 border-t border-line pt-4">
        <button type="button" disabled={pending || view.stuckLeft <= 0} onClick={() => act({ type: "stuck" })} className="btn-ghost">
          <LifeBuoy className="h-4 w-4" /> أنا عالق
          <span className="text-[10px] text-mute">({view.stuckLeft} متبقّية)</span>
        </button>
        <div className="min-w-0 flex-1 md:flex-none">
          <NoteDrawer itemId={view.brickId} />
        </div>
      </footer>
    </div>
  );
}

function MorchidBox({ morchid }: { morchid: SessionView["morchid"] }) {
  if (!morchid.lines.length) {
    return (
      <div className="flex items-center gap-3 rounded-[22px] border border-dashed border-line px-4 py-3">
        <img src="/images/morchid.jpg" alt="" className="h-9 w-9 rounded-full object-cover opacity-60 grayscale" />
        <p className="text-xs leading-6 text-mute">{morchid.presence}</p>
      </div>
    );
  }
  return (
    <div className="flex gap-3 rounded-[22px] bg-forest-deep p-4 text-paper">
      <img src="/images/morchid.jpg" alt="المرشد" className="h-12 w-12 shrink-0 rounded-2xl object-cover" />
      <div className="min-w-0">
        <p className="text-[11px] font-bold text-gold-soft">المرشد</p>
        {morchid.lines.map((line) => (
          <p key={line} className="mt-1 whitespace-pre-line text-sm leading-7 text-paper/95">
            {line}
          </p>
        ))}
      </div>
    </div>
  );
}

function Decouverte({ data, act, pending }: { data: NonNullable<SessionView["decouverte"]>; act: Act; pending: boolean }) {
  const [choice, setChoice] = useState<number | null>(null);

  if (data.probeChoice === null) {
    return (
      <section className="card p-5">
        <p className="eyebrow">سؤال المرشد — قبل أي درس</p>
        <h2 className="mt-2 text-lg font-semibold leading-8">{data.probe.promptAr}</h2>
        <p className="mt-1 text-xs text-mute">لا خطأ مكلف هنا: اختر ما تظنّه، ثم نقرأ.</p>
        <Options name="الفرضية" options={data.probe.options.map((label, key) => ({ key, label }))} value={choice} onChange={setChoice} />
        <button type="button" disabled={choice === null || pending} onClick={() => act({ type: "probe", choice })} className="btn-primary mt-5 w-full">
          هذه فرضيتي
        </button>
      </section>
    );
  }

  return (
    <div className="space-y-4">
      <p className="inline-flex rounded-full bg-paper px-3 py-1 text-xs text-ink-soft ring-1 ring-line">
        فرضيتك: «{data.probe.options[data.probeChoice]}» · {data.probeCorrect ? "تصمد" : "تُراجَع بالقراءة"}
      </p>
      {data.content && (
        <>
          <article className="card space-y-4 p-5">
            {data.content.bodyAr.map((paragraph) => (
              <p key={paragraph.slice(0, 40)} className="text-[15.5px] leading-9 text-ink">
                {paragraph}
              </p>
            ))}
          </article>
          <section className="rounded-[24px] bg-sage-soft p-5">
            <p className="eyebrow !text-forest">ما يجب أن يبقى</p>
            <ul className="mt-2 space-y-1.5">
              {data.content.keyPointsAr.map((point) => (
                <li key={point} className="text-sm leading-7 text-forest-deep">
                  • {point}
                </li>
              ))}
            </ul>
          </section>
          <p className="rounded-[20px] border border-gold/40 bg-gold-soft/50 p-4 text-sm leading-7 text-clay">
            <span className="font-bold">الخطأ الذي تقتله هذه اللبنة: </span>
            {data.content.errorAr}
          </p>
        </>
      )}
      {data.gate && (
        <section className="card p-5">
          <p className="eyebrow">سؤال التثبيت — يفتح المرحلة التالية</p>
          <h2 className="mt-2 font-semibold leading-8">{data.gate.promptAr}</h2>
          <Options name="سؤال التثبيت" options={data.gate.options.map((label, key) => ({ key, label }))} value={choice} onChange={setChoice} />
          <button type="button" disabled={choice === null || pending} onClick={() => act({ type: "gate", choice })} className="btn-primary mt-5 w-full">
            تحقّق
          </button>
        </section>
      )}
    </div>
  );
}

function Vocab({ data, act, pending }: { data: NonNullable<SessionView["vocabulaire"]>; act: Act; pending: boolean }) {
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const ready = data.defs.every((d) => answers[d.i] !== undefined);
  return (
    <section className="space-y-3">
      <p className="eyebrow">اربط كل تعريف بمصطلحه — أربعة فقط، لا قاموس</p>
      {data.defs.map((def, k) => (
        <div key={def.i} className="card p-4">
          <p className="text-sm leading-7">
            <span className="ml-1 font-bold text-gold">{k + 1}.</span>
            {def.defAr}
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            {data.terms.map((term) => (
              <button
                key={term.i}
                type="button"
                data-on={answers[def.i] === term.i}
                onClick={() => setAnswers((v) => ({ ...v, [def.i]: term.i }))}
                className="chip"
              >
                {term.termAr}
              </button>
            ))}
          </div>
        </div>
      ))}
      <button type="button" disabled={!ready || pending} onClick={() => act({ type: "vocab", answers })} className="btn-primary w-full">
        تحقّق من الربط
      </button>
    </section>
  );
}

function Method({ data, act, pending }: { data: NonNullable<SessionView["methodologie"]>; act: Act; pending: boolean }) {
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const ready = data.sentences.every((s) => answers[s.i] !== undefined);
  return (
    <section className="space-y-4">
      <div className="relative overflow-hidden rounded-[24px]">
        <img src="/images/key-miftah.jpg" alt="" className="h-28 w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-l from-forest-deep/90 to-forest-deep/40" />
        <div className="absolute inset-0 flex flex-col justify-end p-4 text-paper">
          <p className="text-[11px] font-bold text-gold-soft">مفتاح المنهجية</p>
          <p className="font-naskh text-2xl">فعل · دليل · علاقة · جواب</p>
        </div>
      </div>
      <div className="card space-y-1 p-4 text-sm leading-7">
        <p>
          <span className="font-bold text-forest-deep">فعل الأداء: </span>
          {data.verbAr}
        </p>
        <p>
          <span className="font-bold text-forest-deep">السند: </span>
          {data.docAr}
        </p>
      </div>
      <ol className="grid grid-cols-2 gap-2 md:grid-cols-4">
        {data.teeth.map((t) => (
          <li key={t.n} className="rounded-2xl border border-line bg-paper p-3">
            <p className="text-xs font-bold text-gold">
              السنّ {t.n} · {t.ar}
              {t.triadAr ? ` (${t.triadAr})` : ""}
            </p>
            <p className="mt-1 text-[12px] leading-5 text-ink-soft">{t.questionAr}</p>
          </li>
        ))}
      </ol>
      <p className="eyebrow">إجابة نموذجية مبعثرة: أسند كل جملة إلى سنّها</p>
      {data.sentences.map((sentence) => (
        <div key={sentence.i} className="card p-4">
          <p className="text-sm leading-7">{sentence.textAr}</p>
          <div className="mt-3 grid grid-cols-4 gap-1.5">
            {data.teeth.map((t) => (
              <button
                key={t.n}
                type="button"
                data-on={answers[sentence.i] === t.n}
                onClick={() => setAnswers((v) => ({ ...v, [sentence.i]: t.n }))}
                className="chip !px-1"
              >
                {t.ar}
              </button>
            ))}
          </div>
        </div>
      ))}
      <button type="button" disabled={!ready || pending} onClick={() => act({ type: "teeth", answers })} className="btn-primary w-full">
        تحقّق من المفتاح
      </button>
    </section>
  );
}

function Apply({ data, act, pending }: { data: NonNullable<SessionView["application"]>; act: Act; pending: boolean }) {
  const [text, setText] = useState("");
  const [ticked, setTicked] = useState<number[]>([]);
  const [code, setCode] = useState<number | null>(null);

  const statement = (
    <section className="card p-5">
      <p className="eyebrow">تمرين على نمط البكالوريا</p>
      <p className="mt-2 text-[15.5px] leading-9">{data.enonceAr}</p>
      {data.supportsAr.length > 0 && (
        <ul className="mt-3 space-y-1 text-sm text-mute">
          {data.supportsAr.map((s) => (
            <li key={s}>• {s}</li>
          ))}
        </ul>
      )}
    </section>
  );

  if (!data.answer) {
    return (
      <div className="space-y-4">
        {statement}
        <p className="rounded-[20px] bg-gold-soft/60 p-4 text-sm leading-7 text-clay">
          <span className="font-bold">سؤال التحقّق قبل الكتابة: </span>
          {data.checkAr}
        </p>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={8}
          className="field"
          placeholder="المطلوب… ← نلاحظ (قيمة + وحدة)… ← لأنّ… ← إذن…"
        />
        <div className="flex items-center justify-between text-[11px] text-mute">
          <span>{text.trim().length} حرفاً</span>
          <span>سلّم التنقيط يظهر بعد أن تسلّم إجابتك</span>
        </div>
        <button type="button" disabled={pending || text.trim().length < 40} onClick={() => act({ type: "answer", text })} className="btn-primary w-full">
          سلّم الورقة
        </button>
      </div>
    );
  }

  if (data.needsType) {
    return (
      <div className="space-y-4">
        <section className="card p-5">
          <p className="eyebrow">إجابتك · {data.score}/{data.total}</p>
          <p className="mt-2 whitespace-pre-line text-sm leading-8 text-ink-soft">{data.answer}</p>
        </section>
        <section className="card p-5">
          <p className="eyebrow">ما نوع خطئك؟ — قبل أيّ تعليق</p>
          <Options name="نوع الخطأ" options={data.errorTypes.map((e, key) => ({ key, label: `${e.code} · ${e.ar}` }))} value={code} onChange={setCode} />
          <button
            type="button"
            disabled={code === null || pending}
            onClick={() => act({ type: "errortype", code: code === null ? null : data.errorTypes[code].code })}
            className="btn-primary mt-5 w-full"
          >
            هذا خطئي
          </button>
        </section>
      </div>
    );
  }

  const rubric = data.rubric ?? [];
  const total = rubric.reduce((sum, r) => sum + r.points, 0);
  const score = ticked.reduce((sum, i) => sum + (rubric[i]?.points ?? 0), 0);

  return (
    <div className="space-y-4">
      {statement}
      <section className="card p-5">
        <p className="eyebrow">إجابتك</p>
        <p className="mt-2 whitespace-pre-line text-sm leading-8 text-ink-soft">{data.answer}</p>
      </section>
      <section className="card p-5">
        <p className="eyebrow">سلّم التنقيط — ضع علامة على ما كتبتَه فعلاً</p>
        <ul className="mt-3 space-y-2">
          {rubric.map((item, i) => (
            <li key={item.textAr}>
              <label className="option cursor-pointer" data-on={ticked.includes(i)}>
                <input
                  type="checkbox"
                  className="mt-1.5 accent-[#1f5c45]"
                  checked={ticked.includes(i)}
                  onChange={() => setTicked((v) => (v.includes(i) ? v.filter((x) => x !== i) : [...v, i]))}
                />
                <span className="flex-1">{item.textAr}</span>
                <span className="shrink-0 text-xs font-bold text-gold">{item.points} ن</span>
              </label>
            </li>
          ))}
        </ul>
        <div className="mt-4 flex items-center justify-between text-sm">
          <span className="text-mute">العتبة: 6 من 10</span>
          <span className="font-bold text-forest-deep" dir="ltr">
            {score} / {total}
          </span>
        </div>
      </section>
      {data.piegeAr && (
        <p className="rounded-[20px] border border-gold/40 bg-gold-soft/50 p-4 text-sm leading-7 text-clay">
          <span className="font-bold">الفخّ: </span>
          {data.piegeAr}
        </p>
      )}
      <button type="button" disabled={pending} onClick={() => act({ type: "selfcheck", ticked })} className="btn-primary w-full">
        أنهِ التقييم
      </button>
    </div>
  );
}
