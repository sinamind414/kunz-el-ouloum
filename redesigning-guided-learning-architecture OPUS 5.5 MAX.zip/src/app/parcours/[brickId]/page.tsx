import Link from "next/link";
import { notFound } from "next/navigation";
import SessionPlayer, { type SessionView } from "@/components/SessionPlayer";
import { Gate, MorchidQuote, Waiting } from "@/components/gates";
import { PHASES, PHASE_META, TEETH, brickById, rubricOf, seededOrder, teethSentences, unitById, type Brick } from "@/lib/curriculum";
import { formatDayAr, todayKey } from "@/lib/dates";
import { currentLearnerId, getState, itemMode, payloadOf, previousItemTitle, rowFor, type AppState } from "@/lib/engine";
import { ERROR_TYPES, presenceAr } from "@/lib/morchid";

export const dynamic = "force-dynamic";

export default async function BrickPage({ params }: { params: Promise<{ brickId: string }> }) {
  const { brickId } = await params;
  const brick = brickById(brickId);
  if (!brick) notFound();
  const state = await getState(await currentLearnerId());
  const mode = itemMode(state, brickId);

  if (mode === "locked") {
    return (
      <Gate
        title="هذه اللبنة لم تُفتح بعد"
        text={`تُفتح بعد «${previousItemTitle(brickId) ?? "اللبنة السابقة"}». المسار خطّي عمداً: لا قفز، ولا تراكم.`}
      />
    );
  }
  if (mode === "attente") return <Waiting state={state} />;
  if (mode === "relecture") return <Relecture state={state} brick={brick} />;
  return <SessionPlayer view={buildView(state, brick)} />;
}

function buildView(state: AppState, brick: Brick): SessionView {
  const unit = unitById(brick.unitId);
  const spec = brick.spec;
  const phase = state.currentPhase ?? "decouverte";
  const index = PHASES.indexOf(phase);
  const payload = payloadOf(state, brick.id, phase);
  const row = rowFor(state, brick.id, phase);
  const probed = payload.probeChoice !== undefined;

  let lines: string[] = payload.morchid ? [payload.morchid] : [];
  if (!lines.length && phase === "decouverte" && !probed) {
    lines = ["قبل أن تقرأ أيّ سطر: سؤال واحد. اختر ما تظنّه — الفرضية الخاطئة مفيدة هنا، لأنها تجعلك تقرأ بانتباه."];
  }
  if (!lines.length && phase === "application") {
    const fromKey = payloadOf(state, brick.id, "methodologie").morchid;
    if (fromKey) lines = [fromKey];
  }

  const view: SessionView = {
    brickId: brick.id,
    unitLabel: `${unit?.number ?? ""} · ${unit?.titleAr ?? ""} · اللبنة ${brick.order}`,
    titleAr: spec.titleAr,
    titleFr: spec.titleFr,
    objectifAr: spec.objectifAr,
    phase,
    phaseKey: `${phase}-${row?.attempts ?? 0}-${probed ? 1 : 0}-${payload.answer ? 1 : 0}-${payload.needsType ? 1 : 0}`,
    minutesTotal: PHASES.slice(index).reduce((sum, kind) => sum + PHASE_META[kind].minutes, 0),
    phases: PHASES.map((kind) => {
      const r = rowFor(state, brick.id, kind);
      return {
        kind,
        ar: PHASE_META[kind].ar,
        minutes: PHASE_META[kind].minutes,
        status: r?.status === "valide" ? "done" : kind === phase ? "current" : "locked",
        fragile: Boolean(r?.fragile),
      };
    }),
    morchid: { lines, presence: presenceAr(phase), speaking: lines.length > 0 },
    stuckLeft: Math.max(0, 2 - (payload.stuck ?? 0)),
  };

  if (phase === "decouverte") {
    const probe = spec.checks[0];
    const gate = spec.checks[1] ?? spec.checks[0];
    view.decouverte = {
      probe: { promptAr: probe.promptAr, options: probe.optionsAr },
      probeChoice: probed ? (payload.probeChoice as number) : null,
      probeCorrect: probed ? Boolean(payload.probeCorrect) : null,
      content: probed ? { bodyAr: spec.concept.bodyAr, keyPointsAr: spec.concept.keyPointsAr, errorAr: spec.concept.errorAr } : null,
      gate: probed ? { promptAr: gate.promptAr, options: gate.optionsAr } : null,
    };
  }
  if (phase === "vocabulaire") {
    view.vocabulaire = {
      defs: seededOrder(spec.vocab.length, `${brick.id}-def`).map((i) => ({ i, defAr: spec.vocab[i].defAr })),
      terms: seededOrder(spec.vocab.length, `${brick.id}-term`).map((i) => ({ i, termAr: spec.vocab[i].termAr })),
    };
  }
  if (phase === "methodologie") {
    const sentences = teethSentences(brick);
    view.methodologie = {
      verbAr: spec.methode.verbAr,
      docAr: spec.methode.docAr,
      sentences: seededOrder(sentences.length, `${brick.id}-teeth`).map((i) => ({ i, textAr: sentences[i] })),
      teeth: TEETH.map((t) => ({ n: t.n, ar: t.ar, nameAr: t.nameAr, questionAr: t.questionAr, triadAr: t.triadAr })),
    };
  }
  if (phase === "application") {
    view.application = {
      enonceAr: spec.application.enonceAr,
      supportsAr: spec.application.supportsAr,
      checkAr: spec.methode.checkAr,
      answer: payload.answer ?? null,
      rubric: payload.answer ? rubricOf(brick) : null,
      piegeAr: payload.answer ? spec.application.piegeAr : null,
      needsType: Boolean(payload.needsType),
      score: payload.score ?? null,
      total: payload.total ?? null,
      errorTypes: ERROR_TYPES.map((e) => ({ code: e.code, ar: e.ar })),
    };
  }
  return view;
}

function Relecture({ state, brick }: { state: AppState; brick: Brick }) {
  const unit = unitById(brick.unitId);
  const spec = brick.spec;
  const decouverte = payloadOf(state, brick.id, "decouverte");
  const application = payloadOf(state, brick.id, "application");
  const finalRow = rowFor(state, brick.id, "application");
  const finishedToday = Boolean(finalRow?.completedAt && todayKey(finalRow.completedAt) === state.today);
  const review = state.reviewRows.find((r) => r.brickId === brick.id && r.active);
  const rubric = rubricOf(brick);
  const sentences = teethSentences(brick);
  const ticked = application.ticked ?? [];
  const fragile = PHASES.some((kind) => rowFor(state, brick.id, kind)?.fragile);

  return (
    <div className="space-y-5">
      {finishedToday ? (
        <section className="relative overflow-hidden rounded-[28px] bg-forest-deep text-paper">
          <img src="/images/olive.jpg" alt="" className="absolute inset-0 h-full w-full object-cover opacity-20" />
          <div className="relative p-6">
            <p className="text-xs font-semibold text-gold-soft">اكتملت لبنة اليوم · {unit?.number}</p>
            <h1 className="mt-1 font-naskh text-[2rem] leading-snug">{spec.titleAr}</h1>
            {application.morchid && (
              <div className="mt-4">
                <MorchidQuote text={application.morchid} light />
              </div>
            )}
            <Link href="/" className="mt-5 inline-flex rounded-full bg-paper px-5 py-2.5 text-sm font-bold text-forest-deep">
              العودة إلى «اليوم»
            </Link>
          </div>
        </section>
      ) : (
        <header>
          <Link href="/parcours" className="text-xs font-semibold text-mute">
            → المسار
          </Link>
          <p className="mt-3 text-xs font-semibold text-forest">
            {unit?.number} · {unit?.titleAr} · اللبنة {brick.order}
          </p>
          <h1 className="mt-1 font-naskh text-[2rem] leading-snug">{spec.titleAr}</h1>
          <p className="mt-2 inline-flex rounded-full bg-paper px-3 py-1 text-xs text-mute ring-1 ring-line">
            قراءة فقط · {fragile ? "هشّة" : "مثبّتة"}
            {review ? ` · المراجعة يوم ${formatDayAr(review.dueOn)}` : ""}
          </p>
        </header>
      )}

      <Section n={1} title={PHASE_META.decouverte.ar}>
        <p className="text-sm text-mute">
          سؤال المرشد: {spec.checks[0].promptAr}
          {decouverte.probeChoice !== undefined && (
            <span className="font-semibold text-ink-soft"> — فرضيتك: «{spec.checks[0].optionsAr[decouverte.probeChoice]}»</span>
          )}
        </p>
        {spec.concept.bodyAr.map((p) => (
          <p key={p.slice(0, 40)} className="text-[15px] leading-9">
            {p}
          </p>
        ))}
        <ul className="rounded-2xl bg-sage-soft p-4 text-sm leading-7 text-forest-deep">
          {spec.concept.keyPointsAr.map((k) => (
            <li key={k}>• {k}</li>
          ))}
        </ul>
      </Section>

      <Section n={2} title={PHASE_META.vocabulaire.ar}>
        <dl className="grid gap-2 md:grid-cols-2">
          {spec.vocab.map((v) => (
            <div key={v.termAr} className="rounded-2xl border border-line p-3">
              <dt className="text-sm font-bold text-forest-deep">{v.termAr}</dt>
              <dd className="mt-1 text-sm leading-7 text-ink-soft">{v.defAr}</dd>
            </div>
          ))}
        </dl>
      </Section>

      <Section n={3} title={PHASE_META.methodologie.ar}>
        <p className="text-sm text-mute">
          فعل الأداء: {spec.methode.verbAr} · السند: {spec.methode.docAr}
        </p>
        <ol className="space-y-2">
          {sentences.map((s, i) => (
            <li key={s} className="rounded-2xl border border-line p-3 text-sm leading-7">
              <span className="ml-1 font-bold text-gold">
                {TEETH[i].ar}
                {TEETH[i].triadAr ? ` (${TEETH[i].triadAr})` : ""}:
              </span>
              {s}
            </li>
          ))}
        </ol>
      </Section>

      <Section n={4} title={PHASE_META.application.ar}>
        <p className="text-[15px] leading-8">{spec.application.enonceAr}</p>
        {application.answer && (
          <blockquote className="rounded-2xl bg-cream p-4 text-sm leading-8 text-ink-soft">
            <p className="mb-1 text-[11px] font-bold text-gold">إجابتك</p>
            {application.answer}
          </blockquote>
        )}
        <ul className="space-y-1.5">
          {rubric.map((r, i) => (
            <li key={r.textAr} className="flex items-start gap-2 text-sm leading-7">
              <span className={`mt-1.5 h-3 w-3 shrink-0 rounded-full ${ticked.includes(i) ? "bg-forest" : "bg-line"}`} />
              <span className="flex-1">{r.textAr}</span>
              <span className="text-xs font-bold text-gold">{r.points} ن</span>
            </li>
          ))}
        </ul>
        {typeof application.score === "number" && (
          <p className="text-sm font-semibold text-forest-deep">
            تقييمك: {application.score}/{application.total}
            {application.errorType ? ` · نوع الخطأ: ${application.errorType}` : ""}
          </p>
        )}
        <p className="rounded-2xl border border-gold/40 bg-gold-soft/50 p-3 text-sm leading-7 text-clay">الفخّ: {spec.application.piegeAr}</p>
        {!finishedToday && application.morchid && <MorchidQuote text={application.morchid} />}
      </Section>
    </div>
  );
}

function Section({ n, title, children }: { n: number; title: string; children: React.ReactNode }) {
  return (
    <section className="card space-y-3 p-5">
      <p className="eyebrow">
        {n}. {title}
      </p>
      {children}
    </section>
  );
}
