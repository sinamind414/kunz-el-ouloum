import Link from "next/link";
import { notFound } from "next/navigation";
import { Gate, MorchidQuote, Waiting } from "@/components/gates";
import { JalonForm } from "@/components/widgets";
import { jalonChecklist, jalonId, unitById } from "@/lib/curriculum";
import { todayKey } from "@/lib/dates";
import { currentLearnerId, getState, itemMode, payloadOf, previousItemTitle, rowFor } from "@/lib/engine";

export const dynamic = "force-dynamic";

export default async function JalonPage({ params }: { params: Promise<{ unitId: string }> }) {
  const { unitId } = await params;
  const unit = unitById(Number(unitId));
  if (!unit) notFound();
  const state = await getState(await currentLearnerId());
  const item = jalonId(unit.id);
  const mode = itemMode(state, item);
  const checklist = jalonChecklist(unit.id);
  const payload = payloadOf(state, item, "jalon");

  if (mode === "locked") {
    return (
      <Gate
        title="الجسر لم يُفتح بعد"
        text={`يُفتح بعد آخر لبنة في ${unit.number}: «${previousItemTitle(item) ?? ""}».`}
      />
    );
  }
  if (mode === "attente") return <Waiting state={state} />;

  const header = (
    <header>
      <p className="text-xs font-semibold text-forest">
        {unit.number} · {unit.titleAr}
      </p>
      <h1 className="mt-1 font-naskh text-[2rem] leading-snug">جسر الوحدة</h1>
      <p className="mt-1 text-sm leading-7 text-mute">
        آخر خطوة قبل الوحدة التالية: حصيلة من الذاكرة، ثم قائمة تحقّق. هنا يسمّي المرشد أضعف لبنة، وتعود أسئلتك المؤجّلة.
      </p>
    </header>
  );

  if (mode === "play") {
    const parked = state.notes.filter((n) => n.kind === "question" && n.unitId === unit.id).map((n) => n.body);
    return (
      <div className="space-y-5">
        {header}
        <JalonForm
          unitId={unit.id}
          questionAr={unit.questionAr}
          answer={payload.answer ?? null}
          checklist={checklist.map((c) => ({ kind: c.kind, textAr: c.textAr }))}
          parked={parked}
        />
      </div>
    );
  }

  const row = rowFor(state, item, "jalon");
  const today = Boolean(row?.completedAt && todayKey(row.completedAt) === state.today);
  const ticked = payload.ticked ?? [];
  return (
    <div className="space-y-5">
      {today ? (
        <section className="rounded-[28px] bg-forest-deep p-6 text-paper">
          <p className="text-xs font-semibold text-gold-soft">الجسر مفتوح · {unit.number}</p>
          <h1 className="mt-1 font-naskh text-[2rem] leading-snug">{unit.titleAr}</h1>
          {payload.morchid && (
            <div className="mt-4">
              <MorchidQuote text={payload.morchid} light />
            </div>
          )}
          <Link href="/" className="mt-5 inline-flex rounded-full bg-paper px-5 py-2.5 text-sm font-bold text-forest-deep">
            العودة إلى «اليوم»
          </Link>
        </section>
      ) : (
        header
      )}
      <section className="card space-y-3 p-5">
        <p className="eyebrow">سؤال الوحدة</p>
        <p className="font-semibold leading-8">{unit.questionAr}</p>
        {payload.answer && <p className="whitespace-pre-line rounded-2xl bg-cream p-4 text-sm leading-8 text-ink-soft">{payload.answer}</p>}
      </section>
      <section className="card space-y-2 p-5">
        <p className="eyebrow">
          قائمة التحقّق · {payload.score ?? 0}/{payload.total ?? checklist.length}
        </p>
        {checklist.map((c, i) => (
          <p key={c.textAr} className="flex items-start gap-2 text-sm leading-7">
            <span className={`mt-1.5 h-3 w-3 shrink-0 rounded-full ${ticked.includes(i) ? "bg-forest" : "bg-line"}`} />
            <span>
              <span className="ml-1 text-[11px] font-bold text-gold">{c.kind === "idee" ? "فكرة" : "فخّ"}</span>
              {c.textAr}
            </span>
          </p>
        ))}
        {!today && payload.morchid && <MorchidQuote text={payload.morchid} />}
      </section>
    </div>
  );
}
