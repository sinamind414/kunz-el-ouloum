import Link from "next/link";
import { Check, Lock } from "lucide-react";
import { DOMAINS, PHASE_META } from "@/lib/curriculum";
import { formatShortAr } from "@/lib/dates";
import { currentLearnerId, getState, type BrickView, type UnitView } from "@/lib/engine";

export const dynamic = "force-dynamic";

export default async function ParcoursPage() {
  const state = await getState(await currentLearnerId());

  return (
    <div className="space-y-7">
      <header>
        <p className="eyebrow">مساري</p>
        <h1 className="font-naskh text-[2.2rem] leading-tight">خطوة بعد خطوة</h1>
        <p className="mt-2 text-sm leading-7 text-mute">
          11 وحدة، {state.stats.bricksTotal} لبنة، وجسر في نهاية كل وحدة. لا قائمة دروس: كل لبنة تُفتح بعد التي قبلها، وما أنجزته يبقى
          متاحاً للقراءة.
        </p>
        <ul className="mt-4 flex flex-wrap gap-2 text-[11px]">
          <li className="rounded-full bg-sage px-2.5 py-1 font-semibold text-forest-deep">مثبّتة</li>
          <li className="rounded-full bg-gold-soft px-2.5 py-1 font-semibold text-clay">هشّة — تعود في المراجعة</li>
          <li className="rounded-full bg-paper px-2.5 py-1 font-semibold text-forest ring-1 ring-forest">الحالية</li>
          <li className="rounded-full bg-cream px-2.5 py-1 font-semibold text-mute ring-1 ring-line">تُفتح لاحقاً</li>
        </ul>
      </header>

      {DOMAINS.map((domain) => (
        <section key={domain.id} className="space-y-4">
          <div className="relative overflow-hidden rounded-[24px]">
            <img src={domain.image} alt="" className="h-24 w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-l from-forest-deep/90 to-forest-deep/40" />
            <div className="absolute inset-0 flex flex-col justify-end p-4 text-paper">
              <p dir="ltr" className="text-end font-fr text-[10px] text-gold-soft">
                {domain.titleFr}
              </p>
              <h2 className="font-naskh text-xl">{domain.titleAr}</h2>
            </div>
          </div>
          {state.units
            .filter((unit) => unit.domainId === domain.id)
            .map((unit) => (
              <UnitCard key={unit.id} unit={unit} />
            ))}
        </section>
      ))}
    </div>
  );
}

function UnitCard({ unit }: { unit: UnitView }) {
  return (
    <article className={`card p-4 md:p-5 ${unit.status === "locked" ? "opacity-80" : ""}`}>
      <header className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] font-semibold text-forest">
            {unit.number} · {unit.heures} سا في القسم · {unit.windowAr}
          </p>
          <h3 className="mt-0.5 font-semibold leading-7">{unit.titleAr}</h3>
          <p dir="ltr" className="text-end font-fr text-[11px] text-mute">
            {unit.titleFr}
          </p>
        </div>
        {unit.classHere && (
          <span className="shrink-0 rounded-full bg-clay/10 px-2.5 py-1 text-[10px] font-bold text-clay">القسم هنا</span>
        )}
      </header>
      <ol className="mt-3 space-y-2">
        {unit.bricks.map((brick) => (
          <BrickRow key={brick.id} brick={brick} />
        ))}
        <li>
          <Row
            href={unit.jalon.status === "locked" ? null : `/parcours/jalon/${unit.id}`}
            status={unit.jalon.status}
            fragile={unit.jalon.fragile}
            label="الجسر"
            title={`حصيلة ${unit.number}`}
            meta={
              unit.jalon.status === "done"
                ? `مغلقة${unit.jalon.score ? ` · ${unit.jalon.score.score}/${unit.jalon.score.total}` : ""}`
                : unit.jalon.status === "current"
                  ? "مهمّة اليوم"
                  : "بعد آخر لبنة"
            }
          />
        </li>
      </ol>
    </article>
  );
}

function BrickRow({ brick }: { brick: BrickView }) {
  const meta =
    brick.status === "done"
      ? brick.fragile
        ? `هشّة · تعود ${brick.reviewOn ? formatShortAr(brick.reviewOn) : "قريباً"}`
        : `مثبّتة${brick.score ? ` · ${brick.score.score}/${brick.score.total}` : ""}${brick.reviewOn ? ` · مراجعة ${formatShortAr(brick.reviewOn)}` : ""}`
      : brick.status === "current"
        ? "مهمّتك الحالية"
        : "بعد اللبنة السابقة";
  return (
    <li>
      <Row
        href={brick.status === "locked" ? null : `/parcours/${brick.id}`}
        status={brick.status}
        fragile={brick.fragile}
        label={`اللبنة ${brick.order}`}
        title={brick.titleAr}
        meta={meta}
        pips={brick.phases}
      />
    </li>
  );
}

function Row({
  href,
  status,
  fragile,
  label,
  title,
  meta,
  pips,
}: {
  href: string | null;
  status: "done" | "current" | "locked";
  fragile: boolean;
  label: string;
  title: string;
  meta: string;
  pips?: BrickView["phases"];
}) {
  const tone =
    status === "done"
      ? fragile
        ? "border-gold/40 bg-gold-soft/40"
        : "border-forest/20 bg-sage-soft"
      : status === "current"
        ? "border-forest bg-paper shadow-[0_0_0_3px_rgba(31,92,69,0.1)]"
        : "border-line bg-cream/60";
  const body = (
    <div className={`flex items-center gap-3 rounded-2xl border px-3 py-2.5 ${tone}`}>
      <span
        className={`grid h-7 w-7 shrink-0 place-items-center rounded-full ${
          status === "done" ? "bg-forest text-paper" : status === "current" ? "bg-gold-soft text-clay" : "bg-paper text-mute"
        }`}
      >
        {status === "done" ? <Check className="h-3.5 w-3.5" /> : status === "locked" ? <Lock className="h-3 w-3" /> : "•"}
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-[10px] font-bold text-gold">{label}</p>
        <p className={`truncate text-sm font-semibold ${status === "locked" ? "text-mute" : "text-ink"}`}>{title}</p>
        <p className="text-[11px] text-mute">{meta}</p>
      </div>
      {pips && (
        <div className="flex shrink-0 gap-1" aria-hidden>
          {pips.map((pip) => (
            <span
              key={pip.kind}
              title={PHASE_META[pip.kind].ar}
              className={`h-6 w-1.5 rounded-full ${
                pip.status === "done" ? (pip.fragile ? "bg-gold" : "bg-forest") : pip.status === "current" ? "bg-gold-soft ring-1 ring-gold" : "bg-line"
              }`}
            />
          ))}
        </div>
      )}
    </div>
  );
  return href ? (
    <Link href={href} className="block transition hover:-translate-y-px">
      {body}
    </Link>
  ) : (
    <div aria-disabled>{body}</div>
  );
}
