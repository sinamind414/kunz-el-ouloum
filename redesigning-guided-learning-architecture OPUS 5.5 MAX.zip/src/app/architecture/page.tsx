import type { Metadata } from "next";
import Link from "next/link";
import {
  CALM,
  DASHBOARD_STATES,
  DASHBOARD_ZONES,
  LEGACY_MAP,
  LEVELS,
  NO_PANIC,
  PILLARS,
  UNLOCK_RULES,
  type Level,
} from "@/lib/blueprint";
import { BRICKS, BRICK_MINUTES, JALON_MINUTES, PHASES, PHASE_META, REVIEW_MINUTES, TEETH, UNITS, bricksOfUnit } from "@/lib/curriculum";
import { ERROR_TYPES, MORCHID_FORBIDDEN_FR, MORCHID_MOMENTS, MORCHID_VALVE } from "@/lib/morchid";

export const metadata: Metadata = {
  title: "Kunz El Ouloum — Architecture du parcours guidé",
  description: "Sitemap à 4 onglets, brique de révision de 19 minutes, dashboard anti-stress, intégration du tuteur Morchid.",
};

const LEVEL_ORDER: Level[] = ["premier-plan", "dans-la-brique", "sous-menu", "masque"];

const SITEMAP_TREE = `Kunz El Ouloum
├─ اليوم · Aujourd'hui ............ premier plan
│   └─ 1 carte : brique du jour | reprise | rappel dû | jalon | repos
├─ مساري · Parcours
│   ├─ Domaine 1 · Protéines ...... unités 1 → 5
│   ├─ Domaine 2 · Énergie ........ unités 6 → 8
│   └─ Domaine 3 · Tectonique ..... unités 9 → 11
│        └─ unité = briques (19 min) + 1 jalon جسر (20 min)
│             └─ séance en mode focus, sans onglets :
│                Découverte → Vocabulaire → Méthode → Application Bac
├─ البكالوريا · Bac
│   ├─ Mes copies · Jalons · Ce qui tombe vraiment
│   └─ [à J-56] Plan final · Épreuve blanche 60 min
└─ أنا · Moi
    ├─ Olivier des jalons · Carnet (tadwin + questions garées)
    └─ Date du Bac · Suivi adulte · Compte

Morchid : aucun onglet. 4 moments dans la séance + valve « أنا عالق ».`;

export default function ArchitecturePage() {
  const rows = [...LEGACY_MAP].sort((a, b) => LEVEL_ORDER.indexOf(a.level) - LEVEL_ORDER.indexOf(b.level));

  return (
    <div>
      <header className="relative overflow-hidden">
        <img src="/images/landscape.jpg" alt="" className="h-[440px] w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#141210] via-[#141210]/65 to-[#141210]/10" />
        <div className="absolute inset-x-0 bottom-0 mx-auto max-w-5xl px-6 pb-12 text-white">
          <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[#e8d7a8]">
            Kunz El Ouloum · SVT Bac Algérie · Document produit
          </p>
          <h1 className="mt-3 max-w-3xl font-fr-display text-4xl leading-[1.05] md:text-6xl">
            De la bibliothèque en vrac au parcours pas à pas.
          </h1>
          <p className="mt-4 max-w-2xl text-[15px] leading-7 text-white/80">
            35 surfaces héritées ramenées à 4 onglets. Une seule tâche par jour. Une séance de {BRICK_MINUTES} minutes en 4 phases
            verrouillées. Morchid à 4 moments précis, jamais en libre-service.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link href="/" className="rounded-full bg-white px-5 py-2.5 text-sm font-semibold text-[#143d2e]">
              Ouvrir l&apos;app élève →
            </Link>
            <a href="#sitemap" className="rounded-full border border-white/40 px-5 py-2.5 text-sm font-semibold text-white">
              Lire le document
            </a>
          </div>
        </div>
      </header>

      <nav className="sticky top-0 z-20 border-b border-[#e4d9c5] bg-[#f6f2ea]/90 backdrop-blur">
        <div className="mx-auto flex max-w-5xl gap-1 overflow-x-auto px-6 py-3 text-sm">
          {[
            ["#sitemap", "01 · Arborescence"],
            ["#brique", "02 · Brique & déblocage"],
            ["#dashboard", "03 · Dashboard anti-stress"],
            ["#morchid", "04 · Morchid"],
          ].map(([href, label]) => (
            <a key={href} href={href} className="whitespace-nowrap rounded-full px-3 py-1.5 font-medium text-[#3f3a32] hover:bg-white">
              {label}
            </a>
          ))}
        </div>
      </nav>

      <main className="mx-auto max-w-5xl space-y-24 px-6 py-16">
        <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {[
            ["35 → 4", "surfaces héritées → onglets"],
            ["1", "tâche affichée par jour"],
            [`${BRICK_MINUTES} min`, "par séance, en 4 phases"],
            [`${BRICKS.length} + ${UNITS.length}`, "briques + jalons d'unité"],
            ["4", "moments Morchid, 0 chat"],
          ].map(([n, label]) => (
            <div key={label} className="rounded-3xl border border-[#e4d9c5] bg-white p-5">
              <p className="font-fr-display text-3xl text-[#143d2e]">{n}</p>
              <p className="mt-1 text-xs leading-5 text-[#6b6458]">{label}</p>
            </div>
          ))}
        </section>

        {/* ───────────── 01 ───────────── */}
        <section id="sitemap" className="scroll-mt-20 space-y-8">
          <Heading n="01" title="Arborescence simplifiée" />
          <p className="max-w-3xl text-[15px] leading-7 text-[#4a443b]">
            Règle de tri : une rubrique reste au premier plan seulement si l&apos;élève en a besoin à chaque séance. Tout ce qui est un
            outil, et non une étape, entre dans la brique, descend d&apos;un niveau, ou disparaît du quotidien. La navigation ne pose plus
            la question « où aller ? » : l&apos;onglet « Aujourd&apos;hui » y répond.
          </p>

          <div className="grid gap-4 md:grid-cols-4">
            {PILLARS.map((p, i) => (
              <article key={p.id} className="flex flex-col rounded-3xl border border-[#e4d9c5] bg-white p-5">
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#9a7a2c]">Onglet {i + 1}</p>
                <p dir="rtl" className="mt-2 text-start font-naskh text-2xl text-[#143d2e]">
                  {p.ar}
                </p>
                <h3 className="font-fr-display text-xl">{p.fr}</h3>
                <p className="mt-1 text-xs italic text-[#6b6458]">{p.question}</p>
                <p className="mt-3 text-sm leading-6 text-[#4a443b]">{p.role}</p>
                <ul className="mt-3 space-y-1 border-t border-[#efe6d6] pt-3 text-xs text-[#6b6458]">
                  {p.contains.map((c) => (
                    <li key={c}>· {c}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>

          <pre className="overflow-x-auto rounded-3xl bg-[#1c1914] p-6 font-mono text-[12.5px] leading-6 text-[#efe6d6]">{SITEMAP_TREE}</pre>

          <div className="flex flex-wrap gap-2">
            {LEVEL_ORDER.map((level) => (
              <span key={level} className={`rounded-full px-3 py-1.5 text-xs font-semibold ${LEVELS[level].tone}`}>
                {LEVELS[level].label} · {LEGACY_MAP.filter((r) => r.level === level).length} — {LEVELS[level].hint}
              </span>
            ))}
          </div>

          <div className="overflow-x-auto rounded-3xl border border-[#e4d9c5] bg-white">
            <table className="w-full min-w-[820px] text-left text-sm">
              <thead className="bg-[#f3eee4] text-[11px] uppercase tracking-wide text-[#6b6458]">
                <tr>
                  <th className="px-4 py-3">Rubrique héritée</th>
                  <th className="px-4 py-3">Origine</th>
                  <th className="px-4 py-3">Nouvelle place</th>
                  <th className="px-4 py-3">Niveau</th>
                  <th className="px-4 py-3">Pourquoi</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.legacy} className="border-t border-[#efe6d6] align-top">
                    <td className="px-4 py-3">
                      <span className="font-mono text-[12px] font-semibold">{row.legacy}</span>
                      <span dir="rtl" className="mt-0.5 block text-start text-[12px] text-[#6b6458]">
                        {row.ar}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-[#6b6458]">{row.origin}</td>
                    <td className="px-4 py-3 text-[13px]">{row.destination}</td>
                    <td className="px-4 py-3">
                      <span className={`whitespace-nowrap rounded-full px-2 py-0.5 text-[10px] font-bold ${LEVELS[row.level].tone}`}>
                        {LEVELS[row.level].label}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs leading-5 text-[#4a443b]">{row.why}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* ───────────── 02 ───────────── */}
        <section id="brique" className="scroll-mt-20 space-y-10">
          <Heading n="02" title="La brique de révision" />
          <p className="max-w-3xl text-[15px] leading-7 text-[#4a443b]">
            Une brique = une notion du programme = une séance quotidienne de {BRICK_MINUTES} minutes. La boucle imposée se rejoue dans
            chaque brique, et chaque phase a son propre verrou, validé côté serveur. Un chapitre lourd n&apos;est plus une leçon de
            deux heures : c&apos;est une suite de séances courtes, fermée par un jalon.
          </p>

          <SessionBar />

          <div className="overflow-x-auto rounded-3xl border border-[#e4d9c5] bg-white">
            <table className="w-full min-w-[820px] text-left text-sm">
              <thead className="bg-[#f3eee4] text-[11px] uppercase tracking-wide text-[#6b6458]">
                <tr>
                  <th className="px-4 py-3">Phase</th>
                  <th className="px-4 py-3">Durée</th>
                  <th className="px-4 py-3">Geste de l&apos;élève</th>
                  <th className="px-4 py-3">Verrou (pour passer)</th>
                  <th className="px-4 py-3">Morchid</th>
                  <th className="px-4 py-3">Interdit</th>
                </tr>
              </thead>
              <tbody>
                {PHASES.map((kind, i) => {
                  const m = PHASE_META[kind];
                  return (
                    <tr key={kind} className="border-t border-[#efe6d6] align-top">
                      <td className="px-4 py-3 font-semibold">
                        {i + 1}. {m.fr}
                        <span dir="rtl" className="block text-start font-naskh text-base font-normal text-[#1f5c45]">
                          {m.ar}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-mono">{m.minutes} min</td>
                      <td className="px-4 py-3">{m.gesteFr}</td>
                      <td className="px-4 py-3">{m.verrouFr}</td>
                      <td className="px-4 py-3 text-[#1f5c45]">{m.morchidFr ?? "Silencieux"}</td>
                      <td className="px-4 py-3 text-xs text-[#6b6458]">{m.interditFr}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="rounded-3xl bg-[#143d2e] p-6 text-[#fbf8f1]">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-[#e8d7a8]">Phase 3 · la clé à 4 dents (Miftah / Boussole du dépôt)</p>
            <div className="mt-4 grid gap-3 md:grid-cols-4">
              {TEETH.map((t) => (
                <div key={t.n} className="rounded-2xl bg-white/10 p-4">
                  <p dir="rtl" className="text-start font-naskh text-xl">
                    {t.n}. {t.ar} {t.triadAr && <span className="text-sm text-[#e8d7a8]">({t.triadAr})</span>}
                  </p>
                  <p dir="rtl" className="mt-1 text-start text-xs leading-5 text-white/80">
                    {t.questionAr}
                  </p>
                </div>
              ))}
            </div>
            <p className="mt-4 text-sm leading-6 text-white/80">
              L&apos;élève reçoit la réponse modèle du document en 4 phrases mélangées et doit ranger chacune dans sa dent. Les dents
              2-3-4 portent la triade imposée ألاحظ → أستنتج → أخلص : on n&apos;interprète jamais avant d&apos;avoir relevé une valeur et
              son unité.
            </p>
          </div>

          <div className="grid gap-5 lg:grid-cols-2">
            <Cut unitId={1} label="Exemple A" />
            <Cut unitId={4} label="Exemple B" />
          </div>

          <div>
            <h3 className="font-fr-display text-2xl">Mécanismes de déblocage</h3>
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              {UNLOCK_RULES.map((r, i) => (
                <article key={r.title} className="rounded-2xl border border-[#e4d9c5] bg-white p-4">
                  <p className="text-[11px] font-semibold text-[#9a7a2c]">Règle {i + 1}</p>
                  <h4 className="font-semibold">{r.title}</h4>
                  <p className="mt-1 text-sm leading-6 text-[#4a443b]">{r.rule}</p>
                </article>
              ))}
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-3xl border border-[#e4d9c5] bg-white p-5">
              <h3 className="font-semibold">Gamification calme — ce qu&apos;on garde</h3>
              <ul className="mt-3 space-y-2 text-sm leading-6 text-[#4a443b]">
                {CALM.yes.map((y) => (
                  <li key={y}>✓ {y}</li>
                ))}
              </ul>
            </div>
            <div className="rounded-3xl border border-dashed border-[#d9cdb6] p-5">
              <h3 className="font-semibold">Ce qu&apos;on retire</h3>
              <ul className="mt-3 flex flex-wrap gap-2 text-xs">
                {CALM.no.map((n) => (
                  <li key={n} className="rounded-full bg-[#ece6da] px-3 py-1 text-[#6b6458] line-through decoration-[#8a5a3c]/60">
                    {n}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ───────────── 03 ───────────── */}
        <section id="dashboard" className="scroll-mt-20 space-y-8">
          <Heading n="03" title="Wireframe du dashboard « anti-stress »" />
          <div className="grid items-start gap-10 md:grid-cols-[300px_1fr]">
            <PhoneMock />
            <ol className="space-y-3">
              {DASHBOARD_ZONES.map((z) => (
                <li key={z.zone} className="rounded-2xl border border-[#e4d9c5] bg-white p-4">
                  <p className="text-[11px] font-semibold uppercase tracking-wider text-[#9a7a2c]">{z.zone}</p>
                  <h3 className="font-semibold">{z.name}</h3>
                  <p className="mt-1 text-sm leading-6 text-[#4a443b]">{z.content}</p>
                  <p className="mt-2 text-xs font-semibold text-[#1f5c45]">Règle : {z.rule}</p>
                </li>
              ))}
            </ol>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-3xl border border-[#e4d9c5] bg-white p-5">
              <h3 className="font-semibold">Les 5 états de la carte</h3>
              <ul className="mt-3 space-y-2 text-sm leading-6">
                {DASHBOARD_STATES.map((s) => (
                  <li key={s.state}>
                    <span className="font-semibold">{s.state} — </span>
                    <span className="text-[#4a443b]">{s.text}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-3 text-xs text-[#6b6458]">
                Priorité : reprise &gt; rappel dû ({REVIEW_MINUTES} min) &gt; nouvelle séance (si quota) &gt; repos.
              </p>
            </div>
            <div className="rounded-3xl bg-[#f3e6c4]/60 p-5">
              <h3 className="font-semibold">Afficher l&apos;avancement sans panique</h3>
              <ul className="mt-3 space-y-2 text-sm leading-6 text-[#4a443b]">
                {NO_PANIC.map((n) => (
                  <li key={n}>— {n}</li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ───────────── 04 ───────────── */}
        <section id="morchid" className="scroll-mt-20 space-y-8">
          <Heading n="04" title="Morchid dans le parcours" />
          <div className="grid items-start gap-8 md:grid-cols-[220px_1fr]">
            <img src="/images/morchid.jpg" alt="Morchid" className="h-72 w-full rounded-3xl object-cover" />
            <div className="space-y-4">
              <p className="text-[15px] leading-7 text-[#4a443b]">
                Morchid ne vit plus dans un onglet. Il parle à quatre moments fixes de la séance, toujours sur la brique en cours, et
                se tait le reste du temps. Chaque parole est rattachée à un item et journalisée : on sait exactement quand et pourquoi
                il est intervenu.
              </p>
              <MorchidTimeline />
            </div>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {MORCHID_MOMENTS.map((m, i) => (
              <article key={m.id} className="rounded-3xl border border-[#e4d9c5] bg-white p-5">
                <div className="flex items-baseline justify-between gap-3">
                  <h3 className="font-fr-display text-xl">
                    {i + 1}. {m.fr}
                  </h3>
                  <span className="font-mono text-xs text-[#9a7a2c]">{m.at}</span>
                </div>
                <p dir="rtl" className="text-start font-naskh text-lg text-[#1f5c45]">
                  {m.ar}
                </p>
                <dl className="mt-3 space-y-2 text-sm leading-6">
                  <div>
                    <dt className="text-[11px] font-semibold uppercase text-[#6b6458]">Quand</dt>
                    <dd>{m.quandFr}</dd>
                  </div>
                  <div>
                    <dt className="text-[11px] font-semibold uppercase text-[#6b6458]">Ce qu&apos;il fait</dt>
                    <dd>{m.ditFr}</dd>
                  </div>
                  <div>
                    <dt className="text-[11px] font-semibold uppercase text-[#6b6458]">Ce qu&apos;il ne fait jamais</dt>
                    <dd className="text-[#8a5a3c]">{m.nonFr}</dd>
                  </div>
                </dl>
                <p className="mt-3 inline-block rounded-full bg-[#f3eee4] px-3 py-1 text-xs font-semibold">Plafond : {m.plafondFr}</p>
              </article>
            ))}
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="rounded-3xl bg-[#143d2e] p-5 text-[#fbf8f1]">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-[#e8d7a8]">La valve</p>
              <p dir="rtl" className="mt-1 text-start font-naskh text-2xl">
                {MORCHID_VALVE.ar}
              </p>
              <p className="mt-2 text-sm leading-6 text-white/85">{MORCHID_VALVE.ditFr}</p>
              <p className="mt-2 text-xs text-[#e8d7a8]">Plafond : {MORCHID_VALVE.plafondFr}</p>
            </div>
            <div className="rounded-3xl border border-[#e4d9c5] bg-white p-5 md:col-span-2">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-[#9a7a2c]">Interdits</p>
              <ul className="mt-2 space-y-1.5 text-sm leading-6 text-[#4a443b]">
                {MORCHID_FORBIDDEN_FR.map((f) => (
                  <li key={f}>✕ {f}</li>
                ))}
              </ul>
              <p className="mt-4 text-[11px] font-semibold uppercase tracking-wider text-[#9a7a2c]">Le diagnostic T1–T4</p>
              <div className="mt-2 grid gap-2 sm:grid-cols-2">
                {ERROR_TYPES.map((e) => (
                  <p key={e.code} className="rounded-xl bg-[#f3eee4] px-3 py-2 text-xs">
                    <span className="font-mono font-bold">{e.code}</span> · {e.fr}
                  </p>
                ))}
              </div>
            </div>
          </div>
          <p className="text-xs leading-6 text-[#6b6458]">
            Note d&apos;implémentation : dans ce prototype, les répliques sont dérivées du contenu de la brique (questions, pièges, erreurs
            types). En production, ces quatre points d&apos;ancrage sont les seuls endroits où l&apos;API du tuteur est appelée.
          </p>
        </section>

        <section className="rounded-[32px] bg-[#1f5c45] p-8 text-[#fbf8f1] md:p-10">
          <h2 className="font-fr-display text-3xl leading-tight">Demain matin, l&apos;élève ouvre l&apos;application.</h2>
          <p className="mt-3 max-w-2xl text-[15px] leading-7 text-white/85">
            Une carte, un bouton, {BRICK_MINUTES} minutes. Une question de Morchid avant le cours, quatre mots, une clé à quatre dents,
            une copie écrite avant le barème. Puis « يكفي اليوم ». Pas de catalogue, pas de pourcentage, pas de chat.
          </p>
          <Link href="/" className="mt-6 inline-flex rounded-full bg-white px-5 py-2.5 text-sm font-semibold text-[#143d2e]">
            Entrer dans le parcours de Lina →
          </Link>
        </section>
      </main>
    </div>
  );
}

function Heading({ n, title }: { n: string; title: string }) {
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#9a7a2c]">Livrable {n}</p>
      <h2 className="mt-1 font-fr-display text-3xl md:text-4xl">{title}</h2>
    </div>
  );
}

function SessionBar() {
  return (
    <div className="rounded-3xl border border-[#e4d9c5] bg-white p-5">
      <div className="flex overflow-hidden rounded-2xl text-[12px] font-semibold">
        {PHASES.map((kind, i) => {
          const m = PHASE_META[kind];
          return (
            <div
              key={kind}
              style={{ width: `${(m.minutes / BRICK_MINUTES) * 100}%` }}
              className={`px-3 py-4 ${["bg-[#143d2e] text-white", "bg-[#d7e6dc] text-[#143d2e]", "bg-[#1f5c45] text-white", "bg-[#f3e6c4] text-[#8a5a3c]"][i]}`}
            >
              <span className="block truncate">{m.fr}</span>
              <span className="block font-mono text-[11px] opacity-80">{m.minutes} min</span>
            </div>
          );
        })}
      </div>
      <div className="mt-2 flex justify-between font-mono text-[11px] text-[#6b6458]">
        <span>0:00</span>
        <span>
          {BRICK_MINUTES}:00 · règle d&apos;or 20–25 min · jalon d&apos;unité {JALON_MINUTES} min · rappel {REVIEW_MINUTES} min
        </span>
      </div>
    </div>
  );
}

function Cut({ unitId, label }: { unitId: number; label: string }) {
  const unit = UNITS.find((u) => u.id === unitId);
  if (!unit) return null;
  const bricks = bricksOfUnit(unitId);
  const minutes = bricks.length * BRICK_MINUTES + JALON_MINUTES;
  return (
    <article className="rounded-3xl border border-[#e4d9c5] bg-white p-5">
      <p className="text-[11px] font-semibold uppercase tracking-wider text-[#9a7a2c]">{label}</p>
      <h3 className="font-fr-display text-2xl">{unit.titleFr}</h3>
      <p dir="rtl" className="text-start font-naskh text-lg text-[#1f5c45]">
        {unit.number} · {unit.titleAr}
      </p>
      <p className="mt-2 text-xs leading-5 text-[#6b6458]">
        {unit.heures} h de cours en classe → {bricks.length} séances de {BRICK_MINUTES} min + 1 jalon de {JALON_MINUTES} min ≈{" "}
        {Math.floor(minutes / 60)} h {String(minutes % 60).padStart(2, "0")} de travail guidé, sur {bricks.length + 1} jours.
      </p>
      <ol className="mt-4 space-y-2">
        {bricks.map((b, i) => (
          <li key={b.id} className="grid grid-cols-[3.2rem_1fr] gap-2 rounded-2xl bg-[#f6f2ea] p-3 text-sm">
            <span className="font-mono text-xs font-semibold text-[#9a7a2c]">Jour {i + 1}</span>
            <span>
              <span className="font-semibold">{b.spec.titleFr}</span>
              <span dir="rtl" className="block text-start text-[12px] text-[#6b6458]">
                {b.spec.objectifAr}
              </span>
            </span>
          </li>
        ))}
        <li className="grid grid-cols-[3.2rem_1fr] gap-2 rounded-2xl bg-[#143d2e] p-3 text-sm text-white">
          <span className="font-mono text-xs font-semibold text-[#e8d7a8]">Jour {bricks.length + 1}</span>
          <span>
            <span className="font-semibold">Jalon جسر — synthèse de mémoire + check-list</span>
            <span dir="rtl" className="block text-start text-[12px] text-white/75">
              {unit.questionAr}
            </span>
          </span>
        </li>
      </ol>
      <p className="mt-3 text-xs text-[#6b6458]">Ensuite, chaque brique revient seule en rappel : J+1 ou J+3, puis J+7, puis J+21.</p>
    </article>
  );
}

function MorchidTimeline() {
  const starts: number[] = [];
  PHASES.reduce((t, kind) => {
    starts.push(t);
    return t + PHASE_META[kind].minutes;
  }, 0);
  const marks = [
    { at: 0, label: "1 · Sonde", row: 0 },
    { at: starts[2] + 1, label: "2 · Clé", row: 0 },
    { at: BRICK_MINUTES - 2, label: "3 · Diagnostic (si < 6/10)", row: 1 },
    { at: BRICK_MINUTES, label: "4 · Clôture", row: 0 },
  ];
  return (
    <div className="rounded-3xl border border-[#e4d9c5] bg-white p-5">
      <div className="relative h-20">
        {marks.map((m) => {
          const pct = (m.at / BRICK_MINUTES) * 100;
          const align = m.at === 0 ? "translate-x-0 items-start" : m.at === BRICK_MINUTES ? "-translate-x-full items-end" : "-translate-x-1/2 items-center";
          return (
            <div key={m.label} className={`absolute flex flex-col ${align}`} style={{ left: `${pct}%`, top: m.row ? 30 : 0 }}>
              <span className="whitespace-nowrap rounded-full bg-[#143d2e] px-2.5 py-0.5 text-[10px] font-semibold text-white">{m.label}</span>
              <span className="mt-1 block w-px bg-[#143d2e]" style={{ height: m.row ? 18 : 48 }} />
            </div>
          );
        })}
      </div>
      <div className="flex overflow-hidden rounded-xl text-[11px]">
        {PHASES.map((kind) => {
          const m = PHASE_META[kind];
          const speaks = Boolean(m.morchidFr);
          return (
            <div
              key={kind}
              style={{ width: `${(m.minutes / BRICK_MINUTES) * 100}%` }}
              className={`px-2 py-2 ${speaks ? "bg-[#d7e6dc] text-[#143d2e]" : "bg-[#f3eee4] text-[#6b6458]"}`}
            >
              <span className="block truncate font-semibold">{m.fr}</span>
              <span className="block truncate">{speaks ? "Morchid présent" : "Silence"}</span>
            </div>
          );
        })}
      </div>
      <p className="mt-2 text-[11px] text-[#6b6458]">
        Pendant le vocabulaire et la rédaction, Morchid se tait. « أنا عالق » reste disponible partout, 2 fois par phase.
      </p>
    </div>
  );
}

function PhoneMock() {
  return (
    <div dir="rtl" className="mx-auto w-[290px] rounded-[42px] border-[10px] border-[#1c1914] bg-[#f3eee4] p-3 font-sans shadow-2xl">
      <div className="rounded-[22px] bg-[#143d2e] p-3 text-[#fbf8f1]">
        <p className="text-[9px] text-[#f3e6c4]">الجمعة 2 أكتوبر</p>
        <p className="font-naskh text-lg leading-tight">صباح الخير، لينا</p>
        <p className="text-[9px] opacity-80">مهمّة واحدة اليوم. الباقي ينتظر.</p>
      </div>
      <div className="mt-2 rounded-2xl bg-[#fbf8f1] p-3 ring-1 ring-[#e4d9c5]">
        <p className="text-[9px] font-bold text-[#9a7a2c]">لبنة اليوم · 19 دقيقة</p>
        <p className="mt-1 text-[9px] text-[#1f5c45]">الوحدة 2 · بنية البروتين ووظيفته</p>
        <p className="font-naskh text-[15px] leading-6">سلوك الأحماض الأمينية</p>
        <div className="mt-2 grid grid-cols-4 gap-1">
          {["اكتشاف", "مصطلحات", "منهجية", "تطبيق"].map((p, i) => (
            <span key={p} className={`rounded-md py-1 text-center text-[8px] ${i === 0 ? "bg-[#1f5c45] text-white" : "bg-[#f3eee4] text-[#6b6458]"}`}>
              {p}
            </span>
          ))}
        </div>
        <p className="mt-2 rounded-lg bg-[#f3eee4] px-2 py-1 text-[8px] text-[#3f3a32]">المرشد يبدأ بسؤال واحد قبل الدرس.</p>
        <div className="mt-2 rounded-full bg-[#1f5c45] py-1.5 text-center text-[10px] font-bold text-white">ابدأ</div>
      </div>
      <div className="mt-2 grid grid-cols-2 gap-2">
        <div className="rounded-2xl bg-[#fbf8f1] p-2 ring-1 ring-[#e4d9c5]">
          <p className="text-[8px] font-bold">إيقاع الأسبوع</p>
          <div className="mt-1 grid grid-cols-7 gap-0.5">
            {[1, 1, 0, 1, 0, 0, 0].map((d, i) => (
              <span key={i} className={`h-3 rounded ${d ? "bg-[#1f5c45]" : "bg-[#f3eee4]"}`} />
            ))}
          </div>
          <p className="mt-1 text-[7px] text-[#6b6458]">3 من 5 · لا سلسلة تنقطع</p>
        </div>
        <div className="rounded-2xl bg-[#fbf8f1] p-2 ring-1 ring-[#e4d9c5]">
          <p className="text-[8px] font-bold">متوازٍ مع قسمك</p>
          <div className="mt-1 flex justify-between">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <span
                key={n}
                className={`h-2.5 w-2.5 rounded-full ${n === 1 ? "bg-[#1f5c45]" : n === 2 ? "bg-[#f3e6c4] ring-1 ring-[#9a7a2c]" : "bg-[#f3eee4]"}`}
              />
            ))}
          </div>
          <p className="mt-1 text-[7px] text-[#6b6458]">القسم = أنت · الوحدة 2</p>
        </div>
      </div>
      <div className="mt-3 grid grid-cols-4 text-center text-[8px] text-[#6b6458]">
        <span className="font-bold text-[#143d2e]">اليوم</span>
        <span>مساري</span>
        <span>البكالوريا</span>
        <span>أنا</span>
      </div>
    </div>
  );
}
