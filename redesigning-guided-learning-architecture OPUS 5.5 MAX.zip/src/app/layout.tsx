import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Amiri, Fraunces, IBM_Plex_Sans, IBM_Plex_Sans_Arabic } from "next/font/google";
import AppShell from "@/components/AppShell";
import "./globals.css";

const arabic = IBM_Plex_Sans_Arabic({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--nf-ar",
  display: "swap",
});

const amiri = Amiri({
  subsets: ["arabic", "latin"],
  weight: ["400", "700"],
  variable: "--nf-amiri",
  display: "swap",
});

const plex = IBM_Plex_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--nf-plex",
  display: "swap",
});

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--nf-fraunces",
  display: "swap",
});

export const metadata: Metadata = {
  title: "كنز العلوم — مسار البكالوريا",
  description: "Kunz El Ouloum · SVT Bac Algérie : un parcours guidé, une seule tâche par jour.",
};

export const viewport: Viewport = {
  themeColor: "#143d2e",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="ar"
      dir="rtl"
      className={`${arabic.variable} ${amiri.variable} ${plex.variable} ${fraunces.variable}`}
    >
      <body className="min-h-dvh font-sans antialiased">
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
