import { Gate } from "@/components/gates";
import { MockExam } from "@/components/widgets";
import { brickById, rubricOf, unitById } from "@/lib/curriculum";
import { formatDayAr } from "@/lib/dates";
import { currentLearnerId, getState } from "@/lib/engine";

export const dynamic = "force-dynamic";

export default async function MockExamPage() {
  const state = await getState(await currentLearnerId());
  if (!state.finale.open) {
    return (
      <Gate
        title="الامتحان التجريبي مغلق"
        text={`يُفتح يوم ${formatDayAr(state.finale.opensOn)}، قبل البكالوريا بثمانية أسابيع. حتى ذلك الحين، مهمّة اليوم وحدها تكفي.`}
      />
    );
  }

  const seen = new Set<number>();
  const picked = state.units
    .flatMap((u) => u.bricks.filter((b) => b.status === "done").map((b) => ({ id: b.id, weight: u.bacWeightObserved, unitId: u.id })))
    .sort((a, b) => b.weight - a.weight)
    .filter((b) => (seen.has(b.unitId) ? false : (seen.add(b.unitId), true)))
    .slice(0, 3);

  if (!picked.length) {
    return <Gate title="لا ورقة بعد" text="الامتحان التجريبي يُبنى من اللبنات التي أنجزتها. أنجز لبنة أولاً." />;
  }

  const exercises = picked.map((p) => {
    const brick = brickById(p.id)!;
    return {
      id: brick.id,
      unitNumber: unitById(brick.unitId)?.number ?? "",
      titleAr: brick.spec.titleAr,
      enonceAr: brick.spec.application.enonceAr,
      supportsAr: brick.spec.application.supportsAr,
      rubric: rubricOf(brick),
    };
  });

  return (
    <div className="space-y-5">
      <header>
        <p className="eyebrow">المرحلة النهائية</p>
        <h1 className="font-naskh text-[2rem] leading-tight">امتحان تجريبي · 60 دقيقة</h1>
        <p className="mt-2 text-sm leading-7 text-mute">
          ثلاثة تمارين من وحدات أنجزتها، مرتّبة بوزنها في الجلسات. السلالم تظهر بعد أن تسلّم الورقة كاملة.
        </p>
      </header>
      <MockExam exercises={exercises} />
    </div>
  );
}
