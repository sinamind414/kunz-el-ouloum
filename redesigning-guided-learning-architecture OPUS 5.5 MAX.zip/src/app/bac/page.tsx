import Link from "next/link";
import { Check, Lock } from "lucide-react";
import { UNITS } from "@/lib/curriculum";
import { formatDayAr } from "@/lib/dates";
import { currentLearnerId, getState } from "@/lib/engine";

export const dynamic = "force-dynamic";

export default async function BacPage() {
  const state = await getState(await currentLearnerId());
  const copies = state.units.flatMap((unit) =>
    unit.bricks.filter((b) => b.status === "done").map((b) => ({ ...b, unitNumber: unit.number, weight: unit.bacWeightObserved })),
  );
  const maxWeight = Math.max(...UNITS.map((u) => u.bacWeightObserved));
  const plan = [...copies].sort((a, b) => Number(b.fragile) - Number(a.fragile) || b.weight - a.weight).slice(0, 5);

  return (
    <div className="space-y-6">
      <header>
        <p className="eyebrow">البكالوريا</p>
        <h1 className="font-naskh text-[2.2rem] leading-tight">يُفتح ما أنجزته، لا أكثر.</h1>
        <p className="mt-2 text-sm leading-7 text-mute">
          لا بنك مواضيع مفتوح على مصراعيه. هنا أوراقك المصحّحة، جسور وحداتك، وما يسقط فعلاً. التدريب تحت الضغط ينتظر المرحلة النهائية.
        </p>
      </header>

      <section className="card p-5">
        <div className="flex items-baseline justify-between">
          <h2 className="font-bold">أوراقك</h2>
          <span className="text-xs text-mute">تطبيقات البكالوريا التي كتبتَها</span>
        </div>
        {copies.length === 0 ? (
          <p className="mt-3 text-sm text-mute">أوّل ورقة تظهر هنا بعد أوّل لبنة.</p>
        ) : (
          <ul className="mt-3 divide-y divide-line">
            {copies.map((c) => (
              <li key={c.id}>
                <Link href={`/parcours/${c.id}`} className="flex items-center justify-between gap-3 py-3">
                  <span className="min-w-0">
                    <span className="block text-[11px] font-semibold text-forest">{c.unitNumber}</span>
                    <span className="block truncate text-sm font-semibold">{c.titleAr}</span>
                  </span>
                  <span
                    className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-bold ${c.fragile ? "bg-gold-soft text-clay" : "bg-sage text-forest-deep"}`}
                    dir="ltr"
                  >
                    {c.score ? `${c.score.score}/${c.score.total}` : "—"}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="card p-5">
        <h2 className="font-bold">جسور الوحدات</h2>
        <p className="mt-1 text-xs text-mute">كل جسر حصيلة من الذاكرة لوحدة كاملة: أقرب تمرين إلى روح الموضوع.</p>
        <ol className="mt-4 grid grid-cols-4 gap-2 md:grid-cols-6">
          {state.units.map((u) => {
            const tile = (
              <span
                className={`flex h-16 flex-col items-center justify-center rounded-2xl text-xs font-bold ${
                  u.jalon.status === "done"
                    ? "bg-forest text-paper"
                    : u.jalon.status === "current"
                      ? "border-2 border-gold bg-gold-soft text-clay"
                      : "bg-cream text-mute"
                }`}
              >
                {u.jalon.status === "done" ? <Check className="h-4 w-4" /> : u.jalon.status === "locked" ? <Lock className="h-3.5 w-3.5" /> : "•"}
                <span className="mt-1">الوحدة {u.id}</span>
              </span>
            );
            return (
              <li key={u.id} title={u.titleAr}>
                {u.jalon.status === "locked" ? tile : <Link href={`/parcours/jalon/${u.id}`}>{tile}</Link>}
              </li>
            );
          })}
        </ol>
      </section>

      <section className="card p-5">
        <h2 className="font-bold">ما يسقط فعلاً</h2>
        <p className="mt-1 text-xs leading-6 text-mute">
          حصّة كل وحدة من نقاط الجلسات المفهرسة في التطبيق. لا تغيّر ترتيب مسارك اليوم؛ تُستعمل في المرحلة النهائية لترتيب المراجعة.
        </p>
        <ul className="mt-4 space-y-2">
          {UNITS.map((u) => (
            <li key={u.id} className="grid grid-cols-[4.75rem_1fr_3rem] items-center gap-2 text-xs">
              <span className="font-semibold text-ink-soft">{u.number}</span>
              <span className="h-2.5 overflow-hidden rounded-full bg-cream">
                <span className="block h-full rounded-full bg-forest/80" style={{ width: `${(u.bacWeightObserved / maxWeight) * 100}%` }} />
              </span>
              <span dir="ltr" className="text-end font-fr text-mute">
                {u.bacWeightObserved}%
              </span>
            </li>
          ))}
        </ul>
      </section>

      <section className={`rounded-[24px] p-5 ${state.finale.open ? "card" : "border border-dashed border-line"}`}>
        <h2 className="font-bold">المرحلة النهائية</h2>
        {state.finale.open ? (
          <>
            <p className="mt-1 text-sm leading-7 text-mute">
              ثمانية أسابيع قبل البكالوريا: خطة مراجعة مرتّبة بالهشاشة ثم بالوزن، وامتحان تجريبي واحد تحت الضغط.
            </p>
            <ol className="mt-3 space-y-1.5 text-sm">
              {plan.map((p, i) => (
                <li key={p.id}>
                  {i + 1}. {p.titleAr} <span className="text-xs text-mute">({p.fragile ? "هشّة" : p.unitNumber})</span>
                </li>
              ))}
            </ol>
            <Link href="/bac/blanc" className="btn-primary mt-4">
              امتحان تجريبي · 60 دقيقة
            </Link>
          </>
        ) : (
          <p className="mt-2 flex items-start gap-2 text-sm leading-7 text-mute">
            <Lock className="mt-1.5 h-4 w-4 shrink-0" />
            تُفتح يوم {formatDayAr(state.finale.opensOn)}، قبل البكالوريا بثمانية أسابيع: خطة المراجعة النهائية والامتحان التجريبي. قبلها،
            الامتحان تحت الضغط يضيف قلقاً أكثر مما يضيف تعلّماً.
          </p>
        )}
      </section>
    </div>
  );
}
