import { currentLearnerId, getState } from "@/lib/engine";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/** Résumé lisible de l'état : utile au suivi parent/enseignant et au diagnostic. */
export async function GET() {
  try {
    const state = await getState(await currentLearnerId());
    return Response.json({
      ok: true,
      learner: { id: state.learner.id, name: state.learner.name, examDate: state.learner.examDate },
      today: state.today,
      nba: state.nba.type === "review" ? { ...state.nba, review: undefined } : state.nba,
      pace: state.pace,
      week: { count: state.week.count, target: state.week.target },
      stats: state.stats,
      upcomingReview: state.upcomingReview,
      finale: state.finale,
    });
  } catch (error) {
    console.error(error);
    return Response.json({ ok: false }, { status: 500 });
  }
}
