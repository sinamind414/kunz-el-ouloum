import { runAction } from "@/lib/actions";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const result = await runAction(body);
    return Response.json(result, { status: result.ok ? 200 : 400 });
  } catch (error) {
    console.error(error);
    return Response.json({ ok: false, error: "تعذّر الحفظ. أعد المحاولة بعد لحظة." }, { status: 500 });
  }
}
