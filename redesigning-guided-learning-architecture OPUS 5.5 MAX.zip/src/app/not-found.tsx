import Link from "next/link";

export default function NotFound() {
  return (
    <section className="card mx-auto mt-10 max-w-md p-6 text-center">
      <p className="eyebrow">خارج المسار</p>
      <h1 className="mt-2 font-naskh text-2xl">هذه الصفحة غير موجودة</h1>
      <p className="mt-2 text-sm leading-7 text-mute">لا أبواب جانبية في كنز العلوم: مهمّتك الوحيدة تنتظرك في «اليوم».</p>
      <Link href="/" className="btn-primary mt-5">
        العودة إلى اليوم
      </Link>
    </section>
  );
}
