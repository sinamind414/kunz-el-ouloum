import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { ExtraButton, ReviewForm } from "@/components/widgets";
import { DOMAINS, PHASES, PHASE_META, brickById, seededOrder } from "@/lib/curriculum";
import { formatDayAr } from "@/lib/dates";
import { currentLearnerId, getState, type AppState } from "@/lib/engine";
import { presenceAr } from "@/lib/morchid";

export const dynamic = "force-dynamic";

function greeting(): string {
  const hour = Number(
    new Intl.DateTimeFormat("en-GB", { hour: "numeric", hour12: false, timeZone: "Africa/Algiers" }).format(new Date()),
  );
  return hour >= 4 && hour < 12 ? "صباح الخير" : "مساء الخير";
}

export default async function TodayPage() {
  const state = await getState(await currentLearnerId());
  const first = state.learner.name.split(" ")[0];
  const resting = state.nba.type === "rest" || state.nba.type === "done";

  return (
    <div className="space-y-5">
      <header className="relative overflow-hidden rounded-[28px]">
        <img src="/images/olive.jpg" alt="" className="h-36 w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-l from-forest-deep/95 via-forest-deep/70 to-forest-deep/20" />
        <div className="absolute inset-0 flex flex-col justify-end p-5 text-paper">
          <p className="text-xs font-medium text-gold-soft">{formatDayAr(state.today)}</p>
          <h1 className="font-naskh text-[2rem] leading-tight">
            {greeting()}، {first}
          </h1>
          <p className="text-sm text-paper/85">{resting ? "يكفي اليوم. الباقي ينتظر غداً." : "مهمّة واحدة اليوم. الباقي ينتظر."}</p>
        </div>
      </header>

      <NbaCard state={state} />

      <div className="grid gap-5 md:grid-cols-2">
        <WeekCard state={state} />
        <ClassCard state={state} />
      </div>

      <p className="px-4 text-center text-[11px] leading-6 text-mute">
        لا نسبة مئوية ولا عدّ تنازلي في هذه الصفحة. موعد البكالوريا وأرقامك في «أنا».
      </p>
    </div>
  );
}

function PhaseStrip({ current }: { current: number }) {
  return (
    <ol className="mt-4 grid grid-cols-4 gap-1.5">
      {PHASES.map((kind, i) => (
        <li
          key={kind}
          className={`rounded-xl px-1.5 py-2 text-center ${
            i < current ? "bg-sage text-forest-deep" : i === current ? "bg-forest text-paper" : "bg-cream text-mute"
          }`}
        >
          <span className="block text-[11px] font-bold">{PHASE_META[kind].ar}</span>
          <span className="block text-[10px] opacity-80">{PHASE_META[kind].minutes} د</span>
        </li>
      ))}
    </ol>
  );
}

function NbaCard({ state }: { state: AppState }) {
  const { nba } = state;

  if (nba.type === "brick") {
    return (
      <section className="card p-5 md:p-6">
        <p className="eyebrow">
          {nba.mode === "continue" ? `أكمل لبنتك · المرحلة ${nba.phaseIndex + 1} من 4` : "لبنة اليوم"} · {nba.minutes} دقيقة
        </p>
        <p className="mt-3 text-xs font-semibold text-forest">
          {nba.unitNumber} · {nba.unitTitleAr}
        </p>
        <h2 className="mt-1 font-naskh text-[1.75rem] leading-snug text-ink">{nba.titleAr}</h2>
        <p className="mt-2 text-sm text-ink-soft">
          <span className="font-semibold text-forest-deep">الهدف:</span> {nba.objectifAr}
        </p>
        <PhaseStrip current={nba.phaseIndex} />
        <div className="mt-4 flex items-center gap-3 rounded-2xl bg-cream px-3 py-2.5">
          <img src="/images/morchid.jpg" alt="" className="h-8 w-8 rounded-full object-cover" />
          <p className="text-xs leading-5 text-ink-soft">{presenceAr(nba.phase)}</p>
        </div>
        <Link href={`/parcours/${nba.brickId}`} className="btn-primary mt-5 w-full">
          {nba.mode === "continue" ? "أكمل" : "ابدأ"} <ArrowLeft className="h-4 w-4" />
        </Link>
        <p className="mt-3 text-center text-[11px] leading-5 text-mute">لماذا هذه؟ {state.pace.whyAr}</p>
      </section>
    );
  }

  if (nba.type === "jalon") {
    return (
      <section className="card p-5 md:p-6">
        <p className="eyebrow">جسر الوحدة · {nba.minutes} دقيقة</p>
        <p className="mt-3 text-xs font-semibold text-forest">
          {nba.unitNumber} · {nba.unitTitleAr}
        </p>
        <h2 className="mt-1 font-naskh text-[1.75rem] leading-snug">أغلق الوحدة قبل أن تفتح التالية</h2>
        <p className="mt-2 text-sm leading-7 text-ink-soft">
          سؤال واحد تجيب عنه من ذاكرتك: «{nba.questionAr}» ثم قائمة تحقّق بالأفكار الأساسية والفخاخ.
        </p>
        <Link href={`/parcours/jalon/${nba.unitId}`} className="btn-primary mt-5 w-full">
          {nba.mode === "continue" ? "أكمل الجسر" : "ابدأ الجسر"} <ArrowLeft className="h-4 w-4" />
        </Link>
      </section>
    );
  }

  if (nba.type === "review") {
    const brick = brickById(nba.brickId);
    if (!brick) return null;
    const check = brick.spec.checks[2] ?? brick.spec.checks[0];
    const vocabIndex = nba.review.doneCount % brick.spec.vocab.length;
    const order = seededOrder(brick.spec.vocab.length, `${brick.id}-rev-${nba.review.doneCount}`);
    return (
      <section className="card p-5 md:p-6">
        <p className="eyebrow">مراجعة متباعدة · {nba.minutes} دقائق · قبل أيّ جديد</p>
        <p className="mt-3 text-xs font-semibold text-forest">{nba.unitTitleAr}</p>
        <h2 className="mt-1 font-naskh text-[1.6rem] leading-snug">{nba.titleAr}</h2>
        <p className="mt-2 text-xs leading-6 text-mute">
          {nba.review.fragile ? "هذه اللبنة كانت هشّة: نثبّتها قبل أن نبني فوقها." : "تعود في موعدها حتى لا تُنسى."}
        </p>
        <ReviewForm
          check={{ promptAr: check.promptAr, options: check.optionsAr }}
          vocab={{
            defAr: brick.spec.vocab[vocabIndex].defAr,
            terms: order.map((i) => ({ i, termAr: brick.spec.vocab[i].termAr })),
          }}
        />
      </section>
    );
  }

  if (nba.type === "rest") {
    return (
      <section className="card overflow-hidden">
        <img src="/images/landscape.jpg" alt="" className="h-28 w-full object-cover" />
        <div className="p-5 md:p-6">
          <p className="eyebrow">يكفي اليوم</p>
          <h2 className="mt-1 font-naskh text-[1.6rem] leading-snug">أحسنت. غداً: {nba.nextTitleAr}</h2>
          <p className="mt-2 text-sm leading-7 text-ink-soft">
            {nba.nextUnitAr}. لا شيء آخر ذو أولوية اليوم — التثبيت يحدث أيضاً حين تتوقّف.
          </p>
          {state.upcomingReview && (
            <p className="mt-2 text-xs text-mute">
              مراجعة «{state.upcomingReview.titleAr}» يوم {formatDayAr(state.upcomingReview.dueOn)}.
            </p>
          )}
          {!nba.extraUsed && (
            <div className="mt-4">
              <ExtraButton />
            </div>
          )}
        </div>
      </section>
    );
  }

  return (
    <section className="card p-6 text-center">
      <p className="eyebrow">المسار مكتمل</p>
      <h2 className="mt-2 font-naskh text-2xl">أنهيت كل اللبنات والجسور.</h2>
      <p className="mt-2 text-sm text-mute">تبقى المراجعات المتباعدة في مواعيدها، والمرحلة النهائية في «البكالوريا».</p>
    </section>
  );
}

function WeekCard({ state }: { state: AppState }) {
  const { week } = state;
  return (
    <section className="card p-5">
      <div className="flex items-baseline justify-between">
        <h3 className="text-sm font-bold">إيقاع الأسبوع</h3>
        <span className="text-xs text-mute">
          {week.count} من {week.target} جلسات
        </span>
      </div>
      <ol className="mt-4 grid grid-cols-7 gap-1.5">
        {week.days.map((day) => (
          <li key={day.key} className="text-center">
            <span
              className={`block h-9 rounded-xl ${day.done ? "bg-forest" : "bg-cream"} ${
                day.today ? "ring-2 ring-gold ring-offset-2 ring-offset-paper" : ""
              }`}
            />
            <span className="mt-1.5 block text-[10px] text-mute">{day.label}</span>
          </li>
        ))}
      </ol>
      <p className="mt-3 text-xs leading-6 text-mute">
        {week.count >= week.target
          ? "الإيقاع مكتمل هذا الأسبوع. ما زاد مكافأة، لا واجب."
          : "خمس جلسات في الأسبوع تكفي. يوم ضائع لا يكسر شيئاً: لا سلسلة تنقطع هنا."}
      </p>
    </section>
  );
}

function ClassCard({ state }: { state: AppState }) {
  const { pace } = state;
  return (
    <section className="card p-5">
      <h3 className="text-sm font-bold">{pace.titleAr}</h3>
      <p className="mt-1 text-xs leading-6 text-mute">{pace.textAr}</p>
      <div className="mt-7 grid grid-cols-[5fr_3fr_3fr] gap-2">
        {DOMAINS.map((domain) => (
          <div key={domain.id}>
            <ol className="flex items-center justify-between rounded-full bg-cream px-1.5 py-1">
              {state.units
                .filter((u) => u.domainId === domain.id)
                .map((u) => (
                  <li key={u.id} className="relative flex flex-col items-center">
                    {u.classHere && <span className="absolute -top-5 whitespace-nowrap text-[9px] font-bold text-clay">القسم</span>}
                    <span
                      title={u.titleAr}
                      className={`grid h-6 w-6 place-items-center rounded-full text-[10px] font-bold ${
                        u.status === "done"
                          ? "bg-forest text-paper"
                          : u.status === "current"
                            ? "border-2 border-gold bg-gold-soft text-clay"
                            : "bg-paper text-mute"
                      } ${u.classHere ? "ring-2 ring-clay/40" : ""}`}
                    >
                      {u.id}
                    </span>
                    {u.status === "current" && <span className="absolute -bottom-5 whitespace-nowrap text-[9px] font-bold text-forest">أنت</span>}
                  </li>
                ))}
            </ol>
            <p className="mt-6 truncate text-center text-[10px] text-mute">{domain.shortAr}</p>
          </div>
        ))}
      </div>
      <p className="mt-3 text-[11px] leading-5 text-mute">نقارنك بقسمك (التدرّج السنوي الرسمي)، لا بجبل البرنامج كلّه.</p>
    </section>
  );
}
