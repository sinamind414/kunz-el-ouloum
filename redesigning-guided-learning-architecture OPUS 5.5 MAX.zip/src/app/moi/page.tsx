import Link from "next/link";
import { Leaf } from "lucide-react";
import { AccountButtons, NoteDrawer, ProfileForm } from "@/components/widgets";
import { DOMAINS, unitById } from "@/lib/curriculum";
import { countAr, formatDayAr } from "@/lib/dates";
import { currentLearnerId, getState } from "@/lib/engine";

export const dynamic = "force-dynamic";

export default async function MoiPage() {
  const state = await getState(await currentLearnerId());
  const { stats } = state;

  return (
    <div className="space-y-6">
      <header className="flex items-end justify-between gap-4">
        <div>
          <p className="eyebrow">أنا</p>
          <h1 className="font-naskh text-[2.2rem] leading-tight">{state.learner.name}</h1>
          <p className="mt-1 text-xs text-mute">
            رمز المتابعة: <span dir="ltr" className="font-fr font-semibold text-ink-soft">{state.learner.id.slice(-6).toUpperCase()}</span>
            {state.isDemo && " · مسار تجريبي"}
          </p>
        </div>
      </header>

      <section className="card p-5">
        <h2 className="font-bold">شجرتك</h2>
        <p className="mt-1 text-xs leading-6 text-mute">ورقة لكل لبنة، وزيتونة لكل جسر. لا نقاط، ولا ترتيب بين التلاميذ.</p>
        <div className="mt-4 space-y-4">
          {DOMAINS.map((domain) => (
            <div key={domain.id}>
              <p className="mb-2 text-[11px] font-bold text-gold">{domain.titleAr}</p>
              <ul className="space-y-1.5">
                {state.units
                  .filter((u) => u.domainId === domain.id)
                  .map((u) => (
                    <li key={u.id} className="flex items-center gap-3">
                      <span className="w-40 shrink-0 truncate text-xs text-ink-soft md:w-56" title={u.titleAr}>
                        {u.id}. {u.titleAr}
                      </span>
                      <span className="flex flex-1 flex-wrap items-center gap-1 border-r-2 border-clay/30 pr-2">
                        {u.bricks.map((b) => (
                          <Leaf
                            key={b.id}
                            aria-label={b.titleAr}
                            className={`h-4 w-4 ${
                              b.status === "done" ? (b.fragile ? "fill-gold-soft text-gold" : "fill-forest text-forest") : "text-line"
                            }`}
                          />
                        ))}
                        <span
                          title="الجسر"
                          className={`mr-1 h-3 w-3 rounded-full ${u.jalon.status === "done" ? "bg-forest-deep" : "border border-line"}`}
                        />
                      </span>
                    </li>
                  ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section className="card p-5 text-sm leading-8">
        <h2 className="font-bold">أرقامك بالكلمات</h2>
        <p className="mt-2 text-ink-soft">
          {stats.bricksDone > 0
            ? `${countAr(stats.bricksDone, ["لبنة واحدة مثبّتة", "لبنتان مثبّتتان", "لبنات مثبّتة", "لبنة مثبّتة"])} من ${stats.bricksTotal}`
            : `لا لبنة مثبّتة بعد من ${stats.bricksTotal}`}
          {stats.bricksFragile > 0 && ` — منها ${countAr(stats.bricksFragile, ["واحدة هشّة", "اثنتان هشّتان", "هشّة", "هشّة"])} تعود في المراجعة`}.{" "}
          {stats.jalonsDone > 0
            ? countAr(stats.jalonsDone, ["جسر واحد مفتوح", "جسران مفتوحان", "جسور مفتوحة", "جسراً مفتوحاً"])
            : "لا جسر مفتوح بعد"}
          . {stats.reviewsDone > 0 && `${stats.reviewsDone} مراجعة متباعدة أنجزتها.`}
        </p>
        <p className="mt-2 text-xs text-mute">
          البكالوريا يوم {formatDayAr(state.learner.examDate)} — بعد {state.finale.weeksToBac} أسبوعاً. هذا الرقم يعيش هنا فقط، لا في صفحة «اليوم».
        </p>
      </section>

      <section className="card p-5">
        <div className="flex items-baseline justify-between gap-3">
          <h2 className="font-bold">كرّاستي</h2>
          <span className="text-xs text-mute">التدوين · الأسئلة المؤجّلة</span>
        </div>
        {state.notes.length === 0 ? (
          <p className="mt-3 text-sm text-mute">ما تدوّنه داخل اللبنات يظهر هنا.</p>
        ) : (
          <ul className="mt-3 space-y-2">
            {state.notes.map((note) => (
              <li key={note.id} className="rounded-2xl border border-line p-3">
                <p className="text-[11px] font-bold text-gold">
                  {note.kind === "question"
                    ? `سؤال مؤجّل — يعود في جسر ${note.unitId ? (unitById(note.unitId)?.number ?? "") : "الوحدة"}`
                    : `ملاحظة${note.unitId ? ` · ${unitById(note.unitId)?.number ?? ""}` : ""}`}
                </p>
                <p className="mt-1 text-sm leading-7">{note.body}</p>
              </li>
            ))}
          </ul>
        )}
        <div className="mt-4">
          <NoteDrawer />
        </div>
      </section>

      <section className="card space-y-3 p-5">
        <h2 className="font-bold">الإعدادات</h2>
        <ProfileForm name={state.learner.name} examDate={state.learner.examDate} />
      </section>

      <section className="card space-y-2 p-5 text-sm leading-7">
        <h2 className="font-bold">المتابعة (وليّ الأمر · الأستاذ)</h2>
        <p className="text-ink-soft">
          يرى المتابع ما تراه هنا: لبنات وجسور وإيقاع أسبوعي، لا نسبة مئوية ولا ترتيب. رمز المتابعة أعلاه يكفي لربط الحساب.
        </p>
      </section>

      <section className="card space-y-3 p-5">
        <h2 className="font-bold">الحساب</h2>
        <AccountButtons isDemo={state.isDemo} />
      </section>

      <p className="text-center text-[11px] text-mute">
        <Link href="/architecture" dir="ltr" className="font-fr underline decoration-line underline-offset-4">
          Architecture du parcours (document produit)
        </Link>
      </p>
    </div>
  );
}
