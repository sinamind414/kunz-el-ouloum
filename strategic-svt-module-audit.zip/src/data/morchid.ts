/**
 * AUDIT PÉDAGOGIQUE DU TUTEUR « المرشد الذكي » (Morchid)
 * Méthode : aucune conversation n'ayant été fournie, l'audit porte sur la SOURCE
 * qui produit chaque réponse — smartTutorEngine.ts, studyGuide.ts,
 * methodologyKnowledge.ts, bookTutorQA.ts, AITutorView.tsx.
 * Toute citation ci-dessous est un extrait littéral du dépôt.
 */

export interface Pillar {
  id: "guide" | "coach" | "gardefou";
  n: number;
  name: string;
  role: string;
  question: string;
  score: number;
  color: string;
  verdict: string;
  evidence: { kind: "pour" | "contre"; file: string; code: string; read: string }[];
  flaws: { title: string; detail: string; gravity: "critique" | "majeure" | "mineure" }[];
}

export const PILLARS: Pillar[] = [
  {
    id: "guide",
    n: 1,
    name: "L'Orientation",
    role: "Le Guide",
    question: "Propose-t-il une méthode et une priorisation, ou récite-t-il le cours ?",
    score: 5,
    color: "#f59e0b",
    verdict:
      "Le contenu d'orientation est excellent et dépasse la plupart des manuels algériens — mais il est PASSIF : Morchid ne le propose jamais, il attend qu'on le lui demande. Et sa seule priorisation réelle est l'ordre d'un tableau JavaScript.",
    evidence: [
      {
        kind: "pour",
        file: "studyGuide.ts · unit_study_protocol",
        code: "'افهم منطق الوحدة كقصة علمية: ما المشكلة؟ ما المقر؟ ما الآلية؟ ما النتيجة؟'",
        read: "Le protocole en 5 étapes est une vraie démarche cognitive : comprendre → extraire les mots-clés → dessiner le schéma bilan → exercices gradués → carnet d'erreurs. C'est du niveau inspection.",
      },
      {
        kind: "pour",
        file: "studyGuide.ts · قاعدة العبور",
        code: "'لا تنتقل إلى وحدة جديدة حتى تستطيع كتابة نص علمي قصير عنها'",
        read: "Une règle de passage explicite entre unités : c'est exactement ce qu'un inspecteur attend d'un dispositif d'autonomie.",
      },
      {
        kind: "pour",
        file: "studyGuide.ts · bac_method_pack",
        code: "'لا تجعل الاستنتاج وصفاً للحركة أو الأرقام، بل اجعله مقرّاً أو علاقة أو آلية'",
        read: "Il nomme le piège n°1 du BAC algérien (confondre décrire et conclure). Contenu rare et juste.",
      },
      {
        kind: "contre",
        file: "smartTutorEngine.ts · getDailyMission",
        code: "if (session.mistakes.length > 0) { targetTopicId = session.mistakes[0]; }\nelse { targetTopicId = KNOWLEDGE_CARDS[0].id; }",
        read: "Voilà toute la « priorisation » : la PREMIÈRE erreur jamais enregistrée, sinon la PREMIÈRE carte du tableau. Ni fréquence d'erreur, ni poids BAC de l'unité, ni ancienneté, ni oubli. Ce n'est pas un choix pédagogique, c'est un index zéro.",
      },
      {
        kind: "contre",
        file: "smartTutorEngine.ts · findBestStudyGuide",
        code: "if (studyGuideMatches.length > 0 && studyGuideMatches[0].score >= 18)",
        read: "Le plan de travail n'apparaît que si l'élève tape « كيف ادرس العلوم ». Un élève perdu ne sait pas formuler cette question : le guide est invisible à ceux qui en ont le plus besoin.",
      },
      {
        kind: "contre",
        file: "dashboardActions.ts",
        code: "export const BAC_EXAM_DATE = '';",
        read: "Morchid ignore la date du BAC. Il ne peut donc construire aucun cycle de révision, aucun rétro-planning, aucune priorité temporelle. Un guide sans calendrier n'est pas un guide.",
      },
    ],
    flaws: [
      {
        title: "La priorisation est un index de tableau",
        detail:
          "mistakes[0] et KNOWLEDGE_CARDS[0] : l'élève qui se trompe 9 fois en immunologie et 1 fois en tectonique sera renvoyé vers la tectonique si c'est sa première erreur chronologique.",
        gravity: "critique",
      },
      {
        title: "Aucune reprise espacée dans le tuteur",
        detail:
          "L'algorithme SM-2 existe dans RevisionView mais Morchid ne l'interroge jamais. Les erreurs sont stockées (session.mistakes) et ne sont jamais reprogrammées dans le temps.",
        gravity: "majeure",
      },
      {
        title: "Le guide ne se déclenche jamais de lui-même",
        detail:
          "Aucun code ne pousse le protocole d'étude après un échec. Après un 4/30 au défi BAC, Morchid propose « راجع أخطائي السابقة » — jamais « voici comment on révise cette unité ».",
        gravity: "majeure",
      },
    ],
  },
  {
    id: "coach",
    n: 2,
    name: "La Motivation",
    role: "Le Coach",
    question: "Le ton est-il empathique mais ferme ? Redonne-t-il confiance face au stress ?",
    score: 3,
    color: "#ef4444",
    verdict:
      "Il n'y a pas de coach. Il y a une table de correspondance de trois adjectifs et un distributeur d'XP. Pire : un élève qui exprime son angoisse en darija est classé « hors programme » et renvoyé au programme officiel.",
    evidence: [
      {
        kind: "contre",
        file: "smartTutorEngine.ts · handleBossInput",
        code: "const appreciation = pct >= 80 ? 'ممتاز 🏆' : pct >= 50 ? 'جيد 👍' : 'يحتاج مراجعة 📖';",
        read: "Toute la dimension affective du tuteur tient dans cette ligne. Un élève à 12 % et un élève à 49 % reçoivent le même « يحتاج مراجعة 📖 » : un verdict, sans cause, sans remède, sans lendemain.",
      },
      {
        kind: "contre",
        file: "smartTutorEngine.ts · hasDomainSignal + AR_STOPWORDS",
        code: "// « راني خايف من الباك » → aucun token dans DOMAIN_VOCAB\n// PEDAGOGICAL_TERMS contient 'بكالوريا' mais PAS 'الباك'\n→ outOfScopeResult()",
        read: "Un élève qui écrit sa peur en darija algérienne reçoit : « ❓ هذا السؤال خارج قاعدة علوم الطبيعة والحياة ». Le moment où il avait le plus besoin d'un humain est exactement celui où Morchid le rejette. C'est la faute la plus grave de tout le dispositif.",
      },
      {
        kind: "contre",
        file: "smartTutorEngine.ts · fallback",
        code: "'لم أجد إجابة دقيقة في قاعدتي المحلية. جرّب اختيار مجال…'",
        read: "La réponse d'échec parle de la base de données du tuteur, pas de l'élève. Elle fait porter l'échec à celui qui a posé la question.",
      },
      {
        kind: "contre",
        file: "smartTutorEngine.ts · completeDailyMission",
        code: "'🎯 **مهمة اليوم مكتملة!** كسبت 15 XP. عُد غداً لمهمة جديدة. ⚡'",
        read: "C'est de la dopamine, pas de l'encouragement : on félicite la présence et on promet un retour, sans jamais nommer ce que l'élève a réellement appris.",
      },
      {
        kind: "contre",
        file: "AITutorView.tsx · accueil",
        code: "'مرحباً بك يا بحار المعرفة! أنا المرشد الذكي'",
        read: "Lexique marin que la spécification Boussole v2 a pourtant explicitement supprimé (« Retiré de l'interface : lexique marin — vents, caps, îles »). Deux personas se contredisent dans la même application.",
      },
      {
        kind: "pour",
        file: "smartTutorEngine.ts · anti-farm",
        code: "firstTime ? xpGained: total : 0  // completedBac",
        read: "Refuser l'XP à un défi rejoué est une forme d'honnêteté motivationnelle : la récompense n'est pas achetable par la répétition. C'est le seul bon réflexe de coach du moteur.",
      },
    ],
    flaws: [
      {
        title: "La détresse est traitée comme du hors-sujet",
        detail:
          "Aucune détection d'affect, aucun vocabulaire darija (خايف، ما نقدرش، تعبت، راني ضايع). Le filtre hasDomainSignal, conçu contre le football et le cinéma, rejette aussi l'angoisse du candidat.",
        gravity: "critique",
      },
      {
        title: "Un adjectif n'est pas un feedback",
        detail:
          "« يحتاج مراجعة » ne dit ni quoi réviser, ni pourquoi c'est tombé, ni combien de temps y consacrer. Un feedback qui ne contient pas d'action suivante est une sanction déguisée.",
        gravity: "majeure",
      },
      {
        title: "Aucune attribution à l'effort ou à la stratégie",
        detail:
          "Toute la psychologie de la réussite au BAC repose sur attribuer l'échec à une méthode corrigible, jamais à une aptitude. Morchid n'attribue rien : il note.",
        gravity: "majeure",
      },
    ],
  },
  {
    id: "gardefou",
    n: 3,
    name: "L'Encadrement",
    role: "Le Garde-fou",
    question: "Refuse-t-il de faire le travail à la place de l'élève ? Pousse-t-il à l'effort ?",
    score: 6,
    color: "#10b981",
    verdict:
      "Ingénierie anti-triche remarquable — probablement la meilleure que j'aie vue dans une application scolaire algérienne. Mais elle protège les POINTS contre l'élève, pas l'ÉLÈVE contre lui-même : un bouton donne la correction complète en un clic, et Morchid viole ainsi sa propre règle d'or.",
    evidence: [
      {
        kind: "pour",
        file: "smartTutorEngine.ts · toQuizPrompt (B5)",
        code: "// Charge envoyée à l'UI : volontairement SANS correctIndex/explanation\nreturn { id, question, options };",
        read: "La bonne réponse ne transite jamais vers le navigateur : le QCM n'est pas inspectable dans les outils de développement. Rigueur rare.",
      },
      {
        kind: "pour",
        file: "smartTutorEngine.ts · shuffledView",
        code: "// correctIndex était 0 (option A) sur les 66 questions",
        read: "Bug corrigé par un mélange déterministe : l'élève ne peut plus réussir en cochant toujours A. C'est un garde-fou qui protège la validité de la mesure.",
      },
      {
        kind: "pour",
        file: "smartTutorEngine.ts · gradeKeyPoints",
        code: "if (score > 0 && detecterStuffing(answer).stuffing_detected) return 0;",
        read: "Anti-bourrage lexical : répéter « أنزيم أنزيم أنزيم » annule le score. Le moteur distingue le vocabulaire du raisonnement — exactement ce que fait un correcteur du BAC.",
      },
      {
        kind: "pour",
        file: "smartTutorEngine.ts · tokenAffirmed / adjacentNegation",
        code: "const inverted = adjacentNegation(clause, token) && !adjacentNegation(normKp, token);",
        read: "Gestion de la polarité : « لا تنتقل » n'est pas comptée comme « تنتقل ». Très peu de correcteurs automatiques arabes savent faire cela.",
      },
      {
        kind: "pour",
        file: "smartTutorEngine.ts · auto-évaluation",
        code: "// la couverture des points-clés remplace l'auto-note (+10/+5/0)\n// l'XP n'est plus fermable au clic",
        read: "On a retiré à l'élève le droit de se noter lui-même. Décision pédagogique courageuse et juste.",
      },
      {
        kind: "contre",
        file: "smartTutorEngine.ts · handleBossInput",
        code: "const giveUp = n.includes('لا أعرف');\nconst points = giveUp ? 0 : gradeKeyPoints(...);\nconst correctionText = `✅ **التصحيح النموذجي**\\n\\n${scenario.correction}\\n\\n🔑 **النقاط الأساسية:** …`",
        read: "LA FAILLE CRITIQUE. Un clic sur « لا أعرف » affiche immédiatement la correction modèle ET la totalité des points-clés. Zéro tentative exigée, zéro indice intermédiaire, zéro délai. Morchid fait le travail à la place de l'élève — en un clic.",
      },
      {
        kind: "contre",
        file: "studyGuide.ts vs handleBossInput",
        code: "RÈGLE ÉNONCÉE : 'لا تفتح الحل النموذجي قبل محاولة كتابية حقيقية لمدة 20 إلى 25 دقيقة'\nCOMPORTEMENT RÉEL : correction affichée à la 1ʳᵉ saisie, quelle qu'elle soit.",
        read: "Morchid imprime une règle d'or et la viole dans la fonction d'à côté. Un tuteur qui ne s'applique pas sa propre consigne perd toute autorité pédagogique.",
      },
      {
        kind: "contre",
        file: "smartTutorEngine.ts · réponse par fiche",
        code: "text: `🧩 **${card.title}**\\n\\n${card.shortAnswer}\\n\\n🔑 كلمات مفتاحية: …`",
        read: "Le chemin le plus fréquent de tout le moteur. Une question → la réponse complète, immédiatement. C'est la définition même de la réponse prémâchée : aucune question de relance, aucune vérification de compréhension.",
      },
      {
        kind: "contre",
        file: "smartTutorEngine.ts · fin de défi",
        code: "quickActions: ['راجع أخطائي السابقة', 'العودة للقائمة الرئيسية']",
        read: "Après un échec, aucune route n'est imposée vers la leçon fautive — alors que LESSON_INDEX contient déjà lessonKey, le lien profond vers la leçon exacte. Le garde-fou détecte l'erreur et ne la soigne pas.",
      },
    ],
    flaws: [
      {
        title: "« لا أعرف » = la correction complète en un clic",
        detail:
          "Aucun escalier d'indices, aucune seconde tentative, aucun délai minimal. C'est la porte de sortie la plus confortable de l'application, et elle mène directement à la réponse.",
        gravity: "critique",
      },
      {
        title: "Le garde-fou protège le score, pas l'apprentissage",
        detail:
          "Anti-triche (payload, mélange, bourrage, farm d'XP) : excellent. Anti-passivité (indices, relance, effort minimal, reformulation) : inexistant. On a blindé la note et laissé la porte du savoir grande ouverte.",
        gravity: "critique",
      },
      {
        title: "Les erreurs sont enregistrées, jamais traitées",
        detail:
          "session.mistakes alimente seulement mistakes[0] de la mission du jour. Aucune remédiation déclenchée, aucun renvoi vers lessonKey, aucune reprogrammation.",
        gravity: "majeure",
      },
    ],
  },
];

/* ─────────── Avant / Après : correction stricte du comportement ─────────── */
export interface Duo {
  id: string;
  context: string;
  student: string;
  before: { text: string; tag: string };
  after: { text: string; tag: string };
  rule: string;
}

export const DUOS: Duo[] = [
  {
    id: "giveup",
    context: "Défi BAC — l'élève clique sur « je ne sais pas »",
    student: "لا أعرف",
    before: {
      text: "✅ **التصحيح النموذجي**\n\n[la correction complète du scénario]\n\n🔑 **النقاط الأساسية:**\n- النقطة 1\n- النقطة 2\n- النقطة 3\n\n🎯 نقاطك لهذه الوضعية: 0/10",
      tag: "Travail fait à la place de l'élève · 1 clic",
    },
    after: {
      text: "لا بأس — « لا أعرف » ليست نهاية، هي بداية.\nلن أعطيك التصحيح الآن.\n\n🔑 **مفتاح 1/3:** الوثيقة تقارن حالتين. ابدأ بجملة واحدة فقط:\n« انطلاقًا من الوثيقة، نلاحظ أنّ… »\n\n⏱️ اكتب جملتك خلال 90 ثانية. بعدها أعطيك المفتاح الثاني.",
      tag: "Escalier d'indices · correction verrouillée",
    },
    rule: "R1 — La correction ne s'affiche jamais avant 2 tentatives écrites OU 3 indices consommés.",
  },
  {
    id: "cours",
    context: "Question de cours — le chemin le plus fréquent du moteur",
    student: "ما هو الاستنساخ؟",
    before: {
      text: "🧩 **الاستنساخ**\n\n[shortAnswer complet de la fiche, 6 à 10 lignes]\n\n🔑 كلمات مفتاحية: ADN • ARNm • ARN بوليميراز • النواة",
      tag: "Réponse prémâchée · zéro effort",
    },
    after: {
      text: "قبل أن أجيب، سؤال واحد لك:\n**أين يحدث الاستنساخ — في النواة أم في الهيولى؟**\nأجب بكلمة واحدة.\n\n(إجابتك ستحدّد ما سأشرحه: إن أصبت، ننتقل مباشرة إلى الآلية؛ وإن أخطأت، نبدأ من المقر.)",
      tag: "Mode socratique · 1 question avant tout contenu",
    },
    rule: "R2 — Toute fiche répond d'abord par une question de vérification (champ `probe`), jamais par shortAnswer.",
  },
  {
    id: "note",
    context: "Fin de défi BAC — bilan de l'élève",
    student: "[fin des 3 situations]",
    before: {
      text: "🏁 **انتهى تحدي BAC!**\nنتيجتك: 12/30 نقطة (40%).\nالتقدير: يحتاج مراجعة 📖",
      tag: "Un verdict, aucune cause, aucun lendemain",
    },
    after: {
      text: "نتيجتك: 12/30.\n\n**الخلل ليس في معرفتك — هو في خطوة واحدة.**\nفي 3 وضعيات من 3، كتبتَ الملاحظة ولم تكتب الاستنتاج. معارفك حاضرة؛ الجملة الأخيرة غائبة.\n\n🎯 **عملك الآن (12 دقيقة):**\nأعد كتابة الوضعية 2 وأضف سطراً واحداً يبدأ بـ « ومنه نستنتج أنّ… »\n\n📖 الدرس المعني: [lessonKey → الاتصال العصبي / النقل المشبكي]",
      tag: "Cause nommée · action chiffrée · leçon ciblée",
    },
    rule: "R4 — Tout score s'accompagne de : la cause exacte, une action de moins de 15 min, un lien profond vers la leçon.",
  },
  {
    id: "stress",
    context: "L'élève exprime son angoisse en darija algérienne",
    student: "راني خايف من الباك، ما نقدرش نراجع",
    before: {
      text: "❓ هذا السؤال خارج قاعدة علوم الطبيعة والحياة للبكالوريا. ركّز مراجعتك على المجالات الثلاثة: التخصص الوظيفي للبروتينات، التحولات الطاقوية، والتكتونية العامة.",
      tag: "La détresse classée hors programme",
    },
    after: {
      text: "سمعتك. الخوف قبل البكالوريا طبيعي — ومعناه أنّك تهتم، لا أنّك عاجز.\n\nلن نراجع كل شيء اليوم. سنراجع **شيئاً واحداً**، لمدة **10 دقائق**، ثم تتوقف.\n\nآخر خطأ لك كان في: **التنفس الخلوي — الحصيلة الطاقوية**.\nابدأ به. 10 دقائق فقط. أنا هنا بعدها.",
      tag: "Empathie brève · charge réduite · action unique",
    },
    rule: "R5 — Un lexique d'affect (darija incluse) déclenche la réponse de soutien, jamais le refus « hors programme ».",
  },
];

/* ─────────── La Loi de Morchid : spécification corrective stricte ─────────── */
export interface Law {
  n: string;
  title: string;
  rule: string;
  patch: string;
  pillar: 1 | 2 | 3;
}

export const LAWS: Law[] = [
  {
    n: "R1",
    title: "Jamais la correction au premier clic",
    rule: "« لا أعرف » ne donne plus la correction. Il donne un indice. Trois indices maximum, puis la correction, score plafonné à 3/10. Deux tentatives écrites réelles (≥ 15 caractères utiles) débloquent aussi la correction, score plein.",
    patch: "handleBossInput() : ajouter boss.hintLevel et boss.attempts à BotSession ; giveUp → nextHint(scenario, hintLevel) tant que hintLevel < 3.",
    pillar: 3,
  },
  {
    n: "R2",
    title: "Une question avant tout contenu",
    rule: "Toute réponse issue d'une fiche de connaissance commence par UNE question de vérification à réponse courte. Le contenu complet n'arrive qu'après la tentative de l'élève — ou après son second « اشرح لي ».",
    patch: "KnowledgeCard : ajouter `probe: string`. processStudentInput() : renvoyer probe au premier appel, shortAnswer au second (clé de session askedProbe).",
    pillar: 3,
  },
  {
    n: "R3",
    title: "Morchid obéit à sa propre règle d'or",
    rule: "La règle imprimée « لا تفتح الحل النموذجي قبل محاولة كتابية حقيقية لمدة 20 إلى 25 دقيقة » devient une contrainte du moteur, pas un texte décoratif. Un chronomètre minimal de 90 s s'applique à chaque situation du défi BAC.",
    patch: "startBossStep() : horodater openedAt ; handleBossInput() : refuser la correction si Date.now() - openedAt < 90_000 et attempts === 0.",
    pillar: 3,
  },
  {
    n: "R4",
    title: "Aucune note sans cause, action et porte",
    rule: "Tout score est suivi de trois éléments obligatoires : la cause exacte (quel point-clé a manqué, combien de fois), une action de moins de 15 minutes, un lien profond vers la leçon concernée. L'adjectif seul est interdit.",
    patch: "gradeKeyPoints() : retourner missedKeyPoints[] ; handleBossInput() : composer le bilan avec LESSON_INDEX.lessonKey du topic fautif.",
    pillar: 2,
  },
  {
    n: "R5",
    title: "La détresse n'est jamais hors programme",
    rule: "Un lexique d'affect en arabe standard ET en darija (خايف، تعبت، ما نقدرش، ضايع، فاشل، حابس) court-circuite hasDomainSignal et déclenche la réponse de soutien : écoute en une ligne, réduction de charge, une seule action de 10 minutes.",
    patch: "processStudentInput() : AFFECT_LEXICON testé AVANT isGibberishInput et OUT_OF_PROGRAM → supportResult(session, lastMistake).",
    pillar: 2,
  },
  {
    n: "R6",
    title: "Priorité réelle, pas index zéro",
    rule: "La mission du jour cesse de prendre mistakes[0]. Elle classe par score = fréquence de l'erreur × poids BAC de l'unité × ancienneté (oubli), et renvoie le sommet de ce classement.",
    patch: "getDailyMission() : remplacer mistakes[0] par rankMistakes(session.mistakes, UNIT_BAC_WEIGHT, lastSeenAt).",
    pillar: 1,
  },
  {
    n: "R7",
    title: "Le guide se propose, il n'attend pas",
    rule: "Après tout score inférieur à 50 %, Morchid pousse spontanément le protocole d'étude en 5 étapes de l'unité concernée. L'élève perdu n'a pas à savoir formuler « كيف ادرس العلوم ».",
    patch: "handleBossInput() fin de défi : si pct < 50, injecter formatStudyGuideAnswer(STUDY_GUIDE_CARDS.unit_study_protocol) dans quickActions en première position.",
    pillar: 1,
  },
  {
    n: "R8",
    title: "Un cycle de révision daté",
    rule: "Sans date du BAC, aucun rétro-planning n'est possible. Morchid doit connaître J-X et ajuster : J-120 construction, J-60 entraînement, J-20 annales chronométrées, J-7 fiches or uniquement.",
    patch: "dashboardActions.ts : renseigner BAC_EXAM_DATE ; smartTutorEngine : bacDaysLeft() injecté dans la mission du jour.",
    pillar: 1,
  },
  {
    n: "R9",
    title: "Une persona, pas deux",
    rule: "Le lexique marin (« بحار المعرفة ») a été supprimé par la spécification Boussole v2. Il doit disparaître du tuteur. Ton cible : bref, direct, exigeant, jamais infantilisant — deux lignes d'encouragement maximum, toujours suivies d'une action.",
    patch: "AITutorView.tsx : réécrire le message d'accueil et aligner sur la charte de la Boussole v2.",
    pillar: 2,
  },
  {
    n: "R10",
    title: "Célébrer le gain, jamais la présence",
    rule: "Aucune félicitation pour une connexion, une série de jours ou un clic. On ne félicite que ce qui est mesurable en points : un point-clé nouvellement couvert, une étape de méthode acquise, une erreur qui ne revient plus.",
    patch: "completeDailyMission() : remplacer « كسبت 15 XP » par « أتقنتَ الآن: [point-clé] — لم يكن حاضراً في إجابتك يوم [date] ».",
    pillar: 2,
  },
];

export const GLOBAL = {
  score: 4.7,
  sentence:
    "Morchid est un excellent moteur anti-triche et un tuteur médiocre : il protège la note contre l'élève, mais ne protège pas l'élève contre sa propre passivité.",
  strength:
    "L'ingénierie de validation (payload sans réponse, mélange déterministe, anti-bourrage, polarité des négations, anti-farm d'XP) est d'un niveau professionnel que l'on ne trouve dans aucune autre application scolaire algérienne. Elle doit être conservée intégralement.",
  breach:
    "Un bouton « لا أعرف » rend la totalité de cette ingénierie inutile : il délivre la correction modèle et les points-clés en un clic, sans tentative, sans indice, sans délai — en violation directe de la règle d'or que Morchid imprime lui-même deux écrans plus loin.",
};
