/**
 * SPECKIT — Corrections à faire suite aux audits (modules + Morchid + 6 rapports)
 * Objectif unique : rendre l'application FIABLE pour l'élève de BAC SVT.
 * Chaque ticket est exécutable par un dev ou un agent IA : problème → spec → acceptation → test.
 */

export type Severity = "bloquant" | "critique" | "majeur" | "normal";
export type PhaseId = "S0" | "S1" | "S2" | "S3" | "S4";

export interface Phase {
  id: PhaseId;
  title: string;
  goal: string;
  duration: string;
  gate: string; // condition de sortie : preuve que la phase est finie
}

export interface Ticket {
  id: string;
  phase: PhaseId;
  title: string;
  severity: Severity;
  effort: string;
  audit: string; // quel audit a révélé le défaut
  files: string[];
  problem: string;
  proof: string; // extrait littéral du dépôt
  spec: string[]; // étapes d'implémentation, dans l'ordre
  acceptance: string[]; // critères Given/When/Then simplifiés en checklist
  test: string; // test automatisé à ajouter
  impact: string; // ce que l'élève y gagne, en 1 phrase
}

export const PHASES: Phase[] = [
  {
    id: "S0",
    title: "Sécurité & vérité",
    goal: "Aucune donnée d'élève exposée, aucune date fausse, aucun compteur mensonger, un produit installable.",
    duration: "3 jours",
    gate: "Un AAB signé 1.0.0 s'installe sur un Android réel, le compteur BAC affiche J-X réel, zéro copie d'élève dans git log.",
  },
  {
    id: "S1",
    title: "Garde-fou Morchid — anti-passivité",
    goal: "Le tuteur ne fait plus le travail à la place de l'élève : indices, délai, question préalable, bilan actionnable.",
    duration: "1 semaine",
    gate: "Il est impossible d'obtenir une correction modèle sans 2 tentatives écrites ou 3 indices consommés.",
  },
  {
    id: "S2",
    title: "Coach & orientation",
    goal: "La détresse n'est plus rejetée, les erreurs sont classées par valeur BAC, le guide se propose seul.",
    duration: "1 semaine",
    gate: "« راني خايف من الباك » déclenche un soutien, et la mission du jour cible l'erreur au plus fort poids BAC.",
  },
  {
    id: "S3",
    title: "Contenu fiable & resserré",
    goal: "49 entrées → 12 modules, zéro hors-programme, les 3 trous à 6-7 pts bouchés.",
    duration: "2 semaines",
    gate: "Un élève de 10/20 trouve quoi faire en moins de 10 secondes, et chaque unité a sa typologie de documents.",
  },
  {
    id: "S4",
    title: "Mesure honnête",
    goal: "Piloter sur la rétention et les mots-clés maîtrisés, pas sur des jours de connexion.",
    duration: "4 jours",
    gate: "J1/J7/J30 et mots-clés/semaine sont affichés localement, sans serveur ni identifiant.",
  },
];

export const TICKETS: Ticket[] = [
  // ─────────────────── S0 ───────────────────
  {
    id: "S0-01",
    phase: "S0",
    title: "Purger les copies d'élèves de l'historique Git (RGPD)",
    severity: "bloquant",
    effort: "½ journée",
    audit: "Rapports Les Ignobles + Jeremy — 40 copies de mineurs dans Git",
    files: ["historique git complet", ".gitignore", "docs/POLITIQUE_DONNEES.md (à créer)"],
    problem:
      "Des productions d'élèves (mineurs) sont versionnées dans le dépôt. Risque légal et réputationnel majeur : un seul signalement peut faire suspendre la fiche Play Store et détruire la confiance des parents.",
    proof: "$ git log --all -- '*copie*' / '*eleves*' → ~40 fichiers · aucun .gitignore ne les exclut",
    spec: [
      "1. Inventorier : lister tous les chemins contenant des productions d'élèves (copies, noms, établissements).",
      "2. Purger l'historique avec git filter-repo (ou BFG) sur ces chemins, sur toutes les branches et tags.",
      "3. Forcer la réécriture distante après sauvegarde d'un clone miroir, puis invalider les anciens clones de l'équipe.",
      "4. Ajouter au .gitignore : uploads_externes/, copies/, *eleves*, *copie*, et un hook pre-commit qui refuse les fichiers suspects.",
      "5. Publier docs/POLITIQUE_DONNEES.md : aucune copie d'élève dans le dépôt, stockage local chiffré uniquement.",
    ],
    acceptance: [
      "git log --all --full-history -- '*copie*' ne retourne plus rien",
      "Un commit test contenant « copie_eleve_test.txt » est rejeté par le hook",
      "Le document de politique des données est accessible depuis l'app (Écran À propos)",
    ],
    test: "Script CI `check-no-student-data.sh` : échoue si un chemin interdit est présent dans l'historique ou l'index.",
    impact: "Les parents peuvent confier l'app à leur enfant sans crainte : aucune copie ne quitte le téléphone.",
  },
  {
    id: "S0-02",
    phase: "S0",
    title: "Renseigner la date du BAC et interdire une date vide",
    severity: "bloquant",
    effort: "2 heures",
    audit: "Rapports Les Ignobles + Morchid R8 — compteur mort",
    files: ["src/utils/dashboardActions.ts", "src/components/DashboardView.tsx", "src/data/revisionPlan.ts (ou équivalent)"],
    problem:
      "BAC_EXAM_DATE est une chaîne vide : le compteur « عدّاد BAC », le plan de révision et tout rétro-planning retournent null. Morchid ne peut ni prioriser ni dater un cycle de révision.",
    proof: "export const BAC_EXAM_DATE = '';   // ← VIDE  →  bacDaysLeft() retourne null",
    spec: [
      "1. Renseigner BAC_EXAM_DATE avec la date officielle de la session 2027 (format ISO, ex. '2027-06-13').",
      "2. Ajouter un garde-fou : si la date est vide ou passée, bacDaysLeft() lève une erreur visible en dev et affiche « date à confirmer » côté élève — jamais null silencieux.",
      "3. Brancher bacDaysLeft() dans la mission du jour et le plan de révision (cycles J-120 / J-60 / J-20 / J-7).",
      "4. Ajouter un test qui échoue si la constante est vide.",
    ],
    acceptance: [
      "Le dashboard affiche « J-XXX » réel, pas un compteur vide",
      "bacDaysLeft() avec date vide → message explicite, pas null",
      "Le plan de révision change de contenu selon le cycle (construction / entraînement / annales / fiches or)",
    ],
    test: "dashboardActions.test.ts : `expect(BAC_EXAM_DATE).toMatch(/^\\d{4}-\\d{2}-\\d{2}$/)` + test du calcul J-X sur date figée.",
    impact: "L'élève sait enfin où il en est : chaque jour de révision a un sens calendaire.",
  },
  {
    id: "S0-03",
    phase: "S0",
    title: "Remplacer le compteur de série cassé par la métrique honnête",
    severity: "bloquant",
    effort: "1 journée",
    audit: "Rapport Duolingo + audit Morchid — streak jamais incrémenté",
    files: ["src/App.tsx (handleRateCard, header streak)", "src/components/DailyGoalWidget.tsx", "src/components/StreakCelebrationModal.tsx", "src/data/lessonIndex.ts (unit.progress)"],
    problem:
      "progress.streak et dailyGoals.streakDays ne sont incrémentés nulle part : le compteur reste à 0 / 1 pour toujours et la modale de célébration ne se déclenchera jamais. C'est un mensonge visible dès la première semaine d'usage.",
    proof: "streakDays: 1 apparaît 5× comme valeur par défaut, 0× comme incrémentation · pointsAwarded existe déjà (easy 15 / good 10 / hard 5 / again 2)",
    spec: [
      "1. NE PAS réparer le compteur de jours : le SUPPRIMER du header et du widget (décision tranchée : la flamme mesure la connexion, pas l'apprentissage).",
      "2. Le remplacer par deux métriques déjà disponibles : « % du programme maîtrisé » (agrégation des unit.progress des 11 unités) et « mots-clés du correcteur acquis cette semaine » (compteur incrémenté dans handleRateCard quand rating = easy/good).",
      "3. Supprimer StreakCelebrationModal et playStreakMilestoneSound() ; la seule célébration autorisée est : « Tu as eu 12/20 parce qu'il manquait pyrénoïde — et maintenant tu l'as ».",
      "4. Migrer les sessions existantes : ignorer les anciennes valeurs de streak sans les afficher.",
    ],
    acceptance: [
      "Aucun écran n'affiche plus de « jours consécutifs »",
      "Le header affiche « 34 % du programme · +12 mots-clés cette semaine » avec des valeurs qui bougent réellement",
      "Une réponse 'again' ne fait jamais progresser le compteur de mots-clés",
    ],
    test: "handleRateCard.test.ts : easy/good incrémentent keywordsWeek, again/hard ne l'incrémentent pas ; streakDays n'existe plus dans le store.",
    impact: "Fini le mensonge : l'élève voit des points gagnés au BAC, pas des jours de présence.",
  },
  {
    id: "S0-04",
    phase: "S0",
    title: "Rendre le produit publiable : version, signature, confidentialité",
    severity: "bloquant",
    effort: "1 journée",
    audit: "Rapports Les Ignobles + Jeremy — version 0.0.0, 0 tag, 0 build signé",
    files: ["package.json", "android/ (bundle id, targetSdk)", "docs/POLITIQUE_CONFIDENTIALITE.md (à créer)", "Play Console (fiche)"],
    problem:
      "Version 0.0.0, zéro tag git, aucun build signé, aucun identifiant de bundle, aucune politique de confidentialité. Toute stratégie de lancement discute dans le vide : il n'y a rien à télécharger.",
    proof: 'package.json: "version": "0.0.0" · $ git tag | wc -l → 0 · grep paywall|CIB|premium → rien',
    spec: [
      "1. Passer en 1.0.0, créer le tag git v1.0.0, figer le bundle id (ex. dz.kunzeloulloum.svt).",
      "2. Configurer le build AAB signé (keystore hors dépôt, secrets CI) avec targetSdk conforme à la politique Google en vigueur.",
      "3. Rédiger et héberger la politique de confidentialité : « aucune donnée collectée, zéro analytics, zéro pixel, stockage 100 % local » — c'est vrai dans le code (supabase.ts vide, SW offline), donc déclarable.",
      "4. Remplir le formulaire Play « Sécurité des données » en cohérence stricte, classification IARC, fiche en arabe d'abord.",
      "5. Publier en test interne, installer sur 3 appareils Android réels (entrée/milieu de gamme), valider l'offline total.",
    ],
    acceptance: [
      "Un AAB signé 1.0.0 s'installe depuis la piste de test interne",
      "L'app fonctionne 100 % hors-ligne après premier lancement (mode avion)",
      "La fiche déclare « aucune donnée collectée » sans mensonge vérifiable",
    ],
    test: "CI : build AAB + vérification que version != 0.0.0 et que le tag existe ; test e2e « mode avion » sur les 11 unités.",
    impact: "Pour la première fois, un élève peut réellement installer l'app depuis un lien — tout le reste en découle.",
  },
  {
    id: "S0-05",
    phase: "S0",
    title: "Étendre le cache offline à 47 leçons et verrouiller l'usage en zone blanche",
    severity: "critique",
    effort: "2 jours",
    audit: "Angle mort Play Store — 22 leçons cachées sur 47",
    files: ["service worker / cache manifest", "src/data/lessonIndex.ts", "public/assets/ (schémas SVG)"],
    problem:
      "Le hors-ligne est une exigence de marché (coût de la donnée, bus, zones blanches), pas un confort. Avec 22 leçons sur 47 en cache, l'élève qui révise dans le bus tombe sur un écran vide une fois sur deux — et désinstalle.",
    proof: "LESSON_INDEX : 47 entrées HTML + 20 actives · cache manifest : 22 leçons · schémas SVG non tous pré-cachés",
    spec: [
      "1. Pré-cacher les 47 leçons HTML + les 20 leçons actives + tous les schémas SVG au premier lancement (téléchargement différé en Wi-Fi avec barre de progression honnête).",
      "2. Ajouter un indicateur par leçon : « disponible hors-ligne ✓ » ; toute leçon non disponible affiche sa taille et un bouton de téléchargement, jamais un écran vide.",
      "3. Tester en mode avion strict sur les 3 domaines : chaque leçon, chaque QCM, chaque fiche or doit s'ouvrir.",
    ],
    acceptance: [
      "Mode avion : 47/47 leçons + 20/20 actives + schémas s'ouvrent sans erreur",
      "Aucun écran blanc : tout contenu manquant affiche taille + bouton",
      "Le premier lancement propose le pack offline complet en Wi-Fi",
    ],
    test: "Test e2e offline : parcours automatisé des 47 lessonKey en mode avion simulé, 0 échec toléré.",
    impact: "L'app devient celle qu'on ouvre dans le bus — le seul créneau de révision quotidien de beaucoup d'élèves.",
  },

  // ─────────────────── S1 ───────────────────
  {
    id: "S1-01",
    phase: "S1",
    title: "R1 — « Je ne sais pas » donne un indice, jamais la correction",
    severity: "bloquant",
    effort: "2 jours",
    audit: "Audit Morchid pilier 3 — faille critique handleBossInput",
    files: ["src/smartTutorEngine.ts (handleBossInput, startBossStep)", "src/utils/sessionManager.ts (BotSession : boss.hintLevel, boss.attempts, boss.openedAt)"],
    problem:
      "Un clic sur « لا أعرف » affiche la correction modèle ET tous les points-clés. Zéro tentative exigée, zéro indice, zéro délai. Toute l'ingénierie anti-triche (payload, mélange, anti-bourrage) est contournée en un clic.",
    proof: "const giveUp = n.includes('لا أعرف'); → correctionText = `✅ التصحيح النموذجي ${scenario.correction} + keyPoints`",
    spec: [
      "1. Ajouter à la session boss : hintLevel (0-3), attempts (nombre de tentatives écrites ≥ 15 caractères utiles), openedAt (horodatage d'ouverture de la situation).",
      "2. « لا أعرف » n'affiche plus la correction : il affiche l'indice suivant — indice 1 = relire la consigne (quel verbe ? quel « لأنّ » attendu ?), indice 2 = squelette de phrase à compléter, indice 3 = le premier point-clé masqué à moitié.",
      "3. La correction complète ne se débloque qu'après 3 indices consommés (score plafonné à 3/10) OU 2 tentatives écrites réelles (score plein via gradeKeyPoints).",
      "4. Chaque indice consommé est journalisé (examLog) pour alimenter le bilan R4.",
    ],
    acceptance: [
      "1er clic « لا أعرف » → indice 1, pas de correction, pas de keyPoints",
      "Correction visible seulement si hintLevel = 3 (alors score ≤ 3/10) ou attempts ≥ 2",
      "Une tentative de 3 caractères (« ok ») ne compte pas comme tentative",
    ],
    test: "handleBossInput.test.ts : séquence giveUp ×3 → correction au 3e seulement ; 2 tentatives ≥15 chars → correction + score plein ; bourrage → 0.",
    impact: "L'élève apprend à chercher au lieu d'apprendre à cliquer — c'est toute la différence au BAC.",
  },
  {
    id: "S1-02",
    phase: "S1",
    title: "R3 — La règle des 20-25 minutes devient une contrainte du moteur",
    severity: "critique",
    effort: "½ journée",
    audit: "Audit Morchid pilier 3 — Morchid viole sa propre règle d'or",
    files: ["src/smartTutorEngine.ts (startBossStep, handleBossInput)", "src/studyGuide.ts (unit_study_protocol — قاعدة العبور)"],
    problem:
      "Le guide imprime « لا تفتح الحل النموذجي قبل محاولة كتابية حقيقية لمدة 20 إلى 25 دقيقة » pendant que le moteur livre le corrigé à la première saisie. Un tuteur qui contredit sa propre consigne perd toute autorité.",
    proof: "RÈGLE : 'لا تفتح الحل النموذجي قبل محاولة…' · COMPORTEMENT : correction à la 1ʳᵉ saisie, quel qu'en soit le contenu",
    spec: [
      "1. Horodater openedAt à chaque startBossStep ; refuser la correction si moins de 90 s se sont écoulées ET attempts = 0 (message : « Prends 90 secondes pour écrire ta première phrase — je t'attends »).",
      "2. Reformuler la règle du guide en version applicable : « 90 s minimum par situation dans l'app, 20-25 min en épreuve réelle » — la règle imprimée et le moteur disent désormais la même chose.",
      "3. Afficher un minuteur discret de 90 s, non bloquant pour écrire, bloquant seulement pour demander la correction.",
    ],
    acceptance: [
      "Demande de correction à +20 s sans tentative → refus poli + minuteur visible",
      "Même demande à +95 s ou après 1 tentative → indice (R1), pas refus sec",
      "Le texte du guide et le comportement du moteur sont identiques mot à mot sur ce point",
    ],
    test: "Test avec horloge mockée : correction refusée à t+20s, autorisée (via indices) à t+95s.",
    impact: "La règle d'or redevient crédible : l'app exige l'effort qu'elle prêche.",
  },
  {
    id: "S1-03",
    phase: "S1",
    title: "R2 — Une question avant tout contenu (mode socratique)",
    severity: "critique",
    effort: "2 jours",
    audit: "Audit Morchid pilier 3 — réponse de fiche = réponse prémâchée",
    files: ["src/smartTutorEngine.ts (processStudentInput, réponse internal_card)", "src/knowledgeCards.ts + src/data/smartBotData.ts (ajout champ probe)", "src/utils/sessionManager.ts (askedProbe)"],
    problem:
      "Le chemin le plus fréquent du moteur renvoie shortAnswer complet dès la première question. Aucune vérification préalable, aucune relance : c'est la définition de la réponse prémâchée, et c'est ce chemin qui fabrique l'illusion de compréhension.",
    proof: "text: `🧩 **${card.title}**\\n\\n${card.shortAnswer}\\n\\n🔑 كلمات مفتاحية: …` — dès le 1er appel",
    spec: [
      "1. Ajouter `probe: string` à chaque KnowledgeCard : une question fermée à réponse courte qui teste le prérequis (ex. الاستنساخ → « أين يحدث — النواة أم الهيولى؟ »).",
      "2. Premier appel sur une fiche → renvoyer probe uniquement (+ 2 propositions si pertinent). Second appel OU réponse à la probe → shortAnswer + correction ciblée selon la réponse.",
      "3. Si l'élève écrit « اشرح لي » deux fois de suite, livrer le contenu complet (trappe de sortie anti-frustration, journalisée).",
      "4. Rédiger les ~60 probes manquantes en une passe (1 phrase chacune, réponse attendue ≤ 5 mots).",
    ],
    acceptance: [
      "« ما هو الاستنساخ؟ » → question de lieu d'abord, jamais le cours",
      "Bonne réponse à la probe → contenu + « passons à l'étape suivante »",
      "Double « اشرح لي » → contenu complet livré, événement journalisé",
    ],
    test: "processStudentInput.test.ts : 1er appel → contient probe et pas shortAnswer ; 2e appel → contient shortAnswer.",
    impact: "Chaque explication commence par activer ce que l'élève sait déjà — la rétention double.",
  },
  {
    id: "S1-04",
    phase: "S1",
    title: "R4 — Aucune note sans cause, action et porte vers la leçon",
    severity: "critique",
    effort: "1 journée",
    audit: "Audit Morchid pilier 2 — « يحتاج مراجعة » n'est pas un feedback",
    files: ["src/smartTutorEngine.ts (gradeKeyPoints → missedKeyPoints, handleBossInput bilan)", "src/data/lessonIndex.ts (lessonKey deep-link)"],
    problem:
      "Le bilan de défi se résume à un adjectif (« يحتاج مراجعة 📖 ») identique pour 12 % et 49 %. Aucune cause, aucune action, aucun lien : un feedback sans action suivante est une sanction déguisée.",
    proof: "const appreciation = pct >= 80 ? 'ممتاز 🏆' : pct >= 50 ? 'جيد 👍' : 'يحتاج مراجعة 📖';",
    spec: [
      "1. Faire retourner à gradeKeyPoints la liste missedKeyPoints[] (points-clés non couverts) en plus du score.",
      "2. Composer tout bilan en 3 blocs obligatoires : CAUSE (« dans 3/3 situations, la phrase « ومنه نستنتج » manque »), ACTION (« réécris la situation 2 + 1 ligne, 12 min »), PORTE (deep-link lessonKey vers la leçon exacte via LESSON_INDEX).",
      "3. Interdire l'adjectif seul : tout score < 50 % sans les 3 blocs est une erreur de build (assertion).",
      "4. Si pct < 50 %, placer le protocole d'étude de l'unité en première quickAction (prépare R7).",
    ],
    acceptance: [
      "Tout bilan contient cause chiffrée + action < 15 min + lien lessonKey cliquable",
      "Le lien ouvre la leçon exacte, pas la liste des leçons",
      "Un bilan sans les 3 blocs fait échouer le test",
    ],
    test: "Bilan snapshot test : structure {cause, action, lessonKey} obligatoire ; lessonKey résolu dans LESSON_INDEX.",
    impact: "L'élève sait toujours quoi faire dans les 10 prochaines minutes — c'est ça, un coach.",
  },

  // ─────────────────── S2 ───────────────────
  {
    id: "S2-01",
    phase: "S2",
    title: "R5 — La détresse n'est jamais hors programme (lexique darija)",
    severity: "bloquant",
    effort: "1 journée",
    audit: "Audit Morchid pilier 2 — faute la plus grave du dispositif",
    files: ["src/smartTutorEngine.ts (processStudentInput — avant isGibberishInput et OUT_OF_PROGRAM)", "src/data/affectLexicon.ts (à créer)"],
    problem:
      "Le filtre hasDomainSignal rejette l'angoisse exprimée en darija (« راني خايف من الباك ») comme du hors-sujet, avec un renvoi froid au programme. Le moment de plus grande vulnérabilité reçoit la réponse la plus inhumaine.",
    proof: "« راني خايف من الباك، ما نقدرش نراجع » → aucun token dans DOMAIN_VOCAB → outOfScopeResult()",
    spec: [
      "1. Créer AFFECT_LEXICON : arabe standard + darija algérienne (خايف، خايفة، تعبت، ما نقدرش، ضايع، فاشل، حابس، راني، مقلق، كرهت، الباك) — testé AVANT isGibberishInput et OUT_OF_PROGRAM.",
      "2. Réponse de soutien en 3 temps : écoute en 1 ligne (« سمعتك. الخوف طبيعي… »), réduction de charge (« un seul point, 10 minutes »), action unique basée sur la dernière erreur réelle (session.mistakes).",
      "3. Ne jamais proposer plus d'une action ; ne jamais renvoyer vers le programme ; ne jamais noter.",
      "4. Faire relire les formulations par un professeur de SVT algérien (ton : bref, direct, jamais infantilisant, max 2 lignes d'encouragement).",
    ],
    acceptance: [
      "« راني خايف من الباك » → soutien + 1 action de 10 min, jamais « خارج قاعدة »",
      "« كرة القدم » → toujours hors-sujet (le filtre anti-bruit reste intact)",
      "La réponse cite la dernière erreur réelle de l'élève quand elle existe",
    ],
    test: "affect.test.ts : 15 formulations darija → supportResult ; 10 hors-sujets réels → toujours outOfScope.",
    impact: "L'app ne rejette plus jamais un élève qui a peur — c'est la condition pour qu'il revienne demain.",
  },
  {
    id: "S2-02",
    phase: "S2",
    title: "R6 — Priorité réelle des erreurs (fréquence × poids BAC × oubli)",
    severity: "critique",
    effort: "1 journée",
    audit: "Audit Morchid pilier 1 — mistakes[0] n'est pas une priorisation",
    files: ["src/smartTutorEngine.ts (getDailyMission)", "src/data/unitWeights.ts (à créer : poids BAC par unité)", "src/utils/sessionManager.ts (lastSeenAt par erreur)"],
    problem:
      "La mission du jour prend mistakes[0] (première erreur chronologique) sinon KNOWLEDGE_CARDS[0]. Un élève fautif 9× en immunologie et 1× en tectonique peut être renvoyé vers la tectonique. Ce n'est pas un choix, c'est un index zéro.",
    proof: "if (mistakes.length > 0) targetTopicId = mistakes[0]; else targetTopicId = KNOWLEDGE_CARDS[0].id;",
    spec: [
      "1. Créer UNIT_BAC_WEIGHT : poids moyen au barème par unité (U1 8-10, U2 6-8, U3 5-7, U4 8-10, U5 8-10 — issus de l'audit de modules).",
      "2. Horodater chaque erreur (lastSeenAt) ; score(erreur) = occurrences × poids BAC de son unité × facteur d'oubli (jours depuis dernière revue, courbe SM-2 simplifiée).",
      "3. getDailyMission cible le sommet de ce classement et affiche pourquoi : « parce que tu t'es trompé 4× ici et que ça vaut 8 pts ».",
      "4. Interroger le SM-2 de RevisionView pour la reprogrammation au lieu d'un tableau maison.",
    ],
    acceptance: [
      "9 erreurs immuno vs 1 tectonique → mission = immunologie, avec justification affichée",
      "Une erreur ancienne non revue remonte dans le classement (oubli)",
      "Le choix de la mission est expliqué en 1 ligne à l'élève",
    ],
    test: "rankMistakes.test.ts : cas 9-vs-1, cas oubli 30 jours, cas poids BAC dominant.",
    impact: "Chaque minute de révision va là où elle rapporte le plus de points — fini le hasard.",
  },
  {
    id: "S2-03",
    phase: "S2",
    title: "R7 — Le guide se propose après tout échec (< 50 %)",
    severity: "majeur",
    effort: "½ journée",
    audit: "Audit Morchid pilier 1 — le guide attend qu'on le lui demande",
    files: ["src/smartTutorEngine.ts (fin de handleBossInput)", "src/studyGuide.ts (unit_study_protocol)"],
    problem:
      "Le protocole d'étude en 5 étapes existe mais ne sort que sur requête exacte (« كيف ادرس العلوم »). L'élève qui vient d'échouer — celui qui en a le plus besoin — ne le voit jamais.",
    proof: "findBestStudyGuide : seuil score >= 18 sur triggers exacts · fin de défi : quickActions = ['راجع أخطائي', 'العودة']",
    spec: [
      "1. Si pct < 50 % en fin de défi, injecter le protocole de l'unité fautive en première quickAction + un encart « voici comment on révise cette unité ».",
      "2. Le protocole affiché est celui de l'unité échouée, pas le guide générique.",
      "3. Journaliser l'ouverture du guide pour mesurer s'il est réellement consulté.",
    ],
    acceptance: [
      "Score < 50 % → le protocole de l'unité apparaît avant toute autre action",
      "Score ≥ 50 % → comportement inchangé (pas de bruit pour les bons élèves)",
      "L'ouverture du guide est journalisée",
    ],
    test: "Test fin de défi à 40 % → quickActions[0] contient le protocole de l'unité fautive.",
    impact: "L'élève perdu reçoit la méthode au moment exact où il est prêt à l'entendre.",
  },
  {
    id: "S2-04",
    phase: "S2",
    title: "R8 — Cycle de révision daté (J-120 / J-60 / J-20 / J-7)",
    severity: "majeur",
    effort: "1 journée",
    audit: "Audit Morchid pilier 1 + rapport Les Ignobles — pas de calendrier",
    files: ["src/utils/dashboardActions.ts (bacDaysLeft)", "src/smartTutorEngine.ts (mission du jour)", "src/components/RevisionPlanView.tsx"],
    problem:
      "Sans date, pas de rétro-planning : un élève à J-120 et un élève à J-10 reçoivent les mêmes conseils. Or ce qui est rentable change radicalement selon la distance à l'épreuve.",
    proof: "Dépend de S0-02 (BAC_EXAM_DATE). Sans elle, ce ticket est inimplémentable.",
    spec: [
      "1. Définir 4 régimes branchés sur bacDaysLeft() : J-120+ construction (cours actifs + schémas), J-60 entraînement (mur d'analyse + archétypes), J-20 annales chronométrées, J-7 fiches or uniquement.",
      "2. La mission du jour, le plan de révision et Morchid lisent le même régime (source unique).",
      "3. Afficher le régime en cours à l'élève : « Mode annales — J-18 : 1 sujet/semaine en 3 h ».",
    ],
    acceptance: [
      "À J-100 simulé → régime entraînement ; à J-10 simulé → fiches or uniquement",
      "Les trois surfaces (mission, plan, tuteur) affichent le même régime",
      "Le régime est expliqué en 1 ligne, pas en paragraphe",
    ],
    test: "Test paramétré sur 4 dates simulées → 4 régimes distincts, source unique.",
    impact: "Fini les conseils hors-saison : l'app dit ce qu'il faut faire *maintenant*.",
  },
  {
    id: "S2-05",
    phase: "S2",
    title: "R9 + R10 — Persona unifiée, féliciter le gain jamais la présence",
    severity: "majeur",
    effort: "½ journée",
    audit: "Audit Morchid pilier 2 — deux personas + dopamine vide",
    files: ["src/components/AITutorView.tsx (accueil)", "src/smartTutorEngine.ts (completeDailyMission)", "docs/CHARTE_TON.md (à créer)"],
    problem:
      "Le tuteur dit « يا بحار المعرفة » alors que la spec Boussole v2 a supprimé le lexique marin. Et il félicite la présence (« كسبت 15 XP. عُد غداً ») sans jamais nommer ce qui a été appris.",
    proof: "'مرحباً بك يا بحار المعرفة!' vs spec : « Retiré : lexique marin (vents, caps, îles) » · 'مهمة اليوم مكتملة! كسبت 15 XP'",
    spec: [
      "1. Réécrire l'accueil : bref, direct, exigeant, jamais infantilisant. Supprimer tout lexique marin dans le tuteur.",
      "2. Remplacer « +15 XP » par le gain nommé : « أتقنتَ الآن : [point-clé] — il manquait à ta réponse du [date] ».",
      "3. Figer la charte dans docs/CHARTE_TON.md : 2 lignes d'encouragement max, toujours suivies d'une action ; interdiction de féliciter connexion, série ou clic.",
    ],
    acceptance: [
      "Aucune occurrence de « بحار/ربان/ملاح » dans le parcours tuteur",
      "Toute félicitation cite un point-clé mesurable et daté",
      "La charte est relue et signée par l'équipe (même solo : écrite et datée)",
    ],
    test: "Lint de contenu : grep « بحار|ربان|ملاح » dans le parcours tuteur → 0 occurrence ; snapshot du message de mission.",
    impact: "Le tuteur parle d'une seule voix d'adulte exigeant — et chaque progrès est une preuve, pas un bonbon.",
  },

  // ─────────────────── S3 ───────────────────
  {
    id: "S3-01",
    phase: "S3",
    title: "Supprimer tout contenu hors programme officiel (2011+)",
    severity: "critique",
    effort: "2 jours",
    audit: "Audit de modules — Génétique / Évolution / Repro plantes ne sont plus au BAC",
    files: ["src/quizCorpus.ts (filtrer)", "src/data/lessonIndex.ts", "src/data/smartBotData.ts", "src/bookTutorQA.ts"],
    problem:
      "Génétique, évolution et reproduction des plantes ont quitté le programme de 3e AS. Chaque fiche, QCM ou leçon sur ces thèmes fait réviser du hors-barème : c'est du temps volé à l'élève, et une faute professionnelle.",
    proof: "quizCorpus : 120 questions placeholders déjà écartées à l'import · corpus historique multi-programmes non filtré par année de programme",
    spec: [
      "1. Marquer chaque contenu d'un champ `programme: '2011+' | 'ancien'` ; tout ce qui n'est pas 2011+ sort du parcours élève (archivé, pas supprimé du dépôt).",
      "2. Filtrer quizCorpus, lessonIndex, smartBotData, bookTutorQA sur ce champ ; ajouter une assertion de build qui échoue si un contenu 'ancien' réapparaît dans le parcours.",
      "3. Ajouter dans l'app une page « Ce que le programme exige » (1 page, 3 domaines, poids BAC) issue de curriculumOfficial.ts.",
    ],
    acceptance: [
      "Recherche « génétique / évolution » côté élève → 0 résultat du parcours (ou mention « hors programme actuel »)",
      "Le build échoue si un contenu 'ancien' est référencé par le parcours",
      "La page programme affiche les 3 domaines + poids BAC",
    ],
    test: "curriculumIntegrity.test.ts étendu : aucun chunk du parcours élève ne porte le tag 'ancien'.",
    impact: "Zéro minute perdue sur ce qui ne tombera jamais — la confiance des profs suit.",
  },
  {
    id: "S3-02",
    phase: "S3",
    title: "Resserrer 49 entrées → 12 modules en 3 hub (8 fusions)",
    severity: "critique",
    effort: "1 semaine",
    audit: "Audit de modules étapes 4.1/4.2/4.5 — charge cognitive",
    files: ["navigation / menu principal", "tous les composants Tier 3-4", "src/components/*View.tsx fusionnées"],
    problem:
      "49 entrées au menu : un élève de 10/20 ne choisit pas, il ferme l'app. 17 entrées sont du bruit pur (badges, combat, minuteur, stats, portails) et 8 modules dupliquent un voisin.",
    proof: "17 entrées notées « supprimer » · 8 notées « fusionner » · moyenne générale 11/20",
    spec: [
      "1. Supprimer du menu élève les 17 entrées Tier 4 + Tier 3 « supprimer » (badges, série, combat, minuteur, rappels, motivation, stats, portails, errata, lois maison, OuKacha, YouTube). Sortir compte/sauvegarde/tableau prof du menu élève.",
      "2. Réaliser les 8 fusions : Meftah→Boussole (garder le drill 60 s) · WritingReview+Compiler→Correcteur · 3 QCM→1 positionnement (15 q/unité) · BacExam+Bac2025+Mock→1 lecteur + mode examen · Simulateur électrophorèse→3 documents du Mur · Capsules→Fiches or · Idées→Archétypes · Hosila/Stats/Today→1 dashboard « prochaine action ».",
      "3. Reconstruire le menu en 3 hub : A-APPRENDRE (4 modules), B-S'ENTRAÎNER (4), C-CORRIGER & PILOTER (4). Aucun contenu de programme perdu : tout est déplacé, rien n'est jeté.",
      "4. Mesurer : un élève test trouve « quoi faire » en < 10 s (protocole : 5 élèves filmés).",
    ],
    acceptance: [
      "Le menu élève compte 12 entrées maximum, en 3 hub nommés",
      "Chaque contenu Tier 1-2 supprimé du menu reste accessible via sa destination de fusion",
      "5 élèves tests trouvent leur prochaine action en < 10 s",
    ],
    test: "Test de navigation : chaque ancienne route redirige vers sa destination de fusion (table de correspondance).",
    impact: "L'app passe de labyrinthe à chemin : l'élève ouvre et agit au lieu d'hésiter et partir.",
  },
  {
    id: "S3-03",
    phase: "S3",
    title: "Construire la typologie des 8 documents BAC (trou critique n°1)",
    severity: "critique",
    effort: "3 jours",
    audit: "Audit de modules étape 4.4 — ≈ 2 pts + gain de temps par sujet",
    files: ["src/data/documentTypes.ts (à créer)", "Mur d'analyse (TahlilWall.tsx)", "src/data/bacArchetypes.ts"],
    problem:
      "Aucune fiche méthode par TYPE de document, alors que chaque type a sa recette de lecture (autoradiogramme, caryotype, immunodiffusion, courbe de saturation, coupe géologique, lame mince, courbe enzymatique, tableau de croisements). L'élève redécouvre chaque document comme s'il était le premier.",
    proof: "GAPS : « chaque type a sa recette de lecture » · aucun module ne couvre la typologie",
    spec: [
      "1. Rédiger 8 fiches (1 page chacune) : à quoi ça ressemble, quoi lire en premier, les 3 erreurs classiques, la phrase-type de conclusion.",
      "2. Étiqueter chaque document du Mur d'analyse et chaque sujet BAC avec son type ; filtrer le Mur par type.",
      "3. Brancher la Boussole : l'étape 1 (اِقْرَأْ) affiche automatiquement la recette du type détecté.",
    ],
    acceptance: [
      "8 fiches relues par un prof de SVT, 1 page max chacune",
      "Tout document du Mur porte un type ; le filtre par type fonctionne",
      "L'étape 1 de la Boussole affiche la recette du type en cours",
    ],
    test: "Couverture : chaque document du Mur a un type valide ; snapshot d'une fiche.",
    impact: "Devant un document inconnu, l'élève a une recette au lieu d'avoir peur — 2 pts par sujet.",
  },
  {
    id: "S3-04",
    phase: "S3",
    title: "Construire le module d'exploitation chiffrée (trou critique n°2)",
    severity: "critique",
    effort: "3 jours",
    audit: "Audit de modules étape 4.4 — ≈ 2,5 pts par sujet, jamais entraînés",
    files: ["src/data/quantSkills.ts (à créer)", "Mur d'analyse", "module Enzymes"],
    problem:
      "Vitesses de réaction, densités optiques, pourcentages, dilutions, bilans énergétiques : le barème paie 2-3 pts ce seul geste, et aucun module n'entraîne le calcul pas-à-pas. C'est le discriminant entre 11 et 15.",
    proof: "GAPS : « aucun module n'entraîne le calcul pas-à-pas » · enzyme tombée dans 6/7 sessions",
    spec: [
      "1. Créer 20 exercices chiffrés pas-à-pas (énoncé → grandeur cherchée → formule → application → unité → interprétation biologique), branchés sur les vrais sujets 2019-2025.",
      "2. Exiger l'unité et l'interprétation (« que signifie ce chiffre pour la cellule ? ») : un nombre sans phrase biologique vaut 0.",
      "3. Verrouiller l'accès derrière le QCM de positionnement de l'unité (≥ 50 %) pour éviter le découragement.",
    ],
    acceptance: [
      "20 exercices avec corrigé pas-à-pas complet (6 étapes)",
      "Tout résultat sans unité ou sans interprétation est refusé par le correcteur",
      "Les exercices citent la session BAC source",
    ],
    test: "Tests unitaires des 20 corrigés (valeurs + unités) ; test du verrouillage.",
    impact: "Le calcul cesse d'être la question qu'on saute : 2,5 pts récupérés par sujet.",
  },
  {
    id: "S3-05",
    phase: "S3",
    title: "Construire la trame C3 : hypothèse → témoin → conclusion (trou critique n°3)",
    severity: "critique",
    effort: "3 jours",
    audit: "Audit de modules étape 4.4 — ≈ 2 pts par exercice, la Boussole ne couvre que la rédaction",
    files: ["src/data/reasoningFrame.ts (à créer)", "Boussole (étape 3 اربط)", "Banque de situations"],
    problem:
      "La Boussole traite la rédaction, pas la structure logique du raisonnement : formuler une hypothèse réfutable, exiger un témoin, conclure sans sur-interpréter. C'est pourtant la compétence C3, notée 2 pts par exercice.",
    proof: "GAPS : « formulation d'hypothèse, choix du témoin, validité d'un résultat » non couverts",
    spec: [
      "1. Créer la trame en 4 cases : Hypothèse (réfutable, 1 phrase) → Protocole + témoin → Résultat (décrire) → Conclusion (valide/invalide l'hypothèse, limites).",
      "2. L'intégrer à l'étape 3 de la Boussole comme sous-grille obligatoire dès que la consigne contient « فرضية / اقترح / صمم ».",
      "3. Ajouter 10 situations d'entraînement notées sur cette seule trame (dont 3 où l'hypothèse est fausse : apprendre à invalider).",
    ],
    acceptance: [
      "Toute consigne à hypothèse affiche la trame 4 cases",
      "3 situations pièges où la bonne réponse est « hypothèse invalidée »",
      "Le Correcteur détecte l'absence de témoin comme erreur taggée",
    ],
    test: "Tests du détecteur « témoin absent » + cas d'hypothèse invalidée.",
    impact: "L'élève cesse de raconter des histoires : il raisonne comme le barème l'exige.",
  },
  {
    id: "S3-06",
    phase: "S3",
    title: "Glossaire bilingue arabe/français actif + rappels de 2e AS",
    severity: "majeur",
    effort: "2 jours",
    audit: "Audit de modules étape 4.4 — confusions de termes + prérequis manquants",
    files: ["src/data/glossaire.ts (à créer)", "fiches de cours (liens)", "QCM de positionnement (pré-test)"],
    problem:
      "L'épreuve est en arabe mais les termes arrivent du français : sans glossaire actif, l'élève confond des termes que le barème sanctionne. Et le BAC mobilise des acquis de 2e/1re AS (sang, ATP, ADN, roches) jamais rappelés.",
    proof: "GAPS : « il manque un glossaire bilingue actif » + « prérequis de 2AS jamais rappelés »",
    spec: [
      "1. Glossaire : terme AR ↔ terme FR + définition en 1 ligne + schéma associé ; tap sur un terme dans n'importe quelle leçon → fiche flottante.",
      "2. Pré-test de prérequis (5 questions) en tête de chaque unité ; tout échec renvoie vers une fiche de rappel de 2e AS, pas vers le cours de terminale.",
      "3. Le Correcteur signale la confusion de termes comme erreur dédiée (« tu as écrit X, le correcteur attend Y »).",
    ],
    acceptance: [
      "Tout terme du glossaire est cliquable dans les leçons",
      "Chaque unité a son pré-test de 5 questions avec fiches de rattrapage",
      "La confusion de termes est un tag du Correcteur",
    ],
    test: "Couverture : 150 termes min, chaque terme a AR+FR+définition+schéma ; pré-tests présents sur les 11 unités.",
    impact: "Fini les points perdus sur un mot : l'élève parle la langue du correcteur.",
  },

  // ─────────────────── S4 ───────────────────
  {
    id: "S4-01",
    phase: "S4",
    title: "Télémétrie locale J1/J7/J30 + carte de score partageable + avis au pic",
    severity: "majeur",
    effort: "2 jours",
    audit: "Rapports Jeremy + Les Ignobles — zéro mesure de rétention",
    files: ["src/lib/retention.ts (à créer, localStorage uniquement)", "src/components/WeeklyReportShareModal.tsx", "demande d'avis Play Store"],
    problem:
      "Aucune télémétrie, ni locale ni serveur : impossible de savoir si l'app est aimée, de décider quoi améliorer, ou de publier des chiffres. Et sans carte de score partageable, il n'y a pas de bouche-à-oreille.",
    proof: "src/lib/supabase.ts vide par défaut · zéro analytics · WeeklyReportShareModal existe mais n'est pas branché sur une métrique",
    spec: [
      "1. Télémétrie 100 % locale, sans identifiant, sans serveur : J1/J7/J30 actifs, mots-clés/semaine, % programme. Opt-in explicite, suppression en 1 clic, aucune donnée personnelle.",
      "2. Carte de score partageable : « Cette semaine : +18 mots-clés · 41 % du programme · Immunité : cause trouvée » — image générable, partage WhatsApp/Telegram.",
      "3. Demande d'avis Play Store UNIQUEMENT au pic de valeur (règle 9 : juste après une première note améliorée), jamais à l'ouverture, jamais après un échec. Pas plus d'une demande par version.",
    ],
    acceptance: [
      "Le tableau local affiche J1/J7/J30 et mots-clés/semaine sans aucun appel réseau",
      "La carte de score se génère et se partage en 2 clics",
      "L'avis n'est jamais demandé à froid (test du déclencheur)",
    ],
    test: "Test du déclencheur d'avis : pic de valeur → proposé ; ouverture à froid → jamais ; échec → jamais.",
    impact: "On pilote enfin sur des faits — et chaque progrès de l'élève devient une publicité.",
  },
];

export const SEVERITY_ORDER: Severity[] = ["bloquant", "critique", "majeur", "normal"];

export const SEVERITY_META: Record<Severity, { color: string; bg: string; label: string }> = {
  bloquant: { color: "#ef4444", bg: "bg-red-500/10", label: "Bloquant" },
  critique: { color: "#f97316", bg: "bg-orange-500/10", label: "Critique" },
  majeur: { color: "#f59e0b", bg: "bg-amber-500/10", label: "Majeur" },
  normal: { color: "#94a3b8", bg: "bg-white/5", label: "Normal" },
};

/** Export Markdown complet du SpecKit (bouton « Copier / Exporter ») */
export function speckitMarkdown(): string {
  const lines: string[] = [
    "# SPECKIT — Fiabiliser Kunz El Ouloum pour l'élève (BAC SVT)",
    "",
    "> Objectif unique : une application que l'élève peut croire : contenu au programme, tuteur qui fait chercher, chiffres vrais, zéro donnée exposée.",
    "",
  ];
  for (const p of PHASES) {
    const tickets = TICKETS.filter((t) => t.phase === p.id);
    lines.push(`## ${p.id} — ${p.title} (${p.duration})`, "", `**But :** ${p.goal}`, "", `**Sortie :** ${p.gate}`, "");
    for (const t of tickets) {
      lines.push(`### ${t.id} — ${t.title} [${t.severity.toUpperCase()} · ${t.effort}]`, "", `**Audit source :** ${t.audit}`, "", `**Fichiers :** ${t.files.join(" · ")}`, "", `**Problème :** ${t.problem}`, "", `**Preuve :** \`${t.proof}\``, "", "**Spec :**");
      t.spec.forEach((s) => lines.push(`- ${s}`));
      lines.push("", "**Acceptation :**");
      t.acceptance.forEach((a) => lines.push(`- [ ] ${a}`));
      lines.push("", `**Test :** ${t.test}`, "", `**Gain élève :** ${t.impact}`, "");
    }
  }
  lines.push("## Ordre d'exécution non négociable", "", "S0 → S1 → S2 → S3 → S4. Inverser deux phases, c'est perdre le lancement.", "");
  return lines.join("\n");
}
