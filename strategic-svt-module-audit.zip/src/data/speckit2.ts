/**
 * SPECKIT 001-fiabilite-eleve — modèle de données
 * Source : audits réellement lus à distance. Chaque item porte sa citation littérale.
 * Aucune exigence sans ID d'audit + preuve attachée (règle imposée par la session).
 */

export type Prio = "P0" | "P1" | "P2";
export type Axe = "Scientifique" | "Notation" | "Couverture" | "Contrat méthodo" | "Terminologie";
export type Etat = "à corriger" | "à verrouiller (correctif présent, non protégé)" | "prérequis non exécuté";

export type Track = "moteur-correcteur" | "contenu-domaine-I" | "contenu-domaines-II-III" | "methodo-dictionnaires";

export const TRACKS: { id: Track; label: string; scope: string; color: string }[] = [
  { id: "moteur-correcteur", label: "Moteur & correcteur", scope: "smartTutorEngine.ts · lib/validation · sessionManager · AITutorView (XP)", color: "#10b981" },
  { id: "contenu-domaine-I", label: "Contenu — domaine I", scope: "التخصص الوظيفي للبروتينات · smartBotData · knowledgeCards", color: "#38bdf8" },
  { id: "contenu-domaines-II-III", label: "Contenu — domaines II & III", scope: "التحولات الطاقوية · التكتونية العامة · bacExam · bookTutorQA", color: "#f59e0b" },
  { id: "methodo-dictionnaires", label: "Méthodo & dictionnaires", scope: "data/dictionaries · scienceRules · qcmBilan · فصحى", color: "#a78bfa" },
];

export interface AuditItem {
  id: string;
  source: string;
  verdict: string;
  gravity: string;
  axe: Axe;
  prio: Prio;
  etat: Etat;
  citation: string;
  localisation: string;
  faitEleve: string; // ce que l'élève subit concrètement
  story?: { quand: string; veux: string; afin: string };
  fr?: string;
  ac?: string[]; // critères d'acceptation mesurables
}

/* ───────────────── ITEMS RETENUS ───────────────── */
export const ITEMS: AuditItem[] = [
  {
    id: "B2",
    source: "docs/AUDIT_MORCHID_VERDICT_2026-09-25.md · §B2",
    verdict: "VRAI — confirmé (vérification empirique par script)",
    gravity: "Majeure",
    axe: "Notation",
    prio: "P0",
    etat: "à verrouiller (correctif présent, non protégé)",
    citation:
      "« Réponse niant EXPLICITEMENT chaque point-clé : ‹ لا، ليس صحيحاً أنّ CMH/HLA يعرض المستضدات… › → note 10/10 … la barrière ‹ il suffit de recopier les mots-clés en les niant › est complètement perméable. »",
    localisation: "gradeKeyPoints — src/smartTutorEngine.ts:588-606 · scénario boss1_q1 · script scripts/verify_b2_negation.ts",
    faitEleve:
      "Un élève qui recopie les mots-clés de la correction en les niant obtient 10/10. Il apprend que nier la réponse juste est une stratégie payante au BAC.",
    story: {
      quand: "je rédige au défi BAC une réponse qui commence par « لا، ليس صحيحاً أنّ… » en recopiant les mots-clés",
      veux: "recevoir 0/10 et la mention « ta réponse contredit le point-clé attendu »",
      afin: "de ne jamais confondre « avoir vu les mots » et « avoir dit la vérité scientifique »",
    },
    fr: "FR-N01 — Toute négation d'un point-clé attendu annule la couverture de ce point-clé. Rappel P2/R6 : aucun fit sur notes prof, barème officiel 5/7/8 pts uniquement.",
    ac: [
      "Réponse niant les 3 points-clés → 0/10 (script de vérification vert)",
      "Réponse reprenant exactement les points-clés → 10/10 (non régressée)",
      "Moitié niée, moitié reprise → 5/10 exactement",
      "Point-clé formulé négativement dans l'attendu (« لا تنتقل ») + réponse « لا تنتقل » → crédité (pas de double inversion)",
    ],
  },
  {
    id: "S4",
    source: "docs/AUDIT_MORCHID_VERDICT_2026-09-25.md · §S4",
    verdict: "VRAI — confirmé",
    gravity: "Majeure",
    axe: "Scientifique",
    prio: "P0",
    etat: "à corriger",
    citation: "« AUG → ‹ منيل › au lieu de ‹ ميثيونين › »",
    localisation: "Contenu domaine I (تركيب البروتين) — à localiser par grep dans data/smartBotData.ts · src/bookTutorQA.ts · recoupement data/bookContent.json",
    faitEleve:
      "L'élève mémorise un acide aminé qui n'existe pas. C'est une erreur factuelle enseignée, sanctionnée à l'inverse au BAC si reproduite.",
    story: {
      quand: "je révise le code génétique et que l'application m'affiche l'acide aminé correspondant à AUG",
      veux: "lire « ميثيونين » (méthionine), l'acide aminé initiateur, tel qu'écrit dans le manuel officiel",
      afin: "de répondre correctement à la question du code génétique qui tombe régulièrement",
    },
    fr: "FR-S01 — Le terme désignant l'acide aminé codé par AUG est « ميثيونين » partout, conforme au manuel officiel. Aucun contenu inventé : transcription mécanique depuis bookContent.json.",
    ac: [
      "grep -c 'منيل' sur le parcours élève = 0 occurrence",
      "grep 'ميثيونين' ≥ 1 occurrence sur chaque surface concernée",
      "Le mot est présent dans data/bookContent.json (preuve page officielle consignée dans le commit)",
      "Arabe فصحى, aucun dialecte",
    ],
  },
  {
    id: "S1",
    source: "docs/AUDIT_MORCHID_VERDICT_2026-09-25.md · §S1",
    verdict: "VRAI — confirmé",
    gravity: "Majeure",
    axe: "Scientifique",
    prio: "P0",
    etat: "à corriger",
    citation: "« Ondes S ‹ traversent › le noyau (preuve de liquidité) »",
    localisation: "Contenu domaine III (التكتونية العامة) — ondes sismiques · à localiser par grep · recoupement data/bookContent.json",
    faitEleve:
      "L'élève apprend que les ondes S traversent le noyau — donc que le noyau est solide. C'est l'inverse du raisonnement exigé au BAC : la zone d'ombre des S EST la preuve de liquidité.",
    story: {
      quand: "j'étudie la structure interne de la Terre et le raisonnement sur les ondes sismiques",
      veux: "que l'application enseigne que les ondes S ne traversent pas le noyau externe, ce qui prouve son état liquide",
      afin: "de pouvoir construire le raisonnement « discontinuité → état physique » attendu par le correcteur",
    },
    fr: "FR-S02 — Aucun énoncé ne présente les ondes S comme traversant le noyau. L'argument de liquidité du noyau externe est formulé conformément au manuel.",
    ac: [
      "Aucune surface élève n'affirme que les ondes S traversent le noyau",
      "La preuve de liquidité est énoncée au moins une fois, avec le vocabulaire du manuel",
      "Recoupement bookContent.json consigné (unité + page)",
      "Test de contenu rouge→vert ajouté",
    ],
  },
  {
    id: "S2",
    source: "docs/AUDIT_MORCHID_VERDICT_2026-09-25.md · §S2",
    verdict: "VRAI — confirmé",
    gravity: "Moyenne",
    axe: "Scientifique",
    prio: "P0",
    etat: "à corriger",
    citation: "« Zone d'ombre des ondes P niée dans la situation BAC »",
    localisation: "Scénario de défi BAC domaine III — data/smartBotData.ts (boss scenarios) · recoupement data/bookContent.json",
    faitEleve:
      "La situation d'examen nie un phénomène réel : l'élève qui connaît son cours hésite, ou pire, retient la version fausse de l'application.",
    story: {
      quand: "je traite une situation BAC sur la propagation des ondes P",
      veux: "une situation dont les données et la correction admettent l'existence de la zone d'ombre",
      afin: "de ne pas douter de mon cours le jour de l'épreuve",
    },
    fr: "FR-S03 — Les situations BAC n'infirment aucun phénomène sismique réel ; la zone d'ombre des ondes P est prise en compte dans les données et la correction.",
    ac: [
      "La correction du scénario ne nie plus la zone d'ombre des ondes P",
      "Les données de la situation sont cohérentes avec la correction",
      "Conformité vérifiée contre bookContent.json (unité + page consignée)",
    ],
  },
  {
    id: "S-M1",
    source: "docs/ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md · §3.2",
    verdict: "VRAI — corrigé à HEAD (§5)",
    gravity: "Majeure",
    axe: "Scientifique",
    prio: "P0",
    etat: "à verrouiller (correctif présent, non protégé)",
    citation:
      "« bacExam.ts:53 : منحنى Michaelis-Menten (جرسي الشكل ينبسط نحو Vmax). Preuve interne décisive : le correcteur de l'application sanctionne lui-même ce faux ami — correcteurIntegration.test.ts:117 ‹ faux ami Michaelis ‹en cloche› détecté ›, gravité forte, correctif ‹ التشبع الزائدي ›. »",
    localisation: "src/data/bacExam.ts:53 · contre-preuve src/correcteurIntegration.test.ts:117",
    faitEleve:
      "L'application enseignait une courbe « en cloche » que son propre correcteur sanctionnait chez l'élève. L'élève était puni pour avoir appris la version de l'app.",
    story: {
      quand: "je révise l'activité enzymatique et que je croise la courbe de Michaelis-Menten",
      veux: "une description hyperbolique (« تشبع زائد ») cohérente entre le cours, le sujet et le correcteur",
      afin: "de ne plus être sanctionné pour un mot que l'application m'avait enseigné",
    },
    fr: "FR-S04 — La description de la courbe de Michaelis-Menten est unique, hyperbolique, dans le corrigé ET dans le dictionnaire du correcteur. Test de régression permanent exigé.",
    ac: [
      "Aucune occurrence de « جرسي الشكل » associée à Michaelis-Menten sur le parcours élève (grep = 0)",
      "Le test correcteurIntegration « faux ami Michaelis en cloche » reste vert",
      "Un test de régression empêche toute réintroduction du terme dans bacExam.ts",
      "Preuve : extrait unité × page officielle consigné",
    ],
  },
  {
    id: "B3",
    source: "docs/AUDIT_MORCHID_VERDICT_2026-09-25.md · §B3",
    verdict: "VRAI — confirmé (correctif includesAsWord présent à HEAD+)",
    gravity: "Mineure",
    axe: "Notation",
    prio: "P0",
    etat: "à verrouiller (correctif présent, non protégé)",
    citation:
      "« la carte earth_structure a le mot-clé لب (smartBotData.ts:254) ; le matching se fait par norm.includes(nk) … ‹الباك› normalisé contient la sous-chaîne لب → contentScore = 8 ≥ seuil → carte retenue avec confiance 70 %. Tout mot contenant لب (الباك، البكالوريا، اللباب…) est détourné vers la tectonique. »",
    localisation: "src/smartTutorEngine.ts:423 et 472 (ancien includes) · mot-clé لب — src/data/smartBotData.ts:254",
    faitEleve:
      "L'élève qui tape « الباك » reçoit un cours sur la structure de la Terre. Il apprend que l'application ne comprend pas sa question, puis cesse de lui poser des questions.",
    story: {
      quand: "je tape « الباك » ou « البكالوريا » pour parler de l'examen",
      veux: "une réponse relative à l'examen, jamais un cours sur le noyau terrestre",
      afin: "de faire confiance au tuteur quand je formule ma demande",
    },
    fr: "FR-N02 — Le matching des mots-clés se fait sur mot entier (bord défini), jamais sur sous-chaîne. Correctif includesAsWord verrouillé par test.",
    ac: [
      "findBestKnowledgeCard('الباك') ne retourne plus la carte بنية الكرة الأرضية",
      "Le mot-clé « لب » reste fonctionnel dans une requête le contenant comme mot entier",
      "Test unitaire : liste de 10 mots contenant « لب » comme sous-chaîne → aucun détournement",
    ],
  },
  {
    id: "B7",
    source: "docs/AUDIT_MORCHID_VERDICT_2026-09-25.md · §B7",
    verdict: "VRAI — confirmé (handler présent à HEAD+)",
    gravity: "Moyenne",
    axe: "Notation",
    prio: "P0",
    etat: "à verrouiller (correctif présent, non protégé)",
    citation:
      "« processStudentInput(sessionDom3, ‹اختبرني في الغوص›) → AUCUN quiz ; réponse = carte de cours. Le bouton promet un test (‹اختبرني› = teste-moi) mais déclenche un cours. »",
    localisation: "src/smartTutorEngine.ts — intercepteur d'intention « اختبرني » absent avant correctif",
    faitEleve:
      "L'élève demande à être testé, reçoit un cours. Il croit avoir été évalué alors qu'il n'a rien produit : auto-évaluation faussée.",
    story: {
      quand: "j'écris « اختبرني في الغوص »",
      veux: "un QCM réellement lancé sur la subduction",
      afin: "de savoir si je maîtrise le point avant de passer au suivant",
    },
    fr: "FR-N03 — Toute intention « اختبرني (في X) » déclenche un QCM du sujet X ou un message explicite d'indisponibilité — jamais une fiche de cours.",
    ac: [
      "« اختبرني في الغوص » → QCM dont topicId correspond à الغوص",
      "Si le sujet n'a aucun QCM → message explicite + suggestion, jamais de fiche de cours",
      "Test unitaire sur 8 formulations « اختبرني في … »",
    ],
  },
  {
    id: "B5b",
    source: "docs/AUDIT_MORCHID_VERDICT_2026-09-25.md · §B5",
    verdict: "PARTIELLEMENT VRAI — partie réelle actuelle",
    gravity: "Moyenne",
    axe: "Notation",
    prio: "P0",
    etat: "à corriger",
    citation:
      "« Bouton de parcours ‹القائمة الرئيسية› (AITutorView.tsx:151-168, resetSession()) : erreurs effacées ✓effacées, completedBac effacé … l'anti-farm completedBac est systématiquement effacé : après un défi BAC, un simple retour à l'accueil permet de le re-jouer pour regagner l'XP. »",
    localisation: "src/components/AITutorView.tsx:151-168 (resetSession) · comparé au chemin moteur smartTutorEngine.ts:666-670 qui préserve",
    faitEleve:
      "L'élève peut regagner indéfiniment l'XP d'un même défi en retournant à l'accueil. Son score ne mesure plus rien, et la comparaison entre élèves devient fausse.",
    story: {
      quand: "je termine un défi BAC puis reviens au menu principal par le bouton",
      veux: "que mes erreurs et mes défis déjà récompensés soient conservés",
      afin: "que mon score reflète un travail réel et non une répétition",
    },
    fr: "FR-N04 — Les deux chemins de retour à l'accueil (saisie texte et bouton) préservent mistakes et completedBac. XP d'un défi : première complétion uniquement.",
    ac: [
      "Bouton accueil → mistakes et completedBac préservés (identique au chemin moteur)",
      "Rejouer un défi complété → 0 XP additionnel",
      "Test : séquence défi → accueil bouton → défi → XP total inchangé",
    ],
  },
  {
    id: "B6",
    source: "docs/AUDIT_MORCHID_VERDICT_2026-09-25.md · §B6",
    verdict: "PARTIELLEMENT VRAI — 0-XP non journalisé VRAI · décompte FAUX/obsolète",
    gravity: "Mineure",
    axe: "Notation",
    prio: "P1",
    etat: "à corriger",
    citation:
      "« AITutorView.tsx:103 n'appelle onXPGained que si xpGained > 0. Un quiz terminé à 0 bonnes réponses n'est jamais remonté au tableau de bord enseignant (file /api/student/sync), alors que handleTutorXPGained (App.tsx:394) l'accepterait (total = 23 > 0). »",
    localisation: "src/components/AITutorView.tsx:103 · récepteur src/App.tsx:394",
    faitEleve:
      "Un élève qui échoue complètement devient invisible pour son professeur. Le prof croit qu'il ne travaille pas, alors qu'il travaille et échoue — c'est précisément lui qu'il faut aider.",
    story: {
      quand: "je termine un quiz à 0 bonne réponse",
      veux: "que cette tentative apparaisse dans le suivi de mon professeur",
      afin: "d'être repéré comme élève en difficulté et non comme élève absent",
    },
    fr: "FR-N05 — Toute tentative terminée est journalisée, quelle que soit la note. Le tableau de bord distingue « absent » de « échoué ».",
    ac: [
      "Quiz à 0 → événement émis avec total > 0 et score = 0",
      "Le tableau de bord enseignant affiche l'activité échouée",
      "Le décompte annoncé (« أجب عن N سؤالاً ») reste exact (déjà vérifié : 23/23/20)",
    ],
  },
  {
    id: "S3",
    source: "docs/AUDIT_MORCHID_VERDICT_2026-09-25.md · §S3",
    verdict: "PARTIELLEMENT VRAI",
    gravity: "Mineure",
    axe: "Scientifique",
    prio: "P1",
    etat: "à corriger",
    citation: "« ‹ la vitesse augmente avec la densité › »",
    localisation: "Contenu domaine III — ondes sismiques · recoupement data/bookContent.json",
    faitEleve:
      "Une relation qualitative approximative enseignée comme loi : l'élève l'utilise comme argument et perd les points de rigueur.",
    story: {
      quand: "j'explique la propagation des ondes dans les enveloppes terrestres",
      veux: "une formulation exacte de la relation vitesse/milieu, conforme au manuel",
      afin: "de ne pas écrire une loi fausse dans ma copie",
    },
    fr: "FR-S05 — Toute relation vitesse/densité est formulée selon le manuel officiel, sans généralisation abusive.",
    ac: [
      "La formulation du manuel est reprise mot pour mot (injection mécanique)",
      "Aucune formulation généralisée « la vitesse augmente avec la densité » isolée de son contexte",
      "Recoupement bookContent.json consigné",
    ],
  },
  {
    id: "S6",
    source: "docs/AUDIT_MORCHID_VERDICT_2026-09-25.md · §S6",
    verdict: "VRAI — confirmé",
    gravity: "Mineure",
    axe: "Terminologie",
    prio: "P2",
    etat: "à corriger",
    citation: "« Oxymore ‹ انفراج (تقارب متباعد) › »",
    localisation: "Contenu domaine III — arabe فصحى · recoupement data/bookContent.json",
    faitEleve: "Une contradiction interne dans le vocabulaire : l'élève retient un terme qui n'a pas de sens.",
    story: {
      quand: "je lis la terminologie de la tectonique des plaques",
      veux: "un vocabulaire cohérent et correct en arabe فصحى",
      afin: "d'utiliser les termes exacts que le correcteur attend",
    },
    fr: "FR-T01 — Aucun oxymore terminologique : le terme et sa glose ne se contredisent pas. فصحى uniquement.",
    ac: ["« تقارب متباعد » absent (grep = 0)", "Terme conforme au manuel substitué", "Relecture humaine arabe effectuée et consignée"],
  },
  {
    id: "S7",
    source: "docs/AUDIT_MORCHID_VERDICT_2026-09-25.md · §S7",
    verdict: "VRAI — confirmé",
    gravity: "Mineure",
    axe: "Terminologie",
    prio: "P2",
    etat: "à corriger",
    citation: "« ‹ فيغوص الصهر › (la fonte s'enfonce au lieu de monter) »",
    localisation: "Contenu domaine III — fusion partielle / dorsale · recoupement data/bookContent.json",
    faitEleve: "Le sens physique est inversé : la fonte remonte, elle ne s'enfonce pas. Erreur de mécanisme, pas seulement de mot.",
    story: {
      quand: "j'étudie la formation de la croûte océanique aux dorsales",
      veux: "que la fusion partielle soit décrite comme une remontée",
      afin: "de décrire le mécanisme dans le bon sens dans ma copie",
    },
    fr: "FR-T02 — Le sens de migration de la fonte est conforme au manuel (remontée), jamais inversé.",
    ac: ["« فيغوص الصهر » absent du parcours élève", "Formulation « remontée de la fonte » conforme au manuel", "Relecture humaine arabe consignée"],
  },
  {
    id: "S8",
    source: "docs/AUDIT_MORCHID_VERDICT_2026-09-25.md · §S8",
    verdict: "VRAI — confirmé",
    gravity: "Mineure",
    axe: "Terminologie",
    prio: "P2",
    etat: "à corriger",
    citation: "« ‹ الوشام › au lieu de ‹ الوشاح › »",
    localisation: "Contenu domaine III — vocabulaire du manteau · recoupement data/bookContent.json",
    faitEleve: "Une coquille qui change le mot : « tatouage » au lieu de « manteau ». L'élève écrit le faux terme en copie.",
    story: {
      quand: "je nomme les enveloppes terrestres",
      veux: "« الوشاح » (manteau), le terme exact du manuel",
      afin: "d'utiliser la terminologie officielle dans ma copie",
    },
    fr: "FR-T03 — « الوشاح » est le seul terme employé pour le manteau. Filtre orthographique ر/ز · ح/ة · ف/ب appliqué à toute injection.",
    ac: ["« الوشام » absent (grep = 0)", "« الوشاح » présent sur toutes les surfaces concernées", "Filtre de confusion graphique appliqué et documenté"],
  },
  {
    id: "S-C4",
    source: "docs/ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md · §3.2",
    verdict: "VRAI (à HEAD 574ec4e)",
    gravity: "Moyenne",
    axe: "Couverture",
    prio: "P1",
    etat: "à corriger",
    citation:
      "« unitCatalog.ts:9-10 : ‹ skipped 120 unsupported or placeholder Flutter questions… the current React quiz component supports QCM only ›. Toujours non récupérées. »",
    localisation: "src/unitCatalog.ts:9-10 · scripts d'import Flutter",
    faitEleve:
      "120 questions du corpus d'origine ne sont pas disponibles : des parties du programme ne sont testables nulle part dans l'app.",
    story: {
      quand: "je termine la révision d'une unité et que je veux m'auto-tester",
      veux: "que toutes les questions existantes du programme soient disponibles, y compris celles à compléter",
      afin: "de ne pas croire à tort que je maîtrise une unité faiblement couverte",
    },
    fr: "FR-C01 — Les questions Flutter à trous récupérables sont intégrées ou explicitement exclues avec motif. Aucune perte silencieuse.",
    ac: [
      "Chaque question des 120 est classée : intégrée / hors programme / placeholder irrécupérable (motif consigné)",
      "Le composant supporte le format à compléter ou la question est convertie en QCM explicitement",
      "Comptage avant/après consigné dans le commit",
    ],
  },
  {
    id: "S-Q1",
    source: "docs/ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md · §3.2",
    verdict: "PARTIEL — pool déséquilibré (D1=45/D2=17/D3=29) mais tirage équilibré par construction",
    gravity: "Mineure",
    axe: "Couverture",
    prio: "P1",
    etat: "à corriger",
    citation:
      "« Pool actuel : D1=45, D2=17, D3=29 (total 91). Le déséquilibre s'est réduit mais D1 reste ~50 %. En revanche le tirage est équilibré par construction : 5 QCM par domaine (qcmBilan.ts:145). »",
    localisation: "src/data/qcmBilan.ts:145 (tirage) · pool qcmBilan (répartition)",
    faitEleve:
      "Le bilan couvre inégalement les domaines : un élève fort en domaine III a peu de questions pour le vérifier, et surestime ou sous-estime sa maîtrise.",
    story: {
      quand: "je fais un QCM bilan sur les trois domaines",
      veux: "un nombre de questions comparable par domaine, au prorata du poids BAC",
      afin: "d'obtenir un diagnostic fidèle de mes points faibles",
    },
    fr: "FR-C02 — La répartition du pool de bilan est équilibrée entre domaines, proportionnée au poids BAC officiel (5/7/8 pts). Le tirage équilibré existant est conservé.",
    ac: [
      "Écart de représentation entre domaines ≤ 20 % dans le pool",
      "Le tirage 5/domaine (qcmBilan.ts:145) reste inchangé et testé",
      "Poids BAC issus de data/bac_sessions_2019_2026.json, consignés",
    ],
  },
  {
    id: "S-C2",
    source: "docs/ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md · §3.2",
    verdict: "PARTIEL — balisage correct (Gemini), risque de dispersion réel (Opus)",
    gravity: "Moyenne",
    axe: "Couverture",
    prio: "P1",
    etat: "à corriger",
    citation:
      "« NON_EXIGIBLES + CULTURE_GENERALE existent bien (curriculumOfficial.ts:35-49) — Gemini a raison sur le balisage. Mais Opus a raison sur le risque : unitLessonSequences.ts signale encore des chapitres U11 ‹ à reconstruire ›. »",
    localisation: "src/data/curriculumOfficial.ts:35-49 · src/data/unitLessonSequences.ts:43",
    faitEleve:
      "Des chapitres hors barème côtoient les chapitres exigibles sans que l'élève sache lequel compte. Le chapitre U11 incomplet est inutilisable.",
    story: {
      quand: "j'ouvre la liste des leçons d'une unité",
      veux: "que les chapitres exigibles au BAC soient distingués de la culture générale",
      afin: "de ne pas investir du temps sur ce qui ne tombe pas",
    },
    fr: "FR-C03 — Tout chapitre non exigible est balisé et visuellement distinct ; tout chapitre « à reconstruire » est masqué ou marqué incomplet — jamais présenté comme prêt.",
    ac: [
      "Les chapitres NON_EXIGIBLES/CULTURE_GENERALE portent un badge visible",
      "Les chapitres signalés « à reconstruire » (unitLessonSequences.ts:43) ne sont pas présentés comme complets",
      "Liste des chapitres masqués consignée dans le commit",
    ],
  },
];

/* ───────────────── ITEMS JETÉS (annexe) ───────────────── */
export interface Rejected {
  id: string;
  source: string;
  claim: string;
  verdict: string;
  reason: string;
}

export const REJECTED: Rejected[] = [
  { id: "B1", source: "AUDIT_MORCHID_VERDICT_2026-09-25.md", claim: "Mission quotidienne non résolvable + scoring inter-quiz (prot_q2)", verdict: "FAUX / OBSOLÈTE", reason: "Vérification empirique : mission produisant bien un QCM ; carte study_planning inatteignable ; shuffledView déterministe (seed FNV-1a sur q.id), prompt et correction dans le même ordre. Correctif déjà intégré." },
  { id: "B4", source: "AUDIT_MORCHID_VERDICT_2026-09-25.md", claim: "Sélection du domaine 2 mais QCM du domaine 1", verdict: "FAUX / OBSOLÈTE", reason: "handleDomainClick(2) → activeDomainId 2 ✓ ; premier QCM ene_q1 domaine 2 ✓ ; getQuestionsForDomain cohérente (23/23/20). REC #1 déjà appliqué." },
  { id: "B8", source: "AUDIT_MORCHID_VERDICT_2026-09-25.md", claim: "Dernier QCM encore cliquable après la fin", verdict: "FAUX / OBSOLÈTE", reason: "Déjà corrigé par les correctifs antérieurs intégrés avant 583b77b." },
  { id: "S5", source: "AUDIT_MORCHID_VERDICT_2026-09-25.md", claim: "Rôle de l'ARNt erroné", verdict: "NON CONFIRMÉ (faux)", reason: "Le rapport d'audit initial est infondé : les données décrivent correctement l'ARNt. Aucune correction à faire — corriger serait introduire une erreur." },
  { id: "B6-décompte", source: "AUDIT_MORCHID_VERDICT_2026-09-25.md", claim: "Décompte faux de 1 sur le nombre de questions", verdict: "FAUX / OBSOLÈTE", reason: "totalQuestions = questions.length ; vérifié 23/23/20 (total 66). L'annonce est exacte. Seule la partie journalisation est retenue (item B6)." },
  { id: "T1", source: "ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md §3.1", claim: "fetchMe() sans header Authorization → 401 → JWT effacé (CRITIQUE)", verdict: "OBSOLÈTE", reason: "src/utils/api.ts:50-55 envoie Authorization: Bearer + commentaire de correctif. Hors périmètre fiabilité élève de toute façon." },
  { id: "T2", source: "ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md §3.1", claim: "Session perdue au rechargement", verdict: "OBSOLÈTE", reason: "App.tsx:91-97 hydrate depuis localStorage si jeton valide." },
  { id: "T3", source: "ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md §3.1", claim: "Requête CRLF tue le process Node", verdict: "OBSOLÈTE", reason: "server.ts:45-48 asyncHandler + handler d'erreurs global. Serveur, pas fiabilité élève." },
  { id: "T4", source: "ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md §3.1", claim: "Deadlock HTTP 413, file offline bloquée", verdict: "OBSOLÈTE", reason: "server.ts:118 limit 2mb." },
  { id: "T5", source: "ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md §3.1", claim: "Code de reset par Math.random() prévisible", verdict: "OBSOLÈTE", reason: "server.ts:64-67 randomBytes(8) CSPRNG." },
  { id: "T6", source: "ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md §3.1", claim: "Pas de limitation de tentatives sur reset-password", verdict: "OBSOLÈTE", reason: "3 limiteurs présents (IP, login, reset 10/fenêtre)." },
  { id: "T8", source: "ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md §3.1", claim: "7 vulnérabilités npm audit (3 high)", verdict: "OBSOLÈTE", reason: "npm audit à HEAD : 0 vulnérabilité sur 1 039 dépendances, exit 0." },
  { id: "S-D1", source: "ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md §2", claim: "Gemini A1 : « Zéro erreur scientifique + 31 errata »", verdict: "FAUX", reason: "Contredit par S-M1 (Michaelis-Menten « en cloche » dans bacExam.ts:53). Le rapport Gemini ne peut pas servir de référence de couverture." },
  { id: "S-B1", source: "ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md §3.2", claim: "Opus A4 : Bac 2025 = 1 seul sujet officiel", verdict: "FAUX", reason: "Les deux sujets sont présents (الموضوع الأول / الثاني, 5/7/8 pts) ; le scoreur embarque les attendus bac2023→bac2025 sujets 1 et 2 (baremeCorrecteur.ts:133, correcteurIntegration.test.ts:59)." },
  { id: "S-C1", source: "ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md §3.2", claim: "4 chapitres vides phase23–phase26 (~1,9 Ko)", verdict: "OBSOLÈTE", reason: "25 fichiers HTML, le plus petit 38 Ko. Dette documentée dans unitLessonSequences.ts:43 → couverte par l'item S-C2 (balisage), pas par une reconstruction." },
  { id: "S-C3", source: "ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md §3.2", claim: "Numérotation incohérente leçons HTML vs lessonData.ts", verdict: "NON VÉRIFIABLE", reason: "check:lecons passe (0 erreur). Sans accès au dépôt cette session, aucune exigence ne peut être formulée sans preuve — règle de la session." },
  { id: "T7", source: "ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md §3.1", claim: "Sécurité auth insuffisante (MIN_PASSWORD_LEN, email, CSV)", verdict: "PARTIEL — hors périmètre", reason: "Reste réel (MIN_PASSWORD_LEN = 6) mais relève du serveur et de la sécurité, pas de « ce qu'un élève peut apprendre de faux ou se voir noter de faux ». Reporté hors speckit." },
  { id: "T9", source: "ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md §3.1", claim: "132 fichiers parasites + PDF ONPS 15,3 Mo", verdict: "PARTIEL — hors périmètre", reason: "Risque juridique/publication réel (PDF toujours présent) mais sans effet sur l'apprentissage de l'élève. Reporté au speckit de publication." },
];

/* ───────────────── DONNÉES BAC RÉELLES (PR-3 levé) ───────────────── */
/**
 * Extrait lu depuis data/bac_sessions_2019_2026.json (source ONEC,
 * republications eddirasa.com + dzexams.com). Aucune ligne du fichier
 * n'a été recopiée : seules les métadonnées de structure sont reprises.
 */
export const BAC_SESSIONS = {
  status: "LU cette session" as const,
  url: "https://raw.githubusercontent.com/sinamind414/kunz-el-ouloum/master/data/bac_sessions_2019_2026.json",
  sessions: [2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026] as const,
  continuous: "2019 → 2026, série continue sans trou (sprint 17)",
  lacunePonctuelle: "2021 sujet 2 exercice 1 non lisible dans la source",
  duree: "04 h 30",
  choix: "2 sujets au choix",
  bareme: { ex1: 5, ex2: 7, ex3: 8, total: 20 } as const,
  source: "PDF officiels ONEC republiés par eddirasa.com et dzexams.com",
  methode:
    "lecture du texte des PDF officiels ; aucun énoncé recopié, seules l'idée, les supports, la notion et les verbes sont retenus",
};

/** Poids moyens par domaine déduits de la structure officielle 5/7/8 pts.
 *  Le domaine III (ex3 = 8 pts) pèse le plus lourd ; c'est lui qui doit
 *  être représenté en premier dans tout équilibrage de pool (T-31). */
export const BAC_WEIGHTS = {
  domaine_I: { pts: 5, label: "التخصص الوظيفي للبروتينات", partPct: 25 },
  domaine_II: { pts: 7, label: "التحولات الطاقوية", partPct: 35 },
  domaine_III: { pts: 8, label: "التكتونية العامة", partPct: 40 },
} as const;

/* ───────────────── PRÉREQUIS NON EXÉCUTÉS ───────────────── */
export const PREREQS = [
  {
    id: "PR-1",
    what: "docs/audits_livres/A_MAJAL1_*.md · B_MAJAL2_*.md · C_MAJAL3_*.md · D_METHODO_*.md · CONSOLIDE_*.md",
    status: "INTROUVABLE (404)",
    consequence:
      "AUCUNE exigence de conformité livres A/B/C ne peut être spécifiée : sans les écarts page à page, toute exigence serait inventée — violation de la règle « item sans preuve = item jeté ».",
    blocking: "Bloc les tâches de contenu exigeant une page officielle (T-10, T-20 à T-26) au niveau de la preuve attendue. Celles-ci gardent néanmoins leur preuve issue de AUDIT_MORCHID_VERDICT (verdict + script empirique) — elles ne sont pas annulées, mais leur preuve page officielle reste À COMPLÉTER avant merge.",
  },
  {
    id: "PR-2",
    what: "INDEX.md (hiérarchie de vérité bookContent.json → الكتاب المصحح → bibliothèque)",
    status: "INTROUVABLE (404)",
    consequence:
      "La hiérarchie de vérité n'est pas vérifiable cette session. Le speckit applique donc la hiérarchie déclarée dans la commande (bookContent.json = source première) et exige un recoupement grep obligatoire pour toute correction de contenu.",
    blocking: "Ne bloque pas les tâches moteur (aucun contenu). Bloque la clôture des tâches de contenu : aucune ne peut être déclarée terminée sans recoupement bookContent.json consigné.",
  },
  {
    id: "PR-3",
    what: "data/bac_sessions_2019_2026.json (poids BAC)",
    status: "✅ LU cette session — PR-3 LEVÉ",
    consequence:
      "Barème officiel confirmé : exercice 1 = 5 pts, exercice 2 = 7 pts, exercice 3 = 8 pts (total 20). Série 2019→2026 continue. Lacune ponctuelle : 2021 sujet 2 exercice 1 non lisible. Poids utilisés pour FR-C02 (équilibrage du pool) : domaine III (40 %) > domaine II (35 %) > domaine I (25 %).",
    blocking: "Ne bloque plus aucune tâche. FR-C02 (T-31) peut désormais s'appuyer sur les poids réels 5/7/8 pts.",
  },
];

/* ───────────────── DIVERGENCES TRANCHÉES ───────────────── */
export const DIVERGENCES = [
  {
    topic: "Note globale du dépôt : Opus 63/100 vs Gemini 78/100 (Δ +15)",
    says: [
      "Opus : A1 6,5 · A4 4,5 · A7 5,0 · A8 5,0 — posture sévère",
      "Gemini : A1 8,5 · A4 6,8 · A7 5,8 · A8 8,5 — posture généreuse",
    ],
    ruling:
      "Aucune des deux notes n'est utilisable comme base de priorisation : l'écart vient de choix de grading opposés (A8 = désaccord de valeurs, pas de fait). Le speckit ignore donc les notes globales et priorise uniquement sur des items à verdict empirique confirmé. Concrètement : les 9 items retenus ont tous un verdict VRAI/PARTIEL adossé à un fichier, jamais à une note d'axe.",
    basis: "ANALYSE_AUDITS_OPUS_GEMINI §2 — « l'écart n'est pas un simple décalage d'humeur — il vient de choix de grading opposés »",
  },
  {
    topic: "A1 — Existe-t-il des erreurs scientifiques ? Gemini dit non, Opus oui",
    says: [
      "Gemini : « Zéro erreur + 31 errata »",
      "Opus : erreur Michaelis-Menten relevée",
    ],
    ruling:
      "Opus a raison, Gemini a tort. La preuve est interne et décisive : le correcteur de l'application sanctionne lui-même le faux ami « en cloche » (correcteurIntegration.test.ts:117, gravité forte) alors que le corrigé officiel l'affichait (bacExam.ts:53). Conclusion retenue : l'application punissait l'élève pour une erreur qu'elle enseignait. C'est la divergence la plus grave de tout le corpus, traitée en P0-Scientifique avec test de régression permanent.",
    basis: "S-M1 — bacExam.ts:53 × correcteurIntegration.test.ts:117",
  },
  {
    topic: "A4 — Combien de sujets Bac 2025 ?",
    says: ["Opus : « 1 seul sujet officiel confirmé »", "Gemini : 6,8/10 sans contestation explicite"],
    ruling:
      "Opus a tort. Les deux sujets sont présents et le scoreur embarque les attendus bac2023→bac2025 pour les sujets 1 et 2. Conséquence : aucune tâche de « rattrapage de sujets manquants » n'est créée — ce serait travailler un manque qui n'existe pas.",
    basis: "baremeCorrecteur.ts:133 · correcteurIntegration.test.ts:59 · sujets الموضوع الأول/الثاني (5/7/8 pts)",
  },
  {
    topic: "A7 — Fiabilité technique 5,0 (Opus) vs 5,8 (Gemini) : le cluster serveur critique",
    says: ["Opus : 9 bugs serveur dont un critique (T1)", "Gemini : sous-pondère le cluster"],
    ruling:
      "Les deux sont périmés : T1 à T6 et T8 sont OBSOLÈTES à HEAD (Authorization présent, hydratation, asyncHandler, limit 2mb, CSPRNG, limiteurs, npm audit = 0). Ne subsiste que T7 en PARTIEL (MIN_PASSWORD_LEN = 6) et T9 en PARTIEL (PDF 15,3 Mo) — tous deux hors périmètre fiabilité élève. L'axe A7 devrait être réévalué à ~7,0-7,5 mais aucune tâche n'en découle dans CE speckit.",
    basis: "ANALYSE_AUDITS_OPUS_GEMINI §3.1 — tableau des verdicts OBSOLÈTE",
  },
  {
    topic: "S-C2 — Les chapitres hors programme sont-ils un atout ou un risque ?",
    says: ["Opus (ko) : risque de dispersion", "Gemini (atout) : balisage CULTURE_GENERALE correct"],
    ruling:
      "Les deux ont raison sur des faits différents : le balisage existe bien (curriculumOfficial.ts:35-49) ET le risque de dispersion est réel (unitLessonSequences.ts:43 signale des chapitres U11 « à reconstruire »). Arbitrage : on garde le balisage (c'est le bon mécanisme) et on ajoute l'obligation qu'un chapitre incomplet ne soit jamais présenté comme prêt. Priorité P1-Couverture.",
    basis: "curriculumOfficial.ts:35-49 × unitLessonSequences.ts:43",
  },
  {
    topic: "Verdict Morchid à HEAD 583b77b vs code lu plus tard (B2, B3, B7)",
    says: [
      "AUDIT_MORCHID_VERDICT : B2 « VRAI — confirmé », B3 « VRAI », B7 « VRAI »",
      "Code lu après : correctifs présents (tokenAffirmed/adjacentNegation pour R3, includesAsWord pour B3, intercepteur « اختبرني » pour B7)",
    ],
    ruling:
      "Divergence résolue par la règle « une suite partiellement rouge n'est pas acceptable » d'AGENTS.md : ces trois items sont traités en VERROUILLAGE, pas en correction. Le correctif existe ; ce qui manque est le test qui l'empêche de régresser. Aucun des trois n'est marqué « à corriger » : ils sont marqués « à verrouiller » avec test rouge→vert exigé. Si à l'exécution le correctif est absent, la tâche bascule en correction — et le test reste la preuve de sortie dans les deux cas.",
    basis: "AGENTS.md — Règles d'or §Tests · AUDIT_MORCHID_VERDICT §B2/B3/B7",
  },
  {
    topic: "A2 — S-C1 : chapitres vides phase23-26, faut-il les reconstruire ?",
    says: ["Opus + Gemini : 4 chapitres vides ~1,9 Ko", "État à HEAD : 25 fichiers, plus petit 38 Ko"],
    ruling:
      "Non-goal. Les chapitres sont supprimés, pas vides. La dette restante (collision/ophiolites à reconstruire) est une création de contenu, pas une correction de fiabilité. Elle est hors périmètre de ce speckit et masquée par FR-C03.",
    basis: "unitLessonSequences.ts:43 — « phase26 placeholder exclue — hors-programme ; ch collision/ophiolites à reconstruire »",
  },
];

/* ───────────────── NON-GOALS ───────────────── */
export const NON_GOALS = [
  { item: "II.3 إثرائية (enrichissement hors barème)", why: "Ne sert pas la fiabilité de l'élève sur le programme exigible. Aucune story." },
  { item: "Cosmétique — couleurs, animations, mascotte, lexique marin", why: "Aucun effet mesurable sur ce que l'élève apprend de faux ou se voit noter de faux." },
  { item: "Nouvelles fonctionnalités (paywall, ASO, swipe, onboarding RADAR)", why: "Issues d'autres speckits (publication/acquisition). Ce speckit ne traite que la fiabilité." },
  { item: "Sécurité serveur (T7 auth, T9 PDF ONPS 15,3 Mo)", why: "Réels mais hors périmètre « élève apprend faux / noté en faux ». Reportés au speckit de publication." },
  { item: "Reconstruction des chapitres collision/ophiolites", why: "Création de contenu, pas correction. Déjà documentée (unitLessonSequences.ts:43)." },
  { item: "Fit du scoreur sur les notes prof", why: "INTERDIT par AGENTS.md P2/R6. Aucun modèle a·cov+b. Barème officiel 5/7/8 pts uniquement." },
  { item: "Modification de okacha.ts / hosila.ts à la main", why: "Fichiers GÉNÉRÉS (scripts/build_hosila.ts). Toute tâche passe par le script." },
  { item: "Fichiers interdits AGENTS.md (public/lessons/*.html, SVG, src/App.tsx, lessonIndex.ts, activeLessons.ts, HtmlLessonViewer.tsx, ScienceAnimations.tsx, FigureZoomLayer.tsx, figureZoomRuntime.ts, scripts/tools/, tmp_*, eleve_*.txt, RECAPITULATIF.txt, GUIDE_FUSION_*, package.json)", why: "Travail concurrent non signé. Interdits à la modification, référencés en lecture seule." },
];

/* ───────────────── TÂCHES ───────────────── */
export interface Task {
  id: string;
  track: Track;
  order: number;
  title: string;
  covers: string[]; // FR-xx
  prios: Prio[];
  filesAllowed: string[];
  filesForbidden: string[];
  deps: string[];
  parallel: boolean;
  steps: string[];
  verify: string[];
  reminder?: string;
}

export const TASKS: Task[] = [
  {
    id: "T-00",
    track: "methodo-dictionnaires",
    order: 0,
    title: "PRÉREQUIS — exécuter les audits de livres A/B/C/D et produire INDEX.md",
    covers: ["PR-1", "PR-2", "PR-3"],
    prios: ["P1"],
    filesAllowed: ["docs/audits_livres/ (création)", "INDEX.md (création)"],
    filesForbidden: ["data/bookContent.json (lecture seule)", "public/lessons/*.html", "src/data/lessonIndex.ts"],
    deps: [],
    parallel: false,
    steps: [
      "Vérifier l'existence réelle de docs/audits_livres/ : s'il est absent, l'écrire avant toute tâche de contenu — sinon les preuves page officielle restent indémontrables.",
      "Pour chaque majal (A domaine I, B domaine II, C domaine III) : relever les écarts conformité avec data/bookContent.json, unité × page.",
      "Pour D_METHODO : relever chaque divergence entre ce que l'app entraîne à produire et ce que le barème BAC récompense (verbes, structure attendue, mots payés).",
      "Produire CONSOLIDE_*.md consolidant les écarts avec leur citation page officielle.",
      "Produire INDEX.md : hiérarchie de vérité (bookContent.json → الكتاب المصحح → bibliothèque) + liste des exclusions.",
      "Relever les poids BAC depuis data/bac_sessions_2019_2026.json et les consigner (nécessaire à FR-C02).",
    ],
    verify: [
      "ls docs/audits_livres/ → 4 fichiers + 1 consolidé",
      "test -f INDEX.md",
      "grep -c 'page' docs/audits_livres/CONSOLIDE_*.md → > 0",
      "npm run lint",
    ],
    reminder: "Aucune tâche de contenu ne peut être CLOSE sans la preuve page officielle issue de ce prérequis.",
  },
  /* ───── PISTE 1 : moteur & correcteur ───── */
  {
    id: "T-01",
    track: "moteur-correcteur",
    order: 1,
    title: "B2 — Verrouiller l'annulation des points-clés niés",
    covers: ["FR-N01"],
    prios: ["P0"],
    filesAllowed: ["src/smartTutorEngine.ts", "src/utils/arabicNormalize.ts (si besoin)", "scripts/verify_b2_negation.ts", "src/**/__tests__/gradeKeyPoints*.test.ts (création)"],
    filesForbidden: ["src/App.tsx", "package.json", "src/data/lessonIndex.ts", "baremeCorrecteur.ts (tags + scoreur INCHANGÉS)"],
    deps: [],
    parallel: true,
    steps: [
      "Rappel P2/R6 en tête de commit : INTERDIT de fitter la note sur les notes prof. Barème officiel 5/7/8 pts uniquement.",
      "Vérifier le comportement actuel de gradeKeyPoints : clauseIsDenial, adjacentNegation, tokenAffirmed, inversion de polarité.",
      "Écrire d'abord le TEST qui échoue : réponse niant explicitement les 3 points-clés de boss1_q1 → attendu 0/10.",
      "Corriger le calcul de couverture : un point-clé n'est couvert que si le token apparaît dans une clause non réfutée ET sans inversion de polarité par rapport à l'attendu.",
      "Gérer le cas de l'attendu négatif (« لا تنتقل ») : une réponse « لا تنتقل » reste créditée (pas de double inversion).",
      "Conserver le garde-fou « لا أعرف » → 0 et le détecteur de bourrage lexical (score annulé).",
      "Faire passer scripts/verify_b2_negation.ts en vert sur les 3 cas (tout nié / tout repris / moitié-moitié).",
    ],
    verify: [
      "npx tsx scripts/verify_b2_negation.ts → 0/10 · 10/10 · 5/10 attendus",
      "npx vitest run src/**/__tests__/gradeKeyPoints*.test.ts",
      "npm run lint",
      "npm run build",
    ],
    reminder: "P2/R6 — aucun fit sur notes prof, aucun modèle a·cov+b.",
  },
  {
    id: "T-02",
    track: "moteur-correcteur",
    order: 2,
    title: "B3 — Verrouiller le matching par mot entier (sous-chaîne « لب »)",
    covers: ["FR-N02"],
    prios: ["P0"],
    filesAllowed: ["src/smartTutorEngine.ts", "src/data/smartBotData.ts (mot-clé لب, commentaire seulement)", "src/**/__tests__/includesAsWord*.test.ts (création)"],
    filesForbidden: ["src/App.tsx", "package.json", "public/lessons/*.html"],
    deps: [],
    parallel: true,
    steps: [
      "Écrire le test rouge : liste de mots contenant « لب » comme sous-chaîne (الباك، البكالوريا، اللباب) → aucun ne doit retourner la carte بنية الكرة الأرضية.",
      "Vérifier que includesAsWord est bien appelé sur TOUS les chemins de matching (scoreChunk, findBestKnowledgeCardScored, recherche globale) et pas seulement sur un.",
      "Exclure la ponctuation arabe (؟ ، ؛) des caractères de mot afin que « الغوص؟ » vaille « الغوص ».",
      "Traiter les needles multi-mots : fallback includes simple (ils ne peuvent pas être engloutis dans un mot).",
      "Vérifier qu'un mot-clé mono-mot tapé avec une faute garde son demi-poids flou (R1) sans réintroduire le matching par sous-chaîne.",
    ],
    verify: [
      "npx vitest run src/**/__tests__/includesAsWord*.test.ts",
      "npx tsx -e \"…findBestKnowledgeCard('الباك')…\" → pas de carte بنية الكرة الأرضية (via fichier outil, pas d'arabe inline en console)",
      "npm run lint && npm run build (commandes séparées sous PowerShell, jamais &&)",
    ],
    reminder: "Windows : pas d'arabe inline en console (mojibake). Écrire l'arabe via outil de fichier.",
  },
  {
    id: "T-03",
    track: "moteur-correcteur",
    order: 3,
    title: "B7 — Verrouiller l'intention « اختبرني » = QCM, jamais un cours",
    covers: ["FR-N03"],
    prios: ["P0"],
    filesAllowed: ["src/smartTutorEngine.ts", "src/**/__tests__/testIntent*.test.ts (création)"],
    filesForbidden: ["src/App.tsx", "src/components/AITutorView.tsx (si le fix est côté moteur)", "package.json"],
    deps: [],
    parallel: true,
    steps: [
      "Vérifier la position de l'intercepteur « اختبرني » : il doit s'exécuter AVANT la recherche sémantique de cartes mais APRÈS la gestion des sessions quiz/boss actives.",
      "Écrire le test rouge sur 8 formulations (« اختبرني في الغوص », « اختبرني في الاستنساخ », « اختبرني », variantes avec faute).",
      "Résolution du sujet : carte la mieux scorée dans le domaine actif, sinon première carte du domaine actif.",
      "Si le sujet n'a aucun QCM (topicId sans question) : message explicite + suggestion d'un sujet testable du même domaine — jamais une fiche de cours.",
      "Conserver le mélange déterministe shuffledView (sans correctIndex dans le payload B5).",
    ],
    verify: [
      "npx vitest run src/**/__tests__/testIntent*.test.ts",
      "npm run lint",
      "npm run build",
    ],
  },
  {
    id: "T-04",
    track: "moteur-correcteur",
    order: 4,
    title: "B5b — Aligner le bouton accueil sur le moteur (préserver mistakes + completedBac)",
    covers: ["FR-N04"],
    prios: ["P0"],
    filesAllowed: ["src/components/AITutorView.tsx", "src/utils/sessionManager.ts", "src/**/__tests__/homeNav*.test.ts (création)"],
    filesForbidden: ["src/App.tsx", "package.json", "public/miftah.html"],
    deps: [],
    parallel: true,
    steps: [
      "Relever les DEUX chemins de retour accueil : saisie texte (moteur, préserve déjà) et bouton de parcours (resetSession, efface tout).",
      "Remplacer resetSession() par une réinitialisation de navigation seule : mode + quiz + boss, en préservant mistakes, completedBac, lastMissionDate.",
      "Extraire cette logique en un unique helper partagé par les deux chemins pour empêcher toute future divergence.",
      "Écrire le test : défi complété → bouton accueil → défi rejoué → XP total inchangé.",
      "Nettoyer explicitement après chaque rendu dans les tests (cleanup(), pas de jest-dom).",
    ],
    verify: [
      "npx vitest run src/**/__tests__/homeNav*.test.ts",
      "npx jest (second runner)",
      "npm run lint && npm run build (séparés)",
    ],
    reminder: "@testing-library/jest-dom n'est pas câblé : utiliser .toBeTruthy()/.toBeNull()/.toHaveLength() + cleanup() explicite.",
  },
  {
    id: "T-05",
    track: "moteur-correcteur",
    order: 5,
    title: "B6 — Journaliser les tentatives à 0 (élève en difficulté invisible)",
    covers: ["FR-N05"],
    prios: ["P1"],
    filesAllowed: ["src/components/AITutorView.tsx", "src/App.tsx (lecture : handleTutorXPGained déjà compatible)", "src/**/__tests__/xpZero*.test.ts (création)"],
    filesForbidden: ["package.json", "src/data/lessonIndex.ts"],
    deps: ["T-04"],
    parallel: true,
    steps: [
      "Modifier la condition d'émission : la tentative est remontée dès que total > 0, quelle que soit la note (score = 0 inclus).",
      "Vérifier que le récepteur existant accepte bien score 0 (App.tsx:394 l'accepte déjà : total = 23 > 0).",
      "Ajouter au payload la distinction « échec réel » vs « abandon » afin que le tableau de bord enseignant puisse les séparer.",
      "Écrire le test : quiz 0/23 → événement émis avec total 23 et score 0.",
    ],
    verify: ["npx vitest run src/**/__tests__/xpZero*.test.ts", "npm run lint", "npm run build"],
  },
  /* ───── PISTE 2 : contenu domaine I ───── */
  {
    id: "T-10",
    track: "contenu-domaine-I",
    order: 10,
    title: "S4 — ميثيونين (méthionine) à la place de « منيل » — domaine I",
    covers: ["FR-S01"],
    prios: ["P0"],
    filesAllowed: ["src/data/smartBotData.ts", "src/bookTutorQA.ts", "src/knowledgeCards.ts", "scripts/fix_domain1_terminology.ts (création)", "data/bookContent.json (lecture : source de vérité)"],
    filesForbidden: ["public/lessons/*.html", "src/data/lessonIndex.ts", "src/data/activeLessons.ts", "data/bookContent.json (modification interdite)", "GUIDE_FUSION_*"],
    deps: ["T-00"],
    parallel: true,
    steps: [
      "Localiser toutes les occurrences par script (grep en fichier, jamais d'arabe inline en console) : scripts/fix_domain1_terminology.ts --scan.",
      "Recouper dans data/bookContent.json le terme officiel et relever l'unité × page : c'est la preuve exigée dans le message de commit.",
      "Corriger par INJECTION MÉCANIQUE depuis bookContent.json — la transcription manuelle est proscrite (risque d'introduire une nouvelle coquille).",
      "Appliquer le filtre de confusion graphique arabe sur l'injection : ر/ز · ح/ة · ف/ب (vérifier que ميثيونين n'est pas altéré).",
      "Ajouter un test de contenu : aucune occurrence de « منيل » sur le parcours élève, ≥ 1 occurrence de « ميثيونين » sur les surfaces concernées.",
      "Documenter l'écart dans le commit : fichier · ligne · avant → après · unité × page officielle.",
    ],
    verify: [
      "npx tsx scripts/fix_domain1_terminology.ts --scan → 0 occurrence résiduelle",
      "npx vitest run tests/domain1-content.test.ts",
      "npm run lint && npm run build (séparés)",
    ],
    reminder: "فصحى uniquement — zéro contenu inventé, zéro OCR verbatim, filtre ر/ز · ح/ة · ف/ب. Preuve page officielle à compléter par T-00 si absente.",
  },
  /* ───── PISTE 3 : contenu domaines II & III ───── */
  {
    id: "T-20",
    track: "contenu-domaines-II-III",
    order: 20,
    title: "S1 — Ondes S ne traversent PAS le noyau (preuve de liquidité)",
    covers: ["FR-S02"],
    prios: ["P0"],
    filesAllowed: ["src/data/smartBotData.ts (boss scenarios domaine III)", "src/bookTutorQA.ts", "scripts/fix_domain3_waves.ts (création)", "data/bookContent.json (lecture)"],
    filesForbidden: ["public/lessons/*.html", "tous les SVG", "src/data/lessonIndex.ts", "src/data/activeLessons.ts", "src/components/HtmlLessonViewer.tsx", "data/bookContent.json (modification)"],
    deps: ["T-00"],
    parallel: true,
    steps: [
      "Scanner les surfaces du domaine III (boss scenarios, Q&A livre, fiches) à la recherche de toute formulation présentant les ondes S comme traversant le noyau.",
      "Recouper bookContent.json : relever l'unité × page du raisonnement officiel « zone d'ombre des S → noyau externe liquide ».",
      "Injection mécanique : remplacer la formulation fausse par celle du manuel (mot pour mot depuis bookContent.json).",
      "Vérifier que la VALEUR PÉDAGOGIQUE est inversée dans le bon sens : l'absence de traversée EST l'argument, pas une lacune des données.",
      "Test de contenu : aucune surface n'affirme la traversée ; l'argument de liquidité est présent au moins une fois avec le vocabulaire du manuel.",
    ],
    verify: [
      "npx tsx scripts/fix_domain3_waves.ts --scan → 0 occurrence",
      "npx vitest run tests/domain3-content.test.ts",
      "npm run lint && npm run build (séparés)",
    ],
    reminder: "Preuve page officielle : dépend de T-00 (audits_livres introuvable cette session). Ne pas fermer la tâche sans elle.",
  },
  {
    id: "T-21",
    track: "contenu-domaines-II-III",
    order: 21,
    title: "S2 — Zone d'ombre des ondes P admise dans la situation BAC",
    covers: ["FR-S03"],
    prios: ["P0"],
    filesAllowed: ["src/data/smartBotData.ts (scénario BAC concerné + sa correction)", "data/bookContent.json (lecture)"],
    filesForbidden: ["public/lessons/*.html", "src/data/lessonIndex.ts", "src/App.tsx"],
    deps: ["T-20"],
    parallel: false,
    steps: [
      "Identifier le scénario de défi BAC concerné par la négation du phénomène.",
      "Comparer données de la situation et correction : elles doivent être mutuellement cohérentes.",
      "Injection mécanique depuis bookContent.json de la formulation admettant la zone d'ombre des ondes P.",
      "Vérifier que la correction ne contredit plus les données (aucune assertion non soutenable par le document).",
      "Test : la correction ne contient aucune négation d'un phénomène sismique réel présent dans le manuel.",
    ],
    verify: ["npx vitest run tests/domain3-content.test.ts -t shadow", "npm run lint", "npm run build"],
    reminder: "Dépend de T-20 (même fichier, même domaine, ordre imposé pour éviter les conflits d'édition).",
  },
  {
    id: "T-22",
    track: "contenu-domaines-II-III",
    order: 22,
    title: "S3 — Formulation exacte de la relation vitesse/milieu",
    covers: ["FR-S05"],
    prios: ["P1"],
    filesAllowed: ["src/data/smartBotData.ts", "src/bookTutorQA.ts", "data/bookContent.json (lecture)"],
    filesForbidden: ["public/lessons/*.html", "tous les SVG", "src/data/activeLessons.ts"],
    deps: ["T-20"],
    parallel: false,
    steps: [
      "Localiser la généralisation « la vitesse augmente avec la densité » isolée de son contexte.",
      "Reprendre la formulation du manuel (injection mécanique) avec son contexte : nature du milieu, état physique, discontinuité.",
      "Test : la généralisation isolée est absente ; la formulation contextuelle du manuel est présente.",
    ],
    verify: ["npx vitest run tests/domain3-content.test.ts -t vitesse", "npm run lint"],
    reminder: "Même fichier que T-20/T-21 : tâche NON [P], après T-21.",
  },
  {
    id: "T-23",
    track: "contenu-domaines-II-III",
    order: 23,
    title: "S-M1 — Verrou de régression Michaelis-Menten (hyperbole, pas « en cloche »)",
    covers: ["FR-S04"],
    prios: ["P0"],
    filesAllowed: ["src/data/bacExam.ts", "src/**/__tests__/michaelisRegression.test.ts (création)", "data/bookContent.json (lecture)"],
    filesForbidden: ["baremeCorrecteur.ts (tags + scoreur INCHANGÉS)", "package.json", "public/lessons/*.html"],
    deps: [],
    parallel: true,
    steps: [
      "Rappel P2/R6 : on ne touche ni aux 8 tags du correcteur ni au scoreur — uniquement au contenu du corrigé dans bacExam.ts.",
      "Vérifier l'état à HEAD : le correctif §5 est-il bien appliqué (bacExam.ts:53 ne décrit plus la courbe comme « جرسي الشكل ») ?",
      "Écrire le test de régression PERMANENT : aucune occurrence de « جرسي الشكل » associée à Michaelis-Menten dans bacExam.ts.",
      "Vérifier la cohérence croisée : le corrigé (bacExam.ts) et le dictionnaire du correcteur (baremeCorrecteur.ts:133) emploient la même description « التشبع الزائدي ».",
      "Conserver vert le test existant correcteurIntegration.test.ts:117 « faux ami Michaelis en cloche détecté » — c'est la contre-preuve.",
      "Consigner la preuve unité × page officielle (issue de T-00) dans le message de commit.",
    ],
    verify: [
      "npx vitest run src/**/__tests__/michaelisRegression.test.ts",
      "npx vitest run src/correcteurIntegration.test.ts",
      "npm run lint && npm run build (séparés)",
    ],
    reminder: "Tags + scoreur INCHANGÉS (spec Boussole v2 + P2/R6). Ce n'est pas un ajustement de barème, c'est un contenu de corrigé.",
  },
  {
    id: "T-24",
    track: "contenu-domaines-II-III",
    order: 24,
    title: "S6/S7/S8 — Terminologie arabe فصحى du domaine III (oxymore, fonte, الوشاح)",
    covers: ["FR-T01", "FR-T02", "FR-T03"],
    prios: ["P2"],
    filesAllowed: ["src/data/smartBotData.ts", "src/bookTutorQA.ts", "scripts/fix_domain3_terms.ts (création)", "data/bookContent.json (lecture)"],
    filesForbidden: ["public/lessons/*.html", "tous les SVG", "src/data/lessonIndex.ts", "src/data/activeLessons.ts"],
    deps: ["T-21"],
    parallel: false,
    steps: [
      "Un seul script pour les 3 corrections terminologiques (même domaine, même fichier, même passe de relecture arabe).",
      "S6 : supprimer l'oxymore « تقارب متباعد », substituer le terme du manuel.",
      "S7 : rétablir le sens physique — la fusion partielle REMONTE, elle ne s'enfonce pas.",
      "S8 : « الوشاح » (manteau) partout, « الوشام » absent.",
      "Appliquer le filtre de confusion graphique sur TOUTE injection : ر/ز · ح/ة · ف/ب.",
      "Relecture humaine obligatoire du contenu arabe (tâche P0-scientifique adjacente) avant merge — consigner le nom du relecteur et la date.",
    ],
    verify: [
      "npx tsx scripts/fix_domain3_terms.ts --scan → 0 occurrence de « الوشام » · « تقارب متباعد » · « فيغوص الصهر »",
      "npx vitest run tests/domain3-content.test.ts -t terminology",
      "npm run lint && npm run build (séparés)",
    ],
    reminder: "فصحى uniquement. Zéro contenu inventé. Zéro OCR verbatim. Filtre ر/ز · ح/ة · ف/ب.",
  },
  /* ───── PISTE 4 : méthodo & dictionnaires ───── */
  {
    id: "T-30",
    track: "methodo-dictionnaires",
    order: 30,
    title: "S-C4 — Récupérer les 120 questions Flutter ignorées (ou les exclure avec motif)",
    covers: ["FR-C01"],
    prios: ["P1"],
    filesAllowed: ["src/unitCatalog.ts (commentaire d'import)", "scripts/recover_flutter_questions.ts (création)", "src/data/qcmBilan.ts (si intégration)"],
    filesForbidden: ["package.json", "src/data/lessonIndex.ts", "scripts/tools/", "tmp_*.txt", "tmp_*.mjs"],
    deps: [],
    parallel: true,
    steps: [
      "Inventorier les 120 questions ignorées (unitCatalog.ts:9-10) et les classer en 3 catégories avec motif : intégrable / hors programme 2011+ / placeholder irrécupérable.",
      "Écrire le script de conversion : question à trous → format supporté, sans altérer l'énoncé (aucune reformulation).",
      "Tout élément classé hors programme est exclu du parcours élève et archivé, jamais supprimé du dépôt.",
      "Ajouter une assertion de build : aucune question hors programme dans le parcours.",
      "Consigner le comptage avant/après dans le message de commit (mesure exigée par AGENTS.md).",
    ],
    verify: [
      "npx tsx scripts/recover_flutter_questions.ts --report → tableau 3 catégories avec motifs",
      "npx vitest run tests/curriculumIntegrity.test.ts",
      "npm run lint && npm run build (séparés)",
    ],
    reminder: "Zéro contenu inventé : l'énoncé d'origine est repris tel quel ou la question est exclue avec motif.",
  },
  {
    id: "T-31",
    track: "methodo-dictionnaires",
    order: 31,
    title: "S-Q1 — Équilibrer le pool de bilan au prorata du poids BAC",
    covers: ["FR-C02"],
    prios: ["P1"],
    filesAllowed: ["src/data/qcmBilan.ts", "data/bac_sessions_2019_2026.json (lecture : poids)"],
    filesForbidden: ["package.json", "src/data/lessonIndex.ts", "src/App.tsx"],
    deps: ["T-00"],
    parallel: true,
    steps: [
      "Relire les poids BAC depuis data/bac_sessions_2019_2026.json et les consigner (prérequis PR-3).",
      "Mesurer la répartition actuelle du pool : D1=45 · D2=17 · D3=29 (total 91).",
      "Rééquilibrer le pool — PAS le tirage : le tirage 5/domaine (qcmBilan.ts:145) est correct par construction et reste inchangé.",
      "Ne jamais dépasser le barème officiel (5/7/8 pts) comme règle de proportionnalité : rappel P2/R6.",
      "Test : écart de représentation entre domaines ≤ 20 %, tirage inchangé.",
    ],
    verify: [
      "npx vitest run tests/qcmBilanBalance.test.ts",
      "npx vitest run src/data/qcmBilan.test.ts (tirage inchangé)",
      "npm run lint && npm run build (séparés)",
    ],
    reminder: "P2/R6 — le barème officiel 5/7/8 pts est la seule référence de pondération autorisée.",
  },
  {
    id: "T-32",
    track: "methodo-dictionnaires",
    order: 32,
    title: "S-C2 — Baliser les chapitres non exigibles et masquer les chapitres incomplets",
    covers: ["FR-C03"],
    prios: ["P1"],
    filesAllowed: ["src/data/curriculumOfficial.ts", "src/data/unitLessonSequences.ts", "composant de liste de leçons (hors fichiers interdits)"],
    filesForbidden: ["src/App.tsx", "public/lessons/*.html", "src/data/lessonIndex.ts", "src/data/activeLessons.ts", "src/components/HtmlLessonViewer.tsx", "tous les SVG"],
    deps: [],
    parallel: true,
    steps: [
      "Vérifier le balisage existant NON_EXIGIBLES + CULTURE_GENERALE (curriculumOfficial.ts:35-49).",
      "Ajouter un badge visible et distinct sur tout chapitre non exigible, côté élève.",
      "Masquer ou marquer explicitement incomplet tout chapitre signalé « à reconstruire » (unitLessonSequences.ts:43 : phase26 placeholder, collision/ophiolites).",
      "Consigner la liste exacte des chapitres masqués dans le message de commit.",
      "Test de navigation : aucun chapitre masqué n'est atteignable depuis la liste élève.",
    ],
    verify: ["npx vitest run tests/curriculumIntegrity.test.ts", "npm run lint", "npm run build"],
  },
];
