/**
 * MÉTA-AUDIT — les 6 rapports stratégiques passés au crible
 * Objectif de l'évaluation : « top téléchargements Play Store » + « aimé par les élèves de BAC SVT »
 * Chaque affirmation est confrontée à la réalité du dépôt kunz-el-ouloum.
 */

export type ReportId = "jeremy" | "modules" | "ignobles" | "duolingo" | "audit2609" | "banlieue";

export interface Report {
  id: ReportId;
  rank: number;
  title: string;
  origin: string;
  focus: string;
  /** note de l'objectif réel du rapport, telle qu'annoncée par ses propres critères */
  selfScore: string;
  role: string;
  /** C1 utilité stratégique · C2 fiabilité vérifiée dans le code · C3 applicabilité Algérie
   *  C4 impact téléchargements · C5 impact amour élèves · C6 coût de mise en œuvre (10 = gratuit) */
  c: [number, number, number, number, number, number];
  verdict: string;
  keep: { label: string; proof: string }[];
  reject: { label: string; proof: string }[];
  unique: string;
}

export const CRIT = [
  { key: "C1", label: "Utilité stratégique", w: 1.0 },
  { key: "C2", label: "Fiabilité vérifiée dans ton code", w: 1.2 },
  { key: "C3", label: "Applicabilité marché algérien", w: 1.2 },
  { key: "C4", label: "Impact sur les téléchargements", w: 1.4 },
  { key: "C5", label: "Impact sur l'amour des élèves", w: 1.2 },
  { key: "C6", label: "Faible coût de mise en œuvre", w: 0.8 },
];

export const W_SUM = CRIT.reduce((a, c) => a + c.w, 0);

export const weighted = (r: Report) =>
  Math.round((r.c.reduce((a, v, i) => a + v * CRIT[i].w, 0) / W_SUM) * 10) / 10;

export const REPORTS: Report[] = [
  {
    id: "jeremy",
    rank: 1,
    title: "Jeremy Pitault / Shinobi Japanese",
    origin: "Analyse mot à mot de 15 vidéos · 7 240 abonnés · 400 K$/an · solo dev",
    focus: "Focus produit, onboarding, boucle de récompense, contenu = acquisition",
    selfScore: "9/10",
    role: "LE SYSTÈME D'EXPLOITATION",
    c: [9, 9, 7, 9, 8, 8],
    verdict:
      "C'est la seule approche à adopter telle quelle : même profil (solo), même catégorie (éducatif), même budget (zéro), chiffres publics. Les autres rapports te disent quoi penser, celui-ci te dit quoi supprimer.",
    keep: [
      { label: "1 fonctionnalité, rien de plus", proof: "Ton app a 19 rubriques et 12 onglets : c'est le diagnostic exact de son « erreur n°2 — ton app n'est pas un MVP »." },
      { label: "Règle 23 — l'information est la meilleure récompense variable", proof: "answerStructureCheck.ts détecte déjà تحليل vs تفسير et le mot-clé causal manquant : ta récompense est codée, elle n'est pas exposée." },
      { label: "Onboarding ≥ 10 étapes (RADAR)", proof: "Actuellement currentTab 'splash' → home : 1 étape. Aucune récolte (filière, date BAC, unités faibles)." },
      { label: "Action minuscule (règles 20-21)", proof: "10 secondes = 1 mot-clé à retrouver, pas 40 minutes de correction à lire." },
      { label: "Greffé à un rituel existant (règle 17)", proof: "En Algérie, le rituel est le trajet lycée-maison : « 5 mots-clés dans le bus »." },
      { label: "Externaliser la mémoire (règle 27)", proof: "favorites.ts, examLog.ts, methodologyLog.ts existent : c'est ton coût de sortie, donc ta rétention." },
      { label: "Le contenu fait l'acquisition", proof: "7 240 abonnés → 400 K$ ARR sans une seule publicité payée. Ton script S1 est prêt." },
    ],
    reject: [
      { label: "Hard paywall pur", proof: "Lui a 45 000 gratuits à ménager et des marchés US/DE solvables. Toi : pas de CB généralisée, 95-99 % des élèves ne paieront jamais." },
      { label: "Essai de 3 jours", proof: "Il le dit lui-même : 7-14 jours convertissent mieux. Ton unité naturelle est le cycle scolaire (21 jours)." },
      { label: "Abonnement 50 $/an par élève", proof: "Pouvoir d'achat US. En Algérie, le produit payant est la licence établissement, pas l'abonnement élève." },
      { label: "ASO « App Store » + Small Business Program", proof: "Le marché algérien est Android à ~95 %. Ta cible est le Play Store, l'App Store est marginal — plusieurs rapports se trompent de magasin." },
    ],
    unique: "Le seul benchmark dont les contraintes sont identiques aux tiennes et dont les chiffres sont publics.",
  },
  {
    id: "modules",
    rank: 2,
    title: "Audit des modules d'apprentissage (le mien)",
    origin: "49 entrées notées /20 sur 6 critères · vérifié fichier par fichier",
    focus: "Découpe du produit : ce qui rapporte des points, ce qui est du bruit",
    selfScore: "—",
    role: "LE SPEC D'EXÉCUTION DE LA DÉCOUPE",
    c: [8, 10, 9, 7, 9, 9],
    verdict:
      "Biais déclaré : c'est mon propre rapport. Il n'est pas « l'approche » à suivre, il est le spec qui rend l'approche de Jeremy exécutable — la liste précise des 17 suppressions, 8 fusions et 12 modules restants.",
    keep: [
      { label: "49 entrées → 12 modules en 3 hub", proof: "C'est la traduction chiffrée de « 1 fonctionnalité, rien de plus » appliquée à ton code réel." },
      { label: "La killer feature est déjà identifiée", proof: "Correcteur (19/20) + Boussole (19/20) : les deux seuls modules qui agissent sur la compétence notée au barème." },
      { label: "Les 3 trous qui coûtent 6-7 pts", proof: "Exploitation chiffrée, typologie des documents, trame C3 : ce sont eux qui feront aimer l'app, pas la gamification." },
      { label: "Programme officiel 2011+", proof: "Génétique, évolution et reproduction des plantes ne sont plus au programme : tout module sur ces thèmes est hors barème." },
    ],
    reject: [
      { label: "Rien à rejeter — mais il ne se suffit pas", proof: "Un audit de modules ne dit rien de l'acquisition, du store ou du revenu. Il doit être piloté par la doctrine de Jeremy." },
    ],
    unique: "Le seul document qui dit exactement quels fichiers supprimer, fusionner et construire.",
  },
  {
    id: "ignobles",
    rank: 3,
    title: "Les Ignobles — vendre ton app SVT",
    origin: "Benchmarks Elyze / Winology / Rocapine · lancement · monétisation",
    focus: "Calendrier d'acquisition et modèle de revenu B2B2C",
    selfScore: "7/10",
    role: "LE CALENDRIER DE DISTRIBUTION",
    c: [8, 6, 9, 9, 6, 6],
    verdict:
      "Le meilleur rapport sur le QUAND et le QUI PAIE, le plus faible sur le COMMENT : 4 de ses recommandations supposent des fonctionnalités qui n'existent pas dans ton dépôt.",
    keep: [
      { label: "Lancer à J-100 du BAC", proof: "L'anxiété est ta fenêtre de vente — mais DashboardView.tsx a un compteur mort : BAC_EXAM_DATE = '' dans dashboardActions.ts." },
      { label: "QCM mots-clés en stories Instagram/TikTok DZ", proof: "Coût 0 DA, risque 0 : tu mesures la demande avant de coder. Winology a validé sa thèse ainsi." },
      { label: "Payeur ≠ utilisateur", proof: "TeacherDashboardView.tsx existe déjà : c'est ton produit payant, pas l'app élève." },
      { label: "« Hold, not hook »", proof: "Thèse financée en 2026 : Rocapine a levé 13 M$ sur exactement ton positionnement anti-dark-pattern." },
      { label: "Métrique honnête (§5.1)", proof: "unit.progress existe par unité : agréger les 11 unités donne le « % du programme maîtrisé » sans rien construire." },
      { label: "La phrase de vente arabe", proof: "Constante sur les 5 rapports, vérifiée dans ton code : hors-ligne, sans tracking, sans dark pattern." },
    ],
    reject: [
      { label: "« Vise le top Éducation de l'App Store DZ »", proof: "package.json version 0.0.0, zéro tag git, zéro build signé : tu n'es publié nulle part. La stratégie de lancement est prématurée." },
      { label: "Paywall au moment de valeur", proof: "grep paywall|payment|CIB|premium → aucun système de paiement, aucune dépendance. C'est un projet de 6 semaines, pas un réglage." },
      { label: "Mécanique de swipe « familière » (Elyze)", proof: "RevisionView.tsx retourne les cartes par onClick : aucune gesture, aucun drag, aucun touch codé." },
      { label: "Team streak / temps réel", proof: "Aucune infrastructure multi-joueurs, tuteur 100 % local : ça contredit ton offline-first, qui est ton avantage." },
    ],
    unique: "Le seul qui fixe une date (J-100) et un payeur (l'établissement) — les deux inconnues de tous les autres.",
  },
  {
    id: "duolingo",
    rank: 4,
    title: "12 vidéos Duolingo → Kunz El Ouloum",
    origin: "12 fiches → moteur consolidé → contre-thèse → mapping → livrables",
    focus: "Gamification sous filtre éthique ADOPTE / ADAPTE / REJETTE",
    selfScore: "8/10",
    role: "LE GARDE-FOU ÉTHIQUE",
    c: [7, 7, 6, 6, 7, 7],
    verdict:
      "Sa méthode (le filtre ADOPTE/ADAPTE/REJETTE) est excellente et doit rester ta règle permanente. Ses mécanismes, eux, viennent d'un marché solvable et d'une app de 500 M$ : trois recommandations sont contredites par ton propre code.",
    keep: [
      { label: "Rejeter cœurs, rareté, culpabilité", proof: "Ton app n'en a aucun : c'est ton avantage marketing vérifiable, pas une lacune." },
      { label: "La charte éthique (§5.2)", proof: "Elle prévient les dérives quand l'équipe grandira et c'est ton argument devant parents, profs et jury." },
      { label: "Le modèle B2B2C (§5.3)", proof: "Licences établissements + codes prépayés physiques en librairie + CIB/Edahabia : la seule voie de revenu crédible en Algérie." },
      { label: "La formulation de différenciation", proof: "« Les autres apps te montrent combien de jours tu t'es connecté. Nous te montrons combien de points tu as gagnés au BAC. »" },
    ],
    reject: [
      { label: "« La série ne doit compter que si la session produit un gain réel »", proof: "App.tsx handleRateCard module déjà le XP par la qualité de réponse (easy 15 / good 10 / hard 5 / again 2) : la recommandation est déjà satisfaite." },
      { label: "Team streak pilotée par le prof", proof: "server.ts sépare élèves et enseignants, aucun socket, aucun état partagé classe." },
      { label: "Freemium élève à 7 $/mois", proof: "Pas de moyen de paiement en ligne chez les lycéens algériens." },
    ],
    unique: "Le filtre éthique ADOPTE/ADAPTE/REJETTE : la seule méthode des 6 rapports à réutiliser sur toutes les décisions futures.",
  },
  {
    id: "audit2609",
    rank: 5,
    title: "Audit général 26/09/2026",
    origin: "Diagnostic pédagogique + plan de restructuration en 5 pôles",
    focus: "Restructuration par intention d'apprentissage",
    selfScore: "7/10",
    role: "LE PRÉDÉCESSEUR UTILE",
    c: [7, 6, 8, 4, 7, 8],
    verdict:
      "Ses 5 pôles par intention sont justes et convergent avec ma découpe en 3 hub. Mais il ne parle ni store, ni acquisition, ni revenu : il ne peut pas, à lui seul, te faire télécharger.",
    keep: [
      { label: "5 pôles par intention", proof: "Équivalent fonctionnel de mes 3 hub (Apprendre / S'entraîner / Corriger) : les deux analyses aboutissent au même regroupement." },
      { label: "Diagnostic pédagogique", proof: "Confirme que la valeur est dans la méthodologie d'écriture, pas dans le volume de cours." },
    ],
    reject: [
      { label: "Un point factuel faux sur le hors-ligne", proof: "Toute stratégie de lancement qui repose sur un fait faux s'effondre au premier avis Play Store contradictoire." },
    ],
    unique: "La première cartographie par intention — reprise et chiffrée par l'audit de modules.",
  },
  {
    id: "banlieue",
    rank: 6,
    title: "Startup Banlieue — mindset, pitch & parcours",
    origin: "Chaîne à 98 abonnés · récit motivationnel et institutionnel",
    focus: "Structure de pitch et liste d'accélérateurs",
    selfScore: "6/10",
    role: "À CONSULTER 30 MINUTES, PAS PLUS",
    c: [5, 3, 6, 2, 1, 5],
    verdict:
      "Le plus faible des six, et il le reconnaît lui-même. Zéro métrique, zéro chiffre, zéro benchmark vérifiable. Il t'apporte exactement deux choses que tu n'as pas : un template de pitch et une liste d'accélérateurs.",
    keep: [
      { label: "Structure de pitch en 7 étapes", proof: "ls docs/ | grep business|pricing|modele → rien. Tu n'as ni pitch, ni business model, ni page tarif." },
      { label: "Algeria Venture + incubateurs universitaires", proof: "Le plus accessible depuis l'Algérie, coût zéro, crédibilité locale pour signer des établissements." },
    ],
    reject: [
      { label: "Ordolib comme preuve de ton modèle prof", proof: "C'est une app de livraison pharmaceutique : aucun chiffre de revenu, d'usagers ni de rétention, juste un récit émotionnel." },
      { label: "« Le récit d'origine vend »", proof: "Il est déjà écrit dans PROTOCOLE_PREUVE.md : le rapport ne t'apprend rien." },
      { label: "French Tech Tremplin / Prix Moovjee", proof: "Critères de résidence à vérifier avant d'y investir une heure." },
    ],
    unique: "Le template de pitch en 7 étapes — ton seul document réellement manquant côté business.",
  },
];

/* ─────────────── Les contradictions entre rapports, tranchées ─────────────── */
export interface Contradiction {
  question: string;
  positions: { report: string; says: string }[];
  ruling: string;
  proof: string;
}

export const CONTRADICTIONS: Contradiction[] = [
  {
    question: "Faut-il réparer le streak cassé ?",
    positions: [
      { report: "Duolingo", says: "Le streak doit mesurer un gain réel, sinon c'est une métrique de vanité." },
      { report: "Les Ignobles", says: "Répare-le en priorité : c'est un bug bloquant avant lancement." },
      { report: "Audit de modules", says: "Supprime badges, série et célébrations : Tier 4, bruit, 0 point au barème." },
    ],
    ruling:
      "Ne répare PAS le compteur de jours — remplace-le. La règle 23 de Jeremy (l'information est la récompense) et la §5.1 du rapport Duolingo (métrique honnête) convergent : affiche « mots-clés du correcteur maîtrisés » et « % du programme », pas « jours consécutifs ».",
    proof:
      "Ton XP est déjà modulé par la qualité de réponse (handleRateCard) : la donnée utile existe. Le compteur de jours, lui, n'est jamais incrémenté — et une métrique cassée est pire qu'une métrique absente : c'est le premier mensonge que l'élève découvre.",
  },
  {
    question: "App Store ou Play Store ?",
    positions: [
      { report: "Jeremy", says: "ASO App Store + Small Business Program (15 % de commission)." },
      { report: "Les Ignobles", says: "Viser le top Éducation de l'App Store DZ." },
    ],
    ruling:
      "Play Store, exclusivement, au moins pour les 12 prochains mois. Le marché mobile algérien est Android à ~95 % : publier sur iOS d'abord serait optimiser un canal qui ne contient pas tes élèves.",
    proof:
      "Conséquence pratique : bundle AAB signé, targetSdk conforme à la politique Google en vigueur, formulaire « Sécurité des données » (ton zéro-tracking devient un argument visible dans la fiche), classification IARC, et fiche rédigée en arabe d'abord, français ensuite.",
  },
  {
    question: "Hard paywall ou freemium ?",
    positions: [
      { report: "Jeremy", says: "Hard paywall : revenu par install × 2,4 (0,78 $ → 1,84 $)." },
      { report: "Duolingo", says: "Freemium 95 % gratuit / 5 % payants à 7 $/mois." },
      { report: "Les Ignobles", says: "Licences B2B2C aux établissements + codes prépayés physiques." },
    ],
    ruling:
      "Aucun paywall élève. Freemium complet pour l'élève + licence établissement, vendue par code prépayé physique (librairies, profs) et réglée en CIB/Edahabia. Le paywall au pic de valeur s'applique à l'établissement, pas à l'adolescent.",
    proof:
      "95 % des étudiants ne paient jamais (Perkox) — en Algérie c'est plus proche de 99 %, faute de moyen de paiement. Son hard paywall a fonctionné sur des marchés US/DE solvables avec 45 000 gratuits à ne pas froisser : tu n'as ni l'un ni l'autre.",
  },
];

/* ─────────────── La réalité Play Store / Algérie — absente des 6 rapports ─────────────── */
export interface StoreItem {
  title: string;
  detail: string;
  status: "bloquant" | "atout" | "canal";
}

export const STORE: StoreItem[] = [
  {
    title: "Le produit n'est pas publiable en l'état",
    detail:
      "version 0.0.0, zéro tag git, zéro build signé, zéro identifiant de bundle, BAC_EXAM_DATE vide. Trois jours de travail — mais trois jours qui doivent passer avant toute stratégie de lancement, sinon les 5 rapports discutent du sexe des anges.",
    status: "bloquant",
  },
  {
    title: "40 copies d'élèves dans l'historique Git",
    detail:
      "Données de mineurs dans un dépôt : risque légal et réputationnel majeur. À purger de l'historique (git filter-repo / BFG) AVANT toute ouverture du dépôt ou toute publication. Un seul signalement peut coûter ta fiche Play Store.",
    status: "bloquant",
  },
  {
    title: "Formulaire « Sécurité des données » = argument de vente",
    detail:
      "Zéro analytics, zéro pixel, supabase.ts vide, service worker offline : ta déclaration Play Store sera « aucune donnée collectée ». Peu d'apps éducatives peuvent l'écrire. C'est visible dans la fiche, lisible par les parents, et c'est la thèse qui a valu 13 M$ à Rocapine.",
    status: "atout",
  },
  {
    title: "ASO en arabe d'abord",
    detail:
      "Titre ≤ 30 caractères : « كنز العلوم · كلمات المصحّح ». Mots-clés : بكالوريا, علوم الطبيعة والحياة, دروس الباك, تمارين البكالوريا, مراجعة الباك — puis SVT BAC Algérie en français. La recherche algérienne est majoritairement arabe.",
    status: "atout",
  },
  {
    title: "La distribution parallèle : APK + QR code",
    detail:
      "Une part importante des lycéens algériens n'a pas de compte Play Store configuré ni de moyen de paiement. Prévoir un APK signé téléchargeable directement, partagé dans les groupes WhatsApp/Telegram de profs et d'élèves, avec un QR code imprimable pour la salle des profs. Aucun des 6 rapports ne mentionne ce canal — c'est pourtant celui qui fera le volume.",
    status: "canal",
  },
  {
    title: "Zéro budget publicitaire = contenu + ambassadeurs",
    detail:
      "TikTok et Reels DZ (3 vidéos/semaine, un mot-clé du correcteur par vidéo), 5 à 10 profs de SVT ambassadeurs, groupes Telegram de professeurs. C'est exactement le chemin de Jeremy : 7 240 abonnés → 400 K$ sans une publicité.",
    status: "canal",
  },
  {
    title: "Les 30 premiers avis décident de la conversion",
    detail:
      "Un 4,6 avec 40 avis convertit mieux qu'un 4,8 avec 400. Demander l'avis au pic de valeur (règle 9 : juste après la première note améliorée), jamais à l'ouverture, jamais après un échec.",
    status: "atout",
  },
  {
    title: "Le hors-ligne est une exigence de marché, pas une option",
    detail:
      "Coût de la donnée mobile et connexion intermittente : l'élève révise dans le bus, en zone blanche, le soir. Ton cache offline couvre 22 leçons sur 47 — c'est le chantier technique le plus rentable pour la note Play Store.",
    status: "bloquant",
  },
];

/* ─────────────── Métriques nord ─────────────── */
export const METRICS = [
  { name: "Rétention J30", target: "≥ 30 %", why: "La seule métrique qui prédit le bouche-à-oreille. Aujourd'hui : non mesurée (aucune télémétrie, ni locale ni serveur).", now: "0 instrumentation" },
  { name: "% du programme maîtrisé", target: "visible élève", why: "La métrique honnête (§5.1) : agréger unit.progress des 11 unités. Remplace le compteur de jours.", now: "donnée existe, non agrégée" },
  { name: "Mots-clés du correcteur maîtrisés / semaine", target: "+40", why: "La métrique de valeur (règle 23) : c'est elle qui déclenche le partage et l'avis Play Store.", now: "détectés, non comptés" },
  { name: "Fiche Play Store → install", target: "≥ 35 %", why: "Mesure l'ASO arabe et les captures d'écran. Se pilote depuis la console, sans code.", now: "non publié" },
  { name: "Établissements sous licence", target: "3 la 1ʳᵉ année", why: "Le revenu réel. TeacherDashboardView est déjà codé : le produit payant existe.", now: "produit codé, 0 vente" },
  { name: "Note Play Store", target: "≥ 4,6 (100 avis)", why: "Sous 4,2, l'algorithme cesse de te recommander : le téléchargement organique meurt.", now: "non publié" },
];

/* ─────────────── Plan consolidé ─────────────── */
export interface Phase {
  code: string;
  title: string;
  days: string;
  from: string;
  tasks: string[];
  proof: string;
}

export const PLAN: Phase[] = [
  {
    code: "S0",
    title: "Rendre publiable",
    days: "3 jours",
    from: "Les Ignobles + réalité store",
    tasks: [
      "version 1.0.0, tag git, build AAB signé, identifiant de bundle",
      "renseigner BAC_EXAM_DATE (date officielle 2027)",
      "purger les copies d'élèves de l'historique Git",
      "politique de confidentialité hébergée + formulaire Sécurité des données",
    ],
    proof: "Un artefact installable sur un téléphone Android réel.",
  },
  {
    code: "S1",
    title: "Découper en MVP",
    days: "1 semaine",
    from: "Jeremy (règle MVP) + audit de modules",
    tasks: [
      "49 entrées → 12 modules en 3 hub",
      "17 suppressions, 8 fusions, aucune migration de contenu perdue",
      "la killer feature (mots-clés du correcteur) en page d'accueil",
      "tout le reste derrière un « plus » discret",
    ],
    proof: "Un élève de 10/20 trouve quoi faire en moins de 10 secondes.",
  },
  {
    code: "S2",
    title: "Onboarding RADAR + métrique honnête",
    days: "1 semaine",
    from: "Jeremy (RADAR) + Duolingo (§5.1)",
    tasks: [
      "10 étapes : filière, date BAC, unités faibles, objectif de note",
      "écran « paradis » : projection à J-60 sur ses unités faibles",
      "remplacer le compteur de jours par « % du programme maîtrisé »",
      "supprimer badges, célébrations et déclencheur de motivation",
    ],
    proof: "89,4 % des conversions se jouent au jour 0 (Adapty) : la première session décide.",
  },
  {
    code: "S3",
    title: "Boucle de récompense par l'information",
    days: "1 semaine",
    from: "Jeremy (règles 17, 20-21, 23, 27)",
    tasks: [
      "après chaque production : la note + LE mot-clé manquant, en 1 écran",
      "micro-action de 10 secondes : retrouver 1 mot-clé",
      "rituel « 5 mots-clés dans le bus » + mode hors-ligne complet",
      "exploiter favorites/examLog/methodologyLog comme coût de sortie",
    ],
    proof: "La récompense variable la plus puissante est gratuite à coder et 100 % pédagogique.",
  },
  {
    code: "S4",
    title: "Mesurer ce qui compte",
    days: "4 jours",
    from: "Jeremy (rétention) + Les Ignobles (J30)",
    tasks: [
      "télémétrie locale J1/J7/J30, sans serveur, sans identifiant",
      "carte de score partageable (WeeklyReportShareModal existe)",
      "déclencheur d'avis Play Store au pic de valeur uniquement",
    ],
    proof: "Sans rétention mesurée, il n'y a ni décision possible ni « build in public ».",
  },
  {
    code: "S5",
    title: "Valider avant de scaler",
    days: "2 semaines",
    from: "Les Ignobles (phase 1) + Jeremy (erreur n°1)",
    tasks: [
      "QCM mots-clés en stories Instagram/TikTok DZ (coût 0 DA)",
      "10 élèves test filmés : où ils bloquent, ce qu'ils ouvrent vraiment",
      "5 à 10 profs de SVT ambassadeurs via le tableau de bord",
      "dossier de candidature Algeria Venture + pitch en 7 étapes",
    ],
    proof: "Une idée jamais validée = erreur n°1 de Jeremy. Tu as construit 19 rubriques sans demander.",
  },
  {
    code: "S6",
    title: "Publier et lancer à J-100",
    days: "continu jusqu'au BAC",
    from: "Les Ignobles (phase 2) + Jeremy (contenu)",
    tasks: [
      "publication Play Store, fiche arabe d'abord, captures orientées mots-clés",
      "APK signé + QR code imprimable pour les salles des profs",
      "3 vidéos TikTok/Reels par semaine : 1 mot-clé du correcteur par vidéo",
      "communauté de bacheliers (groupe Telegram) avec mur d'analyses modéré",
    ],
    proof: "L'anxiété de J-100 est ta fenêtre : le contenu enseigne, l'app récolte.",
  },
];

export const PITCH = {
  ar: "تطبيق يراجعك بلا انترنت، بلا سكرول، بلا خدع — غير الكلمات لي يطلبها المصحّح",
  fr: "L'app qui te fait réviser hors ligne, sans scroll, sans piège — juste les mots-clés que le correcteur exige.",
  diff: "Les autres apps te montrent combien de jours tu t'es connecté. Nous te montrons combien de points tu as gagnés au BAC.",
};
