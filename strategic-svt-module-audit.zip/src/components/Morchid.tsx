import { useState } from "react";
import { DUOS, GLOBAL, LAWS, PILLARS, type Pillar } from "../data/morchid";
import { Card, Pill } from "./ui";

const KICKER = "font-mono text-[10.5px] uppercase tracking-[0.22em]";

function Head({ kicker, title, sub }: { kicker: string; title: string; sub?: string }) {
  return (
    <div className="mb-6 border-l-2 border-amber-400/60 pl-4">
      <div className={`${KICKER} text-amber-400/80`}>{kicker}</div>
      <h2 className="mt-1.5 font-display text-[26px] font-semibold leading-tight tracking-tight text-white sm:text-[32px]">{title}</h2>
      {sub && <p className="mt-2.5 max-w-3xl text-[13.5px] leading-relaxed text-white/55">{sub}</p>}
    </div>
  );
}

function Gauge({ value, color, size = 108 }: { value: number; color: string; size?: number }) {
  const r = size / 2 - 7;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,.08)" strokeWidth="7" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth="7"
          strokeLinecap="round"
          strokeDasharray={`${(value / 10) * c} ${c}`}
          style={{ transition: "stroke-dasharray 1.1s cubic-bezier(.22,.61,.36,1)" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">
        <div className="text-center">
          <div className="font-mono text-[26px] font-bold leading-none tabular-nums text-white">{value}</div>
          <div className="font-mono text-[9px] text-white/35">/10</div>
        </div>
      </div>
    </div>
  );
}

const GRAV = {
  critique: { tone: "bad" as const, label: "critique" },
  majeure: { tone: "warn" as const, label: "majeure" },
  mineure: { tone: "neutral" as const, label: "mineure" },
};

function PillarBlock({ p }: { p: Pillar }) {
  const [tab, setTab] = useState<"pour" | "contre">(p.id === "gardefou" ? "pour" : "contre");
  const list = p.evidence.filter((e) => e.kind === tab);
  const pours = p.evidence.filter((e) => e.kind === "pour").length;
  const contres = p.evidence.filter((e) => e.kind === "contre").length;

  return (
    <Card className="!p-0 overflow-hidden">
      <div className="flex flex-col gap-5 border-b border-white/10 p-5 sm:flex-row sm:items-center">
        <Gauge value={p.score} color={p.color} />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-md px-2 py-0.5 font-mono text-[11px] font-bold" style={{ background: `${p.color}22`, color: p.color }}>
              PILIER {p.n}
            </span>
            <span className={`${KICKER} text-white/40`}>{p.role}</span>
          </div>
          <h3 className="mt-1.5 font-display text-[22px] font-semibold text-white">{p.name}</h3>
          <p className="mt-0.5 text-[12.5px] italic text-white/45">{p.question}</p>
          <p className="mt-3 border-l-2 pl-3 text-[13.5px] leading-relaxed text-white/80" style={{ borderColor: p.color }}>
            {p.verdict}
          </p>
        </div>
      </div>

      <div className="p-5">
        <div className="mb-3 flex gap-1.5">
          <button
            onClick={() => setTab("contre")}
            className={`rounded-lg px-3 py-1.5 text-[12px] font-medium transition ${
              tab === "contre" ? "bg-red-500/15 text-red-300 ring-1 ring-red-500/30" : "text-white/45 hover:bg-white/5"
            }`}
          >
            À charge ({contres})
          </button>
          <button
            onClick={() => setTab("pour")}
            className={`rounded-lg px-3 py-1.5 text-[12px] font-medium transition ${
              tab === "pour" ? "bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-500/30" : "text-white/45 hover:bg-white/5"
            }`}
          >
            À décharge ({pours})
          </button>
          <span className="ml-auto self-center font-mono text-[10px] text-white/30">preuves extraites du dépôt</span>
        </div>

        <div className="space-y-2.5">
          {list.map((e) => (
            <div
              key={e.code}
              className={`rounded-xl border p-3.5 ${
                e.kind === "pour" ? "border-emerald-500/20 bg-emerald-500/[0.04]" : "border-red-500/20 bg-red-500/[0.04]"
              }`}
            >
              <div className="font-mono text-[10.5px] text-white/40">{e.file}</div>
              <pre className="mt-2 overflow-x-auto whitespace-pre-wrap break-words rounded-lg bg-black/40 p-2.5 font-mono text-[11px] leading-relaxed text-white/75">
                {e.code}
              </pre>
              <p className="mt-2 text-[13px] leading-relaxed text-white/75">{e.read}</p>
            </div>
          ))}
        </div>

        <div className="mt-5 border-t border-white/10 pt-4">
          <div className={`${KICKER} mb-2 text-white/35`}>Failles retenues</div>
          <div className="grid gap-2 lg:grid-cols-3">
            {p.flaws.map((f) => (
              <div key={f.title} className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                <div className="mb-1.5 flex items-start justify-between gap-2">
                  <span className="text-[12.5px] font-semibold leading-snug text-white">{f.title}</span>
                  <Pill tone={GRAV[f.gravity].tone}>{GRAV[f.gravity].label}</Pill>
                </div>
                <p className="text-[11.5px] leading-snug text-white/60">{f.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}

export default function Morchid() {
  const [mode, setMode] = useState<"before" | "after">("before");
  const avg = PILLARS.reduce((a, p) => a + p.score, 0) / PILLARS.length;

  return (
    <div className="space-y-12">
      {/* AVERTISSEMENT DE MÉTHODE */}
      <Card className="border-amber-500/30 bg-amber-500/[0.06]">
        <div className={`${KICKER} text-amber-300`}>Avertissement de méthode</div>
        <p className="mt-2 text-[13.5px] leading-relaxed text-white/80">
          Aucune conversation n'était jointe à votre demande (« les échanges fournis ci-dessous » étaient vides). Je n'ai pas inventé de
          dialogue : <strong className="text-white">j'ai audité la source qui produit chaque réponse de Morchid</strong> —{" "}
          <span className="font-mono text-amber-200">smartTutorEngine.ts</span>,{" "}
          <span className="font-mono text-amber-200">studyGuide.ts</span>,{" "}
          <span className="font-mono text-amber-200">methodologyKnowledge.ts</span>,{" "}
          <span className="font-mono text-amber-200">AITutorView.tsx</span>. C'est plus sévère qu'un audit de transcript : un échange
          montre un cas, le moteur montre <em>tous</em> les cas possibles. Chaque citation ci-dessous est littérale.
        </p>
      </Card>

      {/* VERDICT GLOBAL */}
      <section className="relative overflow-hidden rounded-3xl border border-white/12 bg-[linear-gradient(135deg,rgba(239,68,68,.08),rgba(16,185,129,.05)_60%,transparent)] p-6 sm:p-9">
        <div className="pointer-events-none absolute -right-20 -top-24 h-64 w-64 rounded-full bg-red-500/10 blur-3xl" />
        <div className="relative grid gap-8 lg:grid-cols-[1.4fr_auto]">
          <div>
            <div className={`${KICKER} text-white/40`}>Verdict d'inspection</div>
            <h2 className="mt-3 font-display text-[28px] font-semibold leading-[1.15] tracking-tight text-white sm:text-[38px]">
              Morchid protège la note contre l'élève.
              <br />
              <span className="text-red-300">Il ne protège pas l'élève contre sa propre passivité.</span>
            </h2>
            <p className="mt-5 max-w-2xl text-[14px] leading-relaxed text-white/70">{GLOBAL.strength}</p>
            <p className="mt-3 max-w-2xl rounded-xl border border-red-500/25 bg-red-500/[0.07] p-4 text-[14px] leading-relaxed text-white/85">
              <strong className="text-red-300">La brèche :</strong> {GLOBAL.breach}
            </p>
          </div>
          <div className="flex shrink-0 flex-col items-center justify-center gap-3 rounded-2xl border border-white/12 bg-black/35 p-6 backdrop-blur">
            <div className={`${KICKER} text-white/40`}>Moyenne des 3 piliers</div>
            <div className="font-mono text-6xl font-bold leading-none tabular-nums text-amber-300">{avg.toFixed(1)}</div>
            <div className="font-mono text-[11px] text-white/35">/10</div>
            <div className="mt-2 w-full space-y-1.5">
              {PILLARS.map((p) => (
                <div key={p.id} className="grid grid-cols-[1fr_52px_26px] items-center gap-2 text-[11px]">
                  <span className="truncate text-white/55">{p.role}</span>
                  <span className="h-1.5 overflow-hidden rounded-full bg-white/10">
                    <span className="block h-full rounded-full" style={{ width: `${p.score * 10}%`, background: p.color }} />
                  </span>
                  <span className="text-right font-mono tabular-nums text-white/70">{p.score}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* LES 3 PILIERS */}
      <section>
        <Head
          kicker="Évaluation détaillée"
          title="Les 3 piliers, preuve par preuve"
          sub="Chaque pilier est noté sur 10, avec les extraits de code à charge et à décharge. Basculez entre les deux onglets pour voir ce qui condamne et ce qui sauve."
        />
        <div className="space-y-5">
          {PILLARS.map((p) => (
            <PillarBlock key={p.id} p={p} />
          ))}
        </div>
      </section>

      {/* AVANT / APRÈS */}
      <section>
        <Head
          kicker="Correction du comportement"
          title="Avant / Après — 4 situations réelles"
          sub="À gauche ce que Morchid répond aujourd'hui, à droite ce qu'il doit répondre. Les textes de droite sont prêts à être intégrés tels quels dans le moteur."
        />
        <div className="mb-4 inline-flex gap-1 rounded-xl border border-white/10 bg-white/[0.03] p-1">
          <button
            onClick={() => setMode("before")}
            className={`rounded-lg px-4 py-1.5 text-[12.5px] font-medium transition ${
              mode === "before" ? "bg-red-500/15 text-red-300" : "text-white/45 hover:text-white/80"
            }`}
          >
            Morchid actuel
          </button>
          <button
            onClick={() => setMode("after")}
            className={`rounded-lg px-4 py-1.5 text-[12.5px] font-medium transition ${
              mode === "after" ? "bg-emerald-500/15 text-emerald-300" : "text-white/45 hover:text-white/80"
            }`}
          >
            Morchid corrigé
          </button>
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          {DUOS.map((d) => {
            const r = mode === "before" ? d.before : d.after;
            const good = mode === "after";
            return (
              <div
                key={d.id}
                className={`rounded-2xl border p-4 transition-colors duration-300 ${
                  good ? "border-emerald-500/25 bg-emerald-500/[0.04]" : "border-red-500/25 bg-red-500/[0.04]"
                }`}
              >
                <div className={`${KICKER} text-white/35`}>{d.context}</div>

                <div className="mt-3 flex justify-end">
                  <div className="max-w-[85%] rounded-2xl rounded-br-sm bg-white/10 px-3.5 py-2.5 text-right" dir="rtl" lang="ar">
                    <span className="text-[13.5px] leading-relaxed text-white/85">{d.student}</span>
                  </div>
                </div>

                <div className="mt-2.5 flex justify-start">
                  <div
                    className={`max-w-[92%] rounded-2xl rounded-bl-sm px-3.5 py-3 text-right ${
                      good ? "bg-emerald-500/12 ring-1 ring-emerald-500/25" : "bg-red-500/12 ring-1 ring-red-500/25"
                    }`}
                    dir="rtl"
                    lang="ar"
                  >
                    <span className="whitespace-pre-line text-[13.5px] leading-[1.9] text-white/90">{r.text}</span>
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-white/10 pt-3">
                  <Pill tone={good ? "good" : "bad"}>{r.tag}</Pill>
                  <span className="font-mono text-[10.5px] text-white/35">{d.rule.split(" — ")[0]}</span>
                </div>
                {good && <p className="mt-2 text-[11.5px] leading-snug text-emerald-300/70">{d.rule}</p>}
              </div>
            );
          })}
        </div>
      </section>

      {/* LA LOI DE MORCHID */}
      <section>
        <Head
          kicker="Spécification corrective"
          title="La Loi de Morchid — 10 règles non négociables"
          sub="Chaque règle est accompagnée du correctif technique exact : fonction à modifier et champ à ajouter. Aucune règle n'exige de LLM ni de connexion : tout reste local et déterministe."
        />
        <div className="space-y-2.5">
          {LAWS.map((l) => {
            const col = l.pillar === 1 ? "#f59e0b" : l.pillar === 2 ? "#ef4444" : "#10b981";
            const name = l.pillar === 1 ? "Guide" : l.pillar === 2 ? "Coach" : "Garde-fou";
            return (
              <div
                key={l.n}
                className="grid gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-4 transition hover:border-white/25 hover:bg-white/[0.055] lg:grid-cols-[auto_1.5fr_1fr]"
              >
                <div className="flex items-start gap-3 lg:w-[150px]">
                  <span className="font-mono text-base font-bold" style={{ color: col }}>
                    {l.n}
                  </span>
                  <span className="rounded px-1.5 py-0.5 font-mono text-[9.5px] uppercase tracking-wider" style={{ background: `${col}1f`, color: col }}>
                    {name}
                  </span>
                </div>
                <div>
                  <div className="text-[14px] font-semibold text-white">{l.title}</div>
                  <p className="mt-1 text-[12.5px] leading-relaxed text-white/65">{l.rule}</p>
                </div>
                <div className="rounded-lg bg-black/35 p-2.5">
                  <div className={`${KICKER} text-white/30`}>Correctif</div>
                  <p className="mt-1 font-mono text-[11px] leading-relaxed text-white/60">{l.patch}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* CONCLUSION */}
      <section className="rounded-3xl border border-white/12 bg-[linear-gradient(160deg,rgba(255,255,255,.05),transparent)] p-6 sm:p-8">
        <div className={`${KICKER} text-white/40`}>Conclusion de l'inspecteur</div>
        <p className="mt-3 font-display text-[20px] font-medium leading-relaxed text-white sm:text-[24px]">{GLOBAL.sentence}</p>
        <div className="mt-6 grid gap-3 sm:grid-cols-3">
          {[
            { k: "Ce qu'on garde", c: "#10b981", d: "Toute la couche de validation : payload sans réponse, mélange déterministe, anti-bourrage, polarité des négations, anti-farm d'XP. C'est du travail d'orfèvre, il ne faut y toucher sous aucun prétexte." },
            { k: "Ce qu'on ferme", c: "#ef4444", d: "Le bouton « لا أعرف » qui livre la correction en un clic, et la réponse de fiche qui livre shortAnswer sans aucune question préalable. Deux fonctions, deux semaines de travail." },
            { k: "Ce qu'on ajoute", c: "#f59e0b", d: "Un lexique d'affect en darija, un classement réel des erreurs, une date de BAC, et l'obligation que toute note s'accompagne d'une cause, d'une action et d'une porte vers la leçon." },
          ].map((x) => (
            <div key={x.k} className="rounded-xl border border-white/10 bg-black/25 p-4">
              <div className="font-mono text-[11px] uppercase tracking-wider" style={{ color: x.c }}>
                {x.k}
              </div>
              <p className="mt-2 text-[12.5px] leading-relaxed text-white/70">{x.d}</p>
            </div>
          ))}
        </div>
        <p className="mt-6 text-[13px] leading-relaxed text-white/60">
          Une dernière remarque, de collègue à collègue : Morchid imprime à l'élève{" "}
          <span dir="rtl" lang="ar" className="text-white/85">« لا تفتح الحل النموذجي قبل محاولة كتابية حقيقية لمدة 20 إلى 25 دقيقة »</span>{" "}
          — puis lui ouvre le corrigé complet au premier clic. Tant que cette contradiction vit dans le code, aucun élève n'apprendra à
          rédiger : il apprendra à cliquer. <strong className="text-white/85">Corriger R1 et R3 vaut à elles seules les neuf autres règles.</strong>
        </p>
      </section>
    </div>
  );
}
