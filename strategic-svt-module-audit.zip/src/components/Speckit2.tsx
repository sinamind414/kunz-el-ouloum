import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { BAC_SESSIONS, BAC_WEIGHTS, DIVERGENCES, ITEMS, NON_GOALS, REJECTED, TASKS, TRACKS, type AuditItem } from "../data/speckit2";
import { SPECKIT_DIR, STATS, renderChecklist, renderPlan, renderReport, renderSpec, renderTasks } from "../lib/speckitRender";
import { Card, Pill } from "./ui";

const KICKER = "font-mono text-[10.5px] uppercase tracking-[0.22em]";

/* ─────────── état persisté d'avancement ─────────── */
const KEY_STATE = "speckit-001-progress-v1";
type TaskState = { done: boolean; note?: string };
type ProgressState = { tasks: Record<string, TaskState>; ac: Record<string, Record<number, boolean>> };
const emptyState: ProgressState = { tasks: {}, ac: {} };

function loadState(): ProgressState {
  try {
    const raw = localStorage.getItem(KEY_STATE);
    if (!raw) return emptyState;
    const parsed = JSON.parse(raw) as ProgressState;
    return { tasks: parsed.tasks ?? {}, ac: parsed.ac ?? {} };
  } catch {
    return emptyState;
  }
}
function saveState(s: ProgressState) {
  try {
    localStorage.setItem(KEY_STATE, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}

function Reveal({ children, delay = 0 }: { children: ReactNode; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [ok, setOk] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => e.isIntersecting && (setOk(true), io.disconnect()), { threshold: 0.1, rootMargin: "0px 0px -30px" });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} style={{ opacity: ok ? 1 : 0, transform: ok ? "none" : "translateY(14px)", transition: `all .55s cubic-bezier(.22,.61,.36,1) ${delay}ms` }}>
      {children}
    </div>
  );
}

const PRIO_META: Record<string, { c: string; label: string }> = {
  P0: { c: "#ef4444", label: "P0" },
  P1: { c: "#f59e0b", label: "P1" },
  P2: { c: "#a78bfa", label: "P2" },
};

type FileId = "spec" | "plan" | "tasks" | "checklist" | "report";

const FILES: { id: FileId; name: string; render: () => string; desc: string }[] = [
  { id: "spec", name: "spec.md", render: renderSpec, desc: "Stories élève P0 d'abord · exigences FR-xx traçables · non-goals · annexe des items jetés" },
  { id: "plan", name: "plan.md", render: renderPlan, desc: "Cause racine · fichiers visés (interdits ≠) · stratégie d'injection mécanique · preuve exigée" },
  { id: "tasks", name: "tasks.md", render: renderTasks, desc: "14 tâches ordonnées · périmètre exact · commande de vérif · étiquettes [P] sur 4 pistes disjointes" },
  { id: "checklist", name: "checklists/validation-avant-merge.md", render: renderChecklist, desc: "Suite verte · relecture humaine arabe · recoupement citations · git add explicite · push JAMAIS" },
  { id: "report", name: "rapport-de-session.md", render: renderReport, desc: "n sources → retenus / jetés · couverture 100 % P0 · divergences tranchées" },
];

function CodeBlock({ text }: { text: string }) {
  return (
    <pre className="max-h-[62vh] overflow-auto whitespace-pre-wrap break-words rounded-xl border border-white/10 bg-black/45 p-4 font-mono text-[11.5px] leading-relaxed text-white/80">
      {text}
    </pre>
  );
}

function ItemCard({ it, acState, onAcToggle }: { it: AuditItem; acState: Record<number, boolean>; onAcToggle: (i: number) => void }) {
  const [open, setOpen] = useState(false);
  const p = PRIO_META[it.prio];
  const locked = it.etat.startsWith("à verrouiller");
  const total = it.ac?.length ?? 0;
  const done = Object.values(acState).filter(Boolean).length;
  return (
    <div className={`overflow-hidden rounded-xl border transition ${open ? "border-white/25 bg-white/[0.055]" : "border-white/10 bg-white/[0.03] hover:border-white/20"}`}>
      <button onClick={() => setOpen(!open)} className="w-full p-4 text-left">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-[12px] font-bold" style={{ color: p.c }}>
            {it.id}
          </span>
          <span className="rounded px-1.5 py-0.5 font-mono text-[10px] font-bold" style={{ background: `${p.c}20`, color: p.c }}>
            {it.prio} · {it.axe}
          </span>
          {locked && <Pill tone="warn">verrouillage, pas correction</Pill>}
          <span className="font-mono text-[10px] text-white/30">{it.gravity}</span>
          {total > 0 && (
            <span className={`font-mono text-[10px] ${done === total ? "text-emerald-300" : "text-white/40"}`}>
              AC {done}/{total}
            </span>
          )}
          <span className={`ml-auto text-white/25 transition ${open ? "rotate-180" : ""}`}>▾</span>
        </div>
        <p className="mt-1.5 text-[13px] font-medium leading-snug text-white">{it.faitEleve}</p>
        <p className="mt-1 truncate font-mono text-[10.5px] text-white/35">{it.localisation}</p>
      </button>

      {open && (
        <div className="space-y-4 border-t border-white/10 bg-black/25 p-4">
          <div>
            <div className={`${KICKER} mb-1.5 text-amber-300/80`}>User story élève</div>
            <p className="text-[13px] leading-relaxed text-white/85">
              <span className="text-amber-200">En tant qu'élève 3AS</span>, quand <em className="text-white">{it.story?.quand}</em>, je veux{" "}
              <em className="text-white">{it.story?.veux}</em>, afin de <em className="text-white">{it.story?.afin}</em>.
            </p>
          </div>

          <div className="rounded-lg border border-white/10 bg-white/[0.03] p-3">
            <div className={`${KICKER} mb-1 text-white/35`}>Citation de l'audit — preuve attachée</div>
            <p className="text-[12.5px] italic leading-relaxed text-white/70">{it.citation}</p>
            <p className="mt-2 font-mono text-[10.5px] text-white/40">
              {it.source} · verdict : {it.verdict}
            </p>
          </div>

          <div className="rounded-lg border border-emerald-500/25 bg-emerald-500/[0.05] p-3">
            <div className={`${KICKER} mb-1 text-emerald-300/80`}>{it.fr?.split(" — ")[0]}</div>
            <p className="text-[12.5px] leading-relaxed text-white/80">{it.fr?.split(" — ").slice(1).join(" — ")}</p>
          </div>

          <div>
            <div className={`${KICKER} mb-1.5 text-white/40`}>Critères d'acceptation mesurables (cocher = preuve validée)</div>
            <ul className="space-y-1.5">
              {it.ac?.map((a, i) => {
                const checked = acState[i] === true;
                return (
                  <li key={a}>
                    <button
                      onClick={() => onAcToggle(i)}
                      className={`flex w-full gap-2 rounded-lg p-2 text-left transition ${
                        checked ? "bg-emerald-500/10 ring-1 ring-emerald-500/30" : "bg-white/[0.02] hover:bg-white/[0.05]"
                      }`}
                    >
                      <span
                        className={`mt-[3px] grid h-3.5 w-3.5 shrink-0 place-items-center rounded border text-[9px] transition ${
                          checked ? "border-emerald-400 bg-emerald-400 text-slate-900" : "border-white/25 text-transparent"
                        }`}
                      >
                        ✓
                      </span>
                      <span className={`text-[12.5px] leading-snug ${checked ? "text-white/50 line-through" : "text-white/75"}`}>{a}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}

function FilesView({ file, setFile }: { file: FileId; setFile: (f: FileId) => void }) {
  const [copied, setCopied] = useState<string | null>(null);
  const [bundleCopied, setBundleCopied] = useState(false);
  const current = FILES.find((f) => f.id === file)!;
  const md = useMemo(() => current.render(), [current]);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(md);
      setCopied(file);
      setTimeout(() => setCopied(null), 2200);
    } catch {
      /* presse-papiers indisponible */
    }
  };

  const copyBundle = async () => {
    const sep = "\n\n" + "═".repeat(78) + "\n\n";
    const bundle = FILES.map((f) => `### ${SPECKIT_DIR}${f.name}\n\n${f.render()}`).join(sep);
    try {
      await navigator.clipboard.writeText(bundle);
      setBundleCopied(true);
      setTimeout(() => setBundleCopied(false), 2400);
    } catch {
      /* ignore */
    }
  };

  return (
    <>
      <section>
        <div className="mb-3 flex flex-wrap items-center gap-2">
          {FILES.map((f) => (
            <button
              key={f.id}
              onClick={() => setFile(f.id)}
              className={`rounded-xl border px-3.5 py-2 text-left transition ${
                file === f.id ? "border-amber-400/60 bg-amber-400/[0.08]" : "border-white/10 bg-white/[0.03] hover:border-white/25"
              }`}
            >
              <div className="font-mono text-[11.5px] font-semibold text-white">{f.name}</div>
              <div className="mt-0.5 max-w-[280px] truncate text-[10.5px] text-white/45">{f.desc}</div>
            </button>
          ))}
          <button
            onClick={copy}
            className="ml-auto rounded-xl bg-amber-400 px-4 py-2.5 text-[13px] font-bold text-slate-900 transition hover:bg-amber-300"
          >
            {copied === file ? "✓ Copié — collez dans le repo" : `Copier ${current.name}`}
          </button>
        </div>

        <div className="mb-2 flex items-center gap-2 font-mono text-[10.5px] text-white/35">
          <span className="text-amber-300/70">{SPECKIT_DIR}</span>
          {current.name}
          <span className="ml-auto">{md.split("\n").length} lignes · {new Blob([md]).size} octets</span>
        </div>
        <CodeBlock text={md} />
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <p className="text-[11.5px] leading-relaxed text-white/45">
            Copiez dans <span className="font-mono text-white/65">{SPECKIT_DIR}{current.name}</span>. <span className="font-mono text-white/65">git add specs/</span>{" "}
            explicite — jamais <span className="font-mono text-white/65">git add -A</span> — <strong className="text-white/65">pas de push</strong> sans validation.
          </p>
          <button
            onClick={copyBundle}
            className="rounded-xl border border-amber-400/40 bg-amber-400/[0.07] px-3 py-1.5 text-[11.5px] font-semibold text-amber-200 transition hover:bg-amber-400/15"
          >
            {bundleCopied ? "✓ Bundle 5 fichiers copié" : "Copier les 5 fichiers d'un coup (bundle)"}
          </button>
        </div>
      </section>
    </>
  );
}

function PilotageView() {
  const [state, setState] = useState<ProgressState>(emptyState);
  useEffect(() => setState(loadState()), []);

  const update = (next: ProgressState) => {
    setState(next);
    saveState(next);
  };
  const toggleTask = (id: string) =>
    update({ ...state, tasks: { ...state.tasks, [id]: { done: !(state.tasks[id]?.done ?? false) } } });
  const toggleAc = (itemId: string, i: number) => {
    const cur = state.ac[itemId] ?? {};
    update({ ...state, ac: { ...state.ac, [itemId]: { ...cur, [i]: !cur[i] } } });
  };
  const setNote = (id: string, note: string) =>
    update({ ...state, tasks: { ...state.tasks, [id]: { ...(state.tasks[id] ?? { done: false }), note } } });
  const reset = () => {
    if (confirm("Réinitialiser tout l'avancement ? Cette action est irréversible.")) update(emptyState);
  };

  /* stats d'avancement */
  const tDone = TASKS.filter((t) => state.tasks[t.id]?.done).length;
  const acTotal = ITEMS.reduce((a, it) => a + (it.ac?.length ?? 0), 0);
  const acDone = ITEMS.reduce((a, it) => a + Object.values(state.ac[it.id] ?? {}).filter(Boolean).length, 0);
  const p0Items = ITEMS.filter((i) => i.prio === "P0");
  const p0AcTotal = p0Items.reduce((a, it) => a + (it.ac?.length ?? 0), 0);
  const p0AcDone = p0Items.reduce((a, it) => a + Object.values(state.ac[it.id] ?? {}).filter(Boolean).length, 0);

  /* export bundle = résumé markdown de l'avancement */
  const progressMd = useMemo(() => {
    const lines = [
      "# Avancement — 001-fiabilite-eleve",
      "",
      `Généré le ${new Date().toISOString().slice(0, 10)}`,
      "",
      "## Synthèse",
      "",
      `- Tâches terminées : **${tDone} / ${TASKS.length}**`,
      `- Critères d'acceptation cochés : **${acDone} / ${acTotal}**`,
      `- Dont P0 : **${p0AcDone} / ${p0AcTotal}**`,
      "",
      "## Tâches",
      "",
    ];
    TASKS.forEach((t) => {
      const s = state.tasks[t.id];
      lines.push(`### ${t.id} — ${t.title}`);
      lines.push(`- [${s?.done ? "x" : " "}] Terminé`);
      if (s?.note) lines.push(`- **Note :** ${s.note}`);
      lines.push("");
    });
    lines.push("## Critères d'acceptation P0", "");
    p0Items.forEach((it) => {
      const acState = state.ac[it.id] ?? {};
      lines.push(`### ${it.id} [${it.axe}]`);
      it.ac?.forEach((a, i) => lines.push(`- [${acState[i] ? "x" : " "}] ${a}`));
      lines.push("");
    });
    return lines.join("\n");
  }, [state, tDone, acDone, p0AcDone]);

  const exportProgress = async () => {
    try {
      await navigator.clipboard.writeText(progressMd);
      alert("Résumé d'avancement copié. Collez-le dans specs/001-fiabilite-eleve/AVANCEMENT.md avant commit.");
    } catch {
      /* ignore */
    }
  };

  return (
    <div className="space-y-8">
      {/* KPI globaux */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <div className={`${KICKER} text-white/40`}>Tâches terminées</div>
          <div className="mt-2 font-mono text-3xl font-bold text-amber-300">{tDone}/{TASKS.length}</div>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10">
            <div className="h-full rounded-full bg-amber-400 transition-all duration-500" style={{ width: `${(tDone / TASKS.length) * 100}%` }} />
          </div>
        </Card>
        <Card>
          <div className={`${KICKER} text-white/40`}>Critères cochés (total)</div>
          <div className="mt-2 font-mono text-3xl font-bold text-violet-300">{acDone}/{acTotal}</div>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10">
            <div className="h-full rounded-full bg-violet-400 transition-all duration-500" style={{ width: `${acTotal ? (acDone / acTotal) * 100 : 0}%` }} />
          </div>
        </Card>
        <Card className="border-red-500/25 bg-red-500/[0.05]">
          <div className={`${KICKER} text-red-300`}>Critères P0 validés</div>
          <div className="mt-2 font-mono text-3xl font-bold text-red-300">{p0AcDone}/{p0AcTotal}</div>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10">
            <div className="h-full rounded-full bg-red-400 transition-all duration-500" style={{ width: `${p0AcTotal ? (p0AcDone / p0AcTotal) * 100 : 0}%` }} />
          </div>
          <div className="mt-1 text-[10.5px] text-white/45">Condition nécessaire : 100 % avant merge.</div>
        </Card>
        <Card>
          <div className={`${KICKER} text-emerald-300`}>Barème BAC (source)</div>
          <div className="mt-2 font-mono text-2xl font-bold text-emerald-300">5 / 7 / 8</div>
          <div className="mt-1 text-[10.5px] text-white/50">
            ex1 = 5 · ex2 = 7 · ex3 = 8 · total 20 · 4h30 · 2 sujets au choix
          </div>
          <div className="mt-1 font-mono text-[9.5px] text-white/30">
            ONEC · eddirasa.com · dzexams.com · 2019→2026
          </div>
        </Card>
      </div>

      {/* actions */}
      <div className="flex flex-wrap items-center gap-2">
        <button
          onClick={exportProgress}
          className="rounded-xl bg-amber-400 px-4 py-2.5 text-[13px] font-bold text-slate-900 transition hover:bg-amber-300"
        >
          Exporter l'avancement (AVANCEMENT.md)
        </button>
        <button
          onClick={reset}
          className="rounded-xl border border-red-500/30 bg-red-500/[0.06] px-3 py-2 text-[12px] text-red-300 transition hover:bg-red-500/10"
        >
          Réinitialiser
        </button>
        <span className="ml-auto font-mono text-[10.5px] text-white/35">État persisté en localStorage · aucune donnée envoyée</span>
      </div>

      {/* tâches */}
      <section>
        <div className="mb-4 border-l-2 border-amber-400/60 pl-4">
          <div className={`${KICKER} text-amber-400/80`}>Tâches — par piste</div>
          <h2 className="mt-1.5 font-display text-[24px] font-semibold tracking-tight text-white sm:text-[28px]">
            Cochez à mesure que la commande de vérification passe
          </h2>
        </div>
        <div className="grid gap-3 lg:grid-cols-2">
          {TRACKS.map((tr) => {
            const ts = TASKS.filter((x) => x.track === tr.id);
            const d = ts.filter((t) => state.tasks[t.id]?.done).length;
            return (
              <Card key={tr.id}>
                <div className="flex items-center gap-2">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: tr.color }} />
                  <span className="text-[14px] font-semibold text-white">{tr.label}</span>
                  <span className="ml-auto font-mono text-[11px] text-white/40">
                    {d}/{ts.length}
                  </span>
                </div>
                <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full transition-all duration-500" style={{ width: `${(d / ts.length) * 100}%`, background: tr.color }} />
                </div>
                <div className="mt-3 space-y-1.5">
                  {ts.map((t) => {
                    const s = state.tasks[t.id];
                    return (
                      <div key={t.id} className={`rounded-lg border p-2 transition ${s?.done ? "border-emerald-500/30 bg-emerald-500/[0.06]" : "border-white/10 bg-white/[0.03]"}`}>
                        <div className="flex items-start gap-2">
                          <button
                            onClick={() => toggleTask(t.id)}
                            className={`mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded border text-[10px] transition ${
                              s?.done ? "border-emerald-400 bg-emerald-400 text-slate-900" : "border-white/25 text-transparent hover:border-emerald-400/60"
                            }`}
                          >
                            ✓
                          </button>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5">
                              <span className="font-mono text-[10.5px] text-white/60">{t.id}</span>
                              {t.parallel && <span className="rounded bg-emerald-500/15 px-1 text-[9px] font-bold text-emerald-300">[P]</span>}
                              <span className={`text-[11.5px] font-medium ${s?.done ? "text-white/45 line-through" : "text-white/85"}`}>{t.title}</span>
                            </div>
                            <input
                              value={s?.note ?? ""}
                              onChange={(e) => setNote(t.id, e.target.value)}
                              placeholder="Note / preuve (copie, écart, mesure avant→après)"
                              className="mt-1 w-full rounded border border-white/10 bg-black/30 px-2 py-1 text-[11px] text-white/70 outline-none placeholder:text-white/30 focus:border-amber-500/40"
                            />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </Card>
            );
          })}
        </div>
      </section>

      {/* critères d'acceptation P0 */}
      <section>
        <div className="mb-4 border-l-2 border-red-400/60 pl-4">
          <div className={`${KICKER} text-red-400/80`}>Critères P0 — 100 % avant merge</div>
          <h2 className="mt-1.5 font-display text-[24px] font-semibold tracking-tight text-white sm:text-[28px]">
            Chaque case cochée doit être soutenue par une preuve (test vert / unité×page / wording فصحى)
          </h2>
        </div>
        <div className="space-y-2.5">
          {p0Items.map((it) => (
            <ItemCard
              key={it.id}
              it={it}
              acState={state.ac[it.id] ?? {}}
              onAcToggle={(i) => toggleAc(it.id, i)}
            />
          ))}
        </div>
      </section>
    </div>
  );
}

export default function Speckit2() {
  const [view, setView] = useState<"files" | "pilotage">("files");
  const [file, setFile] = useState<FileId>("report");
  const [prio, setPrio] = useState<string>("all");

  const list = ITEMS.filter((i) => prio === "all" || i.prio === prio);

  return (
    <div className="space-y-11">
      {/* EN-TÊTE */}
      <section className="relative overflow-hidden rounded-3xl border border-white/12 bg-[linear-gradient(135deg,rgba(167,139,250,.10),rgba(16,185,129,.06)_55%,transparent)] p-6 sm:p-9">
        <div className="pointer-events-none absolute -right-20 -top-24 h-64 w-64 rounded-full bg-violet-400/10 blur-3xl" />
        <div className="relative">
          <div className={`${KICKER} text-violet-300`}>Session architecte · spécification, aucun code</div>
          <h1 className="mt-3 font-display text-[28px] font-semibold leading-[1.12] tracking-tight text-white sm:text-[42px]">
            specs/001-fiabilite-eleve/
          </h1>
          <p className="mt-4 max-w-3xl text-[14px] leading-relaxed text-white/70">
            Les audits transformés en speckit exécutable, orienté <strong className="text-white">fiabilité pour l'élève</strong> : ce qu'il peut
            apprendre de <strong className="text-red-300">FAUX</strong>, ce qu'on peut lui <strong className="text-red-300">noter de faux</strong>,
            et ce qui manque du programme officiel. {STATS.sourceItems} allégations → <strong className="text-white">{STATS.retained} retenues</strong>{" "}
            ({STATS.p0} P0 · {STATS.p1} P1 · {STATS.p2} P2) / <strong className="text-white">{STATS.rejected} jetées</strong>. PR-3 levé : barème
            officiel <strong className="text-emerald-200">5/7/8 pts</strong> confirmé par `bac_sessions_2019_2026.json`.
          </p>
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <Pill tone="bad">{STATS.p0} P0</Pill>
            <Pill tone="warn">{STATS.p1} P1</Pill>
            <Pill tone="neutral">{STATS.p2} P2</Pill>
            <Pill tone="good">couverture {STATS.coverage} %</Pill>
            <Pill tone="neutral">{STATS.tasks} tâches · 4 pistes</Pill>
            <Pill tone="bad">{STATS.rejected} jetées</Pill>
            <Pill tone="good">PR-3 levé · 5/7/8 pts</Pill>
          </div>

          {/* sélecteur de vue */}
          <div className="mt-6 inline-flex gap-1 rounded-xl border border-white/10 bg-black/30 p-1">
            <button
              onClick={() => setView("files")}
              className={`rounded-lg px-4 py-2 text-[13px] font-medium transition ${
                view === "files" ? "bg-amber-400/15 text-amber-200 ring-1 ring-amber-400/30" : "text-white/50 hover:text-white/80"
              }`}
            >
              ▤ Fichiers du speckit
            </button>
            <button
              onClick={() => setView("pilotage")}
              className={`rounded-lg px-4 py-2 text-[13px] font-medium transition ${
                view === "pilotage" ? "bg-emerald-400/15 text-emerald-200 ring-1 ring-emerald-400/30" : "text-white/50 hover:text-white/80"
              }`}
            >
              ◉ Pilotage & avancement
            </button>
          </div>

          {/* socle */}
          <div className="mt-5 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { s: "AGENTS.md", ok: true, note: "lu intégralement — prime sur tout, référencé non réinventé" },
              { s: "INDEX.md", ok: false, note: "404 — hiérarchie de vérité non vérifiable (PR-2)" },
              { s: "docs/audits_livres/*", ok: false, note: "404 — prérequis non exécuté (PR-1)" },
              { s: "bac_sessions_2019_2026.json", ok: true, note: "lu — barème 5/7/8 pts · 2019→2026 · 1 lacune (PR-3 LEVÉ)" },
            ].map((x) => (
              <div key={x.s} className={`rounded-xl border p-3 ${x.ok ? "border-emerald-500/25 bg-emerald-500/[0.05]" : "border-red-500/25 bg-red-500/[0.05]"}`}>
                <div className="flex items-center gap-1.5 font-mono text-[10.5px]">
                  <span style={{ color: x.ok ? "#34d399" : "#f87171" }}>{x.ok ? "✓" : "✕"}</span>
                  <span className="truncate text-white/70">{x.s}</span>
                </div>
                <p className="mt-1 text-[11px] leading-snug text-white/50">{x.note}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* VUE SÉLECTIONNÉE */}
      {view === "files" ? (
        <FilesView file={file} setFile={setFile} />
      ) : (
        <PilotageView />
      )}

      {/* BARÈME BAC OFFICIEL */}
      {view === "pilotage" && (
        <section>
          <div className="mb-4 border-l-2 border-emerald-400/60 pl-4">
            <div className={`${KICKER} text-emerald-400/80`}>Source : data/bac_sessions_2019_2026.json</div>
            <h2 className="mt-1.5 font-display text-[24px] font-semibold tracking-tight text-white sm:text-[28px]">
              Barème officiel confirmé — règle P2/R6
            </h2>
          </div>
          <div className="grid gap-3 lg:grid-cols-3">
            {(["domaine_I", "domaine_II", "domaine_III"] as const).map((k) => {
              const d = BAC_WEIGHTS[k];
              return (
                <Card key={k} className="border-emerald-500/20 bg-emerald-500/[0.04]">
                  <div className="font-mono text-[10.5px] uppercase tracking-wider text-emerald-300/80">{k}</div>
                  <div className="mt-1 text-[14px] text-white" dir="rtl" lang="ar">{d.label}</div>
                  <div className="mt-3 flex items-baseline gap-2">
                    <span className="font-mono text-3xl font-bold text-emerald-300">{d.pts}</span>
                    <span className="text-[12px] text-white/50">pts · {d.partPct} %</span>
                  </div>
                  <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10">
                    <div className="h-full rounded-full bg-emerald-400" style={{ width: `${d.partPct}%` }} />
                  </div>
                </Card>
              );
            })}
          </div>
          <div className="mt-3 rounded-xl border border-white/10 bg-white/[0.03] p-4">
            <p className="text-[12.5px] leading-relaxed text-white/70">
              <strong className="text-white/85">{BAC_SESSIONS.duree}</strong> · {BAC_SESSIONS.choix} · barème {BAC_SESSIONS.bareme.ex1}/{BAC_SESSIONS.bareme.ex2}/{BAC_SESSIONS.bareme.ex3}
              · {BAC_SESSIONS.sessions.length} sessions ({BAC_SESSIONS.sessions[0]}→{BAC_SESSIONS.sessions[BAC_SESSIONS.sessions.length - 1]}, série continue)
              · source : {BAC_SESSIONS.source}. <strong className="text-amber-200">Aucun modèle a·cov+b, aucun fit sur les notes prof</strong> — P2/R6.
            </p>
          </div>
        </section>
      )}

      {/* ITEMS */}
      <Reveal>
        <section>
          <div className="mb-5 border-l-2 border-amber-400/60 pl-4">
            <div className={`${KICKER} text-amber-400/80`}>Traçabilité</div>
            <h2 className="mt-1.5 font-display text-[26px] font-semibold tracking-tight text-white sm:text-[32px]">
              Les {STATS.retained} items retenus — chacun avec ID d'audit + preuve
            </h2>
            <p className="mt-2.5 max-w-3xl text-[13.5px] leading-relaxed text-white/55">
              Règle appliquée strictement : item sans preuve = item jeté. Trois items (B2, B3, B7) sont marqués{" "}
              <strong className="text-amber-200">« verrouillage »</strong> et non « correction » : le code lu après l'audit contient déjà le
              correctif, mais aucun test de régression ne le protège — et une suite partiellement rouge n'est pas acceptable selon AGENTS.md.
            </p>
          </div>

          <div className="mb-4 flex flex-wrap gap-2">
            {["all", "P0", "P1", "P2"].map((p) => (
              <button
                key={p}
                onClick={() => setPrio(p)}
                className={`rounded-lg border px-3 py-1.5 text-[12px] font-medium transition ${
                  prio === p ? "border-amber-400/60 bg-amber-400/10 text-amber-200" : "border-white/10 text-white/50 hover:border-white/25 hover:text-white"
                }`}
              >
                {p === "all" ? `Tous (${ITEMS.length})` : `${p} (${ITEMS.filter((i) => i.prio === p).length})`}
              </button>
            ))}
          </div>

          <div className="space-y-2.5">
            {list.map((it) => (
              <div key={it.id}>
                <div className="mb-1 font-mono text-[10px] text-white/30">
                  → {TASKS.find((t) => t.covers.some((c) => it.fr?.startsWith(c)))?.id ?? "—"}
                </div>
                <ItemCard it={it} acState={{}} onAcToggle={() => {}} />
              </div>
            ))}
          </div>
        </section>
      </Reveal>

      {/* 4 PISTES */}
      <Reveal>
        <section>
          <div className="mb-5 border-l-2 border-amber-400/60 pl-4">
            <div className={`${KICKER} text-amber-400/80`}>Parallélisation</div>
            <h2 className="mt-1.5 font-display text-[26px] font-semibold tracking-tight text-white sm:text-[32px]">
              Les 4 pistes — disjointes par construction
            </h2>
          </div>
          <div className="grid gap-3 lg:grid-cols-2">
            {TRACKS.map((t) => {
              const ts = TASKS.filter((x) => x.track === t.id);
              return (
                <Card key={t.id}>
                  <div className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: t.color }} />
                    <span className="text-[14px] font-semibold text-white">{t.label}</span>
                    <span className="ml-auto font-mono text-[11px] text-white/40">{ts.length} tâches</span>
                  </div>
                  <p className="mt-2 font-mono text-[10.5px] leading-relaxed text-white/40">{t.scope}</p>
                  <div className="mt-3 space-y-1.5">
                    {ts.map((x) => (
                      <div key={x.id} className="flex items-start gap-2 rounded-lg bg-white/[0.04] p-2">
                        <span className="font-mono text-[11px] font-bold text-white/70">{x.id}</span>
                        {x.parallel && <span className="rounded bg-emerald-500/15 px-1.5 text-[9px] font-bold text-emerald-300">[P]</span>}
                        <span className="flex-1 text-[11.5px] leading-snug text-white/70">{x.title}</span>
                        <span className="font-mono text-[9.5px] text-white/30">{x.covers.join(",")}</span>
                      </div>
                    ))}
                  </div>
                </Card>
              );
            })}
          </div>
        </section>
      </Reveal>

      {/* DIVERGENCES */}
      <Reveal>
        <section>
          <div className="mb-5 border-l-2 border-amber-400/60 pl-4">
            <div className={`${KICKER} text-amber-400/80`}>Zones de divergence</div>
            <h2 className="mt-1.5 font-display text-[26px] font-semibold tracking-tight text-white sm:text-[32px]">
              {DIVERGENCES.length} divergences inter-audits — tranchées
            </h2>
          </div>
          <div className="space-y-3">
            {DIVERGENCES.map((d, i) => (
              <Card key={d.topic} className="border-white/12">
                <div className="grid gap-4 lg:grid-cols-[1fr_1.3fr]">
                  <div>
                    <div className={`${KICKER} text-white/35`}>Divergence D{i + 1}</div>
                    <h3 className="mt-1.5 font-display text-[17px] font-semibold leading-snug text-white">{d.topic}</h3>
                    <ul className="mt-3 space-y-2">
                      {d.says.map((s, k) => (
                        <li key={s} className="rounded-lg bg-white/[0.04] p-2.5">
                          <div className="font-mono text-[10px] uppercase tracking-wider text-white/35">{k === 0 ? "Source A" : "Source B"}</div>
                          <div className="mt-0.5 text-[12.5px] leading-snug text-white/70">{s}</div>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="rounded-xl border border-emerald-500/25 bg-emerald-500/[0.06] p-4">
                    <div className={`${KICKER} text-emerald-300`}>Tranché</div>
                    <p className="mt-2 text-[13px] leading-relaxed text-white/85">{d.ruling}</p>
                    <p className="mt-3 border-t border-white/10 pt-3 font-mono text-[11px] leading-relaxed text-emerald-200/70">Base : {d.basis}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>
      </Reveal>

      {/* ANNEXE JETÉS */}
      <Reveal>
        <section>
          <div className="mb-5 border-l-2 border-red-400/60 pl-4">
            <div className={`${KICKER} text-red-400/80`}>Annexe — règle « item sans preuve = item jeté »</div>
            <h2 className="mt-1.5 font-display text-[26px] font-semibold tracking-tight text-white sm:text-[32px]">
              {STATS.rejected} allégations rejetées, raison consignée
            </h2>
          </div>
          <Card className="!p-0 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[860px] border-collapse text-left">
                <thead>
                  <tr className="border-b border-white/10 bg-white/[0.04] text-[11px] uppercase tracking-wider text-white/55">
                    <th className="px-3 py-3">ID</th>
                    <th className="px-3 py-3">Allégation</th>
                    <th className="px-3 py-3">Verdict</th>
                    <th className="px-3 py-3">Raison du rejet</th>
                  </tr>
                </thead>
                <tbody>
                  {REJECTED.map((r) => (
                    <tr key={r.id} className="border-b border-white/[0.06] align-top transition hover:bg-white/[0.02]">
                      <td className="px-3 py-2.5 font-mono text-[11.5px] font-bold text-red-300/80">{r.id}</td>
                      <td className="px-3 py-2.5 text-[12px] leading-snug text-white/75">{r.claim}</td>
                      <td className="px-3 py-2.5 font-mono text-[10.5px] text-white/45">{r.verdict}</td>
                      <td className="px-3 py-2.5 text-[11.5px] leading-snug text-white/55">{r.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </section>
      </Reveal>

      {/* NON-GOALS */}
      <Reveal>
        <section>
          <div className="mb-5 border-l-2 border-white/20 pl-4">
            <div className={`${KICKER} text-white/40`}>Non-goals</div>
            <h2 className="mt-1.5 font-display text-[26px] font-semibold tracking-tight text-white sm:text-[32px]">
              Ce que ce speckit refuse explicitement de faire
            </h2>
          </div>
          <div className="grid gap-2.5 lg:grid-cols-2">
            {NON_GOALS.map((n) => (
              <div key={n.item} className="rounded-xl border border-white/10 bg-white/[0.03] p-3.5">
                <div className="text-[13px] font-semibold text-white">✕ {n.item}</div>
                <p className="mt-1 text-[12px] leading-snug text-white/55">{n.why}</p>
              </div>
            ))}
          </div>
        </section>
      </Reveal>

      {/* DÉCISIONS */}
      <section className="rounded-3xl border border-amber-400/25 bg-amber-400/[0.05] p-6 sm:p-8">
        <div className={`${KICKER} text-amber-300`}>Décisions demandées avant exécution</div>
        <div className="mt-4 grid gap-3 lg:grid-cols-3">
          {[
            {
              n: "1",
              t: "Confirmer ou fournir audits_livres + INDEX.md",
              d: "Sans eux, T-00 doit les produire avant toute clôture de tâche de contenu. Aucune exigence de conformité livres n'a été inventée.",
            },
            {
              n: "2",
              t: "Valider le classement « verrouillage » de B2/B3/B7",
              d: "Le code lu après l'audit contient les correctifs. Ce qui manque est le test de régression. Si à l'exécution le correctif est absent, la tâche bascule en correction.",
            },
            {
              n: "3",
              t: "Confirmer bookContent.json en lecture seule",
              d: "Source de vérité, jamais modifiée. Toute correction de contenu est une injection mécanique depuis ce fichier, pas une transcription manuelle.",
            },
          ].map((x) => (
            <div key={x.n} className="rounded-xl border border-white/10 bg-black/30 p-4">
              <div className="font-mono text-2xl font-bold text-amber-300">{x.n}</div>
              <div className="mt-1 text-[13.5px] font-semibold text-white">{x.t}</div>
              <p className="mt-1.5 text-[12px] leading-relaxed text-white/60">{x.d}</p>
            </div>
          ))}
        </div>
        <p className="mt-6 text-[13px] leading-relaxed text-white/65">
          <strong className="text-white">Le chiffre à retenir :</strong> {Math.round((STATS.rejected / STATS.sourceItems) * 100)} % des
          allégations sources ont été rejetées. L'erreur scientifique la plus grave (S-M1) était celle que l'application{" "}
          <em className="text-white">punissait chez l'élève tout en l'enseignant</em>. C'est pourquoi aucune exigence n'est admise sans ID
          d'audit + preuve attachée.
        </p>
      </section>
    </div>
  );
}
