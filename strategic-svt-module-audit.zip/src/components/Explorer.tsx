import { useMemo, useState } from "react";
import { CRITERIA, MODULES, UNITS, total, tierOf, type ModuleAudit, type Tier, type UnitId } from "../data/audit";
import { ACTION_LABEL, FAMILY_LABEL, TIER_META } from "../lib/compute";
import { Card, CriteriaBars, Pill, Score, SectionTitle, TierBadge } from "./ui";

type SortKey = "score" | "ratio" | "temps";

const ACTION_TONE: Record<string, "good" | "warn" | "bad"> = {
  garder: "good",
  optimiser: "warn",
  fusionner: "warn",
  supprimer: "bad",
};

function ModuleCard({ m, open, onToggle }: { m: ModuleAudit; open: boolean; onToggle: () => void }) {
  const t = total(m);
  const tier = tierOf(m);
  const meta = TIER_META[tier];
  return (
    <div
      className={`overflow-hidden rounded-2xl border transition ${
        open ? "border-white/25 bg-white/[0.06]" : "border-white/10 bg-white/[0.03] hover:border-white/20 hover:bg-white/[0.05]"
      }`}
    >
      <button onClick={onToggle} className="flex w-full items-start gap-4 p-4 text-left">
        <Score m={m} size={52} />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <TierBadge tier={tier} small />
            <span className="font-mono text-[10px] uppercase tracking-wider text-white/35">{FAMILY_LABEL[m.family]}</span>
          </div>
          <div className="mt-1.5 text-[14px] font-semibold leading-snug text-white">
            {m.fr} {m.ar && <span className="ml-1 font-normal text-white/45">· {m.ar}</span>}
          </div>
          <div className="mt-1 truncate font-mono text-[10.5px] text-white/35">{m.source}</div>
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            {m.units.map((u) => (
              <span key={u} className="rounded bg-white/5 px-1.5 py-0.5 text-[10px] text-white/50">
                {u === "HORS" ? "hors programme" : u}
              </span>
            ))}
            <Pill tone={ACTION_TONE[m.action]}>{ACTION_LABEL[m.action]}</Pill>
            {m.temps > 0 && (
              <span className="font-mono text-[10px] text-white/40">
                {m.temps} h · +{m.gain} pt · {m.temps > 0 ? (m.gain / m.temps).toFixed(2) : "0"} pt/h
              </span>
            )}
          </div>
        </div>
        <span className={`mt-1 shrink-0 text-white/30 transition ${open ? "rotate-180" : ""}`}>▾</span>
      </button>

      {open && (
        <div className="border-t border-white/10 bg-black/25 p-4">
          <div className="grid gap-5 lg:grid-cols-[1fr_1.4fr]">
            <div>
              <div className="mb-2 font-mono text-[10px] uppercase tracking-[0.18em] text-white/40">Évaluation /20</div>
              <CriteriaBars m={m} />
              <div className="mt-3 grid grid-cols-2 gap-2 text-[11px]">
                <div className="rounded-lg bg-white/5 p-2">
                  <div className="text-white/40">Fréquence au BAC 2019-2025</div>
                  <div className="mt-0.5 text-white/80">{m.freq}</div>
                </div>
                <div className="rounded-lg bg-white/5 p-2">
                  <div className="text-white/40">Total</div>
                  <div className="mt-0.5 font-mono font-bold" style={{ color: meta.color }}>
                    {t}/20 · Tier {tier}
                  </div>
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <div>
                <div className="mb-1 font-mono text-[10px] uppercase tracking-[0.18em] text-white/40">Justification (1 phrase)</div>
                <p className="text-[13px] leading-relaxed text-white/80">{m.verdict}</p>
              </div>
              {m.fix && (
                <div>
                  <div className="mb-1 font-mono text-[10px] uppercase tracking-[0.18em] text-amber-400/70">Correctif imposé</div>
                  <p className="rounded-lg border border-amber-500/25 bg-amber-500/[0.07] p-3 text-[13px] leading-relaxed text-amber-100/90">{m.fix}</p>
                </div>
              )}
              {m.fusionInto && (
                <div>
                  <div className="mb-1 font-mono text-[10px] uppercase tracking-[0.18em] text-white/40">Destination de la fusion</div>
                  <p className="text-[13px] text-white/75">
                    → {MODULES.find((x) => x.id === m.fusionInto)?.fr ?? m.fusionInto}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function Explorer() {
  const [tier, setTier] = useState<Tier | "all">("all");
  const [unit, setUnit] = useState<UnitId | "all">("all");
  const [family, setFamily] = useState<string>("all");
  const [action, setAction] = useState<string>("all");
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<SortKey>("score");
  const [open, setOpen] = useState<string | null>("boussole");

  const list = useMemo(() => {
    let out = MODULES.filter((m) => {
      if (tier !== "all" && tierOf(m) !== tier) return false;
      if (unit !== "all" && !m.units.includes(unit)) return false;
      if (family !== "all" && m.family !== family) return false;
      if (action !== "all" && m.action !== action) return false;
      if (q.trim()) {
        const s = `${m.fr} ${m.ar ?? ""} ${m.source} ${m.verdict}`.toLowerCase();
        if (!s.includes(q.toLowerCase())) return false;
      }
      return true;
    });
    out = [...out].sort((a, b) => {
      if (sort === "score") return total(b) - total(a);
      if (sort === "temps") return b.temps - a.temps;
      return b.gain / Math.max(b.temps, 0.5) - a.gain / Math.max(a.temps, 0.5);
    });
    return out;
  }, [tier, unit, family, action, q, sort]);

  const select =
    "rounded-lg border border-white/10 bg-white/[0.05] px-2.5 py-1.5 text-[12px] text-white/80 outline-none focus:border-amber-500/50";
  const label = "font-mono text-[10px] uppercase tracking-widest text-white/35";

  return (
    <div>
      <SectionTitle
        kicker="Étape 1 · Audit individuel"
        title={`${list.length} module${list.length > 1 ? "s" : ""} évalué${list.length > 1 ? "s" : ""} sur /20`}
        sub="Chaque note est justifiée en une phrase. Cliquez sur une ligne pour ouvrir le détail des 6 critères, la fréquence BAC et la décision."
      />

      <div className="mb-5 flex flex-wrap items-end gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
        <div>
          <div className={label}>Recherche</div>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="boussole, immunité, gamification…"
            className={`${select} mt-1 w-52`}
          />
        </div>
        <div>
          <div className={label}>Tier</div>
          <select value={tier} onChange={(e) => setTier(e.target.value === "all" ? "all" : (Number(e.target.value) as Tier))} className={`${select} mt-1`}>
            <option value="all">Tous</option>
            <option value={1}>🟢 Tier 1 · Indispensable</option>
            <option value={2}>🟡 Tier 2 · Utile</option>
            <option value={3}>🟠 Tier 3 · Marginal</option>
            <option value={4}>🔴 Tier 4 · Bruit</option>
          </select>
        </div>
        <div>
          <div className={label}>Unité</div>
          <select value={unit} onChange={(e) => setUnit(e.target.value as UnitId | "all")} className={`${select} mt-1`}>
            <option value="all">Toutes</option>
            {UNITS.map((u) => (
              <option key={u.id} value={u.id}>
                {u.id} — {u.short}
              </option>
            ))}
          </select>
        </div>
        <div>
          <div className={label}>Famille</div>
          <select value={family} onChange={(e) => setFamily(e.target.value)} className={`${select} mt-1`}>
            <option value="all">Toutes</option>
            {Object.entries(FAMILY_LABEL).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
        </div>
        <div>
          <div className={label}>Décision</div>
          <select value={action} onChange={(e) => setAction(e.target.value)} className={`${select} mt-1`}>
            <option value="all">Toutes</option>
            <option value="garder">Garder</option>
            <option value="optimiser">Optimiser</option>
            <option value="fusionner">Fusionner</option>
            <option value="supprimer">Supprimer</option>
          </select>
        </div>
        <div>
          <div className={label}>Tri</div>
          <select value={sort} onChange={(e) => setSort(e.target.value as SortKey)} className={`${select} mt-1`}>
            <option value="score">Note décroissante</option>
            <option value="ratio">Rentabilité pt/h</option>
            <option value="temps">Temps élève</option>
          </select>
        </div>
        <button
          onClick={() => {
            setTier("all");
            setUnit("all");
            setFamily("all");
            setAction("all");
            setQ("");
          }}
          className="rounded-lg border border-white/10 px-3 py-1.5 text-[12px] text-white/60 transition hover:border-white/30 hover:text-white"
        >
          Réinitialiser
        </button>
      </div>

      <div className="space-y-2.5">
        {list.map((m) => (
          <ModuleCard key={m.id} m={m} open={open === m.id} onToggle={() => setOpen(open === m.id ? null : m.id)} />
        ))}
        {list.length === 0 && (
          <Card>
            <p className="text-sm text-white/60">Aucun module ne correspond à ces filtres.</p>
          </Card>
        )}
      </div>

      <div className="mt-6 grid gap-2 rounded-2xl border border-white/10 bg-white/[0.02] p-4 sm:grid-cols-2 lg:grid-cols-3">
        {CRITERIA.map((c) => (
          <div key={c.key} className="text-[11.5px] text-white/55">
            <span className="font-mono text-white/80">{c.key}</span> · <span className="text-white/75">{c.label}</span> — /{c.max}
          </div>
        ))}
        <div className="text-[11.5px] text-white/55 sm:col-span-2 lg:col-span-3">
          Barèmes des tiers : 🟢 16-20 · 🟡 12-15 · 🟠 8-11 · 🔴 0-7 — unités listées :{" "}
          {UNITS.map((u) => `${u.id} ${u.short}`).join(" · ")}
        </div>
      </div>
    </div>
  );
}
