import { useEffect, useMemo, useState } from "react";
import { PHASES, SEVERITY_META, SEVERITY_ORDER, TICKETS, speckitMarkdown, type PhaseId, type Severity, type Ticket } from "../data/speckit";
import { Card, Pill } from "./ui";

const KICKER = "font-mono text-[10.5px] uppercase tracking-[0.22em]";
const KEY = "speckit-svt-done-v1";

function TicketCard({ t, done, onToggle, open, onOpen }: { t: Ticket; done: boolean; onToggle: () => void; open: boolean; onOpen: () => void }) {
  const sev = SEVERITY_META[t.severity];
  return (
    <div
      className={`overflow-hidden rounded-xl border transition ${
        done
          ? "border-emerald-500/30 bg-emerald-500/[0.05]"
          : open
            ? "border-white/25 bg-white/[0.055]"
            : "border-white/10 bg-white/[0.03] hover:border-white/20"
      }`}
    >
      <div className="flex items-start gap-3 p-4">
        <button
          onClick={onToggle}
          title={done ? "Marquer à refaire" : "Marquer comme terminé"}
          className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-md border text-[12px] transition ${
            done ? "border-emerald-400 bg-emerald-400 text-slate-900" : "border-white/25 text-transparent hover:border-emerald-400/60"
          }`}
        >
          ✓
        </button>
        <button onClick={onOpen} className="min-w-0 flex-1 text-left">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-mono text-[11px] font-bold text-white/50">{t.id}</span>
            <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider ${sev.bg}`} style={{ color: sev.color }}>
              {sev.label}
            </span>
            <span className="font-mono text-[10.5px] text-white/35">{t.effort}</span>
            <span className={`ml-auto text-white/30 transition ${open ? "rotate-180" : ""}`}>▾</span>
          </div>
          <div className={`mt-1 text-[14px] font-semibold leading-snug ${done ? "text-white/45 line-through" : "text-white"}`}>{t.title}</div>
          <div className="mt-1 truncate font-mono text-[10.5px] text-white/35">{t.files.join(" · ")}</div>
        </button>
      </div>

      {open && (
        <div className="space-y-4 border-t border-white/10 bg-black/25 p-4 sm:p-5">
          <div className="grid gap-4 lg:grid-cols-2">
            <div>
              <div className={`${KICKER} mb-1.5 text-red-300/80`}>Problème</div>
              <p className="text-[13px] leading-relaxed text-white/80">{t.problem}</p>
              <pre className="mt-2 overflow-x-auto whitespace-pre-wrap break-words rounded-lg bg-black/45 p-2.5 font-mono text-[11px] leading-relaxed text-amber-200/80">
                {t.proof}
              </pre>
              <div className="mt-2 font-mono text-[10.5px] text-white/35">Source : {t.audit}</div>
            </div>
            <div>
              <div className={`${KICKER} mb-1.5 text-emerald-300/80`}>Spécification — dans l'ordre</div>
              <ol className="space-y-1.5">
                {t.spec.map((s, i) => (
                  <li key={i} className="flex gap-2 text-[12.5px] leading-snug text-white/75">
                    <span className="mt-0.5 font-mono text-[10px] text-emerald-400/70">{String(i + 1).padStart(2, "0")}</span>
                    {s}
                  </li>
                ))}
              </ol>
            </div>
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3.5">
              <div className={`${KICKER} mb-2 text-white/40`}>Critères d'acceptation</div>
              <ul className="space-y-1.5">
                {t.acceptance.map((a) => (
                  <li key={a} className="flex gap-2 text-[12.5px] leading-snug text-white/75">
                    <span className="mt-[3px] grid h-3.5 w-3.5 shrink-0 place-items-center rounded border border-white/25 text-[9px] text-transparent">✓</span>
                    {a}
                  </li>
                ))}
              </ul>
            </div>
            <div className="space-y-3">
              <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3.5">
                <div className={`${KICKER} mb-1 text-white/40`}>Test automatisé exigé</div>
                <p className="font-mono text-[11.5px] leading-relaxed text-white/65">{t.test}</p>
              </div>
              <div className="rounded-xl border border-emerald-500/25 bg-emerald-500/[0.06] p-3.5">
                <div className={`${KICKER} mb-1 text-emerald-300/80`}>Gain élève</div>
                <p className="text-[12.5px] leading-relaxed text-white/80">{t.impact}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function SpecKit() {
  const [phase, setPhase] = useState<PhaseId | "all">("all");
  const [sev, setSev] = useState<Severity | "all">("all");
  const [q, setQ] = useState("");
  const [openId, setOpenId] = useState<string | null>("S0-03");
  const [done, setDone] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setDone(JSON.parse(raw));
    } catch {
      /* stockage indisponible */
    }
  }, []);

  const toggleDone = (id: string) =>
    setDone((prev) => {
      const next = prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id];
      try {
        localStorage.setItem(KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });

  const list = useMemo(
    () =>
      TICKETS.filter(
        (t) =>
          (phase === "all" || t.phase === phase) &&
          (sev === "all" || t.severity === sev) &&
          (!q.trim() || `${t.id} ${t.title} ${t.problem} ${t.files.join(" ")} ${t.audit}`.toLowerCase().includes(q.toLowerCase())),
      ),
    [phase, sev, q],
  );

  const pct = Math.round((done.length / TICKETS.length) * 100);
  const bloquants = TICKETS.filter((t) => t.severity === "bloquant");
  const bloquantsDone = bloquants.filter((t) => done.includes(t.id)).length;

  const copyAll = async () => {
    try {
      await navigator.clipboard.writeText(speckitMarkdown());
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      /* presse-papiers indisponible */
    }
  };

  const select = "rounded-lg border border-white/10 bg-white/[0.05] px-2.5 py-1.5 text-[12px] text-white/80 outline-none focus:border-amber-500/50";
  const label = "font-mono text-[10px] uppercase tracking-widest text-white/35";

  return (
    <div className="space-y-10">
      {/* VERDICT */}
      <section className="relative overflow-hidden rounded-3xl border border-white/12 bg-[linear-gradient(135deg,rgba(245,158,11,.10),rgba(16,185,129,.06)_50%,transparent)] p-6 sm:p-9">
        <div className="pointer-events-none absolute -right-16 -top-20 h-64 w-64 rounded-full bg-amber-400/10 blur-3xl" />
        <div className="relative">
          <div className={`${KICKER} text-amber-300`}>SpecKit — suite aux audits</div>
          <h2 className="mt-3 font-display text-[28px] font-semibold leading-[1.12] tracking-tight text-white sm:text-[40px]">
            22 correctifs pour une app que l'élève peut croire.
          </h2>
          <p className="mt-4 max-w-3xl text-[14px] leading-relaxed text-white/70">
            Ce n'est plus un audit : c'est le cahier de charges. Chaque ticket dit <strong className="text-white">quoi</strong> corriger
            (preuve littérale du dépôt), <strong className="text-white">comment</strong> (étapes dans l'ordre), et{" "}
            <strong className="text-white">quand c'est fini</strong> (critères d'acceptation + test exigé). Ordre non négociable :{" "}
            <span className="font-mono text-amber-200">S0 → S1 → S2 → S3 → S4</span>. Donnez ce document tel quel à votre agent IA dans
            VS Code, ticket par ticket.
          </p>
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <Pill tone="bad">{bloquants.length} bloquants</Pill>
            <Pill tone="warn">{TICKETS.filter((t) => t.severity === "critique").length} critiques</Pill>
            <Pill tone="neutral">{TICKETS.filter((t) => t.severity === "majeur").length} majeurs</Pill>
            <Pill tone="good">~5 semaines solo</Pill>
            <button
              onClick={copyAll}
              className="ml-auto rounded-xl bg-amber-400 px-4 py-2 text-[13px] font-bold text-slate-900 transition hover:bg-amber-300"
            >
              {copied ? "✓ Copié — collez dans VS Code" : "Copier tout le SpecKit (Markdown)"}
            </button>
          </div>
          <div className="mt-5 flex items-center gap-4 rounded-2xl border border-white/10 bg-black/30 p-4">
            <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-red-400 via-amber-400 to-emerald-400 transition-all duration-500"
                style={{ width: `${pct}%` }}
              />
            </div>
            <span className="font-mono text-[12px] tabular-nums text-white/70">
              {done.length}/{TICKETS.length} · bloquants {bloquantsDone}/{bloquants.length}
            </span>
          </div>
        </div>
      </section>

      {/* PHASES */}
      <section>
        <div className="mb-4 flex items-center justify-between">
          <div className={`${KICKER} text-white/40`}>Les 5 phases — cliquer filtre les tickets</div>
        </div>
        <div className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-5">
          {PHASES.map((p, i) => {
            const n = TICKETS.filter((t) => t.phase === p.id).length;
            const d = TICKETS.filter((t) => t.phase === p.id && done.includes(t.id)).length;
            const active = phase === p.id;
            return (
              <button
                key={p.id}
                onClick={() => setPhase(active ? "all" : p.id)}
                className={`rounded-2xl border p-3.5 text-left transition ${
                  active ? "border-amber-400/60 bg-amber-400/[0.08]" : "border-white/10 bg-white/[0.03] hover:border-white/25"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[12px] font-bold text-amber-300">{p.id}</span>
                  <span className="font-mono text-[10.5px] tabular-nums text-white/40">
                    {d}/{n}
                  </span>
                </div>
                <div className="mt-1 text-[13px] font-semibold leading-tight text-white">{p.title}</div>
                <div className="mt-0.5 font-mono text-[10px] text-white/35">{p.duration}</div>
                <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full bg-emerald-400 transition-all duration-500" style={{ width: `${(d / n) * 100}%` }} />
                </div>
                <div className="mt-2 hidden text-[11px] leading-snug text-white/50 lg:block">
                  <span className="font-mono text-white/30">S{i + 1} · </span>Sortie : {p.gate.slice(0, 72)}…
                </div>
              </button>
            );
          })}
        </div>
        {phase !== "all" && (
          <Card className="mt-3 border-amber-500/25 bg-amber-500/[0.05]">
            <div className="text-[13px] font-semibold text-white">
              {PHASES.find((p) => p.id === phase)?.id} — {PHASES.find((p) => p.id === phase)?.title}
            </div>
            <p className="mt-1 text-[12.5px] leading-relaxed text-white/70">
              <strong className="text-white/85">But :</strong> {PHASES.find((p) => p.id === phase)?.goal}
            </p>
            <p className="mt-1 font-mono text-[11.5px] text-emerald-300">
              → Sortie : {PHASES.find((p) => p.id === phase)?.gate}
            </p>
          </Card>
        )}
      </section>

      {/* FILTRES */}
      <div className="flex flex-wrap items-end gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
        <div>
          <div className={label}>Recherche</div>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="streak, indice, hors programme…" className={`${select} mt-1 w-56`} />
        </div>
        <div>
          <div className={label}>Sévérité</div>
          <select value={sev} onChange={(e) => setSev(e.target.value as Severity | "all")} className={`${select} mt-1`}>
            <option value="all">Toutes</option>
            {SEVERITY_ORDER.map((s) => (
              <option key={s} value={s}>
                {SEVERITY_META[s].label} ({TICKETS.filter((t) => t.severity === s).length})
              </option>
            ))}
          </select>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <span className="font-mono text-[11px] text-white/40">
            {list.length}/{TICKETS.length} tickets
          </span>
          <button
            onClick={() => {
              setPhase("all");
              setSev("all");
              setQ("");
            }}
            className="rounded-lg border border-white/10 px-3 py-1.5 text-[12px] text-white/60 transition hover:border-white/30 hover:text-white"
          >
            Réinitialiser
          </button>
        </div>
      </div>

      {/* TICKETS */}
      <section className="space-y-2.5">
        {list.map((t) => (
          <TicketCard key={t.id} t={t} done={done.includes(t.id)} onToggle={() => toggleDone(t.id)} open={openId === t.id} onOpen={() => setOpenId(openId === t.id ? null : t.id)} />
        ))}
        {list.length === 0 && (
          <Card>
            <p className="text-sm text-white/60">Aucun ticket ne correspond à ces filtres.</p>
          </Card>
        )}
      </section>

      {/* RÈGLE D'OR */}
      <section className="rounded-3xl border border-white/12 bg-[linear-gradient(160deg,rgba(255,255,255,.05),transparent)] p-6 sm:p-8">
        <div className={`${KICKER} text-white/40`}>Règle d'exécution — à coller en tête de chaque session de travail</div>
        <pre className="mt-3 overflow-x-auto whitespace-pre-wrap rounded-xl bg-black/40 p-4 font-mono text-[12px] leading-relaxed text-white/75">
{`Tu travailles sur Kunz El Ouloum (BAC SVT Algérie).
Règles permanentes :
1. Un ticket à la fois, dans l'ordre S0 → S4. Jamais de ticket S(n+1) si un bloquant Sn reste ouvert.
2. Chaque ticket se termine par : test vert + critères d'acceptation cochés + commit message "fix(<id>): <titre>".
3. Interdits : LLM côté client, tracking/analytics, gamification (flamme, badges, coffres), contenu hors programme 2011+.
4. Tout texte élève en arabe (darija acceptée pour le soutien), tout commentaire de code en français.
5. Si une spec contredit le code réel, le code réel gagne : signale-le au lieu d'inventer.`}
        </pre>
        <p className="mt-4 text-[13px] leading-relaxed text-white/60">
          Et la phrase qui doit rester affichée au-dessus de l'écran pendant les 5 semaines :{" "}
          <strong className="text-white/85">corriger R1 (indices) et S0-03 (métrique honnête) vaut à eux seuls la moitié des 22
          tickets</strong> — parce que l'un empêche l'élève de tricher contre lui-même, et l'autre empêche l'app de mentir à l'élève.
        </p>
      </section>
    </div>
  );
}
