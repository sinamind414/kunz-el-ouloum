import { ARCHITECTURE, MODULES, ROADMAP, total, tierOf } from "../data/audit";
import { STATS, TIER_META } from "../lib/compute";
import { Card, Pill, SectionTitle, TierBadge } from "./ui";

const TOP5 = ["boussole", "correcteur", "archetypes", "tahlil", "goldSummaries"];

export default function Decisions() {
  const toDelete = [...STATS.suppr, ...STATS.byTier[3].filter((m) => m.action === "supprimer")];
  const toMerge = MODULES.filter((m) => m.action === "fusionner");
  const toOptim = MODULES.filter((m) => m.action === "optimiser");
  const top5 = TOP5.map((id) => MODULES.find((m) => m.id === id)!).filter(Boolean);

  return (
    <div className="space-y-12">
      {/* 1. SUPPRESSIONS */}
      <div>
        <SectionTitle
          kicker="Étape 4.1"
          title={`${toDelete.length} modules à supprimer immédiatement`}
          sub="Aucune migration de contenu nécessaire : ce sont des écrans, des portails ou des contenus hors barème. Suppression = gain de temps de dev et baisse de la charge cognitive."
        />
        <div className="grid gap-2.5 lg:grid-cols-2">
          {toDelete.map((m) => (
            <div key={m.id} className="flex items-start gap-3 rounded-xl border border-red-500/20 bg-red-500/[0.05] p-3.5">
              <span className="mt-0.5 font-mono text-[11px] font-bold text-red-400">{total(m)}/20</span>
              <div className="min-w-0">
                <div className="text-[13.5px] font-semibold text-white">{m.fr}</div>
                <div className="mt-0.5 truncate font-mono text-[10.5px] text-white/35">{m.source}</div>
                <p className="mt-1.5 text-[12.5px] leading-snug text-white/65">{m.verdict}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 2. FUSIONS */}
      <div>
        <SectionTitle
          kicker="Étape 4.2"
          title={`${toMerge.length} modules à fusionner`}
          sub="Règle appliquée : un seul point d'entrée par intention d'apprentissage. Le contenu n'est jamais perdu, il est déplacé dans le module de destination."
        />
        <Card className="!p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] border-collapse text-left">
              <thead>
                <tr className="border-b border-white/10 bg-white/[0.04] text-[11px] uppercase tracking-wider text-white/60">
                  <th className="px-4 py-3">Module absorbé</th>
                  <th className="px-4 py-3">Note</th>
                  <th className="px-4 py-3">Module de destination</th>
                  <th className="px-4 py-3">Ce qu'il faut conserver</th>
                </tr>
              </thead>
              <tbody>
                {toMerge.map((m) => (
                  <tr key={m.id} className="border-b border-white/[0.06] align-top hover:bg-white/[0.02]">
                    <td className="px-4 py-3">
                      <div className="text-[13px] font-medium text-white">{m.fr}</div>
                      <div className="font-mono text-[10.5px] text-white/35">{m.source}</div>
                    </td>
                    <td className="px-4 py-3 font-mono text-[12px] tabular-nums" style={{ color: TIER_META[tierOf(m)].color }}>
                      {total(m)}
                    </td>
                    <td className="px-4 py-3 text-[13px] text-emerald-300">
                      → {MODULES.find((x) => x.id === m.fusionInto)?.fr ?? "—"}
                    </td>
                    <td className="px-4 py-3 text-[12.5px] leading-snug text-white/65">{m.fix ?? "Contenu intégré tel quel."}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <div className="mt-4 grid gap-2.5 lg:grid-cols-2">
          {toOptim.map((m) => (
            <div key={m.id} className="rounded-xl border border-amber-500/20 bg-amber-500/[0.04] p-3.5">
              <div className="flex items-center gap-2">
                <TierBadge tier={tierOf(m)} small />
                <span className="font-mono text-[11px] text-amber-300">{total(m)}/20</span>
                <span className="text-[13px] font-semibold text-white">{m.fr}</span>
              </div>
              <p className="mt-1.5 text-[12.5px] leading-snug text-white/65">{m.fix}</p>
            </div>
          ))}
        </div>
      </div>

      {/* 3. TOP 5 */}
      <div>
        <SectionTitle
          kicker="Étape 4.3"
          title="Les 5 modules les plus rentables pour viser 14+/20"
          sub="Ordre imposé. Un élève qui suit ces 5 modules dans cet ordre couvre à lui seul l'essentiel du barème de rédaction et de restitution."
        />
        <div className="space-y-2.5">
          {top5.map((m, i) => (
            <div key={m.id} className="flex items-start gap-4 rounded-xl border border-emerald-500/20 bg-emerald-500/[0.05] p-4">
              <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-emerald-500/15 font-mono text-sm font-bold text-emerald-300">
                {i + 1}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[14px] font-semibold text-white">{m.fr}</span>
                  <Pill tone="good">
                    {m.temps} h · +{m.gain} pts
                  </Pill>
                  <Pill>{(m.gain / m.temps).toFixed(2)} pt/h</Pill>
                </div>
                <p className="mt-1 text-[12.5px] leading-snug text-white/65">{m.verdict}</p>
              </div>
            </div>
          ))}
        </div>
        <Card className="mt-4">
          <p className="text-[13px] leading-relaxed text-white/75">
            <strong className="text-white">Règle de priorité élève :</strong> la Boussole d'abord (sinon il écrit mal ce qu'il sait), le Correcteur ensuite
            (sinon il répète ses fautes), les Archétypes en troisième (sinon il révise dans le vide), le Mur d'analyse en quatrième (c'est là que se jouent
            les 8-10 pts), les Fiches or en dernier (la veille de l'épreuve). Tout le reste est optionnel et doit être conditionné au niveau atteint.
          </p>
        </Card>
      </div>

      {/* 5. ARCHITECTURE */}
      <div>
        <SectionTitle
          kicker="Étape 4.5"
          title="Architecture finale : 49 entrées → 12 modules en 3 hub"
          sub="Trois hub, quatre modules chacun, un seul point d'entrée par intention. Aucun contenu du programme n'est perdu dans l'opération."
        />
        <div className="grid gap-4 lg:grid-cols-3">
          {ARCHITECTURE.map((h, i) => (
            <Card
              key={h.name}
              className={
                i === 0
                  ? "border-emerald-500/25"
                  : i === 1
                    ? "border-amber-500/25"
                    : "border-violet-500/25"
              }
            >
              <div className="font-mono text-[11px] uppercase tracking-[0.18em] text-white/45">{h.role}</div>
              <h3 className="mt-1 mb-4 text-lg font-semibold text-white">{h.name}</h3>
              <ol className="space-y-3">
                {h.modules.map((mod) => (
                  <li key={mod.n} className="border-t border-white/[0.07] pt-3 first:border-0 first:pt-0">
                    <div className="flex items-start gap-2">
                      <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded bg-white/10 font-mono text-[10px] text-white/70">
                        {mod.n}
                      </span>
                      <div>
                        <div className="text-[13px] font-medium leading-snug text-white">{mod.title}</div>
                        <div className="mt-1 text-[11.5px] leading-snug text-white/45">absorbe : {mod.absorbs}</div>
                      </div>
                    </div>
                  </li>
                ))}
              </ol>
            </Card>
          ))}
        </div>
      </div>

      {/* ROADMAP */}
      <div>
        <SectionTitle kicker="Exécution" title="Feuille de route en 4 semaines" />
        <div className="grid gap-3 lg:grid-cols-2">
          {ROADMAP.map((r) => (
            <Card key={r.phase}>
              <div className="mb-1.5 flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-amber-400" />
                <span className="font-mono text-[12px] uppercase tracking-wider text-amber-300">{r.phase}</span>
              </div>
              <p className="text-[13px] leading-relaxed text-white/80">{r.action}</p>
              <div className="mt-2 font-mono text-[11px] text-emerald-300">→ {r.gain}</div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
