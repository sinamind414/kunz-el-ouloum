import { GAPS, MODULES, UNITS, tierOf, total, type Tier, type UnitId } from "../data/audit";
import { TIER_META } from "../lib/compute";
import { Card, Pill, SectionTitle } from "./ui";

const NAMES: Record<UnitId, string> = {
  U1: "U1 — Spécialisation fonctionnelle des protéines (synthèse, structure, enzymes)",
  U2: "U2 — Immunologie (défense de l'organisme, VIH/sida)",
  U3: "U3 — Communication nerveuse (synapse, potentiel d'action)",
  U4: "U4 — Transformations énergétiques (photosynthèse, respiration)",
  U5: "U5 — Tectonique des plaques & structures géologiques",
  U0: "Transversal — Méthodologie, analyse de documents, écriture",
  HORS: "Hors apprentissage — gamification, technique, contenu externe",
};

const PRIO_TONE = { critique: "bad", haute: "warn", moyenne: "neutral" } as const;

export default function UnitsView() {
  const rows = UNITS;

  const cells = (u: UnitId, t: Tier | "34") =>
    MODULES.filter((m) => m.units.includes(u) && (t === "34" ? total(m) < 12 : tierOf(m) === t)).map((m) => m.fr);

  return (
    <div className="space-y-10">
      <div>
        <SectionTitle
          kicker="Étape 3 · Synthèse par unité"
          title="Tableau de répartition des modules par unité du programme"
          sub="Le découpage retenu est celui du programme officiel de 3e AS (2011+). La colonne « Poids BAC » est la part moyenne du barème par exercice."
        />
        <Card className="!p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[880px] border-collapse text-left">
              <thead>
                <tr className="border-b border-white/10 bg-white/[0.04]">
                  {["Unité du programme", "Poids BAC", "Modules", "🟢 Tier 1", "🟡 Tier 2", "🟠🔴 Tier 3-4"].map((h) => (
                    <th key={h} className="px-4 py-3 text-[11px] font-semibold uppercase tracking-wider text-white/60">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((u) => {
                  const t1 = cells(u.id, 1);
                  const t2 = cells(u.id, 2);
                  const t34 = cells(u.id, "34");
                  return (
                    <tr key={u.id} className="border-b border-white/[0.06] align-top transition hover:bg-white/[0.02]">
                      <td className="px-4 py-3">
                        <div className="text-[13px] font-medium text-white">{NAMES[u.id]}</div>
                        {u.ar && <div className="mt-0.5 text-[12px] text-white/40" dir="rtl">{u.ar}</div>}
                      </td>
                      <td className="px-4 py-3 font-mono text-[12px] tabular-nums text-amber-300/90">{u.weight}</td>
                      <td className="px-4 py-3 font-mono text-[12px] tabular-nums text-white/70">{t1.length + t2.length + t34.length}</td>
                      <Cell items={t1} color={TIER_META[1].color} />
                      <Cell items={t2} color={TIER_META[2].color} />
                      <Cell items={t34} color={TIER_META[4].color} />
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>

        <Card className="mt-4 border-amber-500/25 bg-amber-500/[0.05]">
          <div className="mb-2 text-[13px] font-semibold text-white">Correspondance avec votre grille de départ</div>
          <ul className="space-y-1.5 text-[13px] leading-relaxed text-white/70">
            <li>
              • <span className="text-white">Immunologie</span> → devient <span className="font-mono text-amber-300">U2</span> (elle est un thème du domaine
              « spécialisation fonctionnelle des protéines », pas un domaine autonome).
            </li>
            <li>
              • <span className="text-white">Neurophysiologie</span> → devient <span className="font-mono text-amber-300">U3</span> (même domaine).
            </li>
            <li>
              • <span className="text-white">Reproduction des plantes, Génétique, Évolution</span> → <strong className="text-red-300">aucune ligne</strong> :
              ces unités ont été retirées du programme de 3<sup>e</sup> AS et ne peuvent plus tomber au BAC. Y consacrer des modules est une perte sèche.
            </li>
            <li>
              • Les unités <span className="font-mono text-amber-300">U4 Transformations énergétiques</span> et{" "}
              <span className="font-mono text-amber-300">U5 Tectonique</span> (8-10 pts chacune) sont celles qui comptent le plus et qui sont le moins
              accompagnées par des modules dédiés.
            </li>
          </ul>
        </Card>
      </div>

      <div>
        <SectionTitle
          kicker="Étape 4.4 · Trous du programme"
          title="Points BAC fréquents aujourd'hui NON couverts"
          sub="C'est le vrai problème de l'application : elle contient trop de modules qui ne rapportent rien et n'en contient pas assez sur ceux qui rapportent."
        />
        <div className="grid gap-3 lg:grid-cols-2">
          {GAPS.map((g) => (
            <Card
              key={g.title}
              className={
                g.priority === "critique"
                  ? "border-red-500/30 bg-red-500/[0.05]"
                  : g.priority === "haute"
                    ? "border-amber-500/25 bg-amber-500/[0.04]"
                    : ""
              }
            >
              <div className="mb-2 flex items-start justify-between gap-3">
                <h3 className="text-[14px] font-semibold leading-snug text-white">{g.title}</h3>
                <Pill tone={PRIO_TONE[g.priority]}>{g.priority}</Pill>
              </div>
              <p className="text-[13px] leading-relaxed text-white/70">{g.detail}</p>
              <div className="mt-3 font-mono text-[11px] text-emerald-300">Impact barème : {g.impact}</div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

function Cell({ items, color }: { items: string[]; color: string }) {
  return (
    <td className="px-4 py-3">
      {items.length === 0 ? (
        <span className="text-[12px] text-white/25">—</span>
      ) : (
        <ul className="space-y-1">
          {items.map((i) => (
            <li key={i} className="flex gap-1.5 text-[12px] leading-snug text-white/70">
              <span style={{ color }}>•</span>
              <span>{i}</span>
            </li>
          ))}
        </ul>
      )}
    </td>
  );
}
