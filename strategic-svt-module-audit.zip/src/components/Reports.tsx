import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  CONTRADICTIONS,
  CRIT,
  METRICS,
  PITCH,
  PLAN,
  REPORTS,
  STORE,
  weighted,
  type Report,
} from "../data/reports";
import { Card, Pill } from "./ui";

/* ── révélation au scroll ── */
function Reveal({ children, delay = 0, className = "" }: { children: ReactNode; delay?: number; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setShown(true);
          io.disconnect();
        }
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: shown ? 1 : 0,
        transform: shown ? "none" : "translateY(18px)",
        transition: `opacity .6s cubic-bezier(.22,.61,.36,1) ${delay}ms, transform .6s cubic-bezier(.22,.61,.36,1) ${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

const KICKER = "font-mono text-[10.5px] uppercase tracking-[0.22em]";

function Head({ kicker, title, sub }: { kicker: string; title: string; sub?: string }) {
  return (
    <div className="mb-6 border-l-2 border-amber-400/60 pl-4">
      <div className={`${KICKER} text-amber-400/80`}>{kicker}</div>
      <h2 className="mt-1.5 font-display text-[26px] font-semibold leading-tight tracking-tight text-white sm:text-[32px]">{title}</h2>
      {sub && <p className="mt-2 max-w-3xl text-[13.5px] leading-relaxed text-white/55">{sub}</p>}
    </div>
  );
}

const RANK_TONE = ["#10b981", "#34d399", "#f59e0b", "#f59e0b", "#f97316", "#ef4444"];

function ReportRow({ r, i, open, onToggle }: { r: Report; i: number; open: boolean; onToggle: () => void }) {
  const w = weighted(r);
  const color = RANK_TONE[i] ?? "#94a3b8";
  return (
    <div
      className={`overflow-hidden rounded-xl border transition-all duration-300 ${
        open ? "border-white/25 bg-white/[0.055]" : "border-white/10 bg-white/[0.025] hover:border-white/20 hover:bg-white/[0.045]"
      }`}
    >
      <button onClick={onToggle} className="group grid w-full grid-cols-[34px_1fr_auto] items-center gap-3 p-4 text-left sm:grid-cols-[34px_1.6fr_1fr_auto]">
        <span className="font-mono text-lg font-bold tabular-nums" style={{ color }}>
          {String(i + 1).padStart(2, "0")}
        </span>
        <span className="min-w-0">
          <span className="block truncate text-[14px] font-semibold text-white">{r.title}</span>
          <span className="mt-0.5 block font-mono text-[10px] uppercase tracking-wider" style={{ color }}>
            {r.role}
          </span>
        </span>
        <span className="hidden min-w-0 sm:block">
          <span className="mt-1 block h-1.5 overflow-hidden rounded-full bg-white/10">
            <span
              className="block h-full rounded-full transition-all duration-1000"
              style={{ width: `${(w / 10) * 100}%`, background: color }}
            />
          </span>
          <span className="mt-1 block truncate text-[11px] text-white/40">{r.focus}</span>
        </span>
        <span className="flex items-center gap-2">
          <span className="font-mono text-xl font-bold tabular-nums text-white">{w.toFixed(1)}</span>
          <span className={`text-white/30 transition-transform duration-300 ${open ? "rotate-180" : "group-hover:text-white/60"}`}>▾</span>
        </span>
      </button>

      {open && (
        <div className="border-t border-white/10 bg-black/30 p-4 sm:p-5">
          <div className="mb-4 flex flex-wrap items-center gap-2">
            <Pill tone="neutral">{r.origin}</Pill>
            <Pill tone="warn">Note auto-déclarée : {r.selfScore}</Pill>
          </div>

          {/* critères */}
          <div className="mb-5 grid gap-x-6 gap-y-2 sm:grid-cols-2">
            {CRIT.map((c, k) => {
              const v = r.c[k];
              const col = v >= 8 ? "#10b981" : v >= 6 ? "#f59e0b" : v >= 4 ? "#f97316" : "#ef4444";
              return (
                <div key={c.key} className="grid grid-cols-[1fr_72px_34px] items-center gap-2">
                  <span className="truncate text-[11.5px] text-white/50">
                    <span className="font-mono text-white/70">{c.key}</span> {c.label}
                  </span>
                  <span className="h-1 overflow-hidden rounded-full bg-white/10">
                    <span className="block h-full rounded-full" style={{ width: `${v * 10}%`, background: col }} />
                  </span>
                  <span className="text-right font-mono text-[11px] tabular-nums text-white/65">{v}/10</span>
                </div>
              );
            })}
          </div>

          <p className="mb-5 border-l-2 pl-3 text-[13.5px] leading-relaxed text-white/80" style={{ borderColor: color }}>
            {r.verdict}
          </p>

          <div className="grid gap-5 lg:grid-cols-2">
            <div>
              <div className={`${KICKER} mb-2 text-emerald-400/80`}>✓ Juste — à appliquer ({r.keep.length})</div>
              <ul className="space-y-2">
                {r.keep.map((k) => (
                  <li key={k.label} className="rounded-lg border border-emerald-500/15 bg-emerald-500/[0.05] p-2.5">
                    <div className="text-[12.5px] font-semibold text-white/90">{k.label}</div>
                    <div className="mt-1 text-[11.5px] leading-snug text-white/55">{k.proof}</div>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <div className={`${KICKER} mb-2 text-red-400/80`}>✕ Faux ou inapplicable ({r.reject.length})</div>
              <ul className="space-y-2">
                {r.reject.map((k) => (
                  <li key={k.label} className="rounded-lg border border-red-500/15 bg-red-500/[0.05] p-2.5">
                    <div className="text-[12.5px] font-semibold text-white/90">{k.label}</div>
                    <div className="mt-1 font-mono text-[11.5px] leading-snug text-white/55">{k.proof}</div>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mt-4 rounded-lg bg-white/[0.04] p-3">
            <span className={`${KICKER} text-white/35`}>Contribution unique</span>
            <p className="mt-1 text-[13px] leading-relaxed text-white/80">{r.unique}</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default function Reports() {
  const [open, setOpen] = useState<string | null>("jeremy");
  const ranked = [...REPORTS].sort((a, b) => weighted(b) - weighted(a));
  const winner = ranked[0];

  return (
    <div className="space-y-14">
      {/* ══════════ VERDICT ══════════ */}
      <section className="relative overflow-hidden rounded-3xl border border-white/12 bg-[linear-gradient(135deg,rgba(16,185,129,.10),rgba(245,158,11,.06)_45%,transparent)] p-6 sm:p-9">
        <div className="pointer-events-none absolute -right-16 -top-20 h-64 w-64 rounded-full bg-emerald-400/10 blur-3xl" />
        <div className="relative grid gap-8 lg:grid-cols-[1.35fr_1fr]">
          <div>
            <div className={`${KICKER} text-emerald-300`}>Réponse à ta question</div>
            <h2 className="mt-3 font-display text-[30px] font-semibold leading-[1.12] tracking-tight text-white sm:text-[42px]">
              L'approche gagnante n'est pas un rapport.
              <br />
              <span className="text-emerald-300">C'est Jeremy en pilote,</span> mon audit en spec,{" "}
              <span className="text-amber-300">Les Ignobles en calendrier.</span>
            </h2>
            <p className="mt-5 max-w-2xl text-[14px] leading-relaxed text-white/70">
              Aucun des six ne se suffit. Pris isolément, <strong className="text-white">Jeremy</strong> te donne la doctrine (une seule
              fonctionnalité, le contenu comme acquisition, l'information comme récompense) mais ignore l'Algérie ;{" "}
              <strong className="text-white">l'audit de modules</strong> te donne la liste exacte des fichiers à couper mais ignore le
              store ; <strong className="text-white">Les Ignobles</strong> te donne la date (J-100) et le payeur (l'établissement) mais
              suppose quatre fonctionnalités inexistantes.
            </p>
            <p className="mt-3 max-w-2xl text-[14px] leading-relaxed text-white/70">
              Et la vérité brutale que les six évitent : <strong className="text-red-300">tu ne peux pas être « top téléchargement »
              parce que tu n'es pas publiable.</strong> Version 0.0.0, zéro tag, zéro build signé, compteur BAC vide, 40 copies d'élèves
              dans l'historique Git. Trois jours de travail séparent ton app du Play Store — et aucune stratégie ne remplace ces trois jours.
            </p>
          </div>

          <div className="rounded-2xl border border-white/12 bg-black/35 p-5 backdrop-blur">
            <div className={`${KICKER} text-white/40`}>Vainqueur · approche à adopter</div>
            <div className="mt-2 font-display text-[22px] font-semibold leading-tight text-white">{winner.title}</div>
            <div className="mt-1 font-mono text-[11px] text-white/45">{winner.origin}</div>
            <div className="mt-4 flex items-end gap-3">
              <span className="font-mono text-5xl font-bold leading-none tabular-nums text-emerald-300">{weighted(winner).toFixed(1)}</span>
              <span className="pb-1.5 font-mono text-[11px] text-white/40">/10 pondéré sur ton objectif</span>
            </div>
            <div className="mt-4 space-y-1.5">
              {CRIT.map((c, k) => (
                <div key={c.key} className="grid grid-cols-[1fr_44px] items-center gap-2 text-[11px]">
                  <span className="flex items-center gap-2 text-white/50">
                    <span className="h-1 w-10 overflow-hidden rounded-full bg-white/10">
                      <span className="block h-full rounded-full bg-emerald-400" style={{ width: `${winner.c[k] * 10}%` }} />
                    </span>
                    {c.label}
                  </span>
                  <span className="text-right font-mono tabular-nums text-white/70">{winner.c[k]}</span>
                </div>
              ))}
            </div>
            <p className="mt-4 border-t border-white/10 pt-3 text-[12.5px] leading-relaxed text-white/60">{winner.unique}</p>
          </div>
        </div>
      </section>

      {/* ══════════ PITCH ══════════ */}
      <Reveal>
        <section className="rounded-3xl border border-amber-400/25 bg-amber-400/[0.05] p-6 sm:p-8">
          <div className={`${KICKER} text-amber-300/90`}>La phrase de vente — constante sur les 6 rapports, vérifiée dans ton code</div>
          <p className="mt-4 text-right text-[24px] font-semibold leading-[1.7] text-white sm:text-[30px]" dir="rtl" lang="ar">
            {PITCH.ar}
          </p>
          <p className="mt-3 text-[14px] italic leading-relaxed text-white/65">{PITCH.fr}</p>
          <div className="mt-5 border-t border-white/10 pt-4">
            <div className={`${KICKER} text-white/35`}>Différenciation défendable</div>
            <p className="mt-1.5 text-[14px] leading-relaxed text-white/80">« {PITCH.diff} »</p>
          </div>
        </section>
      </Reveal>

      {/* ══════════ CLASSEMENT ══════════ */}
      <Reveal>
        <section>
          <Head
            kicker="Classement pondéré"
            title="Les 6 rapports face à ton objectif réel"
            sub="Pondération alignée sur ta question : impact téléchargements ×1,4 · amour des élèves ×1,2 · fiabilité vérifiée dans le code ×1,2 · applicabilité Algérie ×1,2 · utilité stratégique ×1,0 · faible coût ×0,8. Cliquez pour ouvrir le dossier complet."
          />
          <div className="space-y-2">
            {ranked.map((r, i) => (
              <ReportRow key={r.id} r={r} i={i} open={open === r.id} onToggle={() => setOpen(open === r.id ? null : r.id)} />
            ))}
          </div>
          <p className="mt-4 text-[12px] leading-relaxed text-white/45">
            Note de lecture : l'audit de modules (n°2) obtient la meilleure fiabilité (10/10) parce qu'il est le seul vérifié ligne à
            ligne dans ton dépôt — biais déclaré, c'est le mien. Mais il ne remporte pas la catégorie « approche » : il ne dit rien du
            store, de l'acquisition ni du revenu. <strong className="text-white/70">Jeremy reste le pilote</strong>, l'audit est son plan
            de découpe.
          </p>
        </section>
      </Reveal>

      {/* ══════════ CONTRADICTIONS ══════════ */}
      <Reveal>
        <section>
          <Head
            kicker="Arbitrage d'inspection"
            title="3 contradictions entre rapports — tranchées"
            sub="Là où deux rapports se contredisent, la décision ne se prend pas à la majorité : elle se prend sur la preuve dans le code et sur la réalité du marché algérien."
          />
          <div className="space-y-4">
            {CONTRADICTIONS.map((c, i) => (
              <Card key={c.question} className="border-white/12">
                <div className="grid gap-5 lg:grid-cols-[1fr_1.25fr]">
                  <div>
                    <div className={`${KICKER} text-white/35`}>Contradiction {i + 1}</div>
                    <h3 className="mt-1.5 font-display text-[19px] font-semibold leading-snug text-white">{c.question}</h3>
                    <ul className="mt-4 space-y-2">
                      {c.positions.map((p) => (
                        <li key={p.report} className="rounded-lg bg-white/[0.04] p-2.5">
                          <div className="font-mono text-[10.5px] uppercase tracking-wider text-white/40">{p.report}</div>
                          <div className="mt-0.5 text-[12.5px] leading-snug text-white/70">« {p.says} »</div>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="rounded-xl border border-emerald-500/25 bg-emerald-500/[0.06] p-4">
                    <div className={`${KICKER} text-emerald-300`}>Décision de l'inspection</div>
                    <p className="mt-2 text-[13.5px] leading-relaxed text-white/85">{c.ruling}</p>
                    <p className="mt-3 border-t border-white/10 pt-3 font-mono text-[11.5px] leading-relaxed text-white/50">{c.proof}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>
      </Reveal>

      {/* ══════════ PLAY STORE ══════════ */}
      <Reveal>
        <section>
          <Head
            kicker="Angle mort des 6 rapports"
            title="La réalité du Play Store algérien"
            sub="Aucun rapport ne traite du magasin lui-même. Or c'est là que se joue le « top téléchargement » : exigences techniques, ASO en arabe, et un canal de distribution parallèle que tout le monde ignore."
          />
          <div className="grid gap-3 lg:grid-cols-2">
            {STORE.map((s) => (
              <div
                key={s.title}
                className={`rounded-xl border p-4 transition hover:translate-y-[-2px] ${
                  s.status === "bloquant"
                    ? "border-red-500/25 bg-red-500/[0.05]"
                    : s.status === "atout"
                      ? "border-emerald-500/25 bg-emerald-500/[0.05]"
                      : "border-violet-500/25 bg-violet-500/[0.05]"
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-[13.5px] font-semibold leading-snug text-white">{s.title}</h3>
                  <Pill tone={s.status === "bloquant" ? "bad" : s.status === "atout" ? "good" : "neutral"}>
                    {s.status === "bloquant" ? "bloquant" : s.status === "atout" ? "atout" : "canal"}
                  </Pill>
                </div>
                <p className="mt-2 text-[12.5px] leading-relaxed text-white/65">{s.detail}</p>
              </div>
            ))}
          </div>
        </section>
      </Reveal>

      {/* ══════════ MÉTRIQUES ══════════ */}
      <Reveal>
        <section>
          <Head
            kicker="Pilotage"
            title="Les 6 métriques qui décident — et leur état actuel"
            sub="Trois rapports parlent de rétention J30. Aucun ne signale qu'elle n'est pas mesurée : sans instrumentation, tu ne peux ni décider, ni publier des chiffres, ni convaincre un établissement."
          />
          <Card className="!p-0 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[720px] border-collapse text-left">
                <thead>
                  <tr className="border-b border-white/10 bg-white/[0.04] text-[11px] uppercase tracking-wider text-white/55">
                    <th className="px-4 py-3">Métrique</th>
                    <th className="px-4 py-3">Cible</th>
                    <th className="px-4 py-3">État dans ton code</th>
                    <th className="px-4 py-3">Pourquoi elle décide</th>
                  </tr>
                </thead>
                <tbody>
                  {METRICS.map((m) => (
                    <tr key={m.name} className="border-b border-white/[0.06] align-top transition hover:bg-white/[0.02]">
                      <td className="px-4 py-3 text-[13px] font-medium text-white">{m.name}</td>
                      <td className="px-4 py-3 font-mono text-[12px] tabular-nums text-emerald-300">{m.target}</td>
                      <td className="px-4 py-3 font-mono text-[11.5px] text-red-300/80">{m.now}</td>
                      <td className="px-4 py-3 text-[12.5px] leading-snug text-white/60">{m.why}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </section>
      </Reveal>

      {/* ══════════ PLAN ══════════ */}
      <Reveal>
        <section>
          <Head
            kicker="Exécution"
            title="Le plan consolidé en 7 phases — fusion des 6 rapports"
            sub="Ordre non négociable : on rend publiable, on découpe, on chauffe, on récompense, on mesure, on valide, on lance. Inverser deux phases, c'est perdre le lancement."
          />
          <div className="relative space-y-3 pl-6">
            <span className="absolute left-[9px] top-2 bottom-2 w-px bg-gradient-to-b from-emerald-400/60 via-amber-400/40 to-transparent" />
            {PLAN.map((p, i) => (
              <Reveal key={p.code} delay={i * 60}>
                <div className="relative rounded-xl border border-white/10 bg-white/[0.03] p-4 transition hover:border-white/25 hover:bg-white/[0.055]">
                  <span className="absolute -left-[22px] top-5 grid h-[18px] w-[18px] place-items-center rounded-full border border-white/20 bg-[#070a12] font-mono text-[9px] text-amber-300">
                    {i}
                  </span>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="rounded-md bg-amber-400/15 px-2 py-0.5 font-mono text-[11px] font-bold text-amber-300">{p.code}</span>
                    <h3 className="font-display text-[17px] font-semibold text-white">{p.title}</h3>
                    <Pill tone="neutral">{p.days}</Pill>
                    <span className="font-mono text-[10.5px] text-white/35">source : {p.from}</span>
                  </div>
                  <ul className="mt-3 grid gap-1.5 sm:grid-cols-2">
                    {p.tasks.map((t) => (
                      <li key={t} className="flex gap-2 text-[12.5px] leading-snug text-white/70">
                        <span className="mt-[6px] h-1 w-1 shrink-0 rounded-full bg-emerald-400/70" />
                        {t}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-3 border-t border-white/10 pt-2.5 font-mono text-[11.5px] text-emerald-300/80">
                    Preuve de réussite → {p.proof}
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </section>
      </Reveal>

      {/* ══════════ CONCLUSION ══════════ */}
      <Reveal>
        <section className="rounded-3xl border border-white/12 bg-[linear-gradient(160deg,rgba(255,255,255,.05),transparent)] p-6 sm:p-8">
          <div className={`${KICKER} text-white/40`}>Conclusion d'inspection</div>
          <p className="mt-3 font-display text-[20px] font-medium leading-relaxed text-white sm:text-[24px]">
            Ton problème n'est ni le code, ni la stratégie, ni l'éthique. C'est le focus — et il a une solution chiffrée : 49 entrées
            deviennent 12, et l'une d'elles devient l'écran d'accueil.
          </p>
          <div className="mt-6 grid gap-3 sm:grid-cols-3">
            {[
              { k: "1", t: "Une killer feature en accueil", d: "Les mots-clés que le correcteur exige — déjà détectés dans answerStructureCheck.ts, jamais mis en avant." },
              { k: "2", t: "Une récompense = une information", d: "La note + le mot-clé manquant. Ni flamme, ni badge, ni coffre : c'est pédagogique ET addictif (règle 23)." },
              { k: "3", t: "Un payeur = un établissement", d: "TeacherDashboardView est déjà codé. L'élève algérien ne paiera jamais : 95-99 % selon Perkox." },
            ].map((x) => (
              <div key={x.k} className="rounded-xl border border-white/10 bg-black/25 p-4">
                <div className="font-mono text-3xl font-bold text-amber-300">{x.k}</div>
                <div className="mt-1 text-[13.5px] font-semibold text-white">{x.t}</div>
                <p className="mt-1.5 text-[12px] leading-relaxed text-white/60">{x.d}</p>
              </div>
            ))}
          </div>
          <p className="mt-6 text-[13px] leading-relaxed text-white/60">
            Ce que les six rapports ont en commun, et qu'aucun ne formule : <strong className="text-white/85">tu audits au lieu de
            publier.</strong> Six rapports, cinq audits de plus, et toujours version 0.0.0. Jeremy le dit en une phrase — « le
            perfectionnisme, c'est de l'égoïsme » — et c'est la seule ligne de tout le corpus qui changera ton nombre de téléchargements.
          </p>
        </section>
      </Reveal>
    </div>
  );
}
