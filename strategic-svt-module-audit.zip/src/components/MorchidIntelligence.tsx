import { useMemo, useState } from "react";
import {
  FRAMEWORK,
  PRIORITY_META,
  PRIORITY_ORDER,
  SYSTEM_PROMPT,
  TICKETS,
  specMarkdown,
  type Component,
  type Priority,
  type Ticket,
} from "../data/morchidIntelligence";
import { Pill } from "./ui";

const KICKER = "font-mono text-[10.5px] uppercase tracking-[0.22em]";

const COMPONENTS: Component[] = [
  "System Prompt",
  "Logique de dialogue socratique",
  "Moteur de détection des erreurs",
  "RAG / Base de connaissances SVT",
];

function TicketView({ t }: { t: Ticket }) {
  const [shot, setShot] = useState<"before" | "after">("after");
  const color = PRIORITY_META[t.priority].color;
  const shown = shot === "before" ? t.example.before : t.example.after;

  return (
    <article className="overflow-hidden rounded-2xl border border-white/12 bg-white/[0.03]">
      <header className="border-b border-white/10 p-5">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-[12px] font-bold" style={{ color }}>
            [{t.id}]
          </span>
          <span className="rounded px-1.5 py-0.5 font-mono text-[10px] font-bold uppercase" style={{ background: `${color}22`, color }}>
            {t.priority}
          </span>
          <Pill>{t.pillar}</Pill>
          <span className="font-mono text-[10.5px] text-white/40">{t.component}</span>
        </div>
        <h3 className="mt-2 font-display text-[20px] font-semibold leading-snug text-white sm:text-[24px]">{t.title}</h3>
        <p className="mt-2 font-mono text-[10.5px] text-white/35">{t.auditRef}</p>
      </header>

      <div className="grid gap-0 lg:grid-cols-2">
        <div className="space-y-4 border-white/10 p-5 lg:border-r">
          <div>
            <div className={`${KICKER} mb-1.5 text-red-300/80`}>Problème constaté</div>
            <p className="text-[13.5px] leading-relaxed text-white/80">{t.problem}</p>
            <pre className="mt-2 overflow-x-auto whitespace-pre-wrap break-words rounded-lg bg-black/40 p-2.5 font-mono text-[11px] leading-relaxed text-amber-100/80">
              {t.proof}
            </pre>
          </div>
          <div className="rounded-xl border border-emerald-500/25 bg-emerald-500/[0.05] p-3.5">
            <div className={`${KICKER} mb-1.5 text-emerald-300`}>Règle visée</div>
            <p className="text-[13px] leading-relaxed text-white/85">{t.rule}</p>
          </div>
          <div>
            <div className={`${KICKER} mb-1.5 text-white/40`}>Directives de prompt</div>
            <ul className="space-y-1.5">
              {t.directives.map((d) => (
                <li key={d} className="flex gap-2 text-[12.5px] leading-snug text-white/75">
                  <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-amber-300/80" />
                  {d}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="space-y-4 bg-black/20 p-5">
          <div>
            <div className="mb-2 flex items-center justify-between gap-2">
              <div className={`${KICKER} text-white/40`}>Few-shot</div>
              <div className="flex rounded-lg border border-white/10 p-0.5">
                <button
                  onClick={() => setShot("before")}
                  className={`rounded-md px-2.5 py-1 text-[11px] ${shot === "before" ? "bg-red-500/20 text-red-200" : "text-white/45"}`}
                >
                  Ancien
                </button>
                <button
                  onClick={() => setShot("after")}
                  className={`rounded-md px-2.5 py-1 text-[11px] ${shot === "after" ? "bg-emerald-500/20 text-emerald-200" : "text-white/45"}`}
                >
                  Attendu
                </button>
              </div>
            </div>
            <div className="mb-2 flex justify-end">
              <div className="max-w-[90%] rounded-2xl rounded-br-sm bg-white/10 px-3 py-2 text-right" dir="rtl" lang="ar">
                <span className="text-[13px] leading-relaxed text-white/85">{t.example.input}</span>
              </div>
            </div>
            <div
              className={`rounded-2xl rounded-bl-sm px-3.5 py-3 text-right ${
                shot === "after" ? "bg-emerald-500/10 ring-1 ring-emerald-500/25" : "bg-red-500/10 ring-1 ring-red-500/25"
              }`}
              dir="rtl"
              lang="ar"
            >
              <p className="whitespace-pre-line text-[13.5px] leading-[1.85] text-white/90">{shown}</p>
            </div>
          </div>
          <div>
            <div className={`${KICKER} mb-1.5 text-white/40`}>Definition of Done</div>
            <ul className="space-y-1.5">
              {t.dod.map((d) => (
                <li key={d} className="flex gap-2 text-[12.5px] leading-snug text-white/75">
                  <span className="mt-[3px] grid h-3.5 w-3.5 shrink-0 place-items-center rounded border border-white/25 text-[9px] text-transparent">✓</span>
                  {d}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </article>
  );
}

export default function MorchidIntelligence() {
  const [priority, setPriority] = useState<Priority | "all">("all");
  const [component, setComponent] = useState<Component | "all">("all");
  const [copied, setCopied] = useState<"spec" | "prompt" | null>(null);
  const [showPrompt, setShowPrompt] = useState(false);

  const list = useMemo(
    () => TICKETS.filter((t) => (priority === "all" || t.priority === priority) && (component === "all" || t.component === component)),
    [priority, component],
  );

  const copy = async (kind: "spec" | "prompt") => {
    try {
      await navigator.clipboard.writeText(kind === "spec" ? specMarkdown() : SYSTEM_PROMPT);
      setCopied(kind);
      setTimeout(() => setCopied(null), 2000);
    } catch {
      /* ignore */
    }
  };

  return (
    <div className="space-y-10">
      <section className="relative overflow-hidden rounded-3xl border border-white/12 bg-[linear-gradient(145deg,rgba(16,185,129,.1),rgba(245,158,11,.06)_50%,transparent)] p-6 sm:p-9">
        <div className={`${KICKER} text-emerald-300`}>SpecKit 002 · intelligence de Morchid</div>
        <h2 className="mt-3 max-w-4xl font-display text-[28px] font-semibold leading-[1.12] tracking-tight text-white sm:text-[40px]">
          Cesser de réciter. Faire trouver.
          <span className="text-emerald-300"> Puis vérifier que c'est trouvé.</span>
        </h2>
        <p className="mt-4 max-w-3xl text-[14px] leading-relaxed text-white/70">
          Douze tickets, chacun tracé à une preuve du moteur ou du verdict du 25 septembre 2026. Le system prompt ne suffit pas :{" "}
          <strong className="text-white">SPEC-12 est un bug de scoreur</strong>. Tant qu'une réponse qui nie les mots-clés vaut 10/10, aucune
          consigne pédagogique n'est crédible. Les réponses élève sont en فصحى — la darija ne sert qu'à détecter la détresse (AGENTS.md).
        </p>
        <div className="mt-5 flex flex-wrap gap-2">
          {PRIORITY_ORDER.map((p) => (
            <span key={p} className="rounded-lg px-2.5 py-1 font-mono text-[11px]" style={{ background: `${PRIORITY_META[p].color}18`, color: PRIORITY_META[p].color }}>
              {PRIORITY_META[p].count} {p.toLowerCase()}
            </span>
          ))}
          <button onClick={() => copy("spec")} className="ml-auto rounded-xl bg-amber-400 px-4 py-2 text-[13px] font-bold text-slate-900 hover:bg-amber-300">
            {copied === "spec" ? "✓ Spec copiée" : "Copier le SpecKit (Markdown)"}
          </button>
        </div>
      </section>

      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {FRAMEWORK.map((f, i) => (
          <div key={f.id} className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <div className="font-mono text-[10px] text-amber-300/80">0{i + 1}</div>
            <h3 className="mt-1 text-[15px] font-semibold text-white">{f.name}</h3>
            <p className="mt-2 text-[12.5px] leading-relaxed text-white/60">{f.rule}</p>
          </div>
        ))}
      </section>

      <section className="rounded-2xl border border-white/10 bg-black/30">
        <button onClick={() => setShowPrompt((v) => !v)} className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left">
          <div>
            <div className={`${KICKER} text-white/40`}>Annexe · à coller tel quel</div>
            <div className="mt-1 text-[15px] font-semibold text-white">System prompt canonique — 10 règles, un seul bloc</div>
          </div>
          <span className="text-white/40">{showPrompt ? "▴" : "▾"}</span>
        </button>
        {showPrompt && (
          <div className="border-t border-white/10 p-5">
            <pre className="whitespace-pre-wrap text-right font-sans text-[13.5px] leading-[1.9] text-white/85" dir="rtl" lang="ar">
              {SYSTEM_PROMPT}
            </pre>
            <button onClick={() => copy("prompt")} className="mt-4 rounded-lg border border-white/15 px-3 py-1.5 text-[12px] text-white/70 hover:text-white">
              {copied === "prompt" ? "✓ Prompt copié" : "Copier le prompt"}
            </button>
          </div>
        )}
      </section>

      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setPriority("all")}
          className={`rounded-lg border px-3 py-1.5 text-[12px] ${priority === "all" ? "border-amber-400/50 bg-amber-400/10 text-amber-100" : "border-white/10 text-white/50"}`}
        >
          Toutes priorités
        </button>
        {PRIORITY_ORDER.map((p) => (
          <button
            key={p}
            onClick={() => setPriority(p)}
            className={`rounded-lg border px-3 py-1.5 text-[12px] ${priority === p ? "border-white/30 bg-white/10 text-white" : "border-white/10 text-white/50"}`}
          >
            {p}
          </button>
        ))}
        <span className="mx-1 hidden h-6 w-px bg-white/10 sm:inline-block" />
        <button
          onClick={() => setComponent("all")}
          className={`rounded-lg border px-3 py-1.5 text-[12px] ${component === "all" ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-100" : "border-white/10 text-white/50"}`}
        >
          Tous composants
        </button>
        {COMPONENTS.map((c) => (
          <button
            key={c}
            onClick={() => setComponent(c)}
            className={`rounded-lg border px-3 py-1.5 text-[12px] ${component === c ? "border-white/30 bg-white/10 text-white" : "border-white/10 text-white/50"}`}
          >
            {c}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {list.map((t) => (
          <TicketView key={t.id} t={t} />
        ))}
      </div>

      <section className="rounded-2xl border border-amber-400/25 bg-amber-400/[0.05] p-5">
        <div className={`${KICKER} text-amber-300`}>Ordre non négociable</div>
        <ol className="mt-3 space-y-2 text-[13.5px] leading-relaxed text-white/75">
          <li>1. SPEC-12 puis SPEC-02 — le scoreur ment, et un bouton livre le corrigé. Un prompt ne répare ni l'un ni l'autre.</li>
          <li>2. SPEC-01 et SPEC-03 — question d'abord, triade ensuite. C'est le gain de compréhension.</li>
          <li>3. SPEC-04, SPEC-05, SPEC-06 — typer, clore, bilanter. Sans ça, Morchid ne sait toujours pas si l'élève a compris.</li>
          <li>4. Le reste (détresse, test réel, mission, protocole, voix) — nécessaire, pas suffisant.</li>
        </ol>
      </section>
    </div>
  );
}
