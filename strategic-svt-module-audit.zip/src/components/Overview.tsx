import { MODULES, STATS, TIER_META, total, unitShort } from "../lib/compute";
import type { Tier } from "../data/audit";
import { Card, Kpi, Pill, SectionTitle, TierBadge } from "./ui";

const W = 760;
const H = 320;
const PX = 58;
const PY = 24;
const MAX_H = 22;
const MAX_G = 4.5;

const sx = (h: number) => PX + (Math.min(h, MAX_H) / MAX_H) * (W - PX - 24);
const sy = (g: number) => H - 40 - (Math.min(g, MAX_G) / MAX_G) * (H - PY - 64);

export default function Overview({ go }: { go: (tab: string) => void }) {
  const tiers: Tier[] = [1, 2, 3, 4];

  return (
    <div className="space-y-8">
      {/* VERDICT */}
      <Card className="border-amber-500/25 bg-gradient-to-br from-amber-500/[0.07] to-transparent">
        <div className="mb-2 font-mono text-[11px] uppercase tracking-[0.2em] text-amber-400/80">Verdict de l'inspection</div>
        <p className="text-[15px] leading-relaxed text-white/85">
          Vous n'avez pas un problème de <em className="text-white">contenu</em>, vous avez un problème de <em className="text-white">nombre</em>. Sur{" "}
          <strong className="font-mono text-white">{STATS.count} entrées</strong> proposées à l'élève, seulement{" "}
          <strong className="text-emerald-300">{STATS.byTier[1].length} sont irremplaçables</strong> et{" "}
          <strong className="text-red-300">{STATS.suppr.length} devraient disparaître</strong> et {STATS.fusions.length} être absorbés par un
          équivalent. Tant que le menu
          affiche 30 choix, un élève de 10/20 ne choisit pas : il ferme l'application. Le correctif n'est pas d'ajouter un module, il est de
          réduire l'application à <strong className="text-white">12 modules en 3 hub</strong> et de boucher 3 trous qui coûtent réellement des points.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Pill tone="bad">{STATS.suppr.length} modules à supprimer purement et simplement</Pill>
          <Pill tone="warn">{STATS.byTier[3].length + STATS.byTier[4].length} entrées en Tier 3-4 ({STATS.count} auditées)</Pill>
          <Pill tone="warn">{STATS.fusions.length} modules à fusionner</Pill>
          <Pill tone="good">{STATS.heuresBruit} h de travail élève récupérées</Pill>
          <Pill tone="bad">3 trous critiques non couverts</Pill>
        </div>
      </Card>

      {/* KPI */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Kpi value={`${STATS.count}`} label="Entrées auditées" hint="vues + modules de données exposés à l'élève" />
        <Kpi value={`${STATS.avg.toFixed(1)}/20`} label="Note moyenne" hint="une moyenne de 11/20 = la moitié de l'app ne sert pas le BAC" tone="warn" />
        <Kpi value={`${STATS.heuresBruit} h`} label="Heures récupérables" hint={`sur ${STATS.heuresGardees} h de travail utile restant`} tone="good" />
        <Kpi value="12" label="Architecture cible" hint="3 hub : Apprendre · S'entraîner · Corriger" />
      </div>

      {/* TIERS */}
      <div>
        <SectionTitle
          kicker="Étape 2 · Classification"
          title="Répartition en 4 tiers"
          sub="Barème : C1 alignement BAC /4 · C2 efficacité pédagogique /4 · C3 autonomie /3 · C4 rentabilité /3 · C5 non-redondance /3 · C6 profondeur cognitive /3"
        />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {tiers.map((t) => {
            const list = STATS.byTier[t];
            const meta = TIER_META[t];
            const pct = Math.round((list.length / STATS.count) * 100);
            return (
              <button
                key={t}
                onClick={() => go("modules")}
                className="group rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-left transition hover:border-white/25 hover:bg-white/[0.06]"
              >
                <div className="flex items-center justify-between">
                  <TierBadge tier={t} />
                  <span className="font-mono text-xl font-bold tabular-nums" style={{ color: meta.color }}>
                    {list.length}
                  </span>
                </div>
                <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: meta.color }} />
                </div>
                <div className="mt-2 text-[11px] text-white/50">{meta.rule}</div>
                <div className="mt-3 line-clamp-2 text-[12px] leading-snug text-white/40 group-hover:text-white/60">
                  {list.slice(0, 4).map((m) => m.fr).join(" · ")}
                  {list.length > 4 ? " …" : ""}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* RENTABILITÉ */}
      <div>
        <SectionTitle
          kicker="Rentabilité"
          title="Temps investi vs points BAC mobilisables"
          sub="Chaque bulle est un module. En haut à gauche = ce que l'élève doit faire d'abord. En bas à droite = ce que vous devriez supprimer."
        />
        <Card>
          <div className="mb-3 flex flex-wrap gap-2">
            {([1, 2, 3, 4] as Tier[]).map((t) => (
              <span key={t} className="inline-flex items-center gap-1.5 text-[11px] text-white/55">
                <span className="h-2.5 w-2.5 rounded-full" style={{ background: TIER_META[t].color }} />
                Tier {t} · {STATS.byTier[t].length}
              </span>
            ))}
            <span className="ml-auto font-mono text-[10.5px] text-white/35">taille de bulle = points mobilisables</span>
          </div>
          <div className="overflow-x-auto">
            <svg viewBox={`0 0 ${W} ${H}`} className="h-[320px] w-full min-w-[620px]">
              {[1, 2, 3, 4].map((g) => (
                <g key={g}>
                  <line x1={PX} x2={W - 24} y1={sy(g)} y2={sy(g)} stroke="rgba(255,255,255,0.07)" strokeWidth="1" />
                  <text x={PX - 10} y={sy(g) + 4} textAnchor="end" fontSize="10" fill="rgba(255,255,255,0.45)" fontFamily="ui-monospace">
                    {g} pt
                  </text>
                </g>
              ))}
              {[2, 6, 10, 14, 18, 22].map((h) => (
                <g key={h}>
                  <line x1={sx(h)} x2={sx(h)} y1={sy(0)} y2={PY} stroke="rgba(255,255,255,0.05)" strokeWidth="1" />
                  <text x={sx(h)} y={H - 22} textAnchor="middle" fontSize="10" fill="rgba(255,255,255,0.45)" fontFamily="ui-monospace">
                    {h} h
                  </text>
                </g>
              ))}
              <line x1={PX} x2={W - 24} y1={sy(0)} y2={sy(0)} stroke="rgba(255,255,255,0.2)" />
              <line x1={PX} x2={PX} y1={sy(0)} y2={PY} stroke="rgba(255,255,255,0.2)" />
              {MODULES.map((m, i) => {
                const t = total(m) as number;
                const tier = (t >= 16 ? 1 : t >= 12 ? 2 : t >= 8 ? 3 : 4) as Tier;
                const r = 4 + Math.min(m.gain, 4) * 1.6;
                const big = m.gain / Math.max(m.temps, 1) > 0.55 && m.gain >= 2;
                const jx = m.temps <= 1 ? ((i % 7) - 3) * 4.5 : 0;
                const jy = m.gain < 0.6 ? ((i % 5) - 2) * 6 : 0;
                return (
                  <g key={m.id}>
                    <circle
                      cx={sx(m.temps) + jx}
                      cy={sy(m.gain) + jy}
                      r={r}
                      fill={TIER_META[tier].color}
                      fillOpacity={big ? 0.95 : 0.5}
                      stroke={TIER_META[tier].color}
                    />
                    {big && (
                      <text x={sx(m.temps) + r + 5} y={sy(m.gain) + 3.5} fontSize="10" fill="rgba(255,255,255,0.85)" fontFamily="ui-monospace">
                        {m.fr.length > 26 ? m.fr.slice(0, 24) + "…" : m.fr}
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>
        </Card>
      </div>

      {/* TOP RENTABILITÉ */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <div className="mb-3 text-[13px] font-semibold text-white">Classement points / heure</div>
          <div className="space-y-2">
            {STATS.rentables.slice(0, 8).map(({ m, ratio }, i) => (
              <div key={m.id} className="flex items-center gap-3">
                <span className="w-5 font-mono text-[11px] text-white/35">{i + 1}</span>
                <span className="flex-1 truncate text-[13px] text-white/80">{m.fr}</span>
                <span className="font-mono text-[11px] tabular-nums text-white/40">{m.temps} h</span>
                <span className="w-14 text-right font-mono text-[12px] font-bold tabular-nums text-emerald-300">
                  +{ratio.toFixed(2)} pt/h
                </span>
              </div>
            ))}
          </div>
        </Card>
        <Card className="border-red-500/25 bg-red-500/[0.05]">
          <div className="mb-2 text-[13px] font-semibold text-white">Mise en garde du programme officiel</div>
          <p className="text-[13px] leading-relaxed text-white/70">
            Le tableau de synthèse demandé mentionne « Reproduction des plantes », « Génétique » et « Évolution ».{" "}
            <strong className="text-white">Ces trois unités ne figurent plus au programme de 3<sup>e</sup> AS depuis la réforme de 2011.</strong>{" "}
            Le programme actuel est : Spécialisation fonctionnelle des protéines · Transformations énergétiques · Tectonique des plaques.
            Toute ressource de l'application portant sur l'ancien programme est, par définition, du bruit hors barème.
          </p>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {["U1 Protéines & enzymes 8-10 pts", "U2 Immunologie 6-8 pts", "U3 Comm. nerveuse 5-7 pts", "U4 Transform. énergétiques 8-10 pts", "U5 Tectonique 8-10 pts"].map(
              (s) => (
                <Pill key={s} tone="good">
                  {s}
                </Pill>
              ),
            )}
          </div>
        </Card>
      </div>

      {/* COUVERTURE PAR UNITÉ */}
      <div>
        <SectionTitle kicker="Couverture" title="Nombre de modules par unité du programme" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {(["U1", "U2", "U3", "U4", "U5", "U0"] as const).map((u) => {
            const list = MODULES.filter((m) => m.units.includes(u));
            const t1 = list.filter((m) => (total(m) as number) >= 16).length;
            const t4 = list.filter((m) => (total(m) as number) < 8).length;
            return (
              <Card key={u} className="!p-4">
                <div className="flex items-baseline justify-between">
                  <span className="font-mono text-[11px] uppercase tracking-widest text-white/40">{u}</span>
                  <span className="text-[11px] text-white/40">{unitShort(u)}</span>
                </div>
                <div className="mt-2 flex items-end gap-3">
                  <span className="font-mono text-2xl font-bold text-white">{list.length}</span>
                  <span className="pb-1 text-[11px] text-emerald-300">{t1} indispensables</span>
                  {t4 > 0 && <span className="pb-1 text-[11px] text-red-300">{t4} à couper</span>}
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
