import { type ReactNode } from "react";
import { CRITERIA, type ModuleAudit, type Tier } from "../data/audit";
import { TIER_META, total } from "../lib/compute";

export function TierBadge({ tier, small = false }: { tier: Tier; small?: boolean }) {
  const meta = TIER_META[tier];
  const dot = { 1: "🟢", 2: "🟡", 3: "🟠", 4: "🔴" }[tier];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full ring-1 font-semibold uppercase tracking-wider ${meta.bg} ${meta.ring} ${meta.text} ${
        small ? "px-2 py-0.5 text-[10px]" : "px-2.5 py-1 text-[11px]"
      }`}
    >
      <span className="not-italic leading-none">{dot}</span>
      {meta.tag}
    </span>
  );
}

export function Score({ m, size = 56 }: { m: ModuleAudit; size?: number }) {
  const t = total(m);
  const tier = (t >= 16 ? 1 : t >= 12 ? 2 : t >= 8 ? 3 : 4) as Tier;
  const meta = TIER_META[tier];
  const r = size / 2 - 4;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="currentColor" className="text-white/10" strokeWidth="4" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={meta.color}
          strokeWidth="4"
          strokeLinecap="round"
          strokeDasharray={`${(t / 20) * c} ${c}`}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">
        <span className="font-mono text-sm font-bold tabular-nums text-white">{t}</span>
        <span className="absolute bottom-1 font-mono text-[8px] text-white/40">/20</span>
      </div>
    </div>
  );
}

export function CriteriaBars({ m }: { m: ModuleAudit }) {
  return (
    <div className="grid gap-2">
      {CRITERIA.map((cr, i) => {
        const v = m.c[i];
        const pct = (v / cr.max) * 100;
        const col = pct >= 75 ? "#10b981" : pct >= 50 ? "#f59e0b" : pct >= 25 ? "#f97316" : "#ef4444";
        return (
          <div key={cr.key} className="grid grid-cols-[92px_1fr_44px] items-center gap-2">
            <span className="text-[11px] text-white/50">
              <span className="font-mono text-white/70">{cr.key}</span> {cr.label}
            </span>
            <span className="h-1.5 overflow-hidden rounded-full bg-white/10">
              <span className="block h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: col }} />
            </span>
            <span className="text-right font-mono text-[11px] tabular-nums text-white/70">
              {v}/{cr.max}
            </span>
          </div>
        );
      })}
    </div>
  );
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`rounded-2xl border border-white/10 bg-white/[0.03] p-5 backdrop-blur-sm ${className}`}>{children}</div>
  );
}

export function SectionTitle({ kicker, title, sub }: { kicker: string; title: string; sub?: string }) {
  return (
    <div className="mb-6 border-l-2 border-amber-400/60 pl-4">
      <div className="font-mono text-[10.5px] uppercase tracking-[0.22em] text-amber-400/80">{kicker}</div>
      <h2 className="mt-1.5 font-display text-[26px] font-semibold leading-tight tracking-tight text-white sm:text-[32px]">{title}</h2>
      {sub && <p className="mt-2.5 max-w-3xl text-[13.5px] leading-relaxed text-white/55">{sub}</p>}
    </div>
  );
}

export function Kpi({ value, label, hint, tone = "neutral" }: { value: string; label: string; hint?: string; tone?: "good" | "warn" | "bad" | "neutral" }) {
  const tones = {
    good: "text-emerald-300",
    warn: "text-amber-300",
    bad: "text-red-300",
    neutral: "text-white",
  };
  return (
    <div className="rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.06] to-transparent p-4">
      <div className={`font-mono text-2xl font-bold tabular-nums sm:text-3xl ${tones[tone]}`}>{value}</div>
      <div className="mt-1 text-[13px] font-medium text-white/80">{label}</div>
      {hint && <div className="mt-1 text-[11px] leading-snug text-white/45">{hint}</div>}
    </div>
  );
}

export function Pill({ children, tone = "neutral" }: { children: ReactNode; tone?: "neutral" | "good" | "warn" | "bad" }) {
  const map = {
    neutral: "bg-white/5 text-white/70 ring-white/10",
    good: "bg-emerald-500/10 text-emerald-300 ring-emerald-500/30",
    warn: "bg-amber-500/10 text-amber-300 ring-amber-500/30",
    bad: "bg-red-500/10 text-red-300 ring-red-500/30",
  };
  return <span className={`inline-flex items-center rounded-md px-2 py-0.5 text-[11px] font-medium ring-1 ${map[tone]}`}>{children}</span>;
}
