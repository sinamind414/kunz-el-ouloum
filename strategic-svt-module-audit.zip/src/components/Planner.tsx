import { useEffect, useState } from "react";
import { GAPS, MODULES, total, tierOf } from "../data/audit";
import { planForTarget, STATS } from "../lib/compute";
import { Card, Pill, SectionTitle } from "./ui";

const TARGETS = [10, 12, 14, 16];

const CHECKS = [
  { id: "d1", label: "Supprimer les 17 entrées évaluées « à supprimer » (aucune migration de contenu)", impact: "menu élève divisé par 2" },
  { id: "d2", label: "Sortir du menu élève : compte, sauvegarde, zoom, tableau de bord professeur", impact: "parcours élève nettoyé" },
  { id: "d3", label: "Fusionner Meftah + MiftahCard dans la Boussole v2", impact: "1 seule méthode au lieu de 3" },
  { id: "d4", label: "Fusionner WritingReview + Compiler + Stats dans le Correcteur", impact: "1 seul rapport d'erreur" },
  { id: "d5", label: "Fusionner les 3 entrées QCM en un QCM de positionnement (15 q / unité)", impact: "-2 écrans, + usage réel" },
  { id: "d6", label: "Fusionner BacExam / Bac2025 / MockExam en un lecteur unique avec mode examen", impact: "1 point d'entrée sujets" },
  { id: "d7", label: "Absorber le simulateur d'électrophorèse dans le Mur d'analyse", impact: "3 documents figés au lieu d'un simulateur" },
  { id: "d8", label: "Construire la typologie des documents BAC (8 types, 8 recettes)", impact: "≈ 2 pts / sujet" },
  { id: "d9", label: "Construire le module d'exploitation chiffrée (vitesses, DO, bilans)", impact: "≈ 2,5 pts / sujet" },
  { id: "d10", label: "Construire la trame C3 : hypothèse → témoin → conclusion", impact: "≈ 2 pts / exercice" },
  { id: "d11", label: "Brancher Correcteur → micro-remédiation → plan de révision", impact: "boucle d'erreur fermée" },
  { id: "d12", label: "Ajouter un glossaire bilingue arabe / français actif", impact: "fin des confusions de termes" },
];

const KEY = "audit-svt-decisions";

export default function Planner() {
  const [target, setTarget] = useState(14);
  const [done, setDone] = useState<string[]>([]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setDone(JSON.parse(raw));
    } catch {
      /* stockage indisponible */
    }
  }, []);

  const toggle = (id: string) => {
    setDone((prev) => {
      const next = prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id];
      try {
        localStorage.setItem(KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  };

  const plan = planForTarget(target);
  const kept = MODULES.filter((m) => plan.keep.includes(m.id));
  const socle = kept.filter((m) => tierOf(m) === 1);
  const renfort = kept.filter((m) => tierOf(m) === 2);
  const pct = Math.round((done.length / CHECKS.length) * 100);

  return (
    <div className="space-y-10">
      <div>
        <SectionTitle
          kicker="Simulateur"
          title="Que doit voir l'élève selon l'objectif visé ?"
          sub="Principe de charge cognitive : on ne montre à un élève que ce qui est nécessaire à son objectif immédiat. Le reste est masqué, pas supprimé."
        />
        <div className="mb-5 flex flex-wrap gap-2">
          {TARGETS.map((t) => (
            <button
              key={t}
              onClick={() => setTarget(t)}
              className={`rounded-xl border px-4 py-2 text-[13px] font-semibold transition ${
                target === t
                  ? "border-amber-400/60 bg-amber-400/15 text-amber-200"
                  : "border-white/10 bg-white/[0.03] text-white/55 hover:border-white/25 hover:text-white"
              }`}
            >
              Objectif {t}/20
            </button>
          ))}
        </div>

        <Card>
          <p className="text-[13.5px] leading-relaxed text-white/80">{plan.reason}</p>
          <div className="mt-4 grid gap-3 sm:grid-cols-3">
            <div className="rounded-xl bg-white/5 p-3">
              <div className="font-mono text-xl font-bold text-white">{plan.keep.length}</div>
              <div className="text-[11px] text-white/50">modules visibles (sur {STATS.count})</div>
            </div>
            <div className="rounded-xl bg-white/5 p-3">
              <div className="font-mono text-xl font-bold text-emerald-300">{plan.heures} h</div>
              <div className="text-[11px] text-white/50">temps de travail réel</div>
            </div>
            <div className="rounded-xl bg-white/5 p-3">
              <div className="font-mono text-xl font-bold text-amber-300">≈ {plan.gain} pts</div>
              <div className="text-[11px] text-white/50">de barème mobilisés</div>
            </div>
          </div>

          <div className="mt-5 grid gap-5 lg:grid-cols-2">
            <div>
              <div className="mb-2 font-mono text-[10px] uppercase tracking-[0.18em] text-emerald-400/80">Socle — ordre imposé</div>
              <ol className="space-y-1.5">
                {socle.map((m, i) => (
                  <li key={m.id} className="flex items-start gap-2 text-[13px] text-white/80">
                    <span className="mt-0.5 font-mono text-[10px] text-emerald-400/70">{String(i + 1).padStart(2, "0")}</span>
                    <span>
                      {m.fr} <span className="font-mono text-[10.5px] text-white/35">{total(m)}/20 · {m.temps} h</span>
                    </span>
                  </li>
                ))}
              </ol>
            </div>
            <div>
              <div className="mb-2 font-mono text-[10px] uppercase tracking-[0.18em] text-amber-400/80">Renforts conditionnels</div>
              <div className="flex flex-wrap gap-1.5">
                {renfort.length === 0 && <span className="text-[12px] text-white/35">Aucun — inutile à cet objectif.</span>}
                {renfort.map((m) => (
                  <span key={m.id} className="rounded-lg border border-amber-500/20 bg-amber-500/[0.06] px-2 py-1 text-[11.5px] text-amber-100/80">
                    {m.fr}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </Card>
      </div>

      <div>
        <SectionTitle
          kicker="Pilotage"
          title="Checklist d'exécution de la refonte"
          sub="12 décisions, dans l'ordre. Cochez au fur et à mesure — la progression reste enregistrée sur cet appareil."
        />
        <Card>
          <div className="mb-4 flex items-center gap-4">
            <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/10">
              <div className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-amber-400 transition-all duration-500" style={{ width: `${pct}%` }} />
            </div>
            <span className="font-mono text-[12px] tabular-nums text-white/70">
              {done.length}/{CHECKS.length}
            </span>
          </div>
          <div className="grid gap-2 lg:grid-cols-2">
            {CHECKS.map((c) => {
              const on = done.includes(c.id);
              return (
                <button
                  key={c.id}
                  onClick={() => toggle(c.id)}
                  className={`flex items-start gap-3 rounded-xl border p-3 text-left transition ${
                    on ? "border-emerald-500/40 bg-emerald-500/[0.08]" : "border-white/10 bg-white/[0.03] hover:border-white/25"
                  }`}
                >
                  <span
                    className={`mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded border text-[10px] ${
                      on ? "border-emerald-400 bg-emerald-400 text-slate-900" : "border-white/25 text-transparent"
                    }`}
                  >
                    ✓
                  </span>
                  <span className="min-w-0">
                    <span className={`block text-[13px] leading-snug ${on ? "text-white/45 line-through" : "text-white/85"}`}>{c.label}</span>
                    <span className="mt-0.5 block font-mono text-[10.5px] text-emerald-300/70">{c.impact}</span>
                  </span>
                </button>
              );
            })}
          </div>
        </Card>
      </div>

      <div>
        <SectionTitle kicker="Priorité de construction" title="Les 3 trous critiques, dans l'ordre de rentabilité" />
        <div className="grid gap-3 lg:grid-cols-3">
          {GAPS.filter((g) => g.priority === "critique").map((g, i) => (
            <Card key={g.title} className="border-red-500/25 bg-red-500/[0.05]">
              <div className="font-mono text-[11px] text-red-300">PRIORITÉ {i + 1} · {g.impact}</div>
              <h3 className="mt-1.5 text-[14px] font-semibold text-white">{g.title}</h3>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-white/70">{g.detail}</p>
            </Card>
          ))}
        </div>
        <Card className="mt-4">
          <p className="text-[13px] leading-relaxed text-white/75">
            <strong className="text-white">Conclusion d'inspection :</strong> l'application vaut mieux que sa note moyenne. Ce qui existe de méthodologique
            (Boussole v2, Correcteur à 8 tags, Archétypes, Mur d'analyse) est d'un niveau que l'on ne trouve pas dans les manuels algériens ; mais il est noyé
            sous {STATS.byTier[3].length + STATS.byTier[4].length} entrées qui n'ont aucun effet sur la note. Coupez, fusionnez, puis construisez les 3 modules
            manquants : c'est la seule opération qui transformera ce logiciel en outil de réussite au BAC.
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Pill tone="good">49 → 12 modules</Pill>
            <Pill tone="warn">3 trous critiques à boucher</Pill>
            <Pill tone="neutral">0 contenu de programme perdu</Pill>
          </div>
        </Card>
      </div>
    </div>
  );
}
