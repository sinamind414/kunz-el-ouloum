import { MODULES, UNITS, total, tierOf, type ModuleAudit, type Tier, type UnitId } from "../data/audit";

export { MODULES, UNITS, total, tierOf };

export const TIER_META: Record<Tier, { label: string; tag: string; color: string; bg: string; ring: string; text: string; rule: string; order: number }> = {
  1: {
    label: "Tier 1", tag: "INDISPENSABLE", color: "#10b981", bg: "bg-emerald-500/10",
    ring: "ring-emerald-500/40", text: "text-emerald-300",
    rule: "16 – 20 /20 · à garder absolument", order: 1,
  },
  2: {
    label: "Tier 2", tag: "UTILE", color: "#f59e0b", bg: "bg-amber-500/10",
    ring: "ring-amber-500/40", text: "text-amber-300",
    rule: "12 – 15 /20 · à garder mais optimiser / fusionner", order: 2,
  },
  3: {
    label: "Tier 3", tag: "MARGINAL", color: "#f97316", bg: "bg-orange-500/10",
    ring: "ring-orange-500/40", text: "text-orange-300",
    rule: "8 – 11 /20 · à supprimer sauf complément d'un Tier 1", order: 3,
  },
  4: {
    label: "Tier 4", tag: "BRUIT", color: "#ef4444", bg: "bg-red-500/10",
    ring: "ring-red-500/40", text: "text-red-300",
    rule: "0 – 7 /20 · à supprimer immédiatement", order: 4,
  },
};

export const ACTION_LABEL: Record<string, string> = {
  garder: "Garder",
  optimiser: "Optimiser",
  fusionner: "Fusionner",
  supprimer: "Supprimer",
};

export const FAMILY_LABEL: Record<string, string> = {
  contenu: "Contenu / cours",
  entrainement: "Entraînement",
  methode: "Méthodologie",
  correction: "Correction",
  pilotage: "Pilotage / navigation",
  gamification: "Gamification",
  technique: "Technique",
};

export const unitShort = (id: UnitId) => UNITS.find((u) => u.id === id)?.short ?? id;

export const STATS = (() => {
  const byTier: Record<Tier, ModuleAudit[]> = { 1: [], 2: [], 3: [], 4: [] };
  MODULES.forEach((m) => byTier[tierOf(m)].push(m));

  const avg = MODULES.reduce((a, m) => a + total(m), 0) / MODULES.length;
  const heuresBruit = [...byTier[3], ...byTier[4]].reduce((a, m) => a + m.temps, 0);
  const heuresGardees = [...byTier[1], ...byTier[2]].reduce((a, m) => a + m.temps, 0);
  const gainGarde = [...byTier[1], ...byTier[2]].reduce((a, m) => a + m.gain, 0);
  const gainTotal = MODULES.reduce((a, m) => a + m.gain, 0);
  const fusions = MODULES.filter((m) => m.action === "fusionner");
  const suppr = MODULES.filter((m) => m.action === "supprimer");
  const rentables = [...MODULES]
    .filter((m) => m.temps >= 2)
    .map((m) => ({ m, ratio: m.gain / m.temps }))
    .sort((a, b) => b.ratio - a.ratio);

  return {
    count: MODULES.length,
    byTier,
    avg,
    heuresBruit,
    heuresGardees,
    gainGarde,
    gainTotal,
    fusions,
    suppr,
    rentables,
    ratio: Math.round((1 - MODULES.length / 49) * 100),
  };
})();

/** Modules retenus selon la cible visée — parcours ordonnés, pas des filtres */
const PLANS: Record<number, { ids: string[]; reason: string }> = {
  10: {
    ids: ["boussole", "lessons", "goldSummaries", "bacExams", "correcteur"],
    reason:
      "Objectif 10 : le déficit est un déficit de rédaction et de restitution. Cours + fiche or + sujets BAC + la Boussole et le Correcteur. Rien d'autre : le QCM, les animations et la gamification ne rapportent aucun point.",
  },
  12: {
    ids: ["boussole", "lessons", "goldSummaries", "bacExams", "correcteur", "tahlil", "qcm", "revisionPlan"],
    reason:
      "Objectif 12 : on ajoute l'analyse de documents (les 8-10 pts de l'exercice) et le QCM de positionnement pour savoir exactement où l'élève décroche.",
  },
  14: {
    ids: ["boussole", "lessons", "goldSummaries", "bacExams", "correcteur", "tahlil", "qcm", "revisionPlan", "archetypes", "schemaDrill", "enzyme", "flashcards"],
    reason:
      "Objectif 14 : la marche se franchit sur l'exploitation de documents chiffrés et les schémas légendés. On ajoute les archétypes, l'enzymologie et les flashcards de rétention.",
  },
  16: {
    ids: [
      "boussole", "lessons", "goldSummaries", "bacExams", "correcteur", "tahlil", "qcm", "revisionPlan", "archetypes",
      "schemaDrill", "enzyme", "flashcards", "activeLesson", "situationBank", "transferChallenges", "conceptRoutes", "immunityFiches", "mockExam",
    ],
    reason:
      "Objectif 16+ : le parc complet est justifié, mais uniquement dans cet ordre — le transfert et les parcours conceptuels n'ont de sens qu'une fois le socle maîtrisé.",
  },
};

export function planForTarget(target: number): { keep: string[]; reason: string; heures: number; gain: number } {
  const key = target <= 10 ? 10 : target <= 12 ? 12 : target <= 14 ? 14 : 16;
  const plan = PLANS[key];
  const keep = plan.ids.map((id) => MODULES.find((m) => m.id === id)).filter((m): m is ModuleAudit => Boolean(m));
  return {
    keep: keep.map((m) => m.id),
    reason: plan.reason,
    heures: Math.round(keep.reduce((a, m) => a + m.temps, 0)),
    gain: Math.round(keep.reduce((a, m) => a + m.gain, 0) * 10) / 10,
  };
}


