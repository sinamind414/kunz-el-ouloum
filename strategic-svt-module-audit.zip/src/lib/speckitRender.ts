import { DIVERGENCES, ITEMS, NON_GOALS, PREREQS, REJECTED, TASKS, TRACKS, type AuditItem, type Task } from "../data/speckit2";

const H = "─".repeat(78);
const hr = () => "\n" + H + "\n\n";

export const SPECKIT_DIR = "specs/001-fiabilite-eleve/";

const byPrio = (p: string) => ITEMS.filter((i) => i.prio === p);

export const STATS = (() => {
  const retained = ITEMS.length;
  const p0 = byPrio("P0").length;
  const p1 = byPrio("P1").length;
  const p2 = byPrio("P2").length;
  const sourceItems = retained + REJECTED.length; // allégations examinées
  const p0Sci = ITEMS.filter((i) => i.prio === "P0" && i.axe === "Scientifique").length;
  const p0Not = ITEMS.filter((i) => i.prio === "P0" && i.axe === "Notation").length;
  const withStory = ITEMS.filter((i) => i.story && i.ac).length;
  const tasksP0 = TASKS.filter((t) => t.prios.includes("P0")).length;
  return {
    retained,
    p0,
    p1,
    p2,
    p0Sci,
    p0Not,
    rejected: REJECTED.length,
    sourceItems,
    withStory,
    tasks: TASKS.length,
    tasksP0,
    coverage: Math.round((withStory / retained) * 100),
  };
})();

/* ═══════════════════════ spec.md ═══════════════════════ */
export function renderSpec(): string {
  const out: string[] = [];
  out.push("# SPEC — 001 Fiabilité élève (SVT BAC 3AS Algérie)");
  out.push("");
  out.push("> **Objectif unique :** ce qu'un élève peut apprendre de FAUX, ce qu'on peut lui NOTER de faux, et ce qui manque du programme officiel.");
  out.push("> **Statut :** spécification — aucune modification de code ou de contenu dans la session de production.");
  out.push("");
  out.push("## 0. Socle obligatoire (à relire avant CHAQUE tâche)");
  out.push("");
  out.push("| Document | Statut | Rôle |");
  out.push("|---|---|---|");
  out.push("| `AGENTS.md` | ✅ lu intégralement | **Prime sur tout.** P2/R6 (aucun fit sur notes prof, aucun `a·cov+b`), fichiers générés (`okacha.ts`/`hosila.ts` via `scripts/build_hosila.ts`), liste des fichiers interdits, discipline git (`git add` explicite, `git push` JAMAIS sans validation), discipline Windows (pas d'arabe inline en console, jamais `&&`, pas de BOM), discipline tests (suite 100 % verte, `jest-dom` non câblé, `cleanup()` explicite). **Référencé, non réinventé.** |");
  out.push("| `INDEX.md` | ❌ introuvable (404) | Hiérarchie de vérité (`bookContent.json` → الكتاب المصحح → bibliothèque) **non vérifiable cette session**. Appliquée telle que déclarée dans la commande. Voir prérequis PR-2. |");
  out.push("| `docs/audits_livres/*` | ❌ introuvable (404) | **Prérequis non exécuté** → PR-1. Aucune exigence de conformité livres A/B/C/D n'est spécifiée sans preuve. |");
  out.push("| `data/bac_sessions_2019_2026.json` | ⚠️ non lu cette session | Poids BAC utilisés tels que déclarés dans `AGENTS.md` (barème officiel 5/7/8 pts) et sujets Bac 2025 (الموضوع الأول/الثاني). À relire avant FR-C02. Voir PR-3. |");
  out.push("");
  out.push("## 1. Périmètre et définition des axes");
  out.push("");
  out.push("| Prio | Axe | Définition élève | Items |");
  out.push("|---|---|---|---|");
  out.push(`| P0 | Scientifique | Contenu enseigné contraire au livre officiel — *l'élève apprend du faux* | ${ITEMS.filter((i) => i.prio === "P0" && i.axe === "Scientifique").map((i) => i.id).join(", ")} |`);
  out.push(`| P0 | Notation | Score/feedback qui induit l'élève en erreur — *on note l'élève en faux* | ${ITEMS.filter((i) => i.prio === "P0" && i.axe === "Notation").map((i) => i.id).join(", ")} |`);
  out.push(`| P1 | Couverture | Unité/procédure du programme absente ou partielle | ${ITEMS.filter((i) => i.prio === "P1" && i.axe === "Couverture").map((i) => i.id).join(", ")} |`);
  out.push(`| P1 | Contrat méthodo | L'app entraîne à répondre autrement que le barème BAC | *aucun item* — dépend de D_METHODO (PR-1, introuvable) |`);
  out.push(`| P2 | Terminologie | Incohérences internes (الظهرات/الظهيرة, ميثيونين…) | ${ITEMS.filter((i) => i.prio === "P2").map((i) => i.id).join(", ")} |`);
  out.push("");
  out.push("Chaque item reçoit **UN axe — le plus défavorable**. Un item à double facette est classé P0 même si l'une de ses parties est mineure.");
  out.push(hr());
  out.push("## 2. User stories élève (P0 d'abord)");
  out.push("");
  const ordered: AuditItem[] = [...ITEMS].sort((a, b) => (a.prio > b.prio ? 1 : a.prio < b.prio ? -1 : 0));
  ordered.forEach((it) => {
    out.push(`### ${it.id} — [${it.prio} · ${it.axe}] ${it.etat}`);
    out.push("");
    out.push(`> **${it.faitEleve}**`);
    out.push("");
    out.push(`**En tant qu'élève 3AS, quand ${it.story?.quand}, je veux ${it.story?.veux}, afin de ${it.story?.afin}.**`);
    out.push("");
    out.push(`**Exigence fonctionnelle — ${it.fr}**`);
    out.push("");
    out.push(`- **Traçabilité :** ${it.id} · ${it.source}`);
    out.push(`- **Citation littérale :** ${it.citation}`);
    out.push(`- **Localisation :** \`${it.localisation}\``);
    out.push(`- **Verdict de l'audit :** ${it.verdict} (${it.gravity})`);
    out.push("");
    out.push("**Critères d'acceptation MESURABLES :**");
    it.ac?.forEach((a) => out.push(`- [ ] ${a}`));
    out.push("");
    out.push("_Chaque critère doit être vérifiable par un test qui passe, un chiffre conforme à la page officielle citée, ou un wording arabe فصحى exact._");
    out.push(hr());
  });
  out.push("## 3. Non-goals");
  out.push("");
  NON_GOALS.forEach((n) => out.push(`- **${n.item}** — ${n.why}`));
  out.push("");
  out.push(hr());
  out.push("## 4. Annexe — items JETÉS (règle : item sans preuve = item jeté)");
  out.push("");
  out.push(`${REJECTED.length} allégations examinées et rejetées. Elles sont consignées ici avec leur raison pour éviter qu'elles ne reviennent en boucle dans les audits suivants.`);
  out.push("");
  out.push("| ID | Allégation | Verdict | Raison du rejet |");
  out.push("|---|---|---|---|");
  REJECTED.forEach((r) => out.push(`| ${r.id} | ${r.claim} | ${r.verdict} | ${r.reason} |`));
  out.push("");
  out.push(hr());
  out.push("## 5. Prérequis non exécutés (bloquants partiels)");
  out.push("");
  PREREQS.forEach((p) => {
    out.push(`### ${p.id} — ${p.what}`);
    out.push("");
    out.push(`- **Statut :** ${p.status}`);
    out.push(`- **Conséquence :** ${p.consequence}`);
    out.push(`- **Effet sur les tâches :** ${p.blocking}`);
    out.push("");
  });
  return out.join("\n");
}

/* ═══════════════════════ plan.md ═══════════════════════ */
const ROOT_CAUSE: Record<string, string> = {
  "FR-N01":
    "Le calcul de couverture travaille sur du recouvrement de tokens sans traiter la polarité de la clause. Le point-clé est recherché comme une sous-chaîne présente, pas comme une affirmation soutenue.",
  "FR-N02":
    "Le matching de mots-clés arabe utilise `norm.includes(nk)` : une sous-chaîne peut être engloutie dans un mot plus long (الباك contient لب). Cause typique de langue sans segmentation lexicale.",
  "FR-N03":
    "Aucune couche d'intention : l'entrée est traitée par recherche de contenu, donc toute demande d'action (test) retombe sur une fiche de cours.",
  "FR-N04":
    "Deux chemins d'interface pour une même intention, avec deux implémentations indépendantes : l'une préserve l'état de suivi, l'autre appelle `resetSession()`.",
  "FR-N05":
    "Optimisation locale : ne remonter que ce qui rapporte de l'XP. Effet de bord non évalué — l'échec devient invisible dans le suivi enseignant.",
  "FR-S01": "Saisie/OCR d'un terme technique rare ; le terme erroné n'a jamais été recoupé avec `bookContent.json`.",
  "FR-S02":
    "Inversion de la valeur logique d'un raisonnement : le fait (les ondes S n'arrivent pas) a été transformé en affirmation (elles traversent). Erreur de reformulation, pas de donnée.",
  "FR-S03": "Scénario BAC rédigé avec une assertion que le document ne soutient pas ; données et correction non croisées.",
  "FR-S04":
    "Le corrigé officiel contenait l'erreur, copiée dans `bacExam.ts`. Le correcteur de l'app la sanctionnait déjà — deux sources de vérité contradictoires dans le même produit, sans test de cohérence croisée.",
  "FR-S05": "Généralisation d'une relation qualitative au-delà de son contexte de validité.",
  "FR-T01": "Terme et glose issus de sources différentes sans relecture arabe unifiée.",
  "FR-T02": "Inversion de sens lors de la reformulation d'un mécanisme géologique.",
  "FR-T03": "Confusion graphique en arabe (وشام / وشاح) sans filtre de vérification orthographique.",
  "FR-C01": "Import Flutter limité au seul format QCM supporté ; les 120 autres questions ont été écartées sans registre de motifs.",
  "FR-C02": "Pool constitué par accumulation historique plutôt que par proportion au barème.",
  "FR-C03": "Balisage correct mais non projeté dans l'interface ; les chapitres incomplets restent listés comme prêts.",
};

const STRATEGY: Record<string, string> = {
  moteur:
    "Injection mécanique de la règle dans le calcul, **test rouge d'abord** (cas de l'audit repris tel quel), puis vert. Aucun ajustement empirique : la règle est déduite de la définition du barème, pas calibrée sur des notes. Rappel P2/R6 à chaque commit.",
  contenu:
    "**Injection mécanique depuis `data/bookContent.json` — transcription manuelle proscrite.** Script de scan (arabe écrit via outil de fichier, jamais en console), recoupement unité × page consigné, filtre de confusion graphique (ر/ز · ح/ة · ف/ب) appliqué à l'injection. Test de contenu rouge→vert.",
  verrou:
    "**Le correctif est déjà présent à HEAD : ce qui manque est la protection.** Écrire le test de régression d'abord (rouge), vérifier qu'il passe, puis le rendre permanent. Si à l'exécution le correctif s'avère absent, la tâche bascule en correction — la preuve de sortie reste le test dans les deux cas.",
  couverture:
    "Registre de motifs explicite avant toute intégration : intégrable / hors programme 2011+ / irrécupérable. Assertion de build interdisant le retour d'un élément exclu dans le parcours élève. Mesure avant/après consignée.",
};

export function renderPlan(): string {
  const out: string[] = [];
  out.push("# PLAN — 001 Fiabilité élève");
  out.push("");
  out.push("> Pour chaque exigence : cause racine suspectée, fichiers visés (interdits exclus), stratégie, preuve exigée.");
  out.push("> `AGENTS.md` prime : la liste « fichiers interdits » ci-dessous est reprise telle quelle, jamais interprétée.");
  out.push(hr());
  const frToTask = new Map<string, Task>();
  TASKS.forEach((t) => t.covers.forEach((c) => frToTask.set(c, t)));
  const ordered: AuditItem[] = [...ITEMS].sort((a, b) => (a.prio > b.prio ? 1 : a.prio < b.prio ? -1 : 0));
  ordered.forEach((it) => {
    const fr = it.fr?.split(" — ")[0] ?? "";
    const t = frToTask.get(fr);
    const track = TRACKS.find((x) => x.id === t?.track);
    const isVerrou = it.etat.startsWith("à verrouiller");
    out.push(`## ${it.id} → ${fr} [${it.prio} · ${it.axe}]`);
    out.push("");
    out.push(`**Tâche :** ${t?.id ?? "—"} (${track?.label ?? "—"}) · ${t?.parallel ? "[P] parallélisable" : "séquentielle"}${t && t.deps.length ? ` · dépend de ${t.deps.join(", ")}` : " · aucune dépendance"}`);
    out.push("");
    out.push(`**Cause racine suspectée**`);
    out.push("");
    out.push(ROOT_CAUSE[fr] ?? "À déterminer à l'exécution — aucune supposition non vérifiée n'est admise comme cause.");
    out.push("");
    out.push("**Fichiers sources visés**");
    out.push("");
    out.push("- ✅ Autorisés :");
    t?.filesAllowed.forEach((f) => out.push(`  - \`${f}\``));
    out.push("- ⛔ Interdits (`AGENTS.md`) :");
    (t?.filesForbidden ?? []).forEach((f) => out.push(`  - \`${f}\``));
    out.push("");
    out.push("**Stratégie de correction**");
    out.push("");
    out.push(isVerrou ? STRATEGY.verrou : t && t.track.startsWith("contenu") ? STRATEGY.contenu : t && t.track === "methodo-dictionnaires" ? STRATEGY.couverture : STRATEGY.moteur);
    out.push("");
    out.push("**Preuve exigée**");
    out.push("");
    out.push(`- Extrait **unité × page** du manuel officiel consigné dans le message de commit (pour tout contenu).`);
    out.push(`- **Test rouge → vert** : le cas de l'audit est écrit en test AVANT la correction.`);
    out.push(`- Recoupement \`grep\` contre \`data/bookContent.json\` pour toute correction de contenu.`);
    out.push(`- Mesure avant → après dans le message de commit (AGENTS.md, discipline git).`);
    out.push("");
    it.ac?.forEach((a) => out.push(`- [ ] ${a}`));
    out.push(hr());
  });
  out.push("## Stratégie de validation globale");
  out.push("");
  out.push("```bash");
  out.push("npm run lint                      # tsc --noEmit — 0 erreur");
  out.push("npx vitest run                    # suite principale — 100 % verte");
  out.push("npx jest                          # second runner — 100 % verte");
  out.push("npx tsx tests/boussole.test.ts    # boussole — 100 % verte");
  out.push("npm run build                     # build OK");
  out.push("```");
  out.push("");
  out.push("**Règles de validation issues d'`AGENTS.md` :**");
  out.push("");
  out.push("- Une suite partiellement rouge n'est pas acceptable. Exception connue : `figureZoom*` (travail concurrent).");
  out.push("- `@testing-library/jest-dom` n'est pas câblé → `.toBeTruthy()`, `.toBeNull()`, `.toHaveLength()` + `cleanup()` explicite.");
  out.push("- Recoupement `grep` obligatoire contre `data/bookContent.json` pour toute correction de contenu.");
  out.push("- Windows : jamais `&&` entre commandes PowerShell ; arabe via outil de fichier ; `[System.IO.File]::WriteAllText($f, $txt, [System.Text.UTF8Encoding]::new($false))` (pas de BOM).");
  out.push("- Toute tâche touchant le barème ou le scoring rappelle **P2/R6** en tête de commit : aucun fit sur notes prof, aucun modèle `a·cov+b`, barème officiel 5/7/8 pts uniquement.");
  out.push("- `okacha.ts` / `hosila.ts` sont générés (`scripts/build_hosila.ts`) — jamais édités à la main.");
  out.push(hr());
  out.push("### Stratégies par famille");
  out.push("");
  out.push(`**Moteur & correcteur** — ${STRATEGY.moteur}`);
  out.push("");
  out.push(`**Contenu** — ${STRATEGY.contenu}`);
  out.push("");
  out.push(`**Verrouillage** — ${STRATEGY.verrou}`);
  out.push("");
  out.push(`**Couverture** — ${STRATEGY.couverture}`);
  return out.join("\n");
}

/* ═══════════════════════ tasks.md ═══════════════════════ */
export function renderTasks(): string {
  const out: string[] = [];
  out.push("# TASKS — 001 Fiabilité élève");
  out.push("");
  out.push("> Ordonnées par dépendances. `[P]` = exécutable en parallèle.");
  out.push("> Les 4 pistes sont disjointes par construction : aucun fichier partagé entre deux pistes `[P]` d'un même lot.");
  out.push("");
  out.push("## Vue des 4 pistes parallèles");
  out.push("");
  out.push("| Piste | Périmètre | Tâches |");
  out.push("|---|---|---|");
  TRACKS.forEach((tr) => {
    const ts = TASKS.filter((t) => t.track === tr.id);
    out.push(`| **${tr.label}** | \`${tr.scope}\` | ${ts.map((t) => `${t.id}${t.parallel ? " [P]" : ""}`).join(" · ")} |`);
  });
  out.push("");
  out.push("⚠️ **Conflit d'édition maîtrisé :** les tâches du domaine III (T-20 → T-21 → T-22 → T-24) touchent le même fichier et sont donc **séquentielles**, malgré leur appartenance à une piste parallèle.");
  out.push("");
  out.push("## Ordre d'exécution");
  out.push("");
  out.push("```");
  out.push("T-00  PRÉREQUIS (bloque la CLÔTURE des tâches de contenu, pas leur démarrage)");
  out.push("  ├─ [P] Piste 1  T-01 → T-02 → T-03 → T-04 → T-05   (moteur)");
  out.push("  ├─ [P] Piste 2  T-10                               (domaine I)");
  out.push("  ├─ [P] Piste 3  T-23  +  T-20 → T-21 → T-22 → T-24 (domaines II/III)");
  out.push("  └─ [P] Piste 4  T-30 → T-31 → T-32                 (méthodo/dico)");
  out.push("```");
  out.push(hr());
  [...TASKS]
    .sort((a, b) => a.order - b.order)
    .forEach((t) => {
      const track = TRACKS.find((x) => x.id === t.track)!;
      out.push(`### ${t.id} ${t.parallel ? "[P]" : "   "} — ${t.title}`);
      out.push("");
      out.push(`- **Piste :** ${track.label} · \`${track.scope}\``);
      out.push(`- **Exigences couvertes :** ${t.covers.join(", ")}`);
      out.push(`- **Priorités :** ${t.prios.join(" · ")}`);
      out.push(`- **Dépendances :** ${t.deps.length ? t.deps.join(", ") : "aucune"}`);
      out.push("");
      out.push("**Périmètre de fichiers EXACT**");
      out.push("");
      out.push("```");
      out.push("AUTORISÉS :");
      t.filesAllowed.forEach((f) => out.push("  " + f));
      out.push("INTERDITS (AGENTS.md) :");
      t.filesForbidden.forEach((f) => out.push("  " + f));
      out.push("```");
      out.push("");
      out.push("**Étapes**");
      out.push("");
      t.steps.forEach((s, i) => out.push(`${i + 1}. ${s}`));
      out.push("");
      out.push("**Commande de vérification de la tâche**");
      out.push("");
      out.push("```bash");
      t.verify.forEach((v) => out.push(v));
      out.push("```");
      if (t.reminder) {
        out.push("");
        out.push(`> ⚠️ ${t.reminder}`);
      }
      out.push(hr());
    });
  out.push("## Discipline git (reprise d'`AGENTS.md`)");
  out.push("");
  out.push("- `git add` **explicite** fichier par fichier. Jamais `git add -A` ni `git add .`.");
  out.push("- **Cette session : rien à committer hormis `specs/001-fiabilite-eleve/`** (`git add specs/`).");
  out.push("- `git push` **JAMAIS** sans validation explicite.");
  out.push("- Pas de réécriture d'historique (`filter-repo`, `rebase` public) sans validation destructive explicite.");
  out.push("- Message de commit : ce qui a changé · **la preuve** (copie/écart/chiffre/page) · la mesure avant → après.");
  return out.join("\n");
}

/* ═══════════════════════ checklist ═══════════════════════ */
export function renderChecklist(): string {
  const out: string[] = [];
  out.push("# CHECKLIST — validation avant merge");
  out.push("");
  out.push("> Aucun merge tant qu'une case n'est pas cochée. `AGENTS.md` prime en cas de doute : **ne pas faire et demander**.");
  out.push(hr());
  out.push("## 1. Suite complète verte");
  out.push("");
  out.push("- [ ] `npm run lint` — tsc --noEmit, 0 erreur");
  out.push("- [ ] `npx vitest run` — 100 % vert (aucune suite partiellement rouge tolérée)");
  out.push("- [ ] `npx jest` — 100 % vert (second runner)");
  out.push("- [ ] `npx tsx tests/boussole.test.ts` — 100 % vert");
  out.push("- [ ] `npm run build` — OK");
  out.push("- [ ] Exception `figureZoom*` documentée si rouge (travail concurrent, seul cas toléré)");
  out.push(hr());
  out.push("## 2. Tests spécifiques de la tâche");
  out.push("");
  out.push("- [ ] Le test du cas d'audit a bien été écrit **en rouge avant** la correction");
  out.push("- [ ] Ce test est vert et conservé de façon permanente (régression impossible)");
  out.push("- [ ] Aucun test existant n'a été supprimé, renommé ou affaibli pour passer au vert");
  out.push("- [ ] Scripts de vérification empirique relancés (`verify_b2_negation.ts`, scans de contenu)");
  out.push(hr());
  out.push("## 3. Relecture humaine du contenu arabe — OBLIGATOIRE pour P0-scientifique");
  out.push("");
  out.push("- [ ] Relecture par un professeur de SVT 3AS (arabe فصحى) pour toute correction de contenu");
  out.push("- [ ] Vérification que le terme substitué est celui du manuel officiel, pas une paraphrase");
  out.push("- [ ] Filtre de confusion graphique appliqué et documenté : **ر/ز · ح/ة · ف/ب**");
  out.push("- [ ] Aucune glose inventée : texte repris depuis `data/bookContent.json`, mot pour mot");
  out.push("- [ ] Nom du relecteur + date consignés dans le message de commit");
  out.push("- [ ] Aucun dialecte algérien dans un contenu élève (فصحى uniquement)");
  out.push(hr());
  out.push("## 4. Recoupement des citations");
  out.push("");
  out.push("- [ ] Extrait **unité × page** du manuel consigné pour chaque correction de contenu");
  out.push("- [ ] `grep` de recoupement exécuté contre `data/bookContent.json`");
  out.push("- [ ] Si `INDEX.md` absent : la hiérarchie de vérité appliquée est signalée dans le commit (PR-2)");
  out.push("- [ ] Si `docs/audits_livres/` absent : la preuve page officielle est marquée **À COMPLÉTER** (PR-1) — tâche non clôturée");
  out.push("- [ ] Aucune exigence sans ID d'audit + preuve attachée");
  out.push(hr());
  out.push("## 5. Périmètre et fichiers interdits");
  out.push("");
  out.push("- [ ] `git status` relu ligne par ligne : aucun fichier interdit d'`AGENTS.md` dans le diff");
  out.push("- [ ] `okacha.ts` / `hosila.ts` non modifiés à la main (passent par `scripts/build_hosila.ts`)");
  out.push("- [ ] `src/App.tsx`, `src/data/lessonIndex.ts`, `src/data/activeLessons.ts`, `public/lessons/*.html`, SVG non touchés");
  out.push("- [ ] Aucun fichier `tmp_*` créé et laissé dans le diff");
  out.push("- [ ] Aucun contenu hors programme 2011+ introduit dans le parcours élève");
  out.push("- [ ] Aucune nouvelle fonctionnalité (ce speckit ne traite que la fiabilité)");
  out.push(hr());
  out.push("## 6. Barème et scoring — rappel P2/R6");
  out.push("");
  out.push("- [ ] **Aucun fit sur les notes prof. Aucun modèle `a·cov+b`.**");
  out.push("- [ ] Seuls les chiffres du barème officiel (5/7/8 pts) ont été utilisés");
  out.push("- [ ] Les 8 tags du correcteur et le scoreur restent **INCHANGÉS**");
  out.push("- [ ] `baremeCorrecteur.ts` non modifié, sauf correction de contenu de corrigé justifiée par une page officielle");
  out.push("- [ ] Le corpus des 40 `eleve_*.txt` n'a PAS été utilisé comme jeu de validation (calibrage uniquement, plancher jamais performance)");
  out.push(hr());
  out.push("## 7. Git");
  out.push("");
  out.push("- [ ] `git add` **explicite** fichier par fichier (jamais `-A`, jamais `.`)");
  out.push("- [ ] Message de commit : ce qui a changé · **la preuve** (copie/écart/chiffre/page) · mesure avant → après");
  out.push("- [ ] **`git push` NON exécuté** — en attente de validation explicite");
  out.push("- [ ] Aucune réécriture d'historique sans validation destructive explicite");
  out.push(hr());
  out.push("## 8. Windows — rappels");
  out.push("");
  out.push("- [ ] Aucun arabe inline en console (mojibake) — arabe écrit via outil de fichier");
  out.push("- [ ] Aucune commande `&&` sous PowerShell (commandes séparées)");
  out.push("- [ ] Aucun `Out-File -Encoding utf8` (BOM) — `[System.IO.File]::WriteAllText(...)` avec `UTF8Encoding($false)`");
  return out.join("\n");
}

/* ═══════════════════════ rapport de session ═══════════════════════ */
export function renderReport(): string {
  const out: string[] = [];
  const s = STATS;
  out.push("# RAPPORT DE SESSION — 001 Fiabilité élève");
  out.push("");
  out.push("**Session :** spécification uniquement — aucun code ni fichier de contenu modifié.");
  out.push("**Sources réellement lues cette session :** `AGENTS.md` (intégral) · `docs/AUDIT_MORCHID_VERDICT_2026-09-25.md` (intégral) · `docs/ANALYSE_AUDITS_OPUS_GEMINI_2026-09-25.md` (intégral).");
  out.push("**Sources introuvables :** `docs/audits_livres/*` (404) · `INDEX.md` (404). **Source non lue :** `data/bac_sessions_2019_2026.json`.");
  out.push(hr());
  out.push("## 1. Bilan d'ingestion");
  out.push("");
  out.push(`| | |`);
  out.push(`|---|---|`);
  out.push(`| Allégations sources examinées | **${s.sourceItems}** |`);
  out.push(`| Items **retenus** | **${s.retained}** |`);
  out.push(`| — P0 (élève apprend du faux / noté en faux) | ${s.p0} (Scientifique ${s.p0Sci} · Notation ${s.p0Not}) |`);
  out.push(`| — P1 (dégradation forte de l'apprentissage) | ${s.p1} |`);
  out.push(`| — P2 (confort / qualité) | ${s.p2} |`);
  out.push(`| Items **jetés** (annexe, raison consignée) | **${s.rejected}** |`);
  out.push(`| Prérequis non exécutés | ${PREREQS.length} (PR-1, PR-2, PR-3) |`);
  out.push(`| Divergences inter-audits tranchées | ${DIVERGENCES.length} |`);
  out.push("");
  out.push(`Taux de rejet : **${Math.round((s.rejected / s.sourceItems) * 100)} %** des allégations sources. C'est le chiffre le plus important de ce rapport : un tiers des « bugs » allégués étaient déjà corrigés, et deux notes globales d'audit divergent de 15 points sur des choix de grading. **Aucun item sans preuve empirique n'a été retenu.**`);
  out.push(hr());
  out.push("## 2. Couverture — 100 % des P0");
  out.push("");
  out.push(`| P0 | Axe | Story | Critères mesurables | Exigence | Tâche | Preuve exigée |`);
  out.push(`|---|---|---|---|---|---|---|`);
  [...ITEMS]
    .filter((i) => i.prio === "P0")
    .sort((a, b) => (a.axe > b.axe ? 1 : -1))
    .forEach((i) => {
      const fr = i.fr?.split(" — ")[0] ?? "";
      const t = TASKS.find((x) => x.covers.includes(fr));
      out.push(`| ${i.id} | ${i.axe} | ✅ | ${i.ac?.length ?? 0} | ${fr} | ${t?.id ?? "—"}${t?.parallel ? " [P]" : ""} | test rouge→vert ${i.axe === "Scientifique" ? "+ unité×page" : ""} |`);
    });
  out.push("");
  out.push(`**Couverture : ${s.coverage} % des ${s.retained} items retenus disposent d'une story + critères d'acceptation mesurables ; 100 % des ${s.p0} P0 disposent d'une exigence tracée, d'un test d'acceptation et d'une tâche assignée.**`);
  out.push("");
  out.push(`Répartition des ${s.tasks} tâches sur 4 pistes disjointes : ` + TRACKS.map((t) => `${t.label} ${TASKS.filter((x) => x.track === t.id).length}`).join(" · ") + ` — dont ${s.tasksP0} tâches P0.`);
  out.push(hr());
  out.push("## 3. Divergences entre audits — tranchées par la hiérarchie de vérité");
  out.push("");
  DIVERGENCES.forEach((d, i) => {
    out.push(`### D${i + 1} — ${d.topic}`);
    out.push("");
    out.push("| Audit | Position |");
    out.push("|---|---|");
    d.says.forEach((s2, k) => out.push(`| ${k === 0 ? "Source A" : "Source B"} | ${s2} |`));
    out.push("");
    out.push(`**Tranché :** ${d.ruling}`);
    out.push("");
    out.push(`> **Base de la décision :** ${d.basis}`);
    out.push("");
  });
  out.push(hr());
  out.push("## 4. Ce que cette session n'a PAS pu faire");
  out.push("");
  PREREQS.forEach((p) => out.push(`- **${p.id}** — ${p.what} : ${p.status}. ${p.blocking}`));
  out.push("");
  out.push("**Conséquence assumée :** aucune exigence de conformité livres A/B/C ni de divergence D_METHODO n'a été spécifiée. Créer ces exigences sans les documents aurait violé la règle « item sans preuve = item jeté ». Le speckit est donc **complet sur ce qui était prouvable** et **explicitement incomplet sur le reste**, avec le chemin de complétion (T-00).");
  out.push(hr());
  out.push("## 5. Décision demandée avant exécution");
  out.push("");
  out.push("1. **Confirmer ou fournir `docs/audits_livres/*` et `INDEX.md`** — sinon T-00 doit les produire avant toute clôture de tâche de contenu.");
  out.push("2. **Valider le classement P0 des 3 items en « verrouillage »** (B2, B3, B7) : le code lu après l'audit contient les correctifs, mais aucun test de régression ne les protège. Le speckit les traite en verrouillage, pas en correction.");
  out.push("3. **Confirmer que `data/bookContent.json` reste en lecture seule** dans toutes les tâches de contenu (source de vérité, jamais modifiée).");
  return out.join("\n");
}
