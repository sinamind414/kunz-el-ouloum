// Données de l'audit — établies par lecture statique du dépôt
// github.com/sinamind414/kunz-el-ouloum au commit 70b69ec (4 nov. 2026).
// Chaque « constat » renvoie à un fichier ou à un comptage effectué sur ce commit.
// L'application n'a été ni compilée ni exécutée : tout ce qui relève du rendu,
// de la performance ou de l'usage réel est classé « Non vérifiable ».

export type Priority = "haute" | "moyenne" | "basse";

export interface Axe {
  id: number;
  titre: string;
  titreAr: string;
  poids: number;
  note: number;
  resume: string;
  verdict: string;
  couleur: string;
  constats: string[];
  interpretations: string[];
  forces: string[];
  faiblesses: string[];
  preuves: { label: string; valeur: string; source: string }[];
  nonVerifiable: string[];
  recommandations: { prio: Priority; texte: string; chiffrage: string }[];
}

export const BASE_AUDIT = {
  depot: "github.com/sinamind414/kunz-el-ouloum",
  commit: "70b69ec",
  dateCommit: "4 nov. 2026",
  fichiers: 4403,
};

export const AXES: Axe[] = [
  {
    id: 1,
    titre: "Conformité pédagogique au programme officiel",
    titreAr: "المطابقة مع المنهاج الرسمي",
    poids: 15,
    note: 8.0,
    resume:
      "Programme officiel 3AS sciences expérimentales respecté (3 domaines, 11 unités, 108 h), hors-programme et errata du manuel traités ; aucune relecture disciplinaire externe documentée.",
    verdict: "Très bon : le découpage officiel est suivi et les écarts connus sont déclarés par le code lui-même.",
    couleur: "#0d5c46",
    constats: [
      "curriculumOfficial.ts encode 11 unités en 3 domaines — التخصص الوظيفي للبروتينات (U1-U5), التحولات الطاقوية (U6-U8), التكتونية العامة (U9-U11) — avec volume horaire officiel (8, 5, 5, 18, 15, 15, 15, 2, 10, 2 et 13 h, soit 108 h), fenêtre trimestrielle et compétence visée.",
      "Sources déclarées : التدرج السنوي للتعلمات (juin 2017) et دليل الأستاذ (2017). Le fichier précise que l'ancrage n'est pas mot à mot : 15 citations exactes sur 42, et 13 sous 85 % de recouvrement, marquées « à réviser » (OCR bruité).",
      "NON_EXIGIBLES liste 3 contenus du manuel écartés (المتمم، مبدأ الأسيلوسكوب، نضج الـ ARNm). CULTURE_GENERALE signale par un bandeau 2 chapitres d'enrichissement hors exigible (hydrocarbures en Algérie ; cycle énergie-matière de la biosphère).",
      "manuelErrata.ts reprend les tableaux « تصويب الأخطاء » du guide du professeur : un terme erroné imprimé dans le manuel n'est pas sanctionné par le correcteur.",
      "J'ai relu 8 QCM sur 550, pris dans 8 unités différentes : aucune erreur scientifique relevée (ex. drépanocytose : Glu remplacé par Val sur la chaîne β ; gradient de H+ établi à travers la membrane interne mitochondriale).",
      "L'application vise une seule filière, علوم تجريبية. Aucun sélecteur de filière n'existe dans le code.",
    ],
    interpretations: [
      "La règle citée en tête du fichier — l'élève est examiné sur le programme, pas sur le contenu du manuel — est appliquée concrètement. C'est le bon réflexe pour éviter à l'élève de réviser du hors-programme.",
      "La liste d'unités de la grille d'audit (biologie animale et végétale, génétique, écologie) ne correspond pas au programme de 3AS ; l'application suit le découpage officiel en trois domaines, et c'est elle qui est juste sur ce point.",
      "Une partie du corpus a une origine automatisée : le catalogue d'unités est « auto-generated » depuis un ancien projet Flutter, et les en-têtes de code reconnaissent que d'anciens sujets blancs venaient d'un document généré par IA (remplacés le 17/10/2026). Sans visa d'un enseignant, la confiance repose sur les tests, pas sur une relecture disciplinaire.",
    ],
    forces: [
      "Découpage officiel avec heures et fenêtres trimestrielles par unité.",
      "Hors-programme et enrichissement explicitement balisés.",
      "Errata officiels du manuel intégrés au correcteur.",
    ],
    faiblesses: [
      "13 citations du référentiel encore « à réviser » selon le fichier lui-même.",
      "Aucune relecture externe documentée ; une seule carte de survie sur 5 est marquée validée.",
      "Filière unique : rien pour les séries Maths ou Technique.",
    ],
    preuves: [
      { label: "Unités / heures", valeur: "11 unités · 108 h", source: "curriculumOfficial.ts" },
      { label: "Ancrage référentiel", valeur: "15 / 42 exactes", source: "curriculumOfficial.ts (en-tête)" },
      { label: "Hors exigible balisé", valeur: "3 + 2 contenus", source: "NON_EXIGIBLES, CULTURE_GENERALE" },
      { label: "QCM relus", valeur: "8 / 550 corrects", source: "échantillon de l'auditeur" },
    ],
    nonVerifiable: [
      "Exactitude des 542 autres QCM et des 44 chapitres : non relus intégralement.",
      "Conformité à une éventuelle révision du programme postérieure à 2017 : je n'ai consulté aucune source ministérielle plus récente.",
    ],
    recommandations: [
      {
        prio: "haute",
        texte: "Faire viser le corpus par un enseignant de SVT, en commençant par les 13 citations « à réviser » et les 4 cartes de survie non validées, puis afficher ce visa dans l'application.",
        chiffrage: "13 citations + 4 cartes",
      },
      {
        prio: "moyenne",
        texte: "Annoncer le périmètre au premier lancement : « filière علوم تجريبية uniquement ».",
        chiffrage: "1 écran",
      },
      {
        prio: "basse",
        texte: "Relire par échantillonnage 5 QCM par unité avec un enseignant et publier le taux d'erreur trouvé.",
        chiffrage: "55 QCM (10 %)",
      },
    ],
  },
  {
    id: 2,
    titre: "Richesse, qualité et hiérarchisation des contenus",
    titreAr: "ثراء المحتوى وترتيب الأولويات",
    poids: 12,
    note: 7.0,
    resume:
      "Corpus volumineux mais court par item (capsules de 45 à 120 s, chapitres lisibles en quelques minutes) ; le poids d'examen n'est renseigné que pour 7 unités sur 11 et aucun item ne porte de priorité.",
    verdict: "Bon : la matière est découpée finement, mais le tri entre essentiel et secondaire reste à la charge de l'élève.",
    couleur: "#b45309",
    constats: [
      "Volumes comptés dans le dépôt : 44 chapitres HTML (28 480 mots, environ 1 100 par fichier de deux chapitres), 550 QCM, 121 textes à trous, 69 drills de schéma, 32 micro-capsules « فكرة في دقيقة », 22 situations, 11 cartes mentales (une par unité), 112 schémas SVG.",
      "Chaque unité a une fiche d'ouverture (unitOpenings.ts) : question centrale, promesse « ce que l'élève saura faire », itinéraire en 3 à 5 étapes, prérequis, pièges connus, première action à faire.",
      "Le poids au Bac (bacWeightPercent) n'est renseigné que pour U1 à U7 : 10, 9, 13, 13, 16, 20 et 19 %, soit 100 % à elles sept. U8 à U11 n'en ont pas et reçoivent la valeur 5 par défaut dans le plan de révision.",
      "154 QCM sur 550 (28 %) portent sur le domaine 3, la tectonique. Ce domaine représente 25 h sur 108 en classe (23 %), mais environ 3 % des points dans l'index des 65 exercices tombés de 2016 à 2026 (recalcul de ma part, première unité citée par exercice).",
      "Micro-capsules : 20 pour le domaine 1, 9 pour le domaine 2, 3 pour le domaine 3.",
      "Ni les QCM ni les textes à trous ne portent de niveau de priorité. Les cartes de survie des 5 chapitres prioritaires existent, mais une seule (sc_enzymes) est marquée publiable.",
      "Pas de glossaire français-arabe dédié : les termes français apparaissent au fil du texte, par exemple « ARN بوليميراز (ARN polymérase) ». Une seule balise de tableau dans les 25 fichiers de leçons.",
    ],
    interpretations: [
      "Le format est déjà court. Le risque de submersion ne vient pas de la longueur des items mais de leur nombre, et de l'absence de tri visible à l'intérieur d'une unité.",
      "Le code documente lui-même l'écart entre poids annoncé et pression constatée à l'examen. Cette information alimente le plan de révision ; je n'ai pas pu vérifier sous quelle forme elle est montrée à l'élève.",
      "La répartition des QCM suit le volume horaire de la classe, pas la pression d'examen : un élève qui enchaîne les QCM unité par unité consacre plus du quart de son effort au domaine le moins représenté dans les exercices indexés.",
    ],
    forces: [
      "Fiche d'ouverture complète pour les 11 unités.",
      "Formats courts : capsules de 45 à 120 secondes.",
      "Explication et schéma sur chacun des 550 QCM.",
    ],
    faiblesses: [
      "Poids d'examen absent pour 4 unités sur 11.",
      "Aucune priorité au niveau de l'item ; 4 cartes de survie sur 5 non publiées.",
      "Pas de glossaire bilingue ; tableaux comparatifs quasi absents des leçons.",
    ],
    preuves: [
      { label: "Chapitres", valeur: "44 · 28 480 mots", source: "public/lessons (25 fichiers)" },
      { label: "QCM", valeur: "550, tous expliqués", source: "src/quizCorpus" },
      { label: "Micro-capsules", valeur: "32 · 45 à 120 s", source: "microCapsules.ts" },
      { label: "Poids renseigné", valeur: "7 unités sur 11", source: "unitOpenings.ts" },
    ],
    nonVerifiable: [
      "Qualité visuelle des 112 schémas et contenu des cartes mentales : fichiers non ouverts.",
      "Mise en page et lisibilité à l'écran : application non exécutée.",
    ],
    recommandations: [
      {
        prio: "haute",
        texte: "Renseigner le poids des 4 unités manquantes à partir de l'index des sessions, et afficher sur chaque fiche d'unité le poids annoncé à côté de la part réellement constatée.",
        chiffrage: "4 valeurs · 11 fiches",
      },
      {
        prio: "haute",
        texte: "Marquer chaque QCM selon trois niveaux — tombé au Bac, fréquent, approfondissement — en s'appuyant sur les 65 exercices indexés.",
        chiffrage: "550 QCM · 3 niveaux",
      },
      {
        prio: "moyenne",
        texte: "Publier après relecture les 4 cartes de survie en attente et ajouter un tableau comparatif par unité.",
        chiffrage: "4 cartes · 11 tableaux",
      },
    ],
  },
  {
    id: 3,
    titre: "Parcours d'apprentissage et stratégies d'assimilation",
    titreAr: "مسار التعلّم واستراتيجيات الاستيعاب",
    poids: 18,
    note: 7.5,
    resume:
      "Le guidage existe et il est sérieux — une tâche par jour, plan de 1 à 60 jours pondéré par le poids d'examen, SM-2 réel — mais il est le même pour tous : ni test de positionnement, ni objectif de note, ni calage sur la date du Bac.",
    verdict: "Bon : l'élève n'est pas lâché devant une bibliothèque, mais le parcours ne s'adapte pas à son niveau.",
    couleur: "#0f766e",
    constats: [
      "Chemin « مساري » (ParcoursView, nbaEngine.ts) : une seule tâche proposée, choisie dans l'ordre reprise de l'item commencé, rappel échu à J+14, quota du jour atteint (repos), nouvel item. Un quota journalier borne le nombre de validations.",
      "Plan de révision finale (revisionPlan.ts) : l'élève règle les jours restants (1 à 60) et les minutes par jour (20 à 240), avec 4 préréglages. Les unités sont ordonnées par la moyenne du poids annoncé et de la part constatée, plus un bonus de difficulté ; les types de tâche alternent ; les 2 derniers jours sont réservés à la consolidation.",
      "Carte « برنامج اليوم » sur l'accueil (TodayCard) : les 3 premières tâches non cochées du jour.",
      "Répétition espacée : SM-2 (lib/sm2.ts) pour les flashcards et pour 16 concepts à rappel, avec une qualité calculée sur les preuves présentes dans la réponse rédigée. 3 rappels de 2 minutes par jour sont injectés dans le plan.",
      "Métacognition : après un QCM raté, la question « من أين جاء خطؤك في هذا التمرين؟ » propose 4 causes rattachées à une taxonomie de 10 erreurs ; 31 micro-remédiations, dont 11 programment un rappel.",
      "Méthodologie intégrée : fiches des verbes de consigne, fiche A4 imprimable (BoussoleCard), atelier de rédaction, exercice de tri تحليل / تفسير.",
      "Non trouvés dans le code : test de positionnement initial, objectif de note, profils d'élève. Le nombre de jours restants est saisi à la main ; aucune date de Bac n'est utilisée par le plan.",
      "diagnosticQuiz.ts l'écrit explicitement : aucune question du corpus ne porte d'étiquette de notion, donc l'application ne peut pas déduire la cause d'une erreur de QCM ; elle la demande à l'élève.",
    ],
    interpretations: [
      "Sur la question centrale de l'audit, le code répond mieux que le README ne le laisse voir : une tâche à la fois et un quota, c'est exactement ce qui protège un élève moyen de la surcharge.",
      "Trois mécanismes de rappel coexistent : SM-2 des flashcards, SM-2 des 16 concepts, rappel fixe à J+14 du chemin. Pour l'élève, cela peut faire trois files « à revoir » ; une seule serait plus lisible.",
      "Le poids annoncé et le bonus de difficulté n'existent que pour U1 à U7 : le plan sous-pondère mécaniquement la tectonique. C'est cohérent avec la pression constatée, mais je n'ai vu aucune explication destinée à l'élève, qui peut y voir un oubli.",
      "Sans étiquette de notion sur les QCM, le profil d'erreurs dépend de ce que l'élève déclare ; un élève qui ne répond pas à la question garde un profil vide.",
    ],
    forces: [
      "Une tâche à la fois, avec quota journalier.",
      "Plan pondéré par le poids d'examen, consolidation les 2 derniers jours.",
      "SM-2 fondé sur la qualité de la réponse, pas sur le nombre de passages.",
    ],
    faiblesses: [
      "Pas de test de positionnement ni d'objectif de note : même parcours pour tous.",
      "Plan limité à 60 jours, jours restants saisis à la main.",
      "QCM sans étiquette de notion : lacunes non détectées automatiquement.",
    ],
    preuves: [
      { label: "Plan de révision", valeur: "1-60 j · 20-240 min", source: "planSettings.ts" },
      { label: "Rappel du chemin", valeur: "J+14 fixe", source: "parcoursProgress.ts" },
      { label: "Concepts en SM-2", valeur: "16", source: "volumeCorpus.lock.test.ts" },
      { label: "Micro-remédiations", valeur: "31 dont 11 rappels", source: "volumeCorpus.lock.test.ts" },
    ],
    nonVerifiable: [
      "Comportement réel du chemin sur plusieurs semaines : moteurs lus, non exécutés.",
      "Charge ressentie par un élève : aucun test utilisateur.",
      "Auto-estimation de la note avant correction : recherche par mots-clés non concluante.",
    ],
    recommandations: [
      {
        prio: "haute",
        texte: "Ajouter au premier lancement un test de positionnement court, tiré du corpus existant, dont le résultat préremplit le plan et l'ordre du chemin.",
        chiffrage: "22 QCM (2 par unité)",
      },
      {
        prio: "haute",
        texte: "Étiqueter chaque QCM par notion pour que les erreurs alimentent automatiquement le profil et les rappels, sans dépendre de la déclaration de l'élève.",
        chiffrage: "550 étiquettes",
      },
      {
        prio: "moyenne",
        texte: "Demander la date du Bac et un objectif de note, en déduire jours restants et minutes par jour, et étendre le plan au-delà de 60 jours.",
        chiffrage: "2 champs · plan sur 12 semaines",
      },
      {
        prio: "moyenne",
        texte: "Réunir les trois mécanismes de rappel dans une seule file « à revoir aujourd'hui ».",
        chiffrage: "3 files → 1",
      },
    ],
  },
  {
    id: 4,
    titre: "Module d'exercices et de tests",
    titreAr: "التمارين والاختبارات",
    poids: 12,
    note: 7.5,
    resume:
      "Palette large et format réel du Bac respecté (3 exercices notés 5, 7 et 8 points) ; les QCM, tous expliqués, n'ont ni niveau de difficulté ni étiquette de notion.",
    verdict: "Bon : beaucoup de formats, mais l'analyse de documents reste le parent pauvre en volume.",
    couleur: "#1d4ed8",
    constats: [
      "Types présents : QCM à 4 options (550), textes à trous (121), drills « ارسم من الذاكرة » (69), situations complètes (22), QCM du livre officiel (41 chapitres), atelier de rédaction avec contrôle de forme, tri تحليل / تفسير, simulateur d'électrophorèse.",
      "Chaque QCM comporte une explication, un schéma associé et une phrase commençant par « في البكالوريا » qui relie la notion à l'épreuve.",
      "Clés de réponse équilibrées : 161, 130, 133 et 126 bonnes réponses en position A, B, C et D. La bonne réponse est l'option la plus longue dans 149 cas sur 550 (27 %, proche du hasard) : pas d'indice de forme exploitable.",
      "Le type QuizQuestion ne contient ni difficulté ni notion. Seules les 22 situations sont graduées (2 faciles, 12 moyennes, 8 difficiles). Dans les domaines 2 et 3, beaucoup d'énoncés suivent un gabarit du type « ما التعريف الصحيح لـ… ؟ ».",
      "Les réponses rédigées sont pré-notées par couverture des attendus obligatoires, avec plafonds d'intégrité et décision finale laissée au correcteur. Le README précise que le calibrage sur 40 copies est un plancher, pas une validation indépendante.",
    ],
    interpretations: [
      "Les QCM à gabarit entraînent surtout la restitution de définitions. L'analyse de documents, qui porte les exercices à 7 et 8 points, passe par les situations et l'atelier : c'est là que le volume est le plus faible.",
      "Sans difficulté ni notion sur les QCM, ni progression graduée ni quiz adaptatif ne sont possibles.",
    ],
    forces: [
      "Explication, schéma et lien avec le Bac sur chaque QCM.",
      "Barème réel 5 / 7 / 8 repris partout.",
      "Clés de réponse sans biais de position ni de longueur.",
    ],
    faiblesses: [
      "QCM sans niveau de difficulté ni notion.",
      "Énoncés à gabarit centrés sur la définition.",
      "22 situations seulement pour 11 unités.",
    ],
    preuves: [
      { label: "QCM", valeur: "550 · 4 options", source: "src/quizCorpus" },
      { label: "Trous + drills", valeur: "121 + 69", source: "volumeCorpus.lock.test.ts" },
      { label: "Situations graduées", valeur: "22 (2 / 12 / 8)", source: "situationIndex.ts" },
      { label: "Clés A / B / C / D", valeur: "161 / 130 / 133 / 126", source: "comptage de l'auditeur" },
    ],
    nonVerifiable: [
      "Fiabilité du correcteur automatique sur des copies réelles.",
      "Présence de Vrai/Faux avec justification : non recherchée de façon exhaustive.",
    ],
    recommandations: [
      {
        prio: "haute",
        texte: "Ajouter un niveau de difficulté sur 3 crans à chaque QCM, puis proposer les questions dans l'ordre croissant au sein d'une unité.",
        chiffrage: "550 QCM · 3 crans",
      },
      {
        prio: "moyenne",
        texte: "Doubler les situations d'analyse de documents, en priorité sur les unités les plus présentes dans les exercices indexés (U1, U3, U4, U5).",
        chiffrage: "de 22 à 44 situations",
      },
      {
        prio: "basse",
        texte: "Réécrire une partie des énoncés à gabarit des domaines 2 et 3 en questions posées sur un document : courbe, schéma ou tableau.",
        chiffrage: "5 QCM par unité, soit 30",
      },
    ],
  },
  {
    id: 5,
    titre: "Banque de sujets Bac et simulation",
    titreAr: "بنك مواضيع البكالوريا والمحاكاة",
    poids: 10,
    note: 7.5,
    resume:
      "28 sujets officiels en PDF (2013 à 2026), 65 exercices indexés et deux simulateurs au format réel de 4 h 30 ; la correction notée dans l'application ne couvre que la session 2025.",
    verdict: "Bon : les sujets et le format sont là, la correction intégrée reste le maillon faible.",
    couleur: "#7e22ce",
    constats: [
      "public/bac-sujets contient 28 fichiers PDF, 2 sujets par an de 2013 à 2026, pour 94 Mo. bacPdfIndex.ts porte la mention « Autorisation propriétaire 2026-10-22 (droits ONEC résolus) ». Toutes les entrées sont de session principale ; le type « exceptional » existe sans aucune entrée.",
      "bacSessionIndex.ts indexe 65 exercices de 2016 à 2026 : idée, supports, notion évaluée, verbes de consigne, barème. Un exercice manque (2021, sujet 2, exercice 1) et les sessions 2013 à 2015 sont déclarées en attente.",
      "Corrigés : un lien externe vers eddirasa.com par session, donc connexion requise. La correction notée dans l'application (attendus obligatoires, note sur 20) n'existe que pour le sujet 2025.",
      "MockExamPanel compose un sujet numéroté à partir de 3 exercices réellement tombés (5 + 7 + 8 points, 270 minutes, budget de temps par exercice). Bac2025ExamView ajoute un chronomètre persistant de 4 h 30 et fait taire le tuteur pendant l'épreuve. Dans les deux vues, le chronomètre peut être mis en pause, ce que l'épreuve réelle ne permet pas.",
      "Le README affirme encore que le corpus ne reproduit pas les énoncés et qu'un seul sujet complet sert de référence : il est en retard sur le code.",
      "Les en-têtes de code reconnaissent que les 3 anciens « tests bac » (4 exercices de 5 points, 180 minutes) avaient un format qui n'existe pas à l'examen ; ils ont été remplacés le 17/10/2026.",
    ],
    interpretations: [
      "Avec les PDF, l'élève travaille sur le document d'origine ; l'index par idée et par verbe de consigne l'aide à repérer ce qui revient d'une année à l'autre.",
      "Le point faible est la correction : pour 10 sessions sur 11, l'élève doit sortir de l'application et être connecté, ce qui pèse précisément là où la couverture est mauvaise.",
      "94 Mo de PDF : s'ils sont embarqués dans l'APK ou mis en cache d'office, le poids dépasse la cible de 50 Mo de la grille. Je n'ai pas vérifié le contenu du build.",
      "La mention « droits résolus » est une affirmation du dépôt ; je n'ai aucun moyen de la confirmer.",
    ],
    forces: [
      "Sujets d'origine et index de 65 exercices.",
      "Format réel : 2 sujets au choix, 3 exercices, 4 h 30.",
      "Sujet numéroté, identique pour toute une classe.",
    ],
    faiblesses: [
      "Correction notée limitée à une session sur 11.",
      "Corrigés des autres sessions accessibles seulement en ligne.",
      "README contradictoire avec le code ; 2013-2015 non indexées.",
    ],
    preuves: [
      { label: "Sujets PDF", valeur: "28 · 94 Mo", source: "public/bac-sujets" },
      { label: "Exercices indexés", valeur: "65 (2016-2026)", source: "bacSessionIndex.ts" },
      { label: "Durée simulée", valeur: "270 min", source: "mockExam.ts" },
      { label: "Correction notée", valeur: "1 session sur 11", source: "Bac2025ExamView.tsx" },
    ],
    nonVerifiable: [
      "Contenu et lisibilité des PDF : seuls l'en-tête de fichier (3 PDF) et les tailles ont été contrôlés.",
      "Statut juridique réel de la diffusion des sujets.",
      "Verrouillage effectif des corrigés pendant une épreuve simulée.",
    ],
    recommandations: [
      {
        prio: "haute",
        texte: "Étendre la correction notée par attendus aux sessions 2024, 2023 et 2022.",
        chiffrage: "3 sessions · 18 exercices",
      },
      {
        prio: "haute",
        texte: "Embarquer hors ligne un corrigé résumé (attendus et barème) pour chacun des exercices indexés.",
        chiffrage: "65 exercices",
      },
      {
        prio: "moyenne",
        texte: "Télécharger les PDF à la demande au lieu de les embarquer, et mettre le README à jour sur la banque Bac.",
        chiffrage: "94 Mo évités · 1 fichier",
      },
    ],
  },
  {
    id: 6,
    titre: "UX/UI et ergonomie cognitive",
    titreAr: "تجربة الاستخدام",
    poids: 10,
    note: 7.0,
    resume:
      "Recherche, favoris, mode sombre, taille du texte et affichage droite-à-gauche sont présents dans le code ; l'interface n'ayant pas été exécutée, cette note reste provisoire.",
    verdict: "Note provisoire : les fonctions existent, leur qualité d'usage n'a pas pu être observée.",
    couleur: "#0e7490",
    constats: [
      "SearchView et utils/favorites.ts : recherche, favoris de leçons et recherches récentes.",
      "Mode sombre : variantes dédiées dans 67 fichiers source. Taille du texte : 3 crans (useTailleTexte, bouton dans l'en-tête).",
      "Le hub d'entraînement est plafonné à 8 cartes, limite de lisibilité verrouillée par un test.",
      "Interface en arabe, de droite à gauche (manifest.json) ; les bannières du chemin affichent aussi un titre français.",
      "Application web installable avec service worker à caches versionnés ; projet Android Capacitor (minSdk 24, soit Android 7) ; pas de dossier ios.",
    ],
    interpretations: [
      "Toutes les fonctions d'orientation demandées par la grille existent au niveau du code. Ce que je ne peux pas dire, c'est si elles sont faciles à trouver et agréables à utiliser.",
      "Plafonner un écran à 8 cartes et le garantir par un test montre une attention réelle à la charge visuelle.",
      "Sur iPhone, l'usage passe uniquement par le navigateur.",
    ],
    forces: [
      "Recherche, favoris, mode sombre et 3 tailles de texte.",
      "Limite de 8 cartes par écran, garantie par test.",
      "Fonctionnement hors ligne prévu dès la conception.",
    ],
    faiblesses: [
      "Interface en arabe uniquement, sans bascule vers le français.",
      "Pas d'application iOS native.",
      "94 Mo de PDF à gérer sur des téléphones au stockage limité.",
    ],
    preuves: [
      { label: "Mode sombre", valeur: "67 fichiers", source: "recherche dans src/" },
      { label: "Taille du texte", valeur: "3 crans", source: "useTailleTexte.ts" },
      { label: "Cartes par hub", valeur: "8 au plus", source: "ExamensHubView.tsx" },
      { label: "Android minimal", valeur: "7.0 (API 24)", source: "android/variables.gradle" },
    ],
    nonVerifiable: [
      "Rendu visuel, cohérence des couleurs, nombre de clics réel : application non exécutée.",
      "Temps de chargement et fluidité sur un téléphone à 2 Go de mémoire.",
      "Poids installé de l'APK.",
    ],
    recommandations: [
      {
        prio: "haute",
        texte: "Mesurer sur un téléphone d'entrée de gamme en 3G le temps de premier affichage, le poids installé et la mémoire utilisée, puis publier ces chiffres.",
        chiffrage: "1 appareil · 3 mesures",
      },
      {
        prio: "moyenne",
        texte: "Observer 5 élèves sur 3 tâches chronométrées : trouver une leçon, lancer la tâche du jour, ouvrir un sujet.",
        chiffrage: "5 élèves · 3 tâches",
      },
      {
        prio: "moyenne",
        texte: "Ajouter un glossaire français-arabe consultable depuis la recherche.",
        chiffrage: "1 glossaire",
      },
    ],
  },
  {
    id: 7,
    titre: "Fonctionnalités interactives et engagement",
    titreAr: "التفاعلية والتحفيز",
    poids: 13,
    note: 7.5,
    resume:
      "Boucle apprendre, tester, nommer l'erreur, remédier, rappeler fermée en local, avec série, points et badges ; ni classement ni entraide, et un tuteur à règles plutôt qu'une IA générative.",
    verdict: "Bon : la boucle est fermée et la motivation outillée ; l'entraide entre élèves manque.",
    couleur: "#be185d",
    constats: [
      "Révision active : flashcards en SM-2, drills de schéma, minuteur de concentration, mode défi (CombatTrainerView), animations, simulateur d'électrophorèse.",
      "Motivation : objectif quotidien réglable, série affichée seulement si elle est encore en cours, points d'expérience, badges, bilan hebdomadaire partageable.",
      "Le tuteur (AITutorView, smartTutorEngine) est un moteur local hors ligne ; le code le désigne comme « unique source » et n'appelle aucun modèle de langage.",
      "Statistiques : graphiques en barres et en secteurs (StatsView), export en image ; tableau de bord pour l'enseignant.",
      "Notifications : abonnement Web Push facultatif, qui suppose le serveur. Dictée vocale par l'API du navigateur.",
      "Aucune trace de classement entre élèves ni de forum dans src/.",
    ],
    interpretations: [
      "Un tuteur à règles est cohérent avec le hors-ligne et n'invente pas de contenu scientifique. En contrepartie, il ne répond pas à une question libre hors de son corpus ; l'appeler « AI » dans le code peut créer une attente s'il est présenté ainsi à l'élève.",
      "N'afficher la série que lorsqu'elle est vivante évite de culpabiliser l'élève qui a décroché quelques jours.",
      "L'absence de classement n'est pas un défaut pour un public sous pression ; l'absence d'entraide l'est davantage.",
    ],
    forces: [
      "Boucle erreur, cause, remédiation, rappel fermée sans serveur.",
      "Série, points, badges et objectif quotidien.",
      "Tuteur hors ligne, sans risque d'invention.",
    ],
    faiblesses: [
      "Pas de quiz adaptatif en temps réel.",
      "Aucune entraide entre élèves.",
      "Pas de courbe d'évolution dans le temps repérée.",
    ],
    preuves: [
      { label: "Tuteur", valeur: "moteur local", source: "AITutorView.tsx" },
      { label: "Série / points / badges", valeur: "présents", source: "DailyGoalWidget, BadgesView" },
      { label: "Classement, forum", valeur: "0 fichier", source: "recherche dans src/" },
      { label: "Graphiques", valeur: "barres, secteurs", source: "StatsView.tsx" },
    ],
    nonVerifiable: [
      "Pertinence des réponses du tuteur face à de vraies questions d'élèves.",
      "Fréquence et à-propos réels des notifications.",
    ],
    recommandations: [
      {
        prio: "moyenne",
        texte: "Ajouter une courbe d'évolution par unité sur 4 semaines et afficher sur l'accueil le point faible principal.",
        chiffrage: "11 courbes · 1 encart",
      },
      {
        prio: "moyenne",
        texte: "Présenter le tuteur à l'élève comme un guide, avec 3 exemples de ce qu'il sait faire.",
        chiffrage: "3 exemples",
      },
      {
        prio: "basse",
        texte: "Proposer un défi de classe hebdomadaire fondé sur le sujet numéroté commun et le bilan partageable, sans messagerie à modérer.",
        chiffrage: "1 défi par semaine",
      },
    ],
  },
  {
    id: 8,
    titre: "Fiabilité technique et accessibilité économique",
    titreAr: "الموثوقية والقدرة الشرائية",
    poids: 10,
    note: 7.5,
    resume:
      "Discipline d'ingénierie rare (323 fichiers de test, volumes verrouillés, hors-ligne d'abord) et modèle clair — domaine 1 gratuit, essai de 30 jours, 1 200 DA jusqu'au 30 juin — mais pas encore de publication sur les stores.",
    verdict: "Bon : socle technique solide et prix lisible ; la diffusion reste à faire.",
    couleur: "#4d7c0f",
    constats: [
      "323 fichiers de test dans src/ et tests/, un workflow d'intégration continue, des tests « lock » qui figent les volumes publiés. Je n'ai pas exécuté la suite ; le bilan interne du 21/10/2026 indique 3 584 tests passés sur 3 586.",
      "Hors-ligne d'abord : progression en stockage local, serveur facultatif, panneau de sauvegarde (BackupPanel), politique de confidentialité et FAQ dans l'application.",
      "Accès (acces.ts) : invité, domaine 1 (unités 1 à 5) ; essai de 30 jours, tout ; abonnement saison à 1 200 DA, valable jusqu'au 30 juin. Activation par code après un paiement BaridiMob réglé hors de l'application.",
      "Le même fichier précise que la lecture locale des droits « peut être trafiquée par un élève déterminé », la facturation restant côté serveur.",
      "Publication : le bilan du 21/10/2026 liste encore comme à faire le build signé et la création du compte Google Play. Version 1.0, pas de projet iOS.",
      "Dérive documentaire : l'en-tête de acces.ts parle encore d'« unité 1 seulement » alors que la constante ouvre les unités 1 à 5 ; le README décrit la banque Bac d'avant les PDF.",
    ],
    interpretations: [
      "1 200 DA la saison : acheté en octobre, cela revient à environ 133 DA par mois sur 9 mois ; acheté en avril, à 400 DA par mois sur 3 mois. On reste dans la fourchette de 100 à 500 DA, mais le prix unique pénalise l'achat tardif, qui est le moment où beaucoup d'élèves s'y mettent.",
      "Le domaine 1 gratuit couvre 5 unités, soit 51 h sur 108 du programme et la majorité des points de l'index des sessions : la version gratuite est réellement utile.",
      "Avec le seul stockage local, un nettoyage du navigateur efface la progression de l'élève invité s'il n'a pas fait de sauvegarde.",
    ],
    forces: [
      "Tests nombreux et volumes publiés verrouillés.",
      "Gratuit utile, essai de 30 jours, prix affiché sans publicité.",
      "Aucun compte obligatoire, données locales.",
    ],
    faiblesses: [
      "Pas encore sur Google Play à la date du bilan, donc ni avis ni installations.",
      "Prix unique défavorable à l'achat tardif ; activation qui exige une connexion.",
      "Progression perdue si le stockage local est effacé sans sauvegarde.",
    ],
    preuves: [
      { label: "Fichiers de test", valeur: "323", source: "comptage dans src/ et tests/" },
      { label: "Gratuit", valeur: "5 unités · 51 h", source: "acces.ts" },
      { label: "Abonnement", valeur: "1 200 DA → 30 juin", source: "acces.ts, facturation.ts" },
      { label: "Essai", valeur: "30 jours, tout", source: "acces.ts" },
    ],
    nonVerifiable: [
      "Stabilité sur appareil réel et résultat de la suite de tests à ce commit.",
      "Notes, avis et nombre d'installations : aucune fiche de store trouvée.",
      "Consommation de données à l'installation.",
    ],
    recommandations: [
      {
        prio: "haute",
        texte: "Publier l'APK signé sur Google Play : c'est la condition de toute diffusion et de tout retour d'utilisateurs.",
        chiffrage: "1 build signé · 1 fiche",
      },
      {
        prio: "moyenne",
        texte: "Prévoir un tarif réduit après le 1er mars, ou un paiement en 2 fois, pour ne pas pénaliser l'achat tardif.",
        chiffrage: "ex. 600 DA après mars",
      },
      {
        prio: "moyenne",
        texte: "Rappeler à l'élève invité de sauvegarder sa progression toutes les 2 semaines.",
        chiffrage: "1 rappel / 14 jours",
      },
      {
        prio: "basse",
        texte: "Aligner le README et l'en-tête de acces.ts sur l'état réel du code.",
        chiffrage: "2 fichiers",
      },
    ],
  },
];

// Score pondéré calculé en entiers pour éviter les arrondis flottants.
const TOTAL_X100 = AXES.reduce((s, a) => s + Math.round(a.note * 10) * a.poids, 0);
/** Score exact sur 100 (deux décimales). */
export const GLOBAL_EXACT = TOTAL_X100 / 100;
/** Score affiché, arrondi au dixième. */
export const GLOBAL_SCORE = Math.round(TOTAL_X100 / 10) / 10;
export const CONFIANCE = 4;

export const RECOMMANDATIONS_FLAT = AXES.flatMap((a) =>
  a.recommandations.map((r) => ({ ...r, axe: a.id, axeTitre: a.titre }))
);

/* ---------- Répartition par unité ---------- */
export interface Unite {
  id: number;
  domaine: 1 | 2 | 3;
  ar: string;
  fr: string;
  heures: number;
  qcm: number;
  capsules: number;
  /** Poids annoncé dans unitOpenings.ts — null si absent. */
  annonce: number | null;
  /** Part des points dans les 65 exercices indexés (recalcul de l'auditeur). */
  constate: number;
}

export const UNITES: Unite[] = [
  { id: 1, domaine: 1, ar: "تركيب البروتين", fr: "Synthèse des protéines", heures: 8, qcm: 39, capsules: 5, annonce: 10, constate: 18.6 },
  { id: 2, domaine: 1, ar: "العلاقة بين بنية ووظيفة البروتين", fr: "Relation structure-fonction", heures: 5, qcm: 46, capsules: 3, annonce: 9, constate: 5.1 },
  { id: 3, domaine: 1, ar: "النشاط الإنزيمي للبروتينات", fr: "Activité enzymatique", heures: 5, qcm: 50, capsules: 4, annonce: 13, constate: 14.7 },
  { id: 4, domaine: 1, ar: "دور البروتينات في الدفاع عن الذات", fr: "Immunité", heures: 18, qcm: 66, capsules: 4, annonce: 13, constate: 20.0 },
  { id: 5, domaine: 1, ar: "دور البروتينات في الاتصال العصبي", fr: "Communication nerveuse", heures: 15, qcm: 55, capsules: 4, annonce: 16, constate: 18.6 },
  { id: 6, domaine: 2, ar: "تحويل الطاقة الضوئية إلى طاقة كيميائية كامنة", fr: "Photosynthèse", heures: 15, qcm: 53, capsules: 5, annonce: 20, constate: 11.7 },
  { id: 7, domaine: 2, ar: "تحويل الطاقة الكيميائية الكامنة إلى ATP", fr: "Respiration cellulaire", heures: 15, qcm: 47, capsules: 2, annonce: 19, constate: 6.7 },
  { id: 8, domaine: 2, ar: "تحويل الطاقة على المستوى ما فوق البنية الخلوية", fr: "Bilan énergétique à l'échelle cellulaire", heures: 2, qcm: 40, capsules: 2, annonce: null, constate: 1.1 },
  { id: 9, domaine: 3, ar: "النشاط التكتوني للصفائح", fr: "Activité tectonique des plaques", heures: 10, qcm: 43, capsules: 1, annonce: null, constate: 1.1 },
  { id: 10, domaine: 3, ar: "بنية الكرة الأرضية", fr: "Structure du globe", heures: 2, qcm: 50, capsules: 1, annonce: null, constate: 1.1 },
  { id: 11, domaine: 3, ar: "النشاط التكتوني والبنيات الجيولوجية المرتبطة به", fr: "Tectonique et structures géologiques", heures: 13, qcm: 61, capsules: 1, annonce: null, constate: 1.1 },
];

export const DOMAINES = [
  { id: 1 as const, fr: "Domaine 1 · Protéines", ar: "التخصص الوظيفي للبروتينات", couleur: "#0d5c46" },
  { id: 2 as const, fr: "Domaine 2 · Énergie", ar: "التحولات الطاقوية", couleur: "#c2710c" },
  { id: 3 as const, fr: "Domaine 3 · Tectonique", ar: "التكتونية العامة", couleur: "#64748b" },
];

/* ---------- Synthèses ---------- */
export const POINTS_FORTS = [
  {
    titre: "Une tâche à la fois, avec un quota journalier",
    detail: "Le chemin « مساري » et la carte « برنامج اليوم » proposent quoi faire maintenant au lieu d'ouvrir sur une bibliothèque. C'est la meilleure réponse du produit au risque de submersion.",
    axe: "Axe 3",
  },
  {
    titre: "Un plan de révision pondéré par l'examen",
    detail: "De 1 à 60 jours, ordonné par le poids annoncé et la part constatée de chaque unité, avec alternance des gestes et deux derniers jours réservés à la consolidation.",
    axe: "Axe 3",
  },
  {
    titre: "Conformité au programme officiel, écarts déclarés",
    detail: "11 unités et 108 h encodées, hors-programme balisé, errata du manuel intégrés. Les limites sont écrites dans le code, y compris les 13 citations encore à réviser.",
    axe: "Axe 1",
  },
  {
    titre: "Banque Bac au format réel",
    detail: "28 sujets en PDF, 65 exercices indexés par idée et verbe de consigne, simulateurs à 3 exercices (5, 7 et 8 points) en 4 h 30.",
    axe: "Axe 5",
  },
  {
    titre: "Hors ligne, sans compte, gratuit utile",
    detail: "Domaine 1 gratuit (51 h sur 108), essai de 30 jours sur tout, données gardées sur le téléphone, aucune publicité.",
    axe: "Axe 8",
  },
];

export const POINTS_FAIBLES = [
  {
    titre: "Un guidage identique pour tous",
    detail: "Ni test de positionnement, ni objectif de note, ni profil : l'élève à 7 sur 20 et celui à 15 reçoivent le même chemin. Le plan dépend d'un nombre de jours saisi à la main.",
    axe: "Axe 3",
  },
  {
    titre: "Des QCM sans notion ni difficulté",
    detail: "Le code le reconnaît : l'application ne peut pas déduire d'un QCM raté la notion en cause. Pas d'adaptation automatique, profil d'erreurs fondé sur la déclaration de l'élève.",
    axe: "Axes 3 et 4",
  },
  {
    titre: "Une correction notée limitée à 2025",
    detail: "Pour les 10 autres sessions indexées, le corrigé est un lien externe qui exige une connexion.",
    axe: "Axe 5",
  },
  {
    titre: "Une hiérarchisation incomplète",
    detail: "Poids d'examen renseigné pour 7 unités sur 11 ; 28 % des QCM portent sur le domaine le moins représenté dans les exercices indexés ; 4 cartes de survie sur 5 non publiées.",
    axe: "Axe 2",
  },
  {
    titre: "Une diffusion et une validation externes à faire",
    detail: "Pas de fiche Google Play à la date du dernier bilan interne, pas de version iOS, aucune relecture par un enseignant documentée.",
    axe: "Axes 1 et 8",
  },
];

export const RECTIFICATIF = [
  "La version précédente s'appuyait uniquement sur le README. Celle-ci repose sur la lecture du code source.",
  "Elle déclarait absents le parcours guidé, le plan de révision, l'objectif quotidien, la série et les badges : ils existent tous dans le code.",
  "Elle annonçait un seul sujet de Bac intégral : le dépôt en contient 28 en PDF.",
  "Elle raisonnait sur un programme (génétique, écologie, mitose et méiose) qui n'est pas celui de la 3AS. Le glossaire et le plan de 12 semaines bâtis dessus sont retirés.",
  "Elle contenait des chiffres sans source — charge cognitive « 8,5/10 », « Génétique ≈ 30 % », comparaison avec « le marché » — tous supprimés.",
];

export const LIMITES = [
  { titre: "Lecture statique", detail: "Code lu au commit 70b69ec. L'application n'a été ni compilée, ni lancée, ni testée sur téléphone." },
  { titre: "Tests non exécutés", detail: "323 fichiers de test recensés ; les résultats cités viennent des rapports internes du dépôt." },
  { titre: "Échantillons réduits", detail: "8 QCM relus sur 550 ; leçons mesurées en volume, non relues ; 3 PDF contrôlés sur leur seul en-tête." },
  { titre: "Aucun utilisateur", detail: "Ni élève ni enseignant interrogé : tout jugement sur la charge ressentie est une interprétation." },
  { titre: "Part constatée recalculée", detail: "Les parts par unité viennent d'un recalcul de ma part sur l'index des 65 exercices ; à confirmer avec la fonction du dépôt." },
  { titre: "Stores", detail: "Aucune fiche Play Store ou App Store trouvée : notes, avis et installations ne sont pas évaluables." },
];
