import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  AlertTriangle, ArrowRight, BadgeCheck, Banknote, Brain, CalendarDays, CheckCircle2,
  ChevronDown, ChevronsUpDown, ClipboardCheck, Eye, FileSearch, FileText, Gauge as GaugeIcon,
  GitBranch, HeartHandshake, History, Info, Languages, ListChecks, Map as MapIcon, Microscope,
  Printer, Radar as RadarIcon, Route, Scale, Search, ShieldCheck, Signal, Smartphone,
  Sparkles, Star, Target, Timer, WifiOff,
} from "lucide-react";
import {
  AXES, BASE_AUDIT, CONFIANCE, DOMAINES, GLOBAL_EXACT, GLOBAL_SCORE, LIMITES, POINTS_FAIBLES,
  POINTS_FORTS, RECOMMANDATIONS_FLAT, RECTIFICATIF, UNITES, type Priority,
} from "./data/audit";

/* ---------- helpers ---------- */
const fr = (n: number, d = 1) => n.toFixed(d).replace(".", ",");

function scoreColor(n: number) {
  if (n >= 8) return "#0d5c46";
  if (n >= 7) return "#1d7a5f";
  if (n >= 6) return "#b45309";
  return "#b91c1c";
}
function scoreLabel(n: number) {
  if (n >= 8.5) return "Excellent";
  if (n >= 8) return "Très bon";
  if (n >= 7) return "Bon";
  if (n >= 6) return "Correct";
  return "Fragile";
}
const PRIO_LABEL: Record<Priority, string> = { haute: "Haute", moyenne: "Moyenne", basse: "Basse" };
const PRIO_DOT: Record<Priority, string> = { haute: "#dc2626", moyenne: "#f59e0b", basse: "#16a34a" };

/** Pastille de couleur dessinée en CSS : s'affiche partout, même sans police emoji. */
function Dot({ p }: { p: Priority }) {
  return <span aria-hidden className="inline-block h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: PRIO_DOT[p] }} />;
}

/**
 * Isole les passages en arabe insérés dans une phrase française : chaque passage
 * devient un bloc droite-à-gauche autonome, avec la police arabe.
 */
const AR_RUN = /([\u0600-\u06FF]+(?:[ /…]+[\u0600-\u06FF]+)*(?:(?<=ـ) [A-Za-z]+)?)/;
/** Espaces insécables à la française : devant ; : ? ! », après «, entre nombre et unité. */
const nb = (s: string) => s
  .replace(/(\d) (h|%|DA|min|Mo|pts|j|s)(?![A-Za-zÀ-ÿ])/g, "$1\u00A0$2")
  .replace(/ ([:;?!»])/g, "\u00A0$1")
  .replace(/« /g, "«\u00A0");
function T({ children }: { children: string }) {
  const parts = children.split(AR_RUN);
  if (parts.length === 1) return <>{nb(children)}</>;
  return (
    <>
      {parts.map((p, i) => (i % 2 === 1
        ? <bdi key={i} dir="rtl" lang="ar" className="font-arabic text-[1.06em]">{p}</bdi>
        : nb(p)))}
    </>
  );
}
const PRIO_LIGHT: Record<Priority, string> = {
  haute: "bg-red-50 text-red-800 border-red-200",
  moyenne: "bg-amber-50 text-amber-900 border-amber-200",
  basse: "bg-emerald-50 text-emerald-900 border-emerald-200",
};
const PRIO_DARK: Record<Priority, string> = {
  haute: "border-red-300/60 bg-red-500/15 text-red-100",
  moyenne: "border-amber-300/60 bg-amber-400/15 text-amber-100",
  basse: "border-emerald-300/60 bg-emerald-400/15 text-emerald-100",
};

function Stars({ n }: { n: number }) {
  return (
    <span className="inline-flex items-center gap-0.5" role="img" aria-label={`${n} étoiles sur 5`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Star key={i} className={`h-5 w-5 ${i <= n ? "fill-amber-400 text-amber-400" : "text-white/25"}`} />
      ))}
    </span>
  );
}

function RadarChart() {
  const cx = 160, cy = 160, R = 112;
  const ang = (i: number) => (Math.PI * 2 * i) / AXES.length - Math.PI / 2;
  const pts = AXES.map((a, i) => {
    const r = (a.note / 10) * R;
    return {
      a,
      x: cx + r * Math.cos(ang(i)), y: cy + r * Math.sin(ang(i)),
      ax: cx + R * Math.cos(ang(i)), ay: cy + R * Math.sin(ang(i)),
      lx: cx + (R + 24) * Math.cos(ang(i)), ly: cy + (R + 24) * Math.sin(ang(i)) + 4,
    };
  });
  const ring = (k: number) => AXES.map((_, i) => `${(cx + R * k * Math.cos(ang(i))).toFixed(1)},${(cy + R * k * Math.sin(ang(i))).toFixed(1)}`).join(" ");
  return (
    <svg viewBox="0 0 320 320" className="mx-auto w-full max-w-[340px]" role="img" aria-label="Radar des notes des 8 axes">
      {[0.25, 0.5, 0.75, 1].map((k) => (
        <polygon key={k} points={ring(k)} fill="none" stroke={k === 1 ? "#0d5c46" : "#d6ddd8"} strokeWidth={k === 1 ? 1.5 : 1} strokeDasharray={k === 1 ? undefined : "4 4"} />
      ))}
      {pts.map((p) => <line key={p.a.id} x1={cx} y1={cy} x2={p.ax} y2={p.ay} stroke="#e2e8e4" />)}
      <polygon points={pts.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ")} fill="rgba(13,92,70,.15)" stroke="#0d5c46" strokeWidth={2.5} strokeLinejoin="round" />
      {pts.map((p) => (
        <g key={p.a.id}>
          <circle cx={p.x} cy={p.y} r={5} fill={p.a.couleur} stroke="white" strokeWidth={2} />
          <text x={p.lx} y={p.ly} textAnchor="middle" fontSize={11} fontWeight={700} fill="#0f1e1a">A{p.a.id} · {fr(p.a.note)}</text>
        </g>
      ))}
    </svg>
  );
}

function ScoreGauge({ value }: { value: number }) {
  const L = Math.PI * 80;
  const off = L * (1 - value / 100);
  return (
    <svg viewBox="0 0 200 140" className="w-full" role="img" aria-label={`Score global ${fr(value)} sur 100`}>
      <path d="M 20 125 A 80 80 0 0 1 180 125" fill="none" stroke="rgba(255,255,255,.15)" strokeWidth={16} strokeLinecap="round" />
      <path d="M 20 125 A 80 80 0 0 1 180 125" fill="none" stroke="#fbbf24" strokeWidth={16} strokeLinecap="round" strokeDasharray={L} strokeDashoffset={off} className="gauge-arc" />
      <text x={100} y={102} textAnchor="middle" fontSize={40} fontWeight={700} fill="white" fontFamily="Fraunces, serif">{fr(value)}</text>
      <text x={100} y={122} textAnchor="middle" fontSize={11} fontWeight={600} fill="rgba(255,255,255,.75)" letterSpacing={1.5}>SUR 100, PONDÉRÉ</text>
    </svg>
  );
}

function Kicker({ children, dark = false }: { children: ReactNode; dark?: boolean }) {
  return <p className={`text-[12px] font-bold uppercase tracking-[.16em] ${dark ? "text-amber-300" : "text-emerald-800"}`}>{children}</p>;
}

/* ---------- grille de l'axe 3, critère par critère ---------- */
type Statut = "Présent" | "Partiel" | "Non trouvé";
const STATUT_STYLE: Record<Statut, string> = {
  "Présent": "bg-emerald-100 text-emerald-900",
  "Partiel": "bg-amber-100 text-amber-900",
  "Non trouvé": "bg-red-100 text-red-900",
};
const GRILLE_AXE3: { bloc: string; items: { q: string; s: Statut; d: string }[] }[] = [
  {
    bloc: "A · Diagnostic et personnalisation",
    items: [
      { q: "Test de positionnement initial", s: "Non trouvé", d: "Aucun test de niveau au premier lancement." },
      { q: "Parcours adapté au profil", s: "Non trouvé", d: "Même chemin pour tous les élèves." },
      { q: "Choix de la filière", s: "Non trouvé", d: "Filière unique : علوم تجريبية." },
      { q: "Objectif de note (10, 14, 18)", s: "Non trouvé", d: "Seul un objectif quotidien est réglable." },
    ],
  },
  {
    bloc: "B · Structuration du parcours",
    items: [
      { q: "Parcours guidé jour par jour", s: "Présent", d: "Chemin « مساري » et tâche du jour." },
      { q: "Calendrier aligné sur le Bac", s: "Partiel", d: "Jours restants saisis à la main, 60 au plus." },
      { q: "Objectifs quotidiens réalistes", s: "Présent", d: "Carte « برنامج اليوم » : 3 tâches." },
      { q: "Progression visible", s: "Présent", d: "Barre de progression par domaine." },
    ],
  },
  {
    bloc: "C · Lutte contre la surcharge",
    items: [
      { q: "Divulgation progressive", s: "Présent", d: "Une tâche à la fois ; 8 cartes au plus par hub." },
      { q: "Mode express et mode profond", s: "Partiel", d: "Plan final de 3 à 30 jours et chemin annuel, sans bascule nommée." },
      { q: "Étayage des notions complexes", s: "Présent", d: "Fiche d'unité : prérequis, itinéraire, pièges." },
    ],
  },
  {
    bloc: "D · Mémorisation et ancrage",
    items: [
      { q: "Répétition espacée intégrée", s: "Présent", d: "SM-2, 3 rappels par jour dans le plan." },
      { q: "Réactivation des notions fragiles", s: "Partiel", d: "Via la cause déclarée par l'élève." },
      { q: "Révisions croisées entre unités", s: "Non trouvé", d: "Aucun quiz mêlant deux unités repéré." },
      { q: "Rappels selon la courbe d'oubli", s: "Partiel", d: "Échéances SM-2 ; notifications facultatives." },
    ],
  },
  {
    bloc: "E · Métacognition",
    items: [
      { q: "Identification des lacunes", s: "Partiel", d: "Déclarative : 4 causes proposées après un QCM." },
      { q: "Conseils méthodologiques", s: "Présent", d: "Verbes de consigne, fiche A4, atelier." },
      { q: "Auto-évaluation avant correction", s: "Partiel", d: "Auto-test dans les capsules ; estimation de note non trouvée." },
    ],
  },
];

/* ---------- répartition par domaine ---------- */
function partsParDomaine(cle: "heures" | "qcm" | "capsules" | "constate") {
  const tot = UNITES.reduce((s, u) => s + u[cle], 0);
  return DOMAINES.map((d) => {
    const v = UNITES.filter((u) => u.domaine === d.id).reduce((s, u) => s + u[cle], 0);
    return { ...d, valeur: v, pct: (v / tot) * 100 };
  });
}
const REPARTITIONS = [
  { titre: "Heures de classe officielles", note: "108 h", parts: partsParDomaine("heures") },
  { titre: "QCM de l'application", note: "550 QCM", parts: partsParDomaine("qcm") },
  { titre: "Micro-capsules", note: "32 capsules", parts: partsParDomaine("capsules") },
  { titre: "Points aux exercices indexés, 2016-2026", note: "65 exercices", parts: partsParDomaine("constate") },
];

/* ---------- page ---------- */
export default function App() {
  const [openAxe, setOpenAxe] = useState<number | null>(3);
  const [expandAll, setExpandAll] = useState(false);
  const [filter, setFilter] = useState<"toutes" | Priority>("toutes");
  const [query, setQuery] = useState("");

  useEffect(() => {
    const before = () => setExpandAll(true);
    window.addEventListener("beforeprint", before);
    return () => window.removeEventListener("beforeprint", before);
  }, []);

  const counts = useMemo(() => ({
    haute: RECOMMANDATIONS_FLAT.filter((r) => r.prio === "haute").length,
    moyenne: RECOMMANDATIONS_FLAT.filter((r) => r.prio === "moyenne").length,
    basse: RECOMMANDATIONS_FLAT.filter((r) => r.prio === "basse").length,
  }), []);

  const recos = useMemo(() => {
    const q = query.trim().toLowerCase();
    const ordre: Record<Priority, number> = { haute: 0, moyenne: 1, basse: 2 };
    return RECOMMANDATIONS_FLAT
      .filter((r) => filter === "toutes" || r.prio === filter)
      .filter((r) => !q || `${r.texte} ${r.axeTitre} ${r.chiffrage}`.toLowerCase().includes(q))
      .sort((a, b) => ordre[a.prio] - ordre[b.prio] || a.axe - b.axe);
  }, [filter, query]);

  const grilleStats = useMemo(() => {
    const all = GRILLE_AXE3.flatMap((b) => b.items);
    return {
      present: all.filter((i) => i.s === "Présent").length,
      partiel: all.filter((i) => i.s === "Partiel").length,
      absent: all.filter((i) => i.s === "Non trouvé").length,
      total: all.length,
    };
  }, []);

  const imprimer = () => { setExpandAll(true); setTimeout(() => window.print(), 80); };

  return (
    <div className="min-h-screen pb-24 lg:pb-0">
      {/* BARRE HAUTE */}
      <div className="no-print sticky top-0 z-50 border-b border-white/10 bg-[#0a2e24]/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-2.5 text-white">
          <a href="#" aria-label="Haut de page" className="flex min-w-0 items-center gap-3">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-amber-400 text-[#0a2e24]"><Microscope className="h-5 w-5" /></span>
            <span className="min-w-0 leading-tight">
              <span className="block truncate text-[14px] font-bold">Audit SVT · Bac Algérie <span className="font-arabic font-medium text-amber-200">كنز العلوم</span></span>
              <span className="hidden text-[12px] text-white/70 sm:block">Lecture du code · commit {BASE_AUDIT.commit} · {BASE_AUDIT.dateCommit}</span>
            </span>
          </a>
          <nav className="hidden items-center gap-5 text-[13.5px] font-medium text-white/85 lg:flex">
            <a href="#synthese" className="hover:text-amber-300">Synthèse</a>
            <a href="#effort" className="hover:text-amber-300">Répartition</a>
            <a href="#axes" className="hover:text-amber-300">8 axes</a>
            <a href="#assimilation" className="hover:text-amber-300">Assimilation</a>
            <a href="#recommandations" className="hover:text-amber-300">Recommandations</a>
            <a href="#verdict" className="rounded-full bg-amber-400 px-3.5 py-1.5 font-bold text-[#0a2e24] hover:bg-amber-300">Verdict</a>
          </nav>
          <button onClick={imprimer} className="hidden shrink-0 items-center gap-1.5 rounded-full border border-white/25 px-3.5 py-1.5 text-[13px] font-semibold hover:bg-white/10 sm:flex">
            <Printer className="h-4 w-4" /> Imprimer
          </button>
        </div>
      </div>

      {/* HERO */}
      <header id="top" className="relative overflow-hidden bg-[#0a2e24] text-white">
        <div className="dot-grid absolute inset-0 opacity-60" />
        <div className="absolute -right-40 -top-40 h-[460px] w-[460px] rounded-full bg-emerald-500/20 blur-3xl" />
        <div className="relative mx-auto grid max-w-7xl gap-10 px-4 pb-12 pt-10 lg:grid-cols-[1.15fr_.85fr] lg:pt-14">
          <div className="fade-up">
            <div className="flex flex-wrap gap-2 text-[12px] font-bold">
              <span className="rounded-full bg-amber-400 px-3 py-1 text-[#0a2e24]">Audit pédagogique et cognitif</span>
              <span className="rounded-full border border-white/30 px-3 py-1 text-white/90">3AS · علوم تجريبية</span>
            </div>
            <h1 className="font-serif-d mt-5 text-[32px] font-semibold leading-[1.08] tracking-tight sm:text-[44px]">
              L'élève moyen peut-il <span className="italic text-amber-300">assimiler</span> cette richesse sans être submergé ?
            </h1>
            <p className="mt-4 max-w-2xl text-[16px] leading-relaxed text-white/85">
              Oui pour l'essentiel. Le code de <strong className="text-white">Kunz El Ouloum</strong> guide l'élève une tâche à la fois et pondère son plan de révision par le poids réel de l'examen. Ce qui lui manque : s'adapter au niveau de chacun et montrer, item par item, ce qui compte le plus.
            </p>
            <div className="mt-6 grid max-w-2xl grid-cols-2 gap-2.5 sm:grid-cols-4">
              {[
                { i: <ListChecks className="h-4 w-4" />, t: "11 unités", s: "108 h officielles" },
                { i: <Brain className="h-4 w-4" />, t: "550 QCM", s: "44 chapitres" },
                { i: <FileText className="h-4 w-4" />, t: "28 sujets PDF", s: "65 exercices indexés" },
                { i: <ShieldCheck className="h-4 w-4" />, t: "323 fichiers", s: "de test, non exécutés ici" },
              ].map((b) => (
                <div key={b.t} className="rounded-2xl border border-white/15 bg-white/[.06] p-3">
                  <div className="flex items-center gap-1.5 text-[14px] font-bold text-amber-200">{b.i}{b.t}</div>
                  <div className="mt-0.5 text-[12.5px] text-white/70">{b.s}</div>
                </div>
              ))}
            </div>
            <div className="mt-6 flex flex-wrap gap-2.5">
              <a href="#synthese" className="inline-flex items-center gap-2 rounded-full bg-amber-400 px-5 py-2.5 text-[14px] font-bold text-[#0a2e24] hover:bg-amber-300">Tableau de synthèse <ArrowRight className="h-4 w-4" /></a>
              <a href="#assimilation" className="inline-flex items-center gap-2 rounded-full border border-white/30 px-5 py-2.5 text-[14px] font-semibold hover:bg-white/10"><Brain className="h-4 w-4" /> L'axe 3 en détail</a>
            </div>
            <p className="mt-5 flex max-w-2xl items-start gap-2 text-[13px] leading-relaxed text-white/75">
              <GitBranch className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" />
              <span>Base : lecture statique des {BASE_AUDIT.fichiers.toLocaleString("fr-FR")} fichiers du dépôt <span className="font-mono text-[12px] [overflow-wrap:anywhere]">{BASE_AUDIT.depot}</span>. L'application n'a pas été exécutée : ce qui relève de l'écran, de la vitesse ou de l'usage est marqué « Non vérifiable ».</span>
            </p>
          </div>

          <div className="fade-up fade-up-1">
            <div className="rounded-3xl border border-white/15 bg-white/[.06] p-6 shadow-2xl backdrop-blur">
              <div className="flex items-center justify-between gap-2">
                <p className="text-[12px] font-bold uppercase tracking-[.16em] text-white/75">Score global</p>
                <span className="rounded-full bg-emerald-400/15 px-2.5 py-1 text-[12px] font-bold text-emerald-200">8 axes sur 8 à 7 ou plus</span>
              </div>
              <ScoreGauge value={GLOBAL_SCORE} />
              <div className="flex items-center justify-center gap-3">
                <Stars n={CONFIANCE} />
                <span className="text-[13.5px] font-bold text-white/90">Confiance {CONFIANCE}/5</span>
              </div>
              <p className="mt-3 text-center text-[12.5px] text-white/70">Somme des notes × poids = {fr(GLOBAL_EXACT, 2)} sur 100</p>
              <div className="mt-4 rounded-2xl border border-amber-300/30 bg-amber-300/10 p-4 text-[14px] leading-relaxed text-amber-50">
                <strong>En bref :</strong> à recommander aux élèves de sciences expérimentales, en commençant par le domaine 1 gratuit. Le risque n'est plus l'absence de guidage, mais un guidage identique pour tous.
              </div>
            </div>
          </div>
        </div>

        <div className="relative border-t border-white/10 bg-black/25">
          <div className="mx-auto grid max-w-7xl gap-x-4 gap-y-3 px-4 py-4 sm:grid-cols-2 lg:grid-cols-5">
            {[
              { i: <Signal className="h-4 w-4" />, t: "3G intermittente", s: "Hors-ligne prévu dès la conception" },
              { i: <Smartphone className="h-4 w-4" />, t: "Téléphones modestes", s: "Android 7 et plus ; vitesse non mesurée" },
              { i: <Banknote className="h-4 w-4" />, t: "Budget limité", s: "Domaine 1 gratuit ; 1 200 DA la saison" },
              { i: <Languages className="h-4 w-4" />, t: "Arabe et français", s: "Interface en arabe, termes français au fil du texte" },
              { i: <HeartHandshake className="h-4 w-4" />, t: "Stress du Bac", s: "Une tâche par jour ; 2 derniers jours allégés" },
            ].map((c) => (
              <div key={c.t} className="flex items-start gap-2.5">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/10 text-amber-300">{c.i}</span>
                <span className="text-[13px] leading-snug"><strong className="block text-white">{c.t}</strong><span className="text-white/75">{c.s}</span></span>
              </div>
            ))}
          </div>
        </div>
      </header>

      {/* RECTIFICATIF */}
      <section className="mx-auto max-w-7xl px-4 pt-8">
        <div className="rounded-3xl border border-amber-300 bg-amber-50 p-5 sm:p-6">
          <p className="flex items-center gap-2 text-[15px] font-bold text-amber-950"><History className="h-5 w-5" /> Version révisée : ce rapport remplace le précédent</p>
          <ul className="mt-3 grid gap-x-8 gap-y-2 text-[14px] leading-relaxed text-amber-950 md:grid-cols-2">
            {RECTIFICATIF.map((r) => (
              <li key={r} className="flex gap-2"><span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-amber-600" /><span><T>{r}</T></span></li>
            ))}
            <li className="flex gap-2 font-semibold"><span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-amber-600" />Conséquence : le score passe de 69,8 à {fr(GLOBAL_SCORE)} sur 100, et l'axe 3 de 6,0 à 7,5.</li>
          </ul>
        </div>
      </section>

      {/* SYNTHESE */}
      <section id="synthese" className="mx-auto max-w-7xl scroll-mt-20 px-4 pt-12">
        <Kicker>1 · Tableau de synthèse</Kicker>
        <h2 className="font-serif-d mt-1 text-[28px] font-semibold tracking-tight sm:text-[32px]">Huit axes, une phrase chacun</h2>
        <p className="mt-2 max-w-3xl text-[15px] leading-relaxed text-slate-700">Pondération demandée : l'axe 3 pèse 18 %, les axes 1 et 7 pèsent 15 et 13 %, les axes 2 et 4 pèsent 12 %, les autres 10 %. Touchez une ligne pour ouvrir l'analyse.</p>

        <div className="mt-6 grid gap-6 lg:grid-cols-[1.25fr_.75fr]">
          <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
            <div className="hidden grid-cols-[48px_1fr_84px_130px_64px] gap-3 border-b border-slate-100 bg-slate-50 px-5 py-3 text-[12px] font-bold uppercase tracking-wider text-slate-600 md:grid">
              <span>Axe</span><span>Intitulé et résumé</span><span className="text-center">Note</span><span>Apport au score</span><span className="text-right">Poids</span>
            </div>
            {AXES.map((a) => (
              <a key={a.id} href={`#axe-${a.id}`} onClick={() => setOpenAxe(a.id)}
                className="grid grid-cols-[44px_1fr_auto] items-center gap-x-3 gap-y-2.5 border-b border-slate-100 px-4 py-4 transition hover:bg-emerald-50/60 md:grid-cols-[48px_1fr_84px_130px_64px] md:px-5">
                <span className="flex h-10 w-10 items-center justify-center rounded-2xl text-[14px] font-bold text-white" style={{ background: a.couleur }}>A{a.id}</span>
                <span className="min-w-0">
                  <span className="block text-[15px] font-bold leading-snug">{a.titre}</span>
                  <span className="mt-1 hidden text-[13.5px] leading-relaxed text-slate-600 md:block"><T>{a.resume}</T></span>
                </span>
                <span className="text-center">
                  <span className="inline-block whitespace-nowrap rounded-full px-3 py-1 text-[14px] font-bold text-white" style={{ background: scoreColor(a.note) }}>{fr(a.note)}/10</span>
                  <span className="mt-1 block text-[12px] font-semibold text-slate-600 md:hidden">poids {a.poids} %</span>
                </span>
                <span className="col-span-3 text-[14px] leading-relaxed text-slate-600 md:hidden"><T>{a.resume}</T></span>
                <span className="hidden md:block">
                  <span className="block h-2 overflow-hidden rounded-full bg-slate-100"><span className="block h-full rounded-full" style={{ width: `${a.note * 10}%`, background: a.couleur }} /></span>
                  <span className="mt-1 block text-[12px] font-semibold text-slate-600">{scoreLabel(a.note)} · {fr((a.note * a.poids) / 10, 2)} pts</span>
                </span>
                <span className="hidden text-right md:block">
                  <span className={`rounded-full border px-2 py-1 text-[12px] font-bold ${a.id === 3 ? "border-amber-300 bg-amber-50 text-amber-900" : "border-slate-200 bg-slate-50 text-slate-700"}`}>{a.poids} %</span>
                </span>
              </a>
            ))}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0a2e24] px-5 py-4 text-white">
              <span className="flex items-center gap-2 text-[15px] font-bold"><GaugeIcon className="h-5 w-5 text-amber-300" /> Score global : {fr(GLOBAL_SCORE)} / 100</span>
              <span className="flex items-center gap-2 text-[13.5px] font-semibold text-white/90"><Stars n={CONFIANCE} /> Confiance {CONFIANCE}/5</span>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
              <p className="flex items-center gap-2 text-[12px] font-bold uppercase tracking-[.16em] text-slate-600"><RadarIcon className="h-4 w-4" /> Profil des 8 axes</p>
              <RadarChart />
              <p className="text-center text-[13px] text-slate-600">Profil homogène, entre 7,0 et 8,0 : pas d'axe en échec, pas d'axe d'excellence.</p>
            </div>
            <div className="rounded-3xl bg-emerald-50 p-5 text-[14.5px] leading-relaxed text-emerald-950 ring-1 ring-emerald-200">
              <p className="flex items-center gap-2 font-bold"><FileSearch className="h-5 w-5" /> Lecture en vingt secondes</p>
              <p className="mt-2">Le programme officiel est respecté et le guidage existe. Les trois manques qui comptent : pas de test de positionnement, des QCM sans notion ni difficulté, une correction notée limitée à la session 2025.</p>
            </div>
          </div>
        </div>
      </section>

      {/* REPARTITION DE L'EFFORT */}
      <section id="effort" className="mx-auto max-w-7xl scroll-mt-20 px-4 pt-14">
        <Kicker>2 · Où part l'effort de l'élève</Kicker>
        <h2 className="font-serif-d mt-1 text-[28px] font-semibold tracking-tight sm:text-[32px]">Les QCM suivent les heures de classe, pas l'examen</h2>
        <p className="mt-2 max-w-3xl text-[15px] leading-relaxed text-slate-700">La tectonique reçoit 28 % des QCM pour environ 3 % des points dans les exercices indexés de 2016 à 2026. Les micro-capsules, elles, sont réparties bien plus près de l'examen.</p>

        <div className="mt-6 grid gap-6 lg:grid-cols-[.8fr_1.2fr]">
          <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6 lg:sticky lg:top-20 lg:self-start">
            <div className="flex flex-wrap gap-x-5 gap-y-2 text-[13px] font-semibold text-slate-700">
              {DOMAINES.map((d) => (
                <span key={d.id} className="flex items-center gap-2"><span className="h-3 w-3 rounded-sm" style={{ background: d.couleur }} />{d.fr}</span>
              ))}
            </div>
            <div className="mt-5 space-y-5">
              {REPARTITIONS.map((r) => (
                <div key={r.titre}>
                  <div className="flex items-baseline justify-between gap-3">
                    <p className="text-[14.5px] font-bold">{r.titre}</p>
                    <p className="shrink-0 text-[13px] text-slate-600">{r.note}</p>
                  </div>
                  <div className="mt-2 flex h-5 overflow-hidden rounded-full bg-slate-100" role="img" aria-label={`${r.titre} : ${r.parts.map((p) => `${p.fr} ${fr(p.pct, 0)} %`).join(", ")}`}>
                    {r.parts.map((p) => <span key={p.id} style={{ width: `${p.pct}%`, background: p.couleur }} />)}
                  </div>
                  <p className="mt-1.5 text-[13px] text-slate-700">
                    {r.parts.map((p, i) => (
                      <span key={p.id}>{i > 0 && " · "}<strong style={{ color: p.couleur }}>D{p.id}</strong> {fr(p.pct, 0)} %</span>
                    ))}
                  </p>
                </div>
              ))}
            </div>
            <p className="mt-5 flex items-start gap-2 rounded-2xl bg-slate-50 p-3.5 text-[13px] leading-relaxed text-slate-700">
              <Info className="mt-0.5 h-4 w-4 shrink-0 text-slate-500" />
              <span>La dernière barre est un recalcul de ma part sur l'index des 65 exercices (première unité citée par exercice). Elle est à confirmer avec la fonction <span className="font-mono text-[12px]">observedUnitSharePercent()</span> du dépôt.</span>
            </p>
          </div>

          <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px] text-left text-[13.5px]">
                <caption className="sr-only">Heures officielles, QCM, micro-capsules, poids annoncé et part constatée pour chacune des 11 unités</caption>
                <colgroup><col className="w-[44%]" /><col /><col /><col /><col /><col /></colgroup>
                <thead className="bg-slate-50 text-[12px] font-bold uppercase tracking-wider text-slate-600">
                  <tr>
                    <th className="px-4 py-3">Unité</th>
                    <th className="px-3 py-3 text-right">Heures</th>
                    <th className="px-3 py-3 text-right">QCM</th>
                    <th className="px-3 py-3 text-right">Capsules</th>
                    <th className="px-3 py-3 text-right">Poids annoncé</th>
                    <th className="px-4 py-3 text-right">Part constatée</th>
                  </tr>
                </thead>
                <tbody>
                  {UNITES.map((u) => {
                    const d = DOMAINES.find((x) => x.id === u.domaine)!;
                    return (
                      <tr key={u.id} className="border-t border-slate-100 align-top">
                        <td className="px-4 py-3">
                          <span className="flex items-start gap-2.5">
                            <span className="mt-0.5 flex h-6 w-9 shrink-0 items-center justify-center rounded-md text-[12px] font-bold text-white" style={{ background: d.couleur }}>U{u.id}</span>
                            <span>
                              <span className="block font-semibold leading-snug">{u.fr}</span>
                              <span className="font-arabic block text-[14px] leading-snug text-slate-600" dir="rtl" lang="ar">{u.ar}</span>
                            </span>
                          </span>
                        </td>
                        <td className="px-3 py-3 text-right tabular-nums">{u.heures} h</td>
                        <td className="px-3 py-3 text-right tabular-nums">{u.qcm}</td>
                        <td className="px-3 py-3 text-right tabular-nums">{u.capsules}</td>
                        <td className="px-3 py-3 text-right tabular-nums">{u.annonce === null ? <span className="rounded bg-red-50 px-1.5 py-0.5 text-[12px] font-semibold text-red-800">absent</span> : `${u.annonce} %`}</td>
                        <td className="px-4 py-3 text-right tabular-nums">{fr(u.constate)} %</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <p className="border-t border-slate-100 bg-slate-50 px-4 py-3 text-[13px] leading-relaxed text-slate-700">Titres français de U1 à U7 repris du catalogue de l'application ; ceux de U8 à U11 sont une traduction indicative.</p>
          </div>
        </div>
      </section>

      {/* AXES */}
      <section id="axes" className="mx-auto max-w-7xl scroll-mt-20 px-4 pt-14">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <Kicker>3 · Analyse par axe</Kicker>
            <h2 className="font-serif-d mt-1 text-[28px] font-semibold tracking-tight sm:text-[32px]">Constats, interprétations, zones d'ombre</h2>
          </div>
          <button onClick={() => setExpandAll((v) => !v)} className="no-print inline-flex items-center gap-2 rounded-full border border-slate-300 bg-white px-4 py-2 text-[13.5px] font-semibold text-slate-700 hover:border-slate-500">
            <ChevronsUpDown className="h-4 w-4" /> {expandAll ? "Tout replier" : "Tout déplier"}
          </button>
        </div>
        <p className="mt-2 max-w-3xl text-[15px] leading-relaxed text-slate-700">
          Un <span className="rounded bg-slate-800 px-1.5 py-0.5 text-[12px] font-bold text-white">constat</span> est vérifié dans un fichier du dépôt. Une <span className="rounded bg-amber-300 px-1.5 py-0.5 text-[12px] font-bold text-[#0a2e24]">interprétation</span> est mon jugement. Ce que je n'ai pas pu observer est listé à part.
        </p>

        <div className="mt-6 space-y-4">
          {AXES.map((a) => {
            const open = expandAll || openAxe === a.id;
            return (
              <article key={a.id} id={`axe-${a.id}`} className="scroll-mt-24 overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
                <button onClick={() => setOpenAxe(openAxe === a.id ? null : a.id)} aria-expanded={open} className="flex w-full items-center gap-3 p-4 text-left transition hover:bg-slate-50 sm:gap-4 sm:p-5">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl text-[14px] font-bold text-white sm:h-12 sm:w-12 sm:text-[15px]" style={{ background: a.couleur }}>A{a.id}</span>
                  <span className="min-w-0 flex-1">
                    <span className="flex flex-wrap items-center gap-x-3 gap-y-1">
                      <strong className="text-[15.5px] leading-snug tracking-tight sm:text-[16.5px]">{a.titre}</strong>
                      {a.id === 3 && <span className="rounded-full bg-amber-400 px-2.5 py-0.5 text-[12px] font-bold text-[#0a2e24]">Axe central · 18 %</span>}
                    </span>
                    <span className="font-arabic mt-0.5 block text-[14px] text-slate-600" dir="rtl" lang="ar">{a.titreAr}</span>
                  </span>
                  <span className="shrink-0 text-right">
                    <span className="block text-[22px] font-bold leading-none" style={{ color: scoreColor(a.note) }}>{fr(a.note)}<span className="text-[13px] text-slate-500">/10</span></span>
                    <span className="mt-1 hidden text-[12px] font-semibold text-slate-600 sm:block">{scoreLabel(a.note)} · {a.poids} %</span>
                  </span>
                  <ChevronDown className={`h-5 w-5 shrink-0 text-slate-500 transition ${open ? "rotate-180" : ""}`} />
                </button>
                <div className="h-1.5 bg-slate-100"><div className="h-full" style={{ width: `${a.note * 10}%`, background: a.couleur }} /></div>

                {open && (
                  <div className="border-t border-slate-100 p-4 sm:p-6">
                    <p className="text-[15px] font-semibold leading-relaxed text-slate-800"><T>{a.resume}</T></p>
                    <div className="mt-5 grid gap-5 lg:grid-cols-2">
                      <div className="space-y-4">
                        <div className="rounded-2xl bg-slate-900 p-4 text-slate-100 sm:p-5">
                          <p className="flex items-center gap-2 text-[12px] font-bold uppercase tracking-widest text-white"><Eye className="h-4 w-4 text-amber-300" /> Constats vérifiés dans le code</p>
                          <ul className="mt-3 space-y-3 text-[14px] leading-relaxed">
                            {a.constats.map((c) => (<li key={c} className="flex gap-2.5"><CheckCircle2 className="mt-1 h-4 w-4 shrink-0 text-emerald-400" /><span><T>{c}</T></span></li>))}
                          </ul>
                        </div>
                        <div className="rounded-2xl bg-amber-50 p-4 text-amber-950 ring-1 ring-amber-200 sm:p-5">
                          <p className="flex items-center gap-2 text-[12px] font-bold uppercase tracking-widest"><Sparkles className="h-4 w-4" /> Interprétation</p>
                          <ul className="mt-3 space-y-3 text-[14px] leading-relaxed">
                            {a.interpretations.map((c) => (<li key={c} className="flex gap-2.5"><span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-amber-600" /><span><T>{c}</T></span></li>))}
                          </ul>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="rounded-2xl border border-slate-200 p-4 sm:p-5">
                          <p className="flex items-center gap-2 text-[12px] font-bold uppercase tracking-widest text-slate-600"><Scale className="h-4 w-4" /> Preuves chiffrées</p>
                          <div className="mt-3 grid grid-cols-2 gap-2.5">
                            {a.preuves.map((p) => (
                              <div key={p.label} className="rounded-xl bg-slate-50 p-3 ring-1 ring-slate-100">
                                <p className="text-[12px] font-semibold text-slate-600">{p.label}</p>
                                <p className="mt-0.5 text-[16px] font-bold leading-tight" style={{ color: a.couleur }}>{p.valeur}</p>
                                <p className="mt-1 break-words font-mono text-[11.5px] leading-snug text-slate-500">{p.source}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                        <div className="grid gap-3 sm:grid-cols-2">
                          <div className="rounded-2xl border border-emerald-200 bg-emerald-50/70 p-4">
                            <p className="text-[12px] font-bold uppercase tracking-widest text-emerald-900">Points forts</p>
                            <ul className="mt-2 space-y-2 text-[13.5px] leading-snug text-emerald-950">{a.forces.map((f) => (<li key={f} className="flex gap-2"><span aria-hidden>✓</span><span><T>{f}</T></span></li>))}</ul>
                          </div>
                          <div className="rounded-2xl border border-red-200 bg-red-50/70 p-4">
                            <p className="text-[12px] font-bold uppercase tracking-widest text-red-900">Points faibles</p>
                            <ul className="mt-2 space-y-2 text-[13.5px] leading-snug text-red-950">{a.faiblesses.map((f) => (<li key={f} className="flex gap-2"><span aria-hidden>✗</span><span><T>{f}</T></span></li>))}</ul>
                          </div>
                        </div>
                        <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-4">
                          <p className="text-[13.5px] font-bold text-slate-800">Non vérifiable</p>
                          <ul className="mt-2 space-y-1.5 text-[13.5px] leading-relaxed text-slate-700">{a.nonVerifiable.map((n) => (<li key={n} className="flex gap-2"><span aria-hidden>?</span><span><T>{n}</T></span></li>))}</ul>
                        </div>
                        <div className="rounded-2xl bg-[#0a2e24] p-4 text-white sm:p-5">
                          <p className="text-[12px] font-bold uppercase tracking-widest text-amber-300">Recommandations de l'axe {a.id}</p>
                          <div className="mt-3 space-y-2.5">
                            {a.recommandations.map((r) => (
                              <div key={r.texte} className="rounded-xl bg-white/[.07] p-3.5 ring-1 ring-white/10">
                                <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[12px] font-bold ${PRIO_DARK[r.prio]}`}><Dot p={r.prio} />{PRIO_LABEL[r.prio]}</span>
                                <p className="mt-2 text-[14px] leading-relaxed text-white/95"><T>{r.texte}</T></p>
                                <p className="mt-1.5 text-[12.5px] font-semibold text-amber-200">Chiffrage : {r.chiffrage}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                        <p className="text-[14px] leading-relaxed text-slate-700"><strong>Verdict de l'axe.</strong> {a.verdict}</p>
                      </div>
                    </div>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      </section>

      {/* ASSIMILATION */}
      <section id="assimilation" className="mt-14 scroll-mt-20 bg-[#0a2e24] py-14 text-white">
        <div className="mx-auto max-w-7xl px-4">
          <Kicker dark>4 · Axe 3 : assimiler sans être submergé</Kicker>
          <h2 className="font-serif-d mt-1 max-w-3xl text-[28px] font-semibold leading-tight tracking-tight sm:text-[32px]">Le guidage existe ; il ne s'adapte pas encore à l'élève</h2>
          <p className="mt-3 max-w-3xl text-[15px] leading-relaxed text-white/85">
            Sur les {grilleStats.total} critères de la grille pour cet axe, {grilleStats.present} sont présents dans le code, {grilleStats.partiel} le sont en partie et {grilleStats.absent} n'ont pas été trouvés. Les manques se concentrent dans le bloc « diagnostic et personnalisation ».
          </p>

          <div className="mt-6 grid gap-4 lg:grid-cols-2">
            <div className="rounded-3xl bg-white/[.06] p-5 ring-1 ring-white/10 sm:p-6">
              <p className="flex items-center gap-2 text-[16px] font-bold"><Route className="h-5 w-5 text-amber-300" /> Comment l'application choisit la tâche du jour</p>
              <ol className="mt-4 space-y-2.5 text-[14.5px] leading-relaxed">
                {[
                  ["Reprise", "l'item commencé et non terminé passe d'abord."],
                  ["Rappel", "sinon, l'item validé dont l'échéance à 14 jours est atteinte."],
                  ["Repos", "si le quota du jour est atteint, l'application propose d'arrêter."],
                  ["Nouveau", "sinon, le premier item disponible du chemin."],
                ].map(([t, s], i) => (
                  <li key={t} className="flex gap-3 rounded-2xl bg-white/[.05] p-3">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-amber-400 text-[13px] font-bold text-[#0a2e24]">{i + 1}</span>
                    <span className="text-white/90"><strong className="text-white">{t} :</strong> {s}</span>
                  </li>
                ))}
              </ol>
              <p className="mt-3 break-words font-mono text-[12px] text-white/70">src/lib/parcours/nbaEngine.ts</p>
            </div>

            <div className="rounded-3xl bg-white/[.06] p-5 ring-1 ring-white/10 sm:p-6">
              <p className="flex items-center gap-2 text-[16px] font-bold"><CalendarDays className="h-5 w-5 text-amber-300" /> Les 4 préréglages du plan de révision finale</p>
              <div className="mt-4 grid grid-cols-2 gap-2.5">
                {[["30 jours", "60 min par jour"], ["14 jours", "90 min par jour"], ["7 jours", "120 min par jour"], ["3 jours", "120 min par jour"]].map(([j, m]) => (
                  <div key={j} className="rounded-2xl bg-white/[.05] p-3.5">
                    <p className="text-[18px] font-bold text-amber-200">{j}</p>
                    <p className="text-[13.5px] text-white/85">{m}</p>
                  </div>
                ))}
              </div>
              <ul className="mt-4 space-y-2 text-[14px] leading-relaxed text-white/90">
                <li className="flex gap-2.5"><Target className="mt-1 h-4 w-4 shrink-0 text-amber-300" />Unités ordonnées par poids d'examen et difficulté observée.</li>
                <li className="flex gap-2.5"><Target className="mt-1 h-4 w-4 shrink-0 text-amber-300" />Alternance des gestes : lire, dessiner un schéma, rédiger, se rappeler.</li>
                <li className="flex gap-2.5"><Target className="mt-1 h-4 w-4 shrink-0 text-amber-300" />Aucune notion nouvelle les 2 derniers jours.</li>
              </ul>
              <p className="mt-3 break-words font-mono text-[12px] text-white/70">src/data/revisionPlan.ts</p>
            </div>
          </div>

          <div className="mt-4 rounded-3xl bg-white p-5 text-slate-900 sm:p-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-[16px] font-bold">La grille de l'axe 3, critère par critère</p>
              <div className="flex flex-wrap gap-2 text-[12.5px] font-bold">
                <span className={`rounded-full px-2.5 py-1 ${STATUT_STYLE["Présent"]}`}>{grilleStats.present} présents</span>
                <span className={`rounded-full px-2.5 py-1 ${STATUT_STYLE["Partiel"]}`}>{grilleStats.partiel} partiels</span>
                <span className={`rounded-full px-2.5 py-1 ${STATUT_STYLE["Non trouvé"]}`}>{grilleStats.absent} non trouvés</span>
              </div>
            </div>
            <div className="mt-4 grid gap-x-8 gap-y-5 lg:grid-cols-2">
              {GRILLE_AXE3.map((b) => (
                <div key={b.bloc}>
                  <p className="text-[13px] font-bold uppercase tracking-wider text-emerald-800">{b.bloc}</p>
                  <ul className="mt-2 divide-y divide-slate-100">
                    {b.items.map((it) => (
                      <li key={it.q} className="flex items-start justify-between gap-3 py-2.5">
                        <span className="min-w-0">
                          <span className="block text-[14.5px] font-semibold leading-snug"><T>{it.q}</T></span>
                          <span className="block text-[13.5px] leading-snug text-slate-600"><T>{it.d}</T></span>
                        </span>
                        <span className={`shrink-0 rounded-full px-2.5 py-1 text-[12px] font-bold ${STATUT_STYLE[it.s]}`}>{it.s}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
            <p className="mt-4 text-[13px] leading-relaxed text-slate-600">« Non trouvé » signifie que ma recherche dans le code n'a rien donné, pas que la fonction est impossible à atteindre par un autre chemin.</p>
          </div>
        </div>
      </section>

      {/* FORCES / FAIBLESSES */}
      <section className="mx-auto max-w-7xl px-4 pt-14">
        <div className="grid gap-5 lg:grid-cols-2">
          {[
            { kicker: "5 · Points forts, par impact", items: POINTS_FORTS, box: "border-emerald-200 bg-emerald-50/60", ring: "ring-emerald-100", pastille: "bg-emerald-700", tag: "bg-emerald-100 text-emerald-900" },
            { kicker: "6 · Points faibles, par gravité", items: POINTS_FAIBLES, box: "border-red-200 bg-red-50/60", ring: "ring-red-100", pastille: "bg-red-700", tag: "bg-red-100 text-red-900" },
          ].map((col) => (
            <div key={col.kicker} className={`rounded-3xl border p-5 sm:p-6 ${col.box}`}>
              <Kicker>{col.kicker}</Kicker>
              <div className="mt-4 space-y-3">
                {col.items.map((f, i) => (
                  <div key={f.titre} className={`flex gap-3 rounded-2xl bg-white p-4 ring-1 ${col.ring}`}>
                    <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[14px] font-bold text-white ${col.pastille}`}>{i + 1}</span>
                    <div className="min-w-0">
                      <p className="text-[15px] font-bold leading-snug">{f.titre}</p>
                      <p className="mt-1 text-[14px] leading-relaxed text-slate-700"><T>{f.detail}</T></p>
                      <span className={`mt-2 inline-block rounded-full px-2.5 py-0.5 text-[12px] font-bold ${col.tag}`}>{f.axe}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* RECOMMANDATIONS */}
      <section id="recommandations" className="mx-auto max-w-7xl scroll-mt-20 px-4 pt-14">
        <Kicker>7 · Recommandations</Kicker>
        <h2 className="font-serif-d mt-1 text-[28px] font-semibold tracking-tight sm:text-[32px]">{RECOMMANDATIONS_FLAT.length} actions chiffrées, classées par priorité</h2>
        <div className="no-print mt-5 flex flex-wrap items-center gap-2">
          {([["toutes", `Toutes (${RECOMMANDATIONS_FLAT.length})`], ["haute", `Haute (${counts.haute})`], ["moyenne", `Moyenne (${counts.moyenne})`], ["basse", `Basse (${counts.basse})`]] as const).map(([v, l]) => (
            <button key={v} onClick={() => setFilter(v)} aria-pressed={filter === v}
              className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-[13.5px] font-bold ring-1 transition ${filter === v ? "bg-[#0a2e24] text-white ring-[#0a2e24]" : "bg-white text-slate-700 ring-slate-300 hover:ring-slate-500"}`}>{v !== "toutes" && <Dot p={v} />}{l}</button>
          ))}
          <label className="ml-auto flex w-full items-center gap-2 rounded-full border border-slate-300 bg-white px-4 py-2 sm:w-auto">
            <Search className="h-4 w-4 shrink-0 text-slate-500" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Filtrer les recommandations" placeholder="Filtrer : QCM, sujet, plan…" className="w-full bg-transparent text-[14px] outline-none placeholder:text-slate-500 sm:w-52" />
          </label>
        </div>
        <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {recos.map((r) => (
            <div key={`${r.axe}-${r.texte}`} className="flex flex-col rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className="flex items-center justify-between gap-2">
                <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[12.5px] font-bold ${PRIO_LIGHT[r.prio]}`}><Dot p={r.prio} />{PRIO_LABEL[r.prio]}</span>
                <a href={`#axe-${r.axe}`} onClick={() => setOpenAxe(r.axe)} className="rounded-full bg-slate-100 px-2.5 py-1 text-[12.5px] font-bold text-slate-700 hover:bg-slate-200">Axe {r.axe}</a>
              </div>
              <p className="mt-3 flex-1 text-[14.5px] leading-relaxed text-slate-900"><T>{r.texte}</T></p>
              <p className="mt-3 border-t border-slate-100 pt-3 text-[13px] font-semibold text-emerald-800">Chiffrage : {r.chiffrage}</p>
            </div>
          ))}
          {recos.length === 0 && (
            <p className="rounded-3xl border border-dashed border-slate-300 bg-white p-6 text-[14.5px] text-slate-700 md:col-span-2 xl:col-span-3">Aucune recommandation ne correspond à ce filtre.</p>
          )}
        </div>
      </section>

      {/* ECONOMIE + LIMITES */}
      <section className="mx-auto max-w-7xl px-4 pt-14">
        <div className="grid gap-5 lg:grid-cols-2">
          <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
            <p className="flex items-center gap-2 text-[12px] font-bold uppercase tracking-[.16em] text-slate-600"><Banknote className="h-4 w-4" /> Ce que paie l'élève</p>
            <div className="mt-4 grid grid-cols-3 gap-2.5 text-center">
              <div className="rounded-2xl bg-slate-50 p-2.5 sm:p-3"><p className="whitespace-nowrap text-[16px] font-bold sm:text-[19px]">0 DA</p><p className="mt-0.5 text-[13px] leading-snug text-slate-700">Unités 1 à 5, sans publicité</p></div>
              <div className="rounded-2xl bg-slate-50 p-2.5 sm:p-3"><p className="whitespace-nowrap text-[16px] font-bold sm:text-[19px]">30 jours</p><p className="mt-0.5 text-[13px] leading-snug text-slate-700">Essai de tout le contenu</p></div>
              <div className="rounded-2xl bg-[#0a2e24] p-2.5 text-white sm:p-3"><p className="whitespace-nowrap text-[16px] font-bold text-amber-300 sm:text-[19px]">1 200 DA</p><p className="mt-0.5 text-[13px] leading-snug text-white/85">Saison, jusqu'au 30 juin</p></div>
            </div>
            <p className="mt-5 text-[14.5px] font-bold">Coût mensuel équivalent selon le mois d'achat</p>
            <div className="mt-2 grid grid-cols-3 gap-2.5 text-center">
              {[["Octobre", "9 mois", "≈ 133 DA"], ["Janvier", "6 mois", "200 DA"], ["Avril", "3 mois", "400 DA"]].map(([m, d, c]) => (
                <div key={m} className="rounded-2xl border border-slate-200 p-2.5 sm:p-3">
                  <p className="text-[13px] leading-snug text-slate-600">{m}<span className="block whitespace-nowrap sm:inline"><span className="hidden sm:inline"> · </span>{d}</span></p>
                  <p className="whitespace-nowrap text-[16px] font-bold text-emerald-800 sm:text-[17px]">{c}</p>
                </div>
              ))}
            </div>
            <p className="mt-3 text-[13.5px] leading-relaxed text-slate-700">Calcul de ma part : 1 200 DA divisés par le nombre de mois restants jusqu'à juin. Le paiement se fait par BaridiMob hors de l'application, puis par un code d'activation.</p>
            <ul className="mt-4 space-y-2 border-t border-slate-100 pt-4 text-[14px] leading-relaxed text-slate-800">
              <li className="flex gap-2.5"><CheckCircle2 className="mt-1 h-4 w-4 shrink-0 text-emerald-600" />Le domaine 1 gratuit couvre 51 h sur les 108 h du programme.</li>
              <li className="flex gap-2.5"><AlertTriangle className="mt-1 h-4 w-4 shrink-0 text-amber-600" />Le prix unique pénalise l'achat tardif, moment où beaucoup d'élèves s'y mettent.</li>
              <li className="flex gap-2.5"><AlertTriangle className="mt-1 h-4 w-4 shrink-0 text-amber-600" />L'activation par code suppose une connexion ce jour-là.</li>
            </ul>
          </div>

          <div className="rounded-3xl bg-slate-900 p-5 text-slate-100 sm:p-6">
            <p className="flex items-center gap-2 text-[12px] font-bold uppercase tracking-[.16em] text-white/80"><ClipboardCheck className="h-4 w-4" /> Méthode et limites de cet audit</p>
            <div className="mt-4 grid gap-2.5 sm:grid-cols-2">
              {LIMITES.map((l) => (
                <div key={l.titre} className="rounded-2xl bg-white/[.06] p-3.5 ring-1 ring-white/10">
                  <p className="text-[14px] font-bold text-white">{l.titre}</p>
                  <p className="mt-1 text-[13.5px] leading-relaxed text-white/80"><T>{l.detail}</T></p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* VERDICT */}
      <section id="verdict" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-14">
        <div className="relative overflow-hidden rounded-[28px] bg-[#0a2e24] p-6 text-white sm:p-8 lg:p-10">
          <div className="dot-grid absolute inset-0 opacity-50" />
          <div className="relative grid gap-8 lg:grid-cols-2">
            <div>
              <Kicker dark>8 · Verdict final</Kicker>
              <h2 className="font-serif-d mt-1 text-[28px] font-semibold leading-tight sm:text-[34px]">À recommander, avec trois chantiers avant une large diffusion</h2>
              <div className="mt-3 flex flex-wrap items-center gap-3">
                <Stars n={CONFIANCE} />
                <span className="text-[14.5px] font-bold text-white/90">Confiance {CONFIANCE}/5 · {fr(GLOBAL_SCORE)} sur 100</span>
              </div>
              <div className="mt-5 space-y-3">
                {[
                  ["Prête pour le marché ?", "Sur le fond pédagogique, oui pour la filière علوم تجريبية. Sur la diffusion, pas encore : le build signé et la fiche Google Play restaient à faire dans le dernier bilan interne, et rien n'a été mesuré sur téléphone."],
                  ["À recommander aux élèves ?", "Oui, aux élèves de sciences expérimentales, en commençant par le domaine 1 gratuit et l'essai de 30 jours. Réserve : je n'ai pas vu l'application fonctionner."],
                  ["Risque principal ?", "Ni l'inexactitude ni l'absence de guidage. Le risque est un guidage identique pour tous, et un effort dispersé sur des contenus peu présents à l'examen faute de marquage visible."],
                  ["Sur quoi repose la confiance ?", "Sur la qualité du code lu et sur la franchise de ses propres commentaires. Une relecture par un enseignant et un essai sur appareil réel la confirmeraient ou la corrigeraient."],
                ].map(([q, r]) => (
                  <div key={q} className="rounded-2xl bg-white/[.06] p-4 ring-1 ring-white/10">
                    <p className="text-[14.5px] font-bold text-amber-200">{q}</p>
                    <p className="mt-1 text-[14.5px] leading-relaxed text-white/90"><T>{r}</T></p>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <div className="rounded-3xl bg-amber-400 p-5 text-[#0a2e24] sm:p-6">
                <p className="flex items-center gap-2 text-[15px] font-bold"><Timer className="h-5 w-5" /> Les 3 ajouts les plus urgents</p>
                <ol className="mt-4 space-y-3">
                  {[
                    ["Positionner l'élève", "Un test d'entrée de 22 QCM, la date du Bac et un objectif de note, pour préremplir le plan et l'ordre du chemin."],
                    ["Étiqueter les 550 QCM", "Notion, difficulté et fréquence au Bac : c'est ce qui rend possibles la détection des lacunes et le tri de l'essentiel."],
                    ["Corriger hors ligne", "Attendus notés pour 3 sessions de plus et corrigé résumé embarqué pour les 65 exercices indexés."],
                  ].map(([t, s], i) => (
                    <li key={t} className="flex gap-3 rounded-2xl bg-[#0a2e24]/[.08] p-3.5">
                      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#0a2e24] text-[13px] font-bold text-amber-300">{i + 1}</span>
                      <span className="text-[14.5px] leading-relaxed"><strong className="block">{t}</strong>{s}</span>
                    </li>
                  ))}
                </ol>
              </div>
              <div className="grid gap-2.5 sm:grid-cols-3">
                {[
                  { i: <BadgeCheck className="h-5 w-5" />, t: "Pour l'élève", s: "Suivre la tâche du jour, puis le plan final à 30 jours du Bac." },
                  { i: <WifiOff className="h-5 w-5" />, t: "Hors connexion", s: "Télécharger les sujets et corrigés avant de partir." },
                  { i: <AlertTriangle className="h-5 w-5" />, t: "À surveiller", s: "Sauvegarder sa progression : elle vit sur le téléphone." },
                ].map((c) => (
                  <div key={c.t} className="rounded-2xl border border-white/15 bg-white/[.05] p-3.5">
                    <span className="text-amber-300">{c.i}</span>
                    <p className="mt-1.5 text-[14px] font-bold">{c.t}</p>
                    <p className="mt-0.5 text-[13.5px] leading-snug text-white/85">{c.s}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <footer className="mt-6 text-[13px] leading-relaxed text-slate-600">
          Audit établi par lecture du dépôt <span className="break-all font-mono text-[12px]">{BASE_AUDIT.depot}</span>, commit {BASE_AUDIT.commit} du {BASE_AUDIT.dateCommit}. Les notes engagent l'auditeur ; les constats renvoient aux fichiers cités.
        </footer>
      </section>

      {/* NAVIGATION MOBILE */}
      <nav className="no-print fixed bottom-3 left-1/2 z-50 flex -translate-x-1/2 items-center gap-0.5 rounded-full bg-[#0a2e24]/95 p-1.5 text-white shadow-2xl backdrop-blur lg:hidden" aria-label="Sections du rapport">
        {[
          { h: "#synthese", i: <GaugeIcon className="h-4 w-4" />, l: "Score" },
          { h: "#axes", i: <MapIcon className="h-4 w-4" />, l: "Axes" },
          { h: "#assimilation", i: <Brain className="h-4 w-4" />, l: "Axe 3" },
          { h: "#recommandations", i: <ListChecks className="h-4 w-4" />, l: "Actions" },
          { h: "#verdict", i: <Star className="h-4 w-4" />, l: "Verdict" },
        ].map((n) => (
          <a key={n.h} href={n.h} className="flex items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-2 text-[12.5px] font-bold hover:bg-white/10">
            <span className="max-[430px]:hidden">{n.i}</span>{n.l}
          </a>
        ))}
      </nav>
    </div>
  );
}
