import { useState, useMemo, useEffect } from 'react';
import { motion } from 'motion/react';
import { BookOpen, ChevronRight, ArrowRight, CheckCircle2, XCircle, Lightbulb, Target, Search } from 'lucide-react';
import { DOCUMENT_ANALYSIS_EXERCISES, type DocAnalysisExercise } from '../data/documentAnalysisExercises';
import { getDocumentPracticeContext } from '../data/documentPracticeContexts';
import { documentContextReviewId } from '../services/editorialReviewService';
import { getReviewBadge } from '../services/reviewBadgeService';
import { useSmartValidation } from '../hooks/useSmartValidation';
import { recordDocumentTrace, answerHasDocumentContent } from '../services/documentEvidenceService';
import DocumentAssetRenderer from './DocumentAssetRenderer';
import { isDocumentAssetAvailable } from '../data/documentAssets';
import CockpitChecklist from './CockpitChecklist';
import { recordCorrectionFeedback } from '../services/correctionFeedbackService';

interface DocumentAnalysisViewProps {
  onBack: () => void;
  onLaunchQuiz?: (unitId: number) => void;
  initialExerciseId?: string | null;
}

const VERB_COLOR: Record<string, string> = {
  حلل: '#006d37',
  فسر: '#0891b2',
  قارن: '#7c3aed',
  صف: '#d97706',
  حدد: '#0e7490',
  'اقترح فرضية': '#e11d48',
  صادق: '#be123c',
  'أنجز مخططا': '#4f46e5',
  'أنجز رسما': '#4f46e5',
  'اكتب نصا علميا': '#059669',
};

const MAX_HINTS = 2;

// L'en-tête annonçait « 15 وثيقة نخبة » alors que 9 documents sur 15 affichent
// « هذه الوثيقة غير جاهزة بعد. ». On annonce le nombre réellement exploitable.
const READY_COUNT = DOCUMENT_ANALYSIS_EXERCISES.filter((e) =>
  isDocumentAssetAvailable(e.doc.assetKey)
).length;

export default function DocumentAnalysisView({ onBack, initialExerciseId = null }: DocumentAnalysisViewProps) {
  const [selectedId, setSelectedId] = useState<string | null>(initialExerciseId);
  const [activeQ, setActiveQ] = useState(0);

  useEffect(() => {
    if (initialExerciseId) {
      setSelectedId(initialExerciseId);
      setActiveQ(0);
    }
  }, [initialExerciseId]);

  const selected = useMemo(
    () => DOCUMENT_ANALYSIS_EXERCISES.find((e) => e.id === selectedId) || null,
    [selectedId]
  );

  return (
    <div className="w-full max-w-3xl mx-auto" dir="rtl">
      {/* En-tête */}
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={onBack}
          className="flex items-center gap-1 text-sm font-bold text-[#506072] dark:text-gray-300 hover:text-[#006d37] transition-colors cursor-pointer"
        >
          <ChevronRight className="w-4 h-4" /> رجوع
        </button>
        <span className="flex items-center gap-1.5 font-black text-sm text-[#059669]">
          <BookOpen className="w-4 h-4" /> تحليل الوثائق — {READY_COUNT} وثيقة جاهزة من {DOCUMENT_ANALYSIS_EXERCISES.length}
        </span>
      </div>

      {!selected ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {DOCUMENT_ANALYSIS_EXERCISES.map((ex) => (
            <button
              key={ex.id}
              onClick={() => {
                setSelectedId(ex.id);
                setActiveQ(0);
              }}
              className="text-right rounded-3xl p-4 bg-white dark:bg-[#141916] border border-gray-200 dark:border-gray-800 shadow-sm hover:shadow-md hover:-translate-y-0.5 active:scale-[0.99] transition-all cursor-pointer"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-black text-gray-900 dark:text-white text-sm">{ex.doc.descriptionAr}</span>
                <ArrowRight className="w-4 h-4 text-[#059669] shrink-0" />
              </div>
              <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400">
                <span className="px-2 py-0.5 rounded-md bg-gray-100 dark:bg-gray-800">{ex.domain}</span>
                <span className="px-2 py-0.5 rounded-md bg-gray-100 dark:bg-gray-800">{ex.questions.length} أسئلة</span>
                {/* Le document manquant n'était visible qu'après le clic. */}
                {!isDocumentAssetAvailable(ex.doc.assetKey) && (
                  <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300">
                    غير جاهزة
                  </span>
                )}
              </div>
            </button>
          ))}
        </div>
      ) : (
        <ExerciseScreen exercise={selected} qIndex={activeQ} setQIndex={setActiveQ} onBackToList={() => setSelectedId(null)} />
      )}
    </div>
  );
}

export function ExerciseScreen({
  exercise,
  qIndex,
  setQIndex,
  onBackToList,
}: {
  exercise: DocAnalysisExercise;
  qIndex: number;
  setQIndex: (i: number) => void;
  onBackToList: () => void;
}) {
  const q = exercise.questions[qIndex];
  const { result, submit, reset } = useSmartValidation({ ctx: q.ctx });
  const [answer, setAnswer] = useState('');
  const [hintsShown, setHintsShown] = useState(0);
  const [recorded, setRecorded] = useState<boolean | null>(null);
  // #41 — validite de la trace documentaire, pour aligner le verdict affiche.
  const [evidenceValid, setEvidenceValid] = useState<boolean | null>(null);
  const assetAvailable = isDocumentAssetAvailable(exercise.doc.assetKey);

  // Contexte de pratique documentaire (objectif, vocabulaire, preuve attendue).
  const practice = useMemo(
    () => getDocumentPracticeContext(exercise.id, q.id),
    [exercise.id, q.id]
  );

  // #63 (second volet) — Les 42 contextes de document etaient arbitrables dans
  // le panneau enseignant et n'avaient AUCUNE surface d'affichage : l'eleve ne
  // pouvait pas savoir si le document qu'il travaille a ete relu, ni par qui.
  // C'est la majorite des items du circuit editorial. Le badge suit la doctrine
  // de #59 : une revue locale est annoncee locale, jamais presentee comme source certifiee.
  const reviewBadge = useMemo(
    () => getReviewBadge(
      'document_context',
      documentContextReviewId(exercise.id, q.id),
      practice?.sourceStatus
    ),
    [exercise.id, q.id, practice?.sourceStatus]
  );

  const handleValidate = () => {
    if (answer.trim().length < 2) return;
    const r = submit(answer);
    // Sans contexte de pratique, aucune trace n'est enregistrable : le moteur de
    // validation corrige quand même la réponse, mais on ne fabrique pas de preuve.
    // (Auparavant `practice!` provoquait un TypeError qui laissait le bouton mort.)
    if (!practice) {
      setRecorded(null);
      setEvidenceValid(null);
      return;
    }
    // Validation de la trace documentaire réelle (preuve + vocabulaire).
    const outcome = recordDocumentTrace({ context: practice, answer, validationResult: r });
    setRecorded(outcome.evidence != null);
    // Verdict affiché : recouvrement lexical calibré (cf. #41). On n'utilise pas
    // outcome.trace.valid, dont la règle stricte — juste pour la trace de
    // maîtrise — refuse 8 corrections officielles sur 31.
    setEvidenceValid(answerHasDocumentContent(answer, practice, exercise.correctionAr));
  };

  const handleNext = () => {
    if (qIndex < exercise.questions.length - 1) {
      setQIndex(qIndex + 1);
      setAnswer('');
      reset();
      setHintsShown(0);
      setRecorded(null);
      setEvidenceValid(null);
    } else {
      onBackToList();
      setAnswer('');
      reset();
      setHintsShown(0);
      setRecorded(null);
      setEvidenceValid(null);
    }
  };

  const showHint = () => setHintsShown((h) => Math.min(MAX_HINTS, h + 1));

  return (
    <div className="space-y-4">
      {/* Carte doc */}
      <div className="rounded-3xl bg-white dark:bg-[#141916] border border-gray-200 dark:border-gray-800 p-5 shadow-sm">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-[10px] font-black px-2 py-0.5 rounded-md bg-[#059669]/10 text-[#059669]">
            {exercise.domain}
          </span>
          <span className="text-[10px] font-bold text-gray-400">{exercise.doc.type}</span>
        </div>
        <p className="mb-4 text-gray-800 dark:text-gray-200 font-medium leading-7">{exercise.doc.descriptionAr}</p>
        <DocumentAssetRenderer assetKey={exercise.doc.assetKey} />
      </div>

      {/* Question + contexte de pratique */}
      {assetAvailable && <div className="rounded-3xl bg-gradient-to-br from-[#006d37]/5 to-[#059669]/5 border border-[#006d37]/20 p-5 shadow-sm space-y-3">
        <div className="flex items-center gap-2">
          <span
            className="text-[11px] font-black px-2.5 py-1 rounded-lg text-white"
            style={{ background: VERB_COLOR[q.verb] || '#006d37' }}
          >
            {q.verb}
          </span>
          <span className="text-[10px] font-bold text-gray-400">القانون رقم {q.loiFocus}</span>
        </div>
        <p className="text-gray-900 dark:text-white font-bold leading-8">{q.promptAr}</p>

        {/* #63 — Provenance editoriale du document, visible par l'eleve. */}
        <div
          data-testid="doc-review-badge"
          data-tone={reviewBadge.tone}
          className={`text-[10px] font-bold leading-5 rounded-lg px-2 py-1 inline-block ${
            reviewBadge.tone === 'trusted'
              ? 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/20 dark:text-emerald-300'
              : reviewBadge.tone === 'local'
              ? 'bg-amber-50 text-amber-800 dark:bg-amber-950/20 dark:text-amber-300'
              : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400'
          }`}
        >
          {reviewBadge.labelAr}
        </div>

        {/* Objectif + preuve attendue visibles AVANT la production (Speckit §4). */}
        {practice && (
          <div className="bg-[#fff9ed] dark:bg-[#1c241f] border border-[#e2dabf]/60 dark:border-amber-900/30 rounded-2xl p-3 space-y-2">
            <div className="text-[11px] font-black text-[#944a00] dark:text-amber-300 flex items-center gap-1">
              <Target className="w-3.5 h-3.5" /> هدف الوثيقة
            </div>
            <p className="text-[12px] font-bold text-[#1f1c0b] dark:text-white leading-6">{practice.goalAr}</p>
            <div className="text-[11px] font-black text-[#006d37] dark:text-[#2ecc71] flex items-center gap-1">
              <Search className="w-3.5 h-3.5" /> ابحث عن
            </div>
            <div className="flex flex-wrap gap-1">
              {practice.expectedEvidence.map((e, i) => (
                <span key={i} className="text-[10px] font-bold bg-[#2ecc71]/15 text-[#006d37] px-2 py-0.5 rounded-full">
                  {e}
                </span>
              ))}
            </div>
          </div>
        )}

        <p className="text-[11px] text-[#006d37] dark:text-[#2ecc71] flex items-center gap-1">
          <Lightbulb className="w-3.5 h-3.5" /> {q.templateHint}
        </p>

        {/* Indices progressifs (max 2) */}
        {hintsShown > 0 && practice && (
          <div className="space-y-1">
            {hintsShown >= 1 && (
              <p className="text-[11px] bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 rounded-lg px-3 py-2 text-amber-800 dark:text-amber-200 font-medium">
                💡 تلميح 1 — مفردات مفتاحية: {practice.vocabulary.slice(0, 3).join(' · ')}
              </p>
            )}
            {hintsShown >= 2 && (
              <p className="text-[11px] bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 rounded-lg px-3 py-2 text-amber-800 dark:text-amber-200 font-medium">
                💡 تلميح 2 — {practice.trapAr ?? 'ركّز على العلاقة بين المتغيرات.'}
              </p>
            )}
          </div>
        )}
        {hintsShown < MAX_HINTS && !result && (
          <button
            onClick={showHint}
            className="text-[11px] font-bold text-[#944a00] dark:text-amber-300 hover:underline cursor-pointer"
          >
            عرض تلميح ({hintsShown}/{MAX_HINTS})
          </button>
        )}

        <CockpitChecklist verb={q.verb} verbColor={VERB_COLOR[q.verb] || '#006d37'} />

        <textarea
          value={answer}
          onChange={(e) => { setAnswer(e.target.value); setRecorded(null); }}
          placeholder="اكتب إجابتك العلمية هنا…"
          className="w-full mt-1 rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-[#0c0f0d] p-3 text-sm text-gray-800 dark:text-gray-100 leading-7 min-h-[120px] resize-y outline-none focus:border-[#006d37]"
        />

        <div className="flex items-center gap-2 mt-3">
          <button
            onClick={handleValidate}
            disabled={answer.trim().length < 2}
            className="flex-1 bg-[#006d37] text-white font-black py-2.5 rounded-xl text-sm hover:bg-[#005a2e] transition-colors disabled:opacity-40 cursor-pointer"
          >
            صحّح إجابتي
          </button>
          {result && (
            <button
              onClick={handleNext}
              className="flex-1 bg-[#ff9a4a] text-white font-black py-2.5 rounded-xl text-sm hover:brightness-105 transition-all cursor-pointer flex items-center justify-center gap-1"
            >
              {qIndex < exercise.questions.length - 1 ? 'السؤال التالي' : 'القائمة'} <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>}

      {/* Résultat — correction modèle masquée jusqu'à la tentative */}
      {assetAvailable && result && (
        <ResultSheet
          result={result}
          correctionAr={exercise.correctionAr}
          recorded={recorded}
          evidenceValid={evidenceValid}
          grille={exercise.grilleEntrainement}
          exerciseId={exercise.id}
          questionId={q.id}
          answer={answer}
        />
      )}
    </div>
  );
}

function ResultSheet({
  result,
  correctionAr,
  recorded,
  evidenceValid,
  grille,
  exerciseId,
  questionId,
  answer,
}: {
  result: ReturnType<typeof useSmartValidation>['result'];
  correctionAr: string;
  recorded: boolean | null;
  evidenceValid?: boolean | null;
  grille: DocAnalysisExercise['grilleEntrainement'];
  exerciseId: string;
  questionId: string;
  answer: string;
}) {
  // #64 — état local du signalement : on n'affiche une confirmation QUE si
  // l'écriture a réellement eu lieu.
  const [reported, setReported] = useState<boolean | null>(null);
  if (!result) return null;
  // #41 — Le verdict affiche suivait le seul ValidationEngine, qui note la FORME
  // methodologique et non le fond : une reponse hors-sujet obtenait 80-95 % et
  // l'etiquette « مقبول » sur les 31 questions atteignables, alors que la trace
  // documentaire (preuve + vocabulaire) la refusait au meme instant. L'eleve
  // lisait « accepte » pendant que l'application n'enregistrait aucune preuve.
  // Le verdict montre est desormais celui qui fait foi.
  const passed = result.passed && evidenceValid !== false;
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-3xl border p-5 shadow-sm bg-white dark:bg-[#141916] border-gray-200 dark:border-gray-800 space-y-3"
    >
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          {passed ? (
            <CheckCircle2 className="w-6 h-6 text-[#006d37]" />
          ) : (
            <XCircle className="w-6 h-6 text-[#e11d48]" />
          )}
          <span className="font-black text-gray-900 dark:text-white" data-testid="doc-form-score">
            {/* #65 — « 20/20 » se lisait comme une note d'épreuve : le maximum du
                moteur vaut 20 par défaut, homonyme du barème BAC. On nomme donc
                explicitement ce que la note mesure — la FORME méthodologique. */}
            منهجية: {result.score}/{result.maxScore} · {passed ? 'مقبول' : 'يحتاج تحسين'}
          </span>
        </div>
        <span className="text-xs font-bold text-[#b45309] dark:text-[#ffd27a]">+{result.xp} XP</span>
      </div>

      {/* Preuve documentaire réellement enregistrée (jamais par clic). */}
      {recorded != null && (
        <div className={`text-[11px] font-bold p-2 rounded-lg ${recorded ? 'bg-[#2ecc71]/10 text-[#006d37]' : 'bg-rose-50 text-rose-700 dark:bg-rose-950/20 dark:text-rose-300'}`}>
          {recorded ? '✅ تم تسجيل دليل وثيقة حقيقي لتقدّمك.' : '⚠️ تم تسجيل نقطة تحتاج إلى مراجعة (وثيقة).'}
        </div>
      )}

      {result.brokenLois.length > 0 && (
        <div className="bg-rose-50 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900/40 rounded-2xl p-3">
          <div className="flex items-center gap-2 mb-1">
            <Target className="w-4 h-4 text-rose-600" />
            <span className="text-xs font-black text-rose-700 dark:text-rose-300">القوانين التي تحتاج مراجعة</span>
          </div>
          <div className="flex flex-wrap gap-1">
            {result.brokenLois.map((l) => (
              <span key={l} className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-300">
                القانون رقم {l}
              </span>
            ))}
          </div>
        </div>
      )}

      {result.errors.filter((e) => e.severity !== 'hint').length > 0 && (
        <ul className="space-y-1.5">
          {result.errors
            .filter((e) => e.severity !== 'hint')
            .map((e, i) => (
              <li key={i} className="text-[12px] leading-6 text-gray-700 dark:text-gray-300 flex items-start gap-2">
                <span className="mt-1 w-1.5 h-1.5 rounded-full bg-[#ff9a4a] shrink-0" />
                {e.messageAr}
              </li>
            ))}
        </ul>
      )}

      {/* Correction modèle — visible UNIQUEMENT après tentative. */}
      <div className="bg-white dark:bg-black/20 border border-emerald-200/50 dark:border-emerald-900/30 rounded-xl px-3 py-2 text-[12px] font-bold text-emerald-800 dark:text-emerald-300">
        <span className="font-black">التصحيح:</span> {correctionAr}
      </div>

      {/* #66 — Barème d'entraînement : 76 critères pondérés existaient en donnée
          (4 par exercice, 20 points au total) et n'étaient affichés NULLE PART.
          L'élève voyait une note sans savoir sur quoi elle portait. On les montre
          après la tentative, comme grille d'auto-correction — l'app ne sait pas
          les évaluer automatiquement, elle ne prétend donc pas le faire. */}
      {grille.length > 0 && (
        <div
          className="bg-[#fff9ed] dark:bg-[#1c241f] border border-[#e2dabf]/60 dark:border-amber-900/30 rounded-2xl p-3 space-y-2"
          data-testid="doc-grille"
        >
          <div className="text-[11px] font-black text-[#944a00] dark:text-amber-300 flex items-center gap-1">
            <Target className="w-3.5 h-3.5" /> سلّم التنقيط — صحّح نفسك بنفسك
          </div>
          <ul className="space-y-1">
            {grille.map((c, i) => (
              <li
                key={i}
                className="flex items-center justify-between gap-2 text-[12px] font-bold text-[#1f1c0b] dark:text-white"
                data-testid={`doc-grille-critere-${i}`}
              >
                <span className="leading-6">{c.critereAr}</span>
                <span className="shrink-0 text-[11px] font-black px-2 py-0.5 rounded-md bg-[#006d37]/10 text-[#006d37] dark:text-[#2ecc71]">
                  {c.points} ن
                </span>
              </li>
            ))}
          </ul>
          <p className="text-[10px] text-gray-500 dark:text-gray-400 leading-5">
            المجموع {grille.reduce((s, c) => s + c.points, 0)} نقطة — قارن إجابتك بالتصحيح أعلاه وامنح لنفسك النقاط.
          </p>
        </div>
      )}

      <div className="flex items-center justify-between border-t border-gray-100 dark:border-gray-800 pt-2 mt-1 gap-2">
        {/* #67 — `result.label` est rédigé en FRANÇAIS et s'affichait tel quel à un
            élève arabophone, en 10 px gris : l'avertissement le plus important de
            l'écran — « ce n'est pas le barème officiel » — était illisible pour
            son destinataire. Traduit, et non plus dilué. */}
        <p className="text-[10px] text-gray-500 dark:text-gray-400 leading-5" data-testid="doc-training-label">
          سلّم تدريبي من إعداد التطبيق — ليس سلّم التنقيط الرسمي لموضوع البكالوريا.
        </p>
        <button
          onClick={() => {
            const ok = recordCorrectionFeedback({
              exerciseId,
              questionId,
              answer,
              score: result.score,
              maxScore: result.maxScore,
            });
            setReported(ok);
          }}
          className="text-[10px] text-rose-500 font-bold hover:underline cursor-pointer flex items-center gap-1 shrink-0"
          data-testid="doc-report-button"
        >
          <XCircle className="w-3 h-3" /> أبلغ عن خطأ في التصحيح
        </button>
      </div>

      {/* #64 — On ne confirme QUE ce qui a réellement été écrit, et on n'annonce
          aucune relecture par une équipe : l'application est hors ligne. */}
      {reported != null && (
        <p
          className={`text-[11px] font-bold p-2 rounded-lg ${reported ? 'bg-[#2ecc71]/10 text-[#006d37]' : 'bg-rose-50 text-rose-700 dark:bg-rose-950/20 dark:text-rose-300'}`}
          data-testid="doc-report-notice"
        >
          {reported
            ? 'حُفظ اعتراضك على هذا الجهاز فقط — لا يُرسل إلى أي جهة. اعرضه على أستاذك عند المراجعة.'
            : 'تعذّر حفظ الاعتراض على هذا الجهاز.'}
        </p>
      )}
    </motion.div>
  );
}
