import { useState } from "react";
import type { Axe } from "../data/audit";
import { RECOMMANDATIONS } from "../data/audit";

function NoteBadge({ note }: { note: number }) {
  const color =
    note >= 8
      ? "border-emerald-500/50 bg-emerald-500/15 text-emerald-300"
      : note >= 6.5
        ? "border-amber-500/50 bg-amber-500/15 text-amber-300"
        : "border-red-500/50 bg-red-500/15 text-red-300";
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-1.5 text-lg font-black ${color}`}>
      {note.toFixed(1)}
      <span className="text-xs font-semibold opacity-70">/10</span>
    </span>
  );
}

function Block({ titre, couleur, items }: { titre: string; couleur: string; items: string[] }) {
  if (items.length === 0) return null;
  return (
    <div>
      <h4 className={`text-xs font-black uppercase tracking-widest ${couleur}`}>{titre}</h4>
      <ul className="mt-3 space-y-2.5">
        {items.map((it, i) => (
          <li key={i} className="flex gap-2.5 text-sm leading-relaxed text-slate-300">
            <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-current opacity-60" />
            <span>{it}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function AxeCard({ axe, ouvert, onToggle }: { axe: Axe; ouvert: boolean; onToggle: () => void }) {
  const [tab, setTab] = useState<"detail" | "recos">("detail");
  const recos = RECOMMANDATIONS.filter((r) => r.axe === axe.id);
  const prioLabel = { haute: "🔴 Haute", moyenne: "🟡 Moyenne", basse: "🟢 Basse" } as const;

  return (
    <article
      id={`axe-${axe.id}`}
      className="scroll-mt-24 overflow-hidden rounded-3xl border border-slate-800 bg-slate-900/70 transition-colors hover:border-slate-700"
    >
      <button
        onClick={onToggle}
        className="flex w-full flex-wrap items-center gap-4 px-6 py-5 text-left transition-colors hover:bg-slate-800/40"
      >
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-emerald-500/15 text-lg font-black text-emerald-300">
          {axe.id}
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="text-lg font-black text-white md:text-xl">
            Axe {axe.id} — {axe.nom}
          </h3>
          <p className="mt-1 text-sm leading-relaxed text-slate-400">{axe.resume}</p>
        </div>
        <div className="flex items-center gap-4">
          <span className="hidden text-xs font-semibold text-slate-500 sm:block">Poids {axe.poids} %</span>
          <NoteBadge note={axe.note} />
          <span className={`text-slate-400 transition-transform duration-300 ${ouvert ? "rotate-180" : ""}`}>
            <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="m6 9 6 6 6-6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </span>
        </div>
      </button>

      {ouvert && (
        <div className="border-t border-slate-800 px-6 py-6">
          <div className="mb-5 inline-flex rounded-full border border-slate-700 bg-slate-800/70 p-1 text-xs font-bold">
            <button
              onClick={() => setTab("detail")}
              className={`rounded-full px-4 py-1.5 transition-colors ${tab === "detail" ? "bg-emerald-500 text-slate-950" : "text-slate-300 hover:text-white"}`}
            >
              Détail de l'audit
            </button>
            <button
              onClick={() => setTab("recos")}
              className={`rounded-full px-4 py-1.5 transition-colors ${tab === "recos" ? "bg-emerald-500 text-slate-950" : "text-slate-300 hover:text-white"}`}
            >
              Recommandations ({recos.length})
            </button>
          </div>

          {tab === "detail" ? (
            <div className="grid gap-8 lg:grid-cols-2">
              <Block titre="🔎 Constats détaillés" couleur="text-sky-300" items={axe.constat} />
              <div className="space-y-8">
                <Block titre="✅ Points forts" couleur="text-emerald-300" items={axe.pointsForts} />
                <Block titre="❌ Points faibles" couleur="text-red-300" items={axe.pointsFaibles} />
                {axe.nonVerifiable.length > 0 && (
                  <div>
                    <h4 className="text-xs font-black uppercase tracking-widest text-slate-500">
                      ⚪ Non vérifiable (noté comme tel, jamais supposé)
                    </h4>
                    <ul className="mt-3 space-y-2">
                      {axe.nonVerifiable.map((n, i) => (
                        <li key={i} className="flex gap-2.5 text-sm italic text-slate-400">
                          <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-slate-500" />
                          {n}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <ul className="space-y-3">
              {recos.length === 0 && (
                <li className="text-sm italic text-slate-400">Aucune recommandation spécifique à cet axe.</li>
              )}
              {recos.map((r) => (
                <li key={r.id} className="rounded-2xl border border-slate-800 bg-slate-950/60 p-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="rounded-md bg-slate-800 px-2 py-0.5 font-mono text-xs font-bold text-emerald-300">
                      {r.id}
                    </span>
                    <span className="text-xs font-black">{prioLabel[r.priorite]}</span>
                    <span className="text-xs text-slate-500">Axe {r.axe}</span>
                  </div>
                  <p className="mt-2 text-sm font-bold text-white">{r.titre}</p>
                  <p className="mt-1 text-sm leading-relaxed text-slate-400">{r.detail}</p>
                  <p className="mt-2 text-xs font-semibold text-amber-300/90">🎯 {r.chiffrage}</p>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </article>
  );
}
