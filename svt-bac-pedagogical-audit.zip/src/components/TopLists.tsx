import { POINTS_FAIBLES_TOP, POINTS_FORTS_TOP } from "../data/audit";

export default function TopLists() {
  return (
    <section id="forces-faibles" className="mx-auto max-w-6xl scroll-mt-24 px-6 py-14">
      <div className="grid gap-8 lg:grid-cols-2">
        {/* Points forts */}
        <div>
          <h2 className="text-2xl font-black text-white">✅ Points forts (top 5, par impact)</h2>
          <ol className="mt-6 space-y-4">
            {POINTS_FORTS_TOP.map((p) => (
              <li
                key={p.rang}
                className="rounded-2xl border border-emerald-500/25 bg-emerald-500/[0.06] p-5 transition-colors hover:border-emerald-500/50"
              >
                <div className="flex items-start gap-3">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-emerald-500 text-sm font-black text-slate-950">
                    {p.rang}
                  </span>
                  <div>
                    <h3 className="font-black text-emerald-200">{p.titre}</h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-slate-300">{p.detail}</p>
                    <p className="mt-2 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                      Axes {p.axes.join(" & ")}
                    </p>
                  </div>
                </div>
              </li>
            ))}
          </ol>
        </div>

        {/* Points faibles */}
        <div>
          <h2 className="text-2xl font-black text-white">❌ Points faibles (top 5, par gravité)</h2>
          <ol className="mt-6 space-y-4">
            {POINTS_FAIBLES_TOP.map((p) => (
              <li
                key={p.rang}
                className="rounded-2xl border border-red-500/25 bg-red-500/[0.06] p-5 transition-colors hover:border-red-500/50"
              >
                <div className="flex items-start gap-3">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-red-500 text-sm font-black text-white">
                    {p.rang}
                  </span>
                  <div>
                    <h3 className="font-black text-red-200">{p.titre}</h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-slate-300">{p.detail}</p>
                    <p className="mt-2 text-[11px] font-bold uppercase tracking-wider text-red-300/70">
                      Gravité : {p.gravite} · Axes {p.axes.join(" & ")}
                    </p>
                  </div>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
