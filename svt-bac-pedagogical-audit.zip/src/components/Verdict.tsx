import { NON_VERIFIABLES_GLOBAUX, VERDICT } from "../data/audit";

export default function Verdict() {
  const etoiles = "⭐".repeat(VERDICT.confiance) + "☆".repeat(5 - VERDICT.confiance);
  return (
    <section id="verdict" className="mx-auto max-w-6xl scroll-mt-24 px-6 py-14">
      <h2 className="text-3xl font-black text-white">🏆 Verdict final</h2>

      <div className="mt-8 overflow-hidden rounded-3xl border border-emerald-500/30 bg-gradient-to-b from-emerald-500/[0.12] to-slate-900/70">
        <div className="p-8">
          <div className="flex flex-wrap items-center gap-4">
            <span className="text-4xl">{etoiles}</span>
            <span className="text-sm font-black uppercase tracking-widest text-emerald-300">
              Note de confiance globale : {VERDICT.confiance}/5
            </span>
          </div>
          <p className="mt-2 text-xs text-slate-400">{VERDICT.confianceTexte}</p>

          <div className="mt-6 grid gap-4 md:grid-cols-2">
            <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-5">
              <p className="text-xs font-black uppercase tracking-widest text-emerald-300">
                L'application est-elle prête pour le marché ?
              </p>
              <p className="mt-2 text-sm font-bold text-white">{VERDICT.pret}.</p>
              <p className="mt-2 text-sm leading-relaxed text-slate-300">{VERDICT.resume}</p>
            </div>
            <div className="rounded-2xl border border-red-500/30 bg-red-500/[0.07] p-5">
              <p className="text-xs font-black uppercase tracking-widest text-red-300">⚠️ Risque principal</p>
              <p className="mt-2 text-sm leading-relaxed text-slate-200">{VERDICT.risquePrincipal}</p>
            </div>
          </div>

          <div className="mt-4 rounded-2xl border border-amber-500/30 bg-amber-500/[0.07] p-5">
            <p className="text-xs font-black uppercase tracking-widest text-amber-300">
              🚨 Les 3 ajouts les plus urgents
            </p>
            <ol className="mt-3 space-y-2">
              {VERDICT.urgents.map((u, i) => (
                <li key={i} className="flex gap-2.5 text-sm font-semibold text-amber-100">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-amber-500/20 text-xs font-black text-amber-300">
                    {i + 1}
                  </span>
                  <span>{u}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>

      <div className="mt-8 rounded-3xl border border-slate-800 bg-slate-900/70 p-8">
        <h3 className="text-lg font-black text-white">⚪ Informations non vérifiables (notées comme telles, jamais supposées)</h3>
        <ul className="mt-4 grid gap-2.5 md:grid-cols-2">
          {NON_VERIFIABLES_GLOBAUX.map((n, i) => (
            <li key={i} className="flex gap-2.5 rounded-xl border border-slate-800 bg-slate-950/50 px-4 py-3 text-sm italic text-slate-400">
              <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-slate-500" />
              {n}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
