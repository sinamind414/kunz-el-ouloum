import { useState } from "react";
import { RECOMMANDATIONS, type Priorite } from "../data/audit";

const FILTRES: { id: Priorite | "toutes"; label: string }[] = [
  { id: "toutes", label: "Toutes" },
  { id: "haute", label: "🔴 Haute priorité" },
  { id: "moyenne", label: "🟡 Moyenne priorité" },
  { id: "basse", label: "🟢 Basse priorité" },
];

const BADGE: Record<Priorite, string> = {
  haute: "border-red-500/40 bg-red-500/15 text-red-300",
  moyenne: "border-amber-500/40 bg-amber-500/15 text-amber-300",
  basse: "border-emerald-500/40 bg-emerald-500/15 text-emerald-300",
};
const LABEL: Record<Priorite, string> = {
  haute: "🔴 Haute priorité (bloquant)",
  moyenne: "🟡 Moyenne priorité (améliore l'expérience)",
  basse: "🟢 Basse priorité (confort / bonus)",
};

export default function Recommandations() {
  const [filtre, setFiltre] = useState<Priorite | "toutes">("toutes");
  const liste = filtre === "toutes" ? RECOMMANDATIONS : RECOMMANDATIONS.filter((r) => r.priorite === filtre);
  const compte = (p: Priorite) => RECOMMANDATIONS.filter((r) => r.priorite === p).length;

  return (
    <section id="recommandations" className="mx-auto max-w-6xl scroll-mt-24 px-6 py-14">
      <h2 className="text-3xl font-black text-white">🔧 Recommandations (par priorité)</h2>
      <p className="mt-2 max-w-3xl text-slate-400">
        {RECOMMANDATIONS.length} recommandations concrètes, actionnables, associées à un axe et chiffrées :
        {compte("haute")} 🔴 hautes, {compte("moyenne")} 🟡 moyennes, {compte("basse")} 🟢 basses.
      </p>

      <div className="mt-6 flex flex-wrap gap-2">
        {FILTRES.map((f) => (
          <button
            key={f.id}
            onClick={() => setFiltre(f.id)}
            className={`rounded-full border px-4 py-2 text-sm font-bold transition-colors ${
              filtre === f.id
                ? "border-emerald-400 bg-emerald-500/20 text-emerald-200"
                : "border-slate-700 bg-slate-900/60 text-slate-300 hover:border-slate-500"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <ol className="mt-8 space-y-4">
        {liste.map((r, i) => (
          <li
            key={r.id}
            className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5 transition-colors hover:border-slate-600"
          >
            <div className="flex flex-wrap items-center gap-2">
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-slate-800 font-mono text-xs font-black text-emerald-300">
                {i + 1}
              </span>
              <span className="rounded-md bg-slate-800 px-2 py-0.5 font-mono text-xs font-bold text-emerald-300">
                {r.id}
              </span>
              <span className={`rounded-full border px-3 py-0.5 text-[11px] font-black ${BADGE[r.priorite]}`}>
                {LABEL[r.priorite]}
              </span>
              <span className="rounded-full border border-slate-700 px-3 py-0.5 text-[11px] font-bold text-slate-400">
                Axe {r.axe}
              </span>
            </div>
            <h3 className="mt-3 text-base font-black text-white">{r.titre}</h3>
            <p className="mt-1.5 text-sm leading-relaxed text-slate-400">{r.detail}</p>
            <p className="mt-2.5 inline-block rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-1 text-xs font-bold text-amber-300">
              🎯 Chiffrage : {r.chiffrage}
            </p>
          </li>
        ))}
      </ol>
    </section>
  );
}
