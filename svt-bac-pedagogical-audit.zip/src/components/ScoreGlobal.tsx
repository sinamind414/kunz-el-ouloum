import { AXES, SCORE_GLOBAL } from "../data/audit";

function noteColor(note: number): string {
  if (note >= 8) return "text-emerald-400";
  if (note >= 6.5) return "text-amber-300";
  return "text-red-400";
}
function barColor(note: number): string {
  if (note >= 8) return "bg-emerald-400";
  if (note >= 6.5) return "bg-amber-400";
  return "bg-red-400";
}

export default function ScoreGlobal() {
  const score = SCORE_GLOBAL; // /100
  const r = 84;
  const c = 2 * Math.PI * r;
  const offset = c - (score / 100) * c;

  return (
    <section id="synthese" className="mx-auto max-w-6xl scroll-mt-24 px-6 py-14">
      <h2 className="text-3xl font-black text-white">📊 Tableau de synthèse &amp; score global</h2>
      <p className="mt-2 max-w-3xl text-slate-400">
        Notes sur 10 par axe, pondérées selon la grille demandée (l'Axe 3 « Assimilation » pèse 18 %, facteur
        différenciant majeur).
      </p>

      <div className="mt-8 grid items-center gap-8 rounded-3xl border border-slate-800 bg-slate-900/70 p-8 lg:grid-cols-[auto_1fr]">
        {/* Jauge */}
        <div className="relative mx-auto h-56 w-56">
          <svg viewBox="0 0 200 200" className="h-full w-full -rotate-90">
            <circle cx="100" cy="100" r={r} fill="none" strokeWidth="16" className="stroke-slate-800" />
            <circle
              cx="100"
              cy="100"
              r={r}
              fill="none"
              strokeWidth="16"
              strokeLinecap="round"
              strokeDasharray={c}
              strokeDashoffset={offset}
              className="stroke-emerald-400 transition-all duration-1000"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-5xl font-black text-white">{score}</span>
            <span className="text-sm font-semibold text-slate-400">/ 100</span>
            <span className="mt-1 text-xs font-bold uppercase tracking-wider text-emerald-400">Score global pondéré</span>
          </div>
        </div>

        {/* Tableau */}
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-left text-sm">
            <thead>
              <tr className="border-b border-slate-800 text-xs uppercase tracking-wider text-slate-500">
                <th className="pb-3 pr-4 font-bold">Axe</th>
                <th className="pb-3 pr-4 font-bold">Note /10</th>
                <th className="pb-3 pr-4 font-bold">Poids</th>
                <th className="pb-3 pr-4 font-bold">Contribution</th>
                <th className="pb-3 font-bold">Barre</th>
              </tr>
            </thead>
            <tbody>
              {AXES.map((a) => (
                <tr key={a.id} className="border-b border-slate-800/60 last:border-0">
                  <td className="py-3 pr-4 font-semibold text-slate-200">
                    <a href={`#axe-${a.id}`} className="transition-colors hover:text-emerald-300">
                      {a.id}. {a.nom.replace(" ⭐", "")}
                    </a>
                  </td>
                  <td className={`py-3 pr-4 font-black ${noteColor(a.note)}`}>{a.note.toFixed(1)}</td>
                  <td className="py-3 pr-4 text-slate-400">{a.poids} %</td>
                  <td className="py-3 pr-4 font-mono text-xs text-slate-400">
                    {(a.note * a.poids).toFixed(2)}
                  </td>
                  <td className="py-3">
                    <div className="h-2.5 w-32 overflow-hidden rounded-full bg-slate-800">
                      <div
                        className={`h-full rounded-full ${barColor(a.note)}`}
                        style={{ width: `${a.note * 10}%` }}
                      />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="text-sm font-black text-white">
                <td className="pt-3 pr-4">Total pondéré</td>
                <td className="pt-3 pr-4" />
                <td className="pt-3 pr-4 text-slate-400">100 %</td>
                <td className="pt-3 pr-4 font-mono text-emerald-400">{SCORE_GLOBAL.toFixed(1)} / 100</td>
                <td className="pt-3" />
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </section>
  );
}
