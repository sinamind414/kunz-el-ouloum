import { META } from "../data/audit";

export default function Header() {
  return (
    <header className="relative overflow-hidden border-b border-slate-800 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950">
      <div className="pointer-events-none absolute -top-32 right-10 h-96 w-96 rounded-full bg-emerald-500/10 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 left-0 h-96 w-96 rounded-full bg-teal-500/10 blur-3xl" />
      <div className="relative mx-auto max-w-6xl px-6 py-14 md:py-20">
        <div className="flex flex-wrap items-center gap-3">
          <span className="rounded-full border border-emerald-500/40 bg-emerald-500/10 px-4 py-1.5 text-sm font-bold text-emerald-300" dir="rtl">
            كنز العلوم — Kunz El Ouloum
          </span>
          <span className="rounded-full border border-slate-700 bg-slate-800/60 px-4 py-1.5 text-xs font-semibold text-slate-300">
            Bac Algérie · 3AS Sciences expérimentales · SVT
          </span>
          <span className="rounded-full border border-slate-700 bg-slate-800/60 px-4 py-1.5 text-xs font-semibold text-slate-300">
            Audit fondé sur le code source
          </span>
        </div>
        <h1 className="mt-6 text-4xl font-black tracking-tight text-white md:text-6xl">
          {META.titre}
        </h1>
        <p className="mt-4 max-w-3xl text-lg leading-relaxed text-slate-300">{META.sousTitre}</p>
        <div className="mt-6 rounded-2xl border border-amber-500/30 bg-amber-500/10 p-5">
          <p className="text-sm font-bold uppercase tracking-wider text-amber-300">Question centrale de l'audit</p>
          <p className="mt-2 text-base leading-relaxed text-amber-100/90">{META.questionCentrale}</p>
        </div>
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-500">Source auditée</p>
            <p className="mt-1 break-all text-sm font-mono text-emerald-300">{META.source}</p>
            <p className="mt-1 text-xs text-slate-400">{META.date}</p>
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-500">Méthodologie</p>
            <ul className="mt-2 space-y-1.5 text-sm leading-relaxed text-slate-300">
              {META.methode.map((m, i) => (
                <li key={i} className="flex gap-2">
                  <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-400" />
                  <span>{m}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </header>
  );
}
