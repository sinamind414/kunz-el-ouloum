import { useState } from "react";
import Header from "./components/Header";
import ScoreGlobal from "./components/ScoreGlobal";
import AxeCard from "./components/AxeCard";
import TopLists from "./components/TopLists";
import Recommandations from "./components/Recommandations";
import Verdict from "./components/Verdict";
import { AXES, META } from "./data/audit";

const NAV = [
  { id: "synthese", label: "📊 Synthèse" },
  { id: "axes", label: "🔎 Les 8 axes" },
  { id: "forces-faibles", label: "✅❌ Forces & faiblesses" },
  { id: "recommandations", label: "🔧 Recommandations" },
  { id: "verdict", label: "🏆 Verdict" },
];

export default function App() {
  const [ouverts, setOuverts] = useState<Record<number, boolean>>({ 1: true, 3: true });

  const toggle = (id: number) => setOuverts((o) => ({ ...o, [id]: !o[id] }));

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-slate-200 antialiased">
      {/* Navigation fixe */}
      <nav className="sticky top-0 z-50 border-b border-slate-800/80 bg-slate-950/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center gap-1 overflow-x-auto px-4 py-2.5">
          <span className="mr-3 hidden shrink-0 text-sm font-black text-emerald-400 sm:block" dir="rtl">
            كنز العلوم
          </span>
          {NAV.map((n) => (
            <a
              key={n.id}
              href={`#${n.id}`}
              className="shrink-0 rounded-full px-3.5 py-1.5 text-xs font-bold text-slate-300 transition-colors hover:bg-slate-800 hover:text-white"
            >
              {n.label}
            </a>
          ))}
          <button
            onClick={() => setOuverts(Object.fromEntries(AXES.map((a) => [a.id, true])))}
            className="ml-auto shrink-0 rounded-full border border-slate-700 px-3 py-1.5 text-[11px] font-bold text-slate-400 transition-colors hover:border-emerald-500/60 hover:text-emerald-300"
          >
            Tout déplier
          </button>
        </div>
      </nav>

      <Header />
      <ScoreGlobal />

      {/* Axes détaillés */}
      <section id="axes" className="mx-auto max-w-6xl scroll-mt-24 px-6 py-8">
        <h2 className="text-3xl font-black text-white">🔎 Détail des 8 axes d'audit</h2>
        <p className="mt-2 max-w-3xl text-slate-400">
          Chaque axe : note /10, constats vérifiés dans le code (avec noms de fichiers et de modules réels),
          points forts, points faibles et éléments « non vérifiables » notés comme tels.
        </p>
        <div className="mt-8 space-y-4">
          {AXES.map((a) => (
            <AxeCard key={a.id} axe={a} ouvert={!!ouverts[a.id]} onToggle={() => toggle(a.id)} />
          ))}
        </div>
      </section>

      <TopLists />
      <Recommandations />
      <Verdict />

      {/* Pied de page */}
      <footer className="border-t border-slate-800 bg-slate-950">
        <div className="mx-auto max-w-6xl px-6 py-10">
          <p className="text-sm font-bold text-slate-300">Rapport d'audit — {META.titre}</p>
          <p className="mt-2 max-w-3xl text-sm leading-relaxed text-slate-500">
            Audit réalisé en français, sur le dépôt public {META.source} ({META.date}). Constats issus de la
            lecture directe du code (src/data/curriculumOfficial.ts, bacSessionIndex.ts, prioritesBac.ts,
            positionnementInitial.ts, revisionPlan.ts, expressJ7.ts, sm2.ts, quizAdaptatif.ts, sw.js,
            store/README.md, README.md…). Les éléments absents du dépôt sont notés « Non vérifiables » et
            jamais supposés. Contexte algérien pris en compte : 3G intermittente, smartphones d'entrée de
            gamme, budgets limités (100-500 DA/mois), enseignement bilingue arabe-français, stress du Bac.
          </p>
        </div>
      </footer>
    </div>
  );
}
