// ============================================================
// Rapport d'audit — RUBRIQUE EL TAALOUM (كنز العلوم / Kunz El Ouloum)
// Application de révision SVT — Baccalauréat algérien 3AS
// Source auditée : github.com/sinamind414/kunz-el-ouloum (commit 2026-11-13)
// ============================================================

export type Priorite = "haute" | "moyenne" | "basse";

export interface Recommandation {
  id: string;
  priorite: Priorite;
  axe: number;
  titre: string;
  detail: string;
  chiffrage: string;
}

export interface Axe {
  id: number;
  nom: string;
  note: number; // /10
  poids: number; // %
  resume: string;
  constat: string[];
  pointsForts: string[];
  pointsFaibles: string[];
  nonVerifiable: string[];
}

export const META = {
  titre: "Audit de RUBRIQUE EL TAALOUM",
  sousTitre: "Application de révision SVT — Baccalauréat algérien, filière 3AS Sciences expérimentales (كنز العلوم — Kunz El Ouloum)",
  date: "Audit réalisé sur le dépôt cloné au commit du 13 novembre 2026",
  source: "https://github.com/sinamind414/kunz-el-ouloum.git",
  questionCentrale:
    "L'application contient une masse de données (cours, schémas, exercices, sujets Bac). La question centrale de cet audit : comment l'élève algérien moyen assimile-t-il cette richesse sans être submergé ?",
  methode: [
    "Clonage du dépôt public et lecture directe du code source (≈ 40 fichiers clés lus : src/data/curriculumOfficial.ts, bacSessionIndex.ts, prioritesBac.ts, positionnementInitial.ts, revisionPlan.ts, expressJ7.ts, src/lib/sm2.ts, quizAdaptatif.ts, public/sw.js, store/README.md, README.md, android/, package.json…).",
    "Comptages et greps sur les fichiers réels (nombre de leçons, de QCM, de sessions BAC, de budgets de bundle, de tests documentés).",
    "Distinction systématique entre [CONSTAT] (vérifié dans le code), [INTERPRÉTATION] (lecture pédagogique) et « Non vérifiable » (absent du dépôt, jamais supposé).",
    "Grille d'évaluation : les 8 axes du cahier des charges, avec pondération de l'Axe 3 (Assimilation) à 18 %.",
  ],
};

export const AXES: Axe[] = [
  {
    id: 1,
    nom: "Conformité pédagogique au programme officiel",
    note: 8.5,
    poids: 15,
    resume:
      "Les 11 unités / 3 domaines du programme 3AS « علوم تجريبية » sont encodés depuis les sources ministérielles officielles (التدرج السنوي 2017 + دليل الأستاذ 2017), avec volumes horaires, fenêtres trimestrielles et compétences ; les contenus non exigibles sont explicitement écartés — mais la dernière version 2026 en vigueur n'est pas vérifiable dans le dépôt.",
    constat: [
      "[CONSTAT] curriculumOfficial.ts encode PROGRESSION_OFFICIELLE : 11 unités réparties en 3 domaines — Domaine 1 « التخصص الوظيفي للبروتينات » (U1 تركيب البروتين, U2 Relation structure/fonction, U3 النشاط الإنزيمي, U4 الدفاع عن الذات = immunologie, U5 الاتصال العصبي), Domaine 2 « التحولات الطاقوية » (U6 photosynthèse, U7 respiration/ATP, U8 écologie cellulaire), Domaine 3 « التكتونية العامة » (U9 plaques, U10 structure du globe, U11 tectonique et structures géologiques) — avec heures officielles (8h/2 sem pour U1 … 13h pour U11), fenêtres mensuelles et compétences de base, sourcées L5/L6 (juin 2017).",
      "[CONSTAT] NON_EXIGIBLES écarte explicitement du Bac : المتمم (complément C3b), مبدأ الأسيلوسكوب (oscilloscope), نضج الـ ARNm — conformément à la règle L5 p.6 « يمتحن التلميذ على ما جاء في المنهاج وليس على le manuel ». CULTURE_GENERALE signale par un bandeau les chapitres « culture générale » (ex. الموارد البترولية) exclus des statistiques d'exigibilité.",
      "[CONSTAT] Le format d'examen est conforme au réel : barème 5/7/8 points, durée 4 h 30 (270 min) prouvée par l'en-tête des PDF officiels embarqués (« المدة: 04 سا ونصف », vérifiée sur 9 sessions), 2 sujets au choix. La session 2016, de barème différent (6/5/9), est documentée comme telle.",
      "[CONSTAT] La terminologie est celle du manuel officiel algérien (vocabulaire arabe du livre 3AS, verbes d'action الأفعال الإدائية, termes scientifiques latins : ADN, ATP, ARNm, CMH, pH). La progression suit la séquence officielle (OFFICIAL_PROGRAM_SEQUENCE), du concret vers l'abstrait, unité par unité.",
      "[CONSTAT] Honnêteté scientifique documentée : le fichier source L5 est un OCR bruité (15/42 sous-chaînes exactes) — l'équipe l'a figé et marqué « à re-vérifier » au lieu de prétendre un mot-à-mot ; la lacune 2021 sujet 2 exercice 1 (illisible) est déclarée dans INCOMPLETE_SUJETS.",
      "[INTERPRÉTATION] La grille suppose deux séries « SVT » et « EXP » : dans le système algérien actuel, la filière 3AS Sciences expérimentales EST la filière du Bac SVT (coef. majeur) ; l'absence de sélecteur de filière n'est donc pas une lacune de couverture. En revanche, aucun contenu « SVT renforcé » type ancienne série EXP n'existe — non pertinent pour le Bac actuel.",
      "« Non vérifiable » : la dernière circulaire ministérielle 2026 modifiant le programme (les sources internes datent de 2017, qui reste la référence en vigueur connue).",
    ],
    pointsForts: [
      "Alignement unité par unité sur le programme officiel avec heures, fenêtres et compétences — pas un sommaire du manuel.",
      "Exclusion explicite et testée des contenus non exigibles (المتمم، الأسيلوسكوب, نضج ARNm) : l'élève ne révise pas hors-programme.",
      "Format Bac conforme au réel : 5/7/8 pts, 4 h 30, 2 sujets au choix, barème 2016 documenté comme atypique.",
      "Traçabilité et anti-hallucination : chaque chiffre est verrouillé par un test *.lock.test.ts ; les lacunes sont déclarées, pas cachées.",
    ],
    pointsFaibles: [
      "Aucune preuve d'alignement avec une circulaire post-2017 : « dernière version en vigueur — Non vérifiable » depuis le dépôt.",
      "La source L5 est un OCR bruité partiellement fiable (13 citations < 85 % à réviser).",
      "Une lacune factuelle connue : exercice 1 du sujet 2 de la session 2021 absent (illisible dans la source).",
    ],
    nonVerifiable: ["Circulaire ministérielle 2026 modifiant le programme 3AS", "Correspondance exacte avec le manuel 3AS édition 2026"],
  },
  {
    id: 2,
    nom: "Richesse, qualité et hiérarchisation des contenus",
    note: 8.0,
    poids: 12,
    resume:
      "Corpus dense et sourcé (25 leçons HTML + leçons actives, 24 micro-capsules, 17 drills de schémas, 23 situations, 11 cartes mentales, 121 textes à trous, 531 QCM servis, résumés « objectif + 4-6 points + terme-clé Bac »), avec priorités 🔴🟡🟢 calculées sur 65 idées BAC réelles — mais pas de glossaire bilingue FR/AR ni de vidéos, et les leçons longues restent d'un seul tenant.",
    constat: [
      "[CONSTAT] Volumes verrouillés par volumeCorpus.lock.test.ts (convention : on compte l'export servi) : 121 textes à trous, 69 drills de schéma, 31 micro-remédiations, 10 types d'erreurs, 16 concepts à rappel espacé, 41 QCM du livre + ~531 QCM du corpus éclatés en 6 segments par domaine (quizCorpus/qcm0…qcm5).",
      "[CONSTAT] 25 leçons HTML officielles (public/lessons, phases 1-22 = 44 chapitres) + 12 leçons actives TS + 24 micro-capsules + 23 situations d'évaluation + 11 cartes mentales + 112 SVG scientifiques ; chaque leçon active affiche un objectif 🎯 et une durée ⏱️, et chaque leçon se termine par une carte « 📝 خلاصة الدرس » = objectif en 1 phrase + 4-6 points + terme-clé Bac (resumesLecons.ts, ancré lexicalement dans le livre officiel, vérifié mécaniquement).",
      "[CONSTAT] Hiérarchisation réelle ajoutée (prioritesBac.ts) : étiquettes 🔴 Indispensable / 🟡 Important / 🟢 Complémentaire calculées pour les 11/11 unités à partir de unitPressure() sur les 65 idées BAC indexées (rangs 3/4/4), avec partPourCent dérivée mesurée — le module précise honnêtement que c'est un classement relatif, « Non vérifiable » comme pondération officielle du ministère.",
      "[CONSTAT] Poids de chaque unité à l'examen affiché en double mesure : poids annoncé du programme (unitOpenings.bacWeightPercent) ET pression constatée sur les sessions dépouillées (observedUnitSharePercent) — l'écart U6+U7 (39 % annoncés vs ~13 % constatés) est documenté et les deux mesures sont moyennées plutôt que cachées.",
      "[CONSTAT] L'ancien piège des 🔴🟡🟢 de lessonIndex.ts (couleurs de légendes de schémas, 17/1/49) est documenté : ce ne sont PAS des priorités — le module de priorités ne s'en sert pas.",
      "[INTERPRÉTATION] Chunking partiel : micro-capsules et micro-leçons existent (MicroLeconsPanel, MicroCapsulePanel), mais les 25 leçons HTML restent des pages longues d'un seul tenant (20-25 min), pas découpées en micro-leçons de 5-10 min avec ancres.",
      "[CONSTAT] Pas de glossaire bilingue FR/AR : l'app est 100 % arabe RTL, les termes scientifiques restent latins (ADN, ATP, LTc, HbS…). Pas de vidéos ; des animations SVG et simulateurs (électrophorèse) à la place.",
    ],
    pointsForts: [
      "Priorités 🔴🟡🟢 mesurées (pas déclarées) et poids BAC par unité affiché en % — l'élève distingue l'essentiel du secondaire.",
      "Fiches « ce qu'il faut retenir » systématiques (objectif + points + terme-clé), ancrées lexicalement dans le livre officiel.",
      "Richesse multimodale : schémas annotés, drills interactifs, cartes mentales, textes à trous, situations contextualisées.",
      "Convention de comptage verrouillée (export servi, jamais le brut) : les chiffres publiés sont reproductibles.",
    ],
    pointsFaibles: [
      "Leçons longues non découpées en micro-leçons de 5-10 min (chunking incomplet au niveau des leçons HTML).",
      "Glossaire élève = recherche par mot dans la bulle du Capitaine, mais pas de glossaire FR/AR structuré (~200 termes scientifiques).",
      "Pas de vidéos ; les animations sont des SVG/simulateurs (léger, offline, mais moins immersif).",
      "Poids « officiel » du ministère non vérifiable : seuls des poids mesurés/relatifs sont affichés (honnête, mais relatif).",
    ],
    nonVerifiable: ["Pondération officielle du ministère par unité (%)", "Qualité perçue des images par les élèves (pas de test utilisateur dans le dépôt)"],
  },
  {
    id: 3,
    nom: "Parcours d'apprentissage et stratégies d'assimilation ⭐",
    note: 8.5,
    poids: 18,
    resume:
      "L'app transforme sa richesse en parcours guidé : test de positionnement initial (18 items → 3 profils + objectif de note 10/14/18), chemin linéaire avec jalons par unité, plan de révision compte à rebours aligné sur la date du Bac + mode « Révision Express J-7 », SRS SM-2 intégré avec remédiation ciblée automatique — il manque surtout un calendrier long terme type « 12 semaines » de septembre à mai.",
    constat: [
      "[CONSTAT] Diagnostic initial : banque P0-3 de 18 items piochés dans les 531 QCM du corpus (pondération par poids BAC mesuré), un seul store (kunz_positionnement_v1) ; score → note estimée /20 + 3 profils (bases / consolidation / approfondissement) + objectif de note choisi (10 / 14 / 18) + orientation vers la rubrique adaptée (cours / entraînement / révision) — positionnemementInitial.ts + positionnementBanque.ts.",
      "[CONSTAT] Parcours guidé : PARCOURS_FLAT (83 items) dérivé automatiquement de la séquence officielle — chaque item est une leçon existante ou le « جسر » (QCM bilan) de fin d'unité ; progression avec jalons et unités verrouillées jusqu'à complétion (parcoursProgress.ts). L'accueil affiche « voici ta journée » (DailyGoalWidget + réglage partagé planSettings.ts : jours restants 1-60, minutes/jour 20-240).",
      "[CONSTAT] Calendrier aligné sur le Bac : BAC_EXAM_DATE = 2027-06-08, explicitement marquée PROVISOIRE avec bandeau visible (BAC_EXAM_DATE_IS_PROVISIONAL), bacDaysLeft() calcule le compte à rebours ; revisionPlan.ts ordonne le corpus existant sur le temps restant selon 4 règles testées (poids examen × difficulté ressentie, alternance des gestes, rédaction programmée, 2 derniers jours = consolidation uniquement).",
      "[CONSTAT] Mode urgence : expressJ7.ts = 7 séances de 25 min (2 leçons 🔴 + 1 quiz par jour), zéro contenu inventé (leçons réelles du parcours, unités pondérées). Deux modes coexistent donc bien : compte à rebours long + Express J-7.",
      "[CONSTAT] Lutte contre la surcharge : 4 rubriques principales seulement (au lieu de ~25 onglets), liens profonds (?lecon/?qcm/?examen/?idee), lazy loading des vues, progressive disclosure.",
      "[CONSTAT] Mémorisation : SM-2 implémenté (src/lib/sm2.ts), 16 concepts à rappel espacé, rappels programmés (planificationRappels.ts, PanneauSrs.tsx, spacedRecallPromptsAuto.ts), rappels intelligents (SmartReminderCard) + push optionnel (PushOptIn + web-push côté serveur optionnel). Micro-remédiations ciblées après erreur (31, dont 11 rappels espacés programmés automatiquement).",
      "[CONSTAT] Révisions croisées : quizAdaptatif.ts choisit dans un pool INTER-UNITÉS (les paliers 1/2/3 sont corrélés aux domaines) et ajuste la difficulté en temps réel (2 réussites → palier +1).",
      "[CONSTAT] Métacognition : profil d'erreurs (profilErreurs.ts) + taxonomie de 10 confusions + auto-déclaration honnête de la cause (T1-T4, diagnosticQuiz.ts — « inventer serait pire que ne pas savoir ») ; coach « Capitaine » avec prescriptions traçables (suivie/ignorée/expirée, un motif qui échoue 3× cesse d'être répété) ; atelier méthodologique (rédaction de réponses type Bac, analyse de documents, contrats de verbes) + estimation de note « تقديري » avant correction humaine.",
      "[INTERPRÉTATION] Il n'existe pas de « programme de révision sur 12 semaines » préréglé de septembre à mai : le plan est un compte à rebours paramétrable (jours restants saisis par l'élève). C'est flexible, mais moins guidant pour un élève de septembre qui voudrait un calendrier scolaire.",
    ],
    pointsForts: [
      "Positionnement initial réel + 3 profils + objectif de note (10/14/18) : le parcours s'adapte au niveau ET au but visé.",
      "Plan compte à rebours intelligent (poids × difficulté ressentie, alternance des gestes, rien de nouveau les 2 derniers jours) + mode Express J-7.",
      "SRS SM-2 non optionnel : rappels espacés automatiques + remédiation ciblée après chaque erreur + réactivation des notions faibles.",
      "Métacognition poussée : l'élève voit SES lacunes par unité, déclare la cause de ses erreurs, s'entraîne à la rédaction avec estimation de note.",
    ],
    pointsFaibles: [
      "Pas de calendrier long terme « 12 semaines » aligné sur la rentrée (septembre→mai) ; le plan démarre d'un nombre de jours saisi manuellement.",
      "Date du Bac provisoire (2027-06-08) — affichée comme telle, mais à confirmer chaque année.",
      "Les rappels push de qualité nécessitent le serveur optionnel ; en mode invité pur, ils restent locaux (moins fiables sur mobile).",
      "Quiz adaptatif = réordonnancement de paliers existants, pas un vrai modèle psychométrique (documenté comme « Non vérifiable »).",
    ],
    nonVerifiable: ["Efficacité réelle du SRS mesurée sur des cohortes d'élèves (courbe d'oubli personnelle réelle)", "Validité psychométrique des seuils de profils (7/18, 14/18)"],
  },
  {
    id: 4,
    nom: "Module d'exercices et de tests",
    note: 8.0,
    poids: 12,
    resume:
      "531 QCM étiquetés en 3 niveaux avec explications et schémas, quiz adaptatif, 121 textes à trous, 69 drills de schémas, 23 situations d'évaluation, analyses de documents ; corrigés au barème officiel 5/7/8 avec attendus du jury et boucle erreur→remédiation→rappel espacé câblée ; le correcteur automatique de copies reste un plancher calibré sur 40 copies.",
    constat: [
      "[CONSTAT] Types présents : QCM (531, avec explication et schéma par question), textes à trous (121), drills de schéma à légender/reproduire (69), analyses de documents (documentAnalysisExercises.ts + typologie), situations d'évaluation (23 cartes situationIndex.ts), QCM bilan par unité (« حصيلة الوحدة » = jalon du parcours), exercices réels du Bac indexés par session.",
      "[CONSTAT] Niveaux de difficulté : 3 paliers étiquetés (LIBELLES_DIFFICULTE), quiz adaptatif qui monte/descend en temps réel ; pièges classiques du Bac présents via les verbes de consigne officiels (verbDemands.ts, 10 contrats de verbes).",
      "[CONSTAT] Corrigés type Bac : barème officiel 5/7/8, attendus obligatoires du jury (dictionnaireCorrecteur.ts, attendusBac2025.ts avec sous-chaînes verbatim du corrigé officiel, corrigés type jury pour 2023-2025), réponses alternatives acceptées via les « formes de reconnaissance ».",
      "[CONSTAT] Auto-correcteur de productions écrites (« Miftah ») : note contre les attendus par question (jamais contre une unité), note « تقديري » (estimation) affichée avant/avec la correction humaine qui reste le référentiel ; calibré sur 40 copies eleve_*.txt — le dépôt précise honnêtement que tout écart publié là-dessus est un plancher, pas une validation indépendante.",
      "[CONSTAT] Boucle d'apprentissage fermée : erreur → micro-remédiation ciblée (CarteMicroRemediation) → rappel espacé SM-2 programmé → retest. Score/notation intégrés partout (note /20, XP).",
      "[INTERPRÉTATION] Les « questions ouvertes rédactionnelles » sont servies via l'atelier méthodologique et le correcteur par attendus, mais il manque un vrai corpus de Vrai/Faux avec justification obligatoire et de QO libres notées automatiquement à grande échelle.",
    ],
    pointsForts: [
      "Volume et variété : 531 QCM + 121 textes à trous + 69 drills + 23 situations + analyses de documents, tous sourcés.",
      "Corrigés au barème officiel avec attendus du jury traçables (sous-chaînes verbatim du corrigé officiel 2025).",
      "Boucle complète erreur → remédiation → rappel espacé → retest, réellement câblée (pas des modules isolés).",
      "3 niveaux de difficulté affichés + quiz adaptatif inter-unités.",
    ],
    pointsFaibles: [
      "Correcteur auto de copies calibré sur 40 copies seulement : plancher, pas validation indépendante ; la correction humaine reste le référentiel.",
      "Peu de Vrai/Faux avec justification ; les QO libres dépendent des attendus (moins de liberté de formulation reconnue).",
      "Barème type jury complet seulement pour 2023-2025 (2016 atypique documenté).",
    ],
    nonVerifiable: ["Taux de faux positifs/négatifs du correcteur Miftah sur des copies réelles inconnues"],
  },
  {
    id: 5,
    nom: "Banque de sujets Bac + simulation",
    note: 7.0,
    poids: 10,
    resume:
      "11 sessions 2016→2026 indexées (65 idées d'exercices réels avec barème, supports, notion et verbes), 28 PDF officiels embarqués (2013-2026), 4 sujets blancs et un simulateur chronométré 4 h 30 avec phases — mais un seul énoncé intégral (2025) pour cause de droits d'auteur, les sessions de rattrapage ne sont pas indexées et une lacune 2021 est déclarée.",
    constat: [
      "[CONSTAT] Annuaire : bacSessionIndex.ts couvre 2016→2026 sans trou (MISSING_YEARS vide), incluant la session de septembre 2020 (COVID) ; 65 BAC_IDEAS décrivent chacun un exercice réellement tombé (id bac2019_s1_e3, barème 5/7/8, supports fournis, notion évaluée, verbes de consigne), chaque entrée sourcée URL (ONEC republié via eddirasa/dzexams) — sans recopier les énoncés ni les valeurs numériques (droit d'auteur).",
      "[CONSTAT] PDF officiels embarqués : public/bac-sujets/2013…2026 = 28 fichiers (sujets + corrigés officiels), servis offline.",
      "[CONSTAT] Sujets blancs : 4 sujets écrits à la main (sujetsBlancs/sujetBlanc1…4.ts) + générateur déterministe (mockExam.ts) qui compose un sujet 5/7/8 à partir de 59 vrais exercices de 10 sessions, 3 unités porteuses distinctes, 3 sessions distinctes, même numéro = même sujet (un prof peut dire « faites le sujet 7 »).",
      "[CONSTAT] Simulation en conditions réelles : MockExamPanel chronométré 270 min avec phases et budget par exercice affiché (« يُفترض أن تكون في التمرين X »), session persistée et reprise sur l'horloge, remise forcée, barre de progression ; le corrigé (BacCorrectionPanel) est séparé et le panneau de transparence par session affiche les stats (BacTypeStats).",
      "[CONSTAT] Entraînement ciblé : par unité (QCM bilan), par situation, par geste (schéma), par notion (capsule), par session/année (BacIdeasView « أفكار التمارين »).",
      "[CONSTAT] Limites déclarées : énoncés intégraux ONEC non reproduits (droit d'auteur) — seul le sujet 2025 complet sert de référence de format ; 2021 S2 E1 illisible (INCOMPLETE_SUJETS, total 15 pts au lieu de 20) ; sessions de rattrapage (septembre) autres que 2020 non indexées ; le corpus ne prétend pas reproduire les sujets officiels mot à mot.",
      "« Non vérifiable » : statistiques de réussite nationales par type de sujet (les stats disponibles sont personnelles, par type d'exercice).",
    ],
    pointsForts: [
      "11 sessions sans trou + 65 exercices réels indexés (année/sujet/rang/barème/notion/verbes) + sources URL traçables.",
      "Simulateur chronométré fidèle (4 h 30, phases, budget par exercice, persistance) + 4 sujets blancs + générateur déterministe.",
      "PDF officiels embarqués et lisibles offline (28 fichiers, 2013-2026).",
      "Honnêteté sur les limites : lacunes déclarées, barème 2016 atypique documenté, droit d'auteur assumé.",
    ],
    pointsFaibles: [
      "Un seul énoncé intégral (2025) : l'élève s'entraîne mostly sur des « idées » reconstituées, pas sur la copie complète ONEC (mise en page, documents numériques à recopier).",
      "Sessions de rattrapage (septembre) non indexées hormis 2020.",
      "Lacune 2021 sujet 2 exercice 1.",
      "Pas de stats de réussite agrégées par type de sujet au niveau national.",
    ],
    nonVerifiable: ["Correspondance des PDF embarqués avec les dernières rééditions ONEC", "Taux de réussite des élèves par type de sujet (données nationales)"],
  },
  {
    id: 6,
    nom: "UX/UI et ergonomie cognitive",
    note: 8.0,
    poids: 10,
    resume:
      "PWA 100 % arabe RTL, hors ligne complet (service worker avec précache versionné), mode sombre persistant, 3 tailles de texte, recherche plein texte, favoris, navigation réduite à 4 rubriques + liens profonds, entrée ~600 Ko avec budgets de bundle testés et Android natif (Capacitor) — iOS absent (PWA seule) et le dossier public pèse 101 Mo (PDF BAC).",
    constat: [
      "[CONSTAT] Design : 4 rubriques principales (cours / entraînement / révision / profil), mémorisation du dernier onglet, liens profonds (?lecon/?qcm/?examen/?idee), role=tablist, header fixe avec safe-area (PWA installée). Couleurs cohérentes (vert #006d37 identité + code 🔴🟡🟢 stable).",
      "[CONSTAT] Recherche plein texte : SearchView réutilise le moteur de retrieval du tuteur (searchAllBases) indexant leçons + opuscules + QCM. Favoris : src/utils/favorites.ts avec tests.",
      "[CONSTAT] Ergonomie cognitive : mode sombre persistant (localStorage 'theme', classe dark sur <html>), 3 tailles de texte (bouton أ / أ+ / أ++, cran 1-3), texte aéré, leçons avec objectifs 🎯 et durées ⏱️, progressive disclosure (vues lazy : React.lazy sur 21 vues).",
      "[CONSTAT] Performance : budgets testés en CI (bundleBudget.test.ts) — entrée passée de 3 968 Ko à ~599-700 Ko, plafond chunk à la demande 800 Ko ; corpus SVT en chunk dédié 154,4 Ko + 6 segments QCM (237/123/152/27/8/1 Ko) ; service worker sw.js avec précache versionné par hash de build, stale-while-revalidate, 3G-aware, cleanup des anciens caches ; manifest.json PWA standalone RTL.",
      "[CONSTAT] Hors ligne : fonctionnement 100 % offline en mode invité (serveur optionnel) ; précache complet verrouillé (swPrecacheComplet.test.ts).",
      "[CONSTAT] Plateformes : Android natif via Capacitor 8 (dossier android/ + store/ avec assetlinks.json, fiche-play.json, data-safety.md pour TWA) ; aucune dépendance @capacitor/ios et aucun dossier ios → iOS uniquement via PWA web.",
      "[CONSTAT] Langue : 100 % arabe RTL (index.html lang=ar dir=rtl, manifest dir=rtl) ; les termes scientifiques restent en latin (ADN, ATP…). Pas d'interface française.",
      "[INTERPRÉTATION] Poids total : public/ = 101 Mo (dont 28 PDF BAC + images/SVG) — le précache complet signifie qu'une première visite télécharge beaucoup ; sur un smartphone à 8-16 Go de stockage libre c'est supportable, mais ce n'est pas « < 50 Mo ». La PWA elle-même (entrée) est légère (~600 Ko).",
      "« Non vérifiable » : temps de chargement réel < 2 s sur 3G algérienne et sur Redmi/Samsung A-series (RAM ≤ 2 Go) — seuls des budgets de bundle sont testés, pas de mesures terrain.",
    ],
    pointsForts: [
      "Offline-first réel et prouvé (SW versionné, précache testé, mode invité sans serveur ni compte).",
      "Ergonomie cognitive : 4 rubriques, dark mode, 3 tailles de texte, recherche plein texte, favoris, liens profonds — < 3 clics pour l'essentiel.",
      "Budgets de performance appliqués par la CI (entrée ~600 Ko, chunks ≤ 800 Ko, lazy loading).",
      "RTL arabe natif, PWA installable + projet Android Capacitor prêt.",
    ],
    pointsFaibles: [
      "Pas de version iOS native (PWA web uniquement sur iPhone).",
      "100 % arabe, zéro interface française ni glossaire FR/AR — handicap pour les élèves du bilingue.",
      "101 Mo de assets publics (PDF) : le premier téléchargement offline est lourd pour les petits stockages.",
      "Pas de mesure terrain de perf sur smartphones bas de gamme (budgets seulement).",
    ],
    nonVerifiable: ["Temps de chargement mesuré sur 3G réelle / Redmi entrée de gamme", "Poids de l'APK Android final", "Taille réelle du cache offline après précache complet"],
  },
  {
    id: 7,
    nom: "Fonctionnalités interactives et engagement",
    note: 7.5,
    poids: 13,
    resume:
      "Flashcards SM-2, drills de schémas interactifs, simulateurs (électrophorèse), défis « combat » validés par des enseignants, badges/XP/streaks, défis quotidiens, stats fines par compétence avec courbes, tuteur local déterministe « Morchid » + glossaire du Capitaine — boucle Apprendre→Tester→Erreur→Remédier→Retester fermée ; mais pas de forum ni de classement entre élèves.",
    constat: [
      "[CONSTAT] Révision active : flashcards (cartesHosila/hosila) avec répétition espacée SM-2, textes à trous interactifs, drills de schéma (SchemaDrillView : légender/reproduire), simulateur d'électrophorèse, animations scientifiques (AnimationsView, ScienceAnimations), cartes mentales interactives (MindMap/).",
      "[CONSTAT] Gamification : badges + XP + niveaux (BadgesView, RappelBadge), streaks (série de jours), défi quotidien + missions journalières du tuteur (getDailyMission), défis « combat » chronométrés (CombatTrainerView, CombatChallengePortal) dont les énoncés sont « مدقق ومصادق عليه من طرف أساتذة المادة » et conformes au barème officiel ; partage du score par lien externe (texte pré-rempli).",
      "[CONSTAT] Intelligence adaptative : quiz adaptatif 3 paliers, profil d'erreurs automatique + auto-déclaration T1-T4, coach Capitaine à prescriptions traçables, rappels intelligents (SmartReminderCard, planificationRappels), stats détaillées : DashboardView, BacTypeStats (par type d'exercice BAC), MethodologyGlobalStats, courbes d'évolution (recharts).",
      "[CONSTAT] Assistant : AITutorView « Morchid » = moteur déterministe 100 % local (smartTutorEngine, bases préchargées useBasesTuteur) — zéro hallucination, fonctionne offline, avec entrée contextuelle (« اشرح لي هذه الوحدة », « لماذا إجابتي خاطئة؟ ») ; + glossaire du Capitaine (chercherMot par mot). Ce n'est PAS un LLM : pas de génération libre, donc pas de réponse hors programme.",
      "[CONSTAT] Boucle complète : Apprendre (leçons/capsules) → Tester (QCM/quiz/situations) → Identifier l'erreur (profil + taxonomie) → Remédier (micro-remédiation ciblée) → Rappel espacé (SM-2) → Retester — câblée de bout en bout, pas des îlots.",
      "[CONSTAT] Absence constatée : aucun forum / chat entre élèves dans src/ ; aucun classement (leaderboard) national ou entre amis trouvé — seuls des badges locaux et le partage de score par lien.",
    ],
    pointsForts: [
      "Boucle d'apprentissage complète et câblée (apprendre → tester → erreur identifiée → remédiation → rappel → retest).",
      "Gamification sobre : XP, badges, streaks, défis quotidiens, défis combat validés par des enseignants et conformes au barème.",
      "Tuteur local déterministe (pas de LLM) : réponses traçables, offline, sans hallucination — un choix de fiabilité adapté au Bac.",
      "Stats fines par chapitre/compétence/type de question avec identification automatique des points faibles.",
    ],
    pointsFaibles: [
      "Pas de communauté : ni forum, ni classement entre élèves (amis/classe/national), ni défis PvP réels — l'engagement social est externe (lien partagé).",
      "Le tuteur n'est pas génératif (pas d'IA générative) : il ne répond pas à n'importe quelle question hors bases indexées.",
      "Notifications de révision : push serveur optionnel ; en mode invité pur, rappels locaux uniquement.",
    ],
    nonVerifiable: ["Taux d'engagement réel (DAU, rétention J7/J30) — aucune analytics dans le dépôt (volontairement, vie privée)"],
  },
  {
    id: 8,
    nom: "Fiabilité technique et accessibilité économique",
    note: 8.0,
    poids: 10,
    resume:
      "3 465 tests vitest + 3 408 tests jest documentés verts, CI GitHub, lint 0 erreur/0 warning exigé, build + tests post-build ; freemium assumé (domaine 1 gratuit sans pub, abonnement saison 1 200 DA via Baridimob), données 100 % locales en mode invité sans traqueurs, sauvegarde export/import + sync cloud optionnelle ; mais la publication Play Store est préparée et NON soumise, pas d'App Store, et l'historique de versions magasin est non vérifiable.",
    constat: [
      "[CONSTAT] Fiabilité : README documente 294 fichiers / 3 465 tests vitest + 286 suites / 3 408 tests jest verts (au 18/10/2026), tsc --noEmit + ESLint 9 avec 0 erreur ET 0 warning exigés, CI GitHub Actions (ci.yml), build production + suite post-build test:build (budgets, précache, JSON tuteur 562 chunks), Dockerfile + deploy/ (nginx, ecosystem PM2).",
      "[CONSTAT] Données : en mode invité, tout reste en localStorage, aucune requête, aucun identifiant, aucun traqueur tiers — vérifiable dans le code (prescriptions.ts, profilErreurs.ts, rappelAdaptatif.ts) ; politiqueConfidentialite.ts embarquée ; compte serveur optionnel (SQLite par défaut, PostgreSQL si DATABASE_URL, Supabase) avec export des errorTags vers le professeur documenté ; backup export/import (backup.ts) ; teacher-cli pour le suivi de classe.",
      "[CONSTAT] Modèle économique : freemium assumé et affiché — Domaine 1 (unités 1-5) gratuit, sans publicité ; accès complet (unités 6-11, banque BAC, examens) via abonnement saison de 1 200 DA (PRIX_SAISON_DA) payé par Baridimob (EcranPaiement.tsx), valable jusqu'au 30 juin. Zéro publicité, zéro traqueur, pas de compte obligatoire. 1 200 DA ≈ 6-8 €/saison : très accessible pour un budget étudiant algérien (100-500 DA/mois).",
      "[CONSTAT] Distribution : PWA déployable (Vercel, .vercelignore) + projet Android Capacitor 8 prêt (android/) + dossier store/ (fiche-play.json, assetlinks.json, data-safety.md) — mais store/README.md dit explicitement : « rien n'a été soumis » à la Play Console (l'agent n'a pas les accès). Aucun dossier iOS / @capacitor/ios.",
      "[CONSTAT] Mises à jour : commits fréquents et datés (dernier 2026-11-13 : convergence du test de positionnement), version 1.0.0-rc.1, changelog implicite dans les en-têtes de fichiers (sprints 1→56+). FAQ intégrée (FAQView), panneau d'aide, prof/élève documenté (docs/SERVEUR.md, teacher-cli).",
      "[CONSTAT] Multi-appareils : responsive téléphone/tablette ; synchronisation cloud UNIQUEMENT si compte serveur créé (sinon chaque appareil est indépendant, avec export/import manuel).",
      "« Non vérifiable » : stabilité terrain (crashes, perte de données) sur des milliers d'appareils ; note/avis/téléchargements Play Store & App Store (rien n'est publié) ; poids de l'APK ; RGPD au sens strict (politique embarquée oui, audit juridique non).",
    ],
    pointsForts: [
      "Discipline de test remarquable : double runner (vitest + jest), verrous (*.lock.test.ts) sur chaque chiffre publié, lint 0/0, CI, tests post-build.",
      "Vie privée exemplaire en mode invité : 100 % local, aucun traqueur, politique de confidentialité embarquée et vérifiable dans le code.",
      "Modèle économique honnête : gratuit utile (5 unités) sans pub, 1 200 DA/saison via Baridimob — adapté au budget algérien.",
      "Offline par défaut, serveur optionnel, export/import de sauvegarde, outil professeur (teacher-cli).",
    ],
    pointsFaibles: [
      "Non publié sur Play Store (préparé mais non soumis) : l'élève ne trouve pas l'app en magasin — blocage de distribution majeur ; pas d'App Store du tout.",
      "Pas de sync cloud en mode invité (progrès liés à l'appareil, sauf export manuel).",
      "Stabilité terrain et avis utilisateurs : non vérifiables (aucune publication, aucune analytics).",
    ],
    nonVerifiable: ["Note et avis sur Play Store / App Store", "Nombre de téléchargements", "Taux de crash en production", "Poids de l'APK", "Conformité RGPD auditée juridiquement"],
  },
];

export const SCORE_GLOBAL = (() => {
  const total = AXES.reduce((s, a) => s + a.note * a.poids, 0);
  return Math.round(total) / 10; // /10 → on rend /100
})();

export const POINTS_FORTS_TOP: { rang: number; titre: string; detail: string; axes: number[] }[] = [
  {
    rang: 1,
    titre: "Un vrai guidage anti-surcharge (la question centrale de l'audit)",
    detail:
      "Positionnement initial (18 items → 3 profils + objectif 10/14/18) → parcours linéaire à jalons (83 items dérivés du programme) → plan compte à rebours intelligent + mode Express J-7 → accueil « voici ta journée ». L'élève n'est jamais lâché devant une bibliothèque de 500 documents : 4 rubriques, liens profonds, progressive disclosure.",
    axes: [3, 6],
  },
  {
    rang: 2,
    titre: "Priorités et poids BAC mesurés, pas déclarés",
    detail:
      "🔴🟡🟢 calculés sur 11/11 unités à partir de unitPressure() sur 65 exercices réels tombés (2016-2026), avec % par unité affiché en double mesure (annoncé vs constaté) — l'app montre même l'écart U6+U7 (39 % vs 13 %).",
    axes: [2, 5],
  },
  {
    rang: 3,
    titre: "Boucle d'apprentissage fermée : erreur → remédiation → rappel espacé SM-2 → retest",
    detail:
      "31 micro-remédiations ciblées (dont 11 rappels espacés auto-programmés), taxonomie de 10 confusions, profil d'erreurs par unité, quiz adaptatif inter-unités. Les modules ne sont pas isolés : la boucle est câblée de bout en bout.",
    axes: [3, 4, 7],
  },
  {
    rang: 4,
    titre: "Offline-first 100 % + perf budgetée + vie privée par défaut",
    detail:
      "Service worker versionné avec précache testé, mode invité sans serveur ni compte, localStorage uniquement, zéro traqueur ; entrée ~600 Ko, chunks ≤ 800 Ko, budgets appliqués en CI ; PWA + Android Capacitor prêts.",
    axes: [6, 8],
  },
  {
    rang: 5,
    titre: "Honnêteté scientifique et traçabilité totale",
    detail:
      "Contenus non exigibles écartés explicitement (المتمم, الأسيلوسكوب), chapitres « culture générale » balisés, lacunes déclarées (2021 S2E1), barème 2016 atypique documenté, convention « export servi » verrouillée, chaque chiffre chiffrable rapproché d'un test lock.",
    axes: [1, 2, 8],
  },
];

export const POINTS_FAIBLES_TOP: { rang: number; titre: string; detail: string; gravite: string; axes: number[] }[] = [
  {
    rang: 1,
    titre: "Banque BAC sans énoncés intégraux (droit d'auteur) + rattrapages non indexés",
    detail:
      "Un seul sujet complet embarqué (2025) ; 10 sessions servies en « idées d'exercices » reconstituées (65 idées) ; sessions de septembre (rattrapage) non indexées hormis 2020 ; lacune 2021 S2E1. L'entraînement en conditions copie exacte reste incomplet.",
    gravite: "Élevée — l'entraînement final est le moment le plus critique",
    axes: [5],
  },
  {
    rang: 2,
    titre: "Distribution magasin inexistante : Play Store préparé mais NON soumis, pas d'iOS",
    detail:
      "store/README.md dit explicitement « rien n'a été soumis ». Sans fiche magasin, l'élève ne trouve pas l'app : avis, téléchargements, stabilité terrain = non vérifiables. iOS uniquement via PWA.",
    gravite: "Élevée — blocage de découverte pour le public cible",
    axes: [8, 6],
  },
  {
    rang: 3,
    titre: "100 % arabe, aucun glossaire FR/AR des termes scientifiques",
    detail:
      "L'enseignement SVT en Algérie est bilingue ; l'app n'affiche jamais la correspondance français↔arabe (ex. ADN ↔ الـ ADN…) hormis les termes latins. Un élève qui cherche un terme du manuel français ne le trouvera pas.",
    gravite: "Moyenne — friction quotidienne, surtout en début d'année",
    axes: [2, 6],
  },
  {
    rang: 4,
    titre: "Pas de communauté ni de classement entre élèves",
    detail:
      "Aucun forum, aucun leaderboard (amis/classe/national), aucun défi PvP réel — seulement badges locaux et partage de score par lien externe. L'engagement social, pourtant clé à J-30 du Bac, est absent.",
    gravite: "Moyenne — motivation et entraide perdues",
    axes: [7],
  },
  {
    rang: 5,
    titre: "Programme sourcé sur 2017, version 2026 non vérifiable ; plan sans calendrier long terme",
    detail:
      "Sources internes = L5/L6 juin 2017 (référence connue en vigueur, mais aucune circulaire postérieure embarquée) ; OCR bruité de L5. Côté parcours : pas de « programme 12 semaines » septembre→mai préréglé, seulement un compte à rebours à régler soi-même.",
    gravite: "Moyenne — risque de dérive réglementaire + guidage long terme perfectible",
    axes: [1, 3],
  },
];

export const RECOMMANDATIONS: Recommandation[] = [
  {
    id: "R1",
    priorite: "haute",
    axe: 5,
    titre: "Indexer toutes les sessions de rattrapage (septembre) et combler la lacune 2021",
    detail:
      "Ajouter les sessions de septembre 2016→2026 (hors 2020 déjà là) au même format que bacSessionIndex (idée + barème + notion + verbes + source URL), et récupérer l'exercice 1 du sujet 2 de 2021 depuis une source lisible.",
    chiffrage: "Objectif : 22 sessions indexées (11 principales + 11 rattrapage) ; 1 lacune à combler",
  },
  {
    id: "R2",
    priorite: "haute",
    axe: 5,
    titre: "Embarquer les énoncés intégraux via partenariat officiel (ONEC/éditeur) ou liens canoniques",
    detail:
      "Négocier une autorisation ONEC pour embarquer les sujets complets, ou à défaut un deep-link officiel par session + un mode « copie » qui reproduit fidèlement la mise en page (documents à recopier, numérotation des questions) à partir des 65 idées + PDF partagés légalement.",
    chiffrage: "Objectif : 11/11 énoncés intégraux ou liens officiels ; aujourd'hui 1/11",
  },
  {
    id: "R3",
    priorite: "haute",
    axe: 3,
    titre: "Ajouter un calendrier long terme « 12 semaines » préréglé sur la rentrée scolaire",
    detail:
      "En complément du compte à rebours manuel, proposer un plan automatique : sélection de la date de début (ex. 1er septembre) → génération d'un programme semaine par semaine couvrant les 11 unités selon leurs fenêtres officielles (curriculumOfficial.fenetre), avec 2 leçons + 1 quiz par jour.",
    chiffrage: "1 nouvel écran + moteur dérivé des fenêtres officielles existantes ; 12 semaines × 7 jours",
  },
  {
    id: "R4",
    priorite: "haute",
    axe: 2,
    titre: "Créer le glossaire bilingue FR/AR des termes scientifiques",
    detail:
      "Un composant glossaire (réutilisant chercherMot du Capitaine) avec ~200 entrées : terme arabe ↔ français ↔ latin (ex. «الشفرة الوراثية» ↔ « code génétique » ↔ genetic code ; ADN ↔ ADN ↔ DNA). Affiché dans chaque leçon sur les termes surlignés.",
    chiffrage: "~200 entrées à encoder, vérifiées une à une contre le manuel 3AS",
  },
  {
    id: "R5",
    priorite: "haute",
    axe: 8,
    titre: "Soumettre la fiche Play Store et lancer une bêta fermée de 100 élèves",
    detail:
      "Exécuter les étapes documentées dans store/README.md (fiche-play.json, assetlinks.json, data-safety déjà prêts), ouvrir une bêta fermée à ~100 terminales pour obtenir notes, avis, taux de crash réels et données de perf sur Redmi/Samsung A-series.",
    chiffrage: "100 bêta-testeurs ; objectif ≥ 4,2★ et 0 crash bloquant en 4 semaines",
  },
  {
    id: "R6",
    priorite: "moyenne",
    axe: 7,
    titre: "Ajouter un classement hebdomadaire optionnel et anonymisé (amis / classe / national)",
    detail:
      "Côté serveur (compte optionnel) : leaderboard hebdomadaire par XP ou streak, pseudonyme obligatoire, aucune donnée scolaire partagée. En mode invité : comparaison locale uniquement.",
    chiffrage: "1 écran + 1 table serveur ; opt-in RGPD explicite",
  },
  {
    id: "R7",
    priorite: "moyenne",
    axe: 7,
    titre: "Ouvrir une FAQ vivante / mini-forum modéré par le coach",
    detail:
      "Alimenter la FAQView avec les questions réellement posées au tuteur Morchid (fréquence des mots-clés), et permettre de poser une question à la communauté d'une classe (mode prof) avec validation par l'enseignant.",
    chiffrage: "Top 50 questions du tuteur publiées automatiquement chaque semaine",
  },
  {
    id: "R8",
    priorite: "moyenne",
    axe: 3,
    titre: "Rendre les rappels de révision 100 % locaux (fallback des notifications navigateur)",
    detail:
      "En mode invité sans serveur, utiliser l'API Notifications du navigateur (déjà partiellement là via PushOptIn) pour programmer les rappels SM-2 localement, afin que la courbe d'oubli soit respectée même hors ligne.",
    chiffrage: "Couverture des 16 concepts à rappel espacé + rappels de plan en local",
  },
  {
    id: "R9",
    priorite: "moyenne",
    axe: 2,
    titre: "Découper les 25 leçons HTML longues en micro-leçons de 5-10 min",
    detail:
      "Ajouter des ancres internes + sommaire par leçon dans HtmlLessonViewer, et une vue « micro-leçon suivante » qui enchaîne automatiquement (chunking) au lieu d'un défilement libre de 20-25 min.",
    chiffrage: "25 leçons à segmenter ; objectif ~4-6 segments par leçon",
  },
  {
    id: "R10",
    priorite: "moyenne",
    axe: 1,
    titre: "Re-vérifier le programme contre la dernière circulaire MEN et publier la source",
    detail:
      "Embarquer la circulaire 2025-2026 (ou 2026-2027) dans docs/sources/ et lancer un test de couverture unité par unité ; re-vérifier les 13 citations < 85 % de la source L5 (OCR bruité).",
    chiffrage: "11 unités à re-vérifier ; 13 citations L5 à corriger",
  },
  {
    id: "R11",
    priorite: "basse",
    axe: 6,
    titre: "Préparer le portage iOS (Capacitor iOS) ou un guide d'installation PWA pas à pas",
    detail:
      "Soit ajouter la plateforme iOS (1 commande Capacitor), soit un écran d'accueil guidant l'installation « Ajouter à l'écran d'accueil » sur iPhone avec captures.",
    chiffrage: "1 plateforme ou 1 écran tutoriel",
  },
  {
    id: "R12",
    priorite: "basse",
    axe: 4,
    titre: "Enrichir les types de questions : Vrai/Faux avec justification + plus de QO notées",
    detail:
      "Ajouter un type V/F-justifier (la justification obligatoire déclenche la micro-remédiation si fausse) et augmenter le pool d'attendus du correcteur Miftah pour couvrir plus de formulations acceptées.",
    chiffrage: "+100 items V/F-justifier ; +30 % d'attendus reconnus",
  },
  {
    id: "R13",
    priorite: "basse",
    axe: 7,
    titre: "Embarquer de courtes vidéos (3-5 min) des 10 montages BAC les plus rentables",
    detail:
      "Les 10 montages de bacArchetypes (7 exercices de sessions différentes traités par une seule méthode) se prêtent à des vidéos courtes, embarquées et servies offline (codec léger, < 5 Mo chacune).",
    chiffrage: "10 vidéos × 3-5 min, < 50 Mo au total, option de téléchargement à la demande",
  },
];

export const VERDICT = {
  pret: "Oui, avec réserves — recommandable aux élèves de Bac 3AS sciences expérimentales",
  resume:
      "Kunz El Ouloum est l'une des rares applications à avoir résolu la question centrale de cet audit : la richesse n'y noie pas l'élève, elle est ordonnée par un parcours guidé (positionnement → profils → jalons → plan compte à rebours → Express J-7) soutenu par une SRS SM-2 et une boucle d'erreur→remédiation réellement câblées. La conformité au programme officiel 3AS est documentée unité par unité, et l'honnêteté scientifique du dépôt (lacunes déclarées, verrous de tests, contenus non exigibles écartés) inspire confiance.",
  risquePrincipal:
      "Le risque principal n'est pas la surcharge cognitive (bien gérée) mais la distribution et l'entraînement final : l'app n'est publiée sur aucun magasin (Play Store préparé, non soumis) et sa banque BAC ne contient qu'un seul énoncé intégral (2025) — l'élève s'entraîne sur des reconstitutions d'idées, pas sur la copie ONEC exacte, et ne trouve pas l'app en cherchant « révision bac SVT ».",
  urgents: ["R1 + R2 — banque BAC complète (rattrapages + énoncés intégraux ou liens officiels)", "R5 — publication Play Store + bêta fermée de 100 élèves", "R3 — calendrier long terme « 12 semaines » en complément du compte à rebours"],
  confiance: 4, // sur 5 étoiles
  confianceTexte: "⭐⭐⭐⭐ — confiance élevée sur le code et le contenu (entièrement vérifiables), modérée sur la distribution et l'adoption réelle (non publiées, non mesurables).",
};

export const NON_VERIFIABLES_GLOBAUX = [
  "Dernière version ministérielle du programme en vigueur (sources internes = juin 2017)",
  "Date exacte du Bac 2027 (l'app affiche 2027-06-08, marquée « provisoire »)",
  "Publication Play Store / App Store, notes, avis, nombre de téléchargements (rien n'est soumis)",
  "Poids de l'APK Android et performances réelles sur smartphones bas de gamme (budgets de bundle testés, pas de mesures terrain)",
  "Stabilité en production (crashes) et courbe d'oubli réelle des élèves (pas d'analytics, choix vie privée assumé)",
  "Pondération officielle du ministère par unité (seuls des poids mesurés/relatifs sont affichés)",
  "Validité psychométrique des seuils de profils et du quiz adaptatif (documentés « Non vérifiable » par l'équipe elle-même)",
];
